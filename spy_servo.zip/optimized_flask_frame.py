from flask import Flask, render_template, request, jsonify, url_for, Response
from flask_cors import CORS
from flask_sock import Sock
import sqlite3
import datetime
import json
import os
import time
import numpy as np
import cv2
from queue import Queue, deque
from threading import Lock, Thread
import logging
from collections import deque
import asyncio
import threading

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)
sock = Sock(app)

# Global variables for ESP32-CAM frame management
esp32_frame_queue = Queue(maxsize=30)  # Increased buffer size
frame_buffer = deque(maxlen=60)  # Buffer for 60 frames (1 second at 60 FPS)
frame_lock = Lock()
latest_frame = None
frame_timestamps = deque(maxlen=60)
fps_counter = 0
last_fps_time = time.time()

# Active WebSocket connections list
clients = []

# Performance monitoring
performance_stats = {
    'fps': 0,
    'buffer_size': 0,
    'latency': 0,
    'dropped_frames': 0
}

def calculate_fps():
    """Calculate current FPS based on frame timestamps"""
    global performance_stats
    current_time = time.time()
    if len(frame_timestamps) > 1:
        time_diff = current_time - frame_timestamps[0]
        if time_diff > 0:
            performance_stats['fps'] = len(frame_timestamps) / time_diff
    performance_stats['buffer_size'] = len(frame_buffer)

def frame_processor():
    """Background thread for frame processing and buffering"""
    global latest_frame, frame_buffer, frame_timestamps, fps_counter, performance_stats
    while True:
        try:
            if not esp32_frame_queue.empty():
                frame = esp32_frame_queue.get()
                if frame is not None:
                    with frame_lock:
                        latest_frame = frame
                        frame_buffer.append(frame)
                        frame_timestamps.append(time.time())
                        calculate_fps()
                        
                        # Remove old frames if buffer is full
                        if len(frame_buffer) > 55:  # Keep buffer at 90% capacity
                            frame_buffer.popleft()
                            frame_timestamps.popleft()
                            performance_stats['dropped_frames'] += 1
            else:
                time.sleep(0.001)  # 1ms sleep to prevent busy waiting
        except Exception as e:
            logger.error(f"Error in frame processor: {e}")
            time.sleep(0.01)

# Start frame processor thread
frame_processor_thread = Thread(target=frame_processor, daemon=True)
frame_processor_thread.start()

@app.route('/esp32_frame')
def esp32_frame():
    """Single frame endpoint with optimized response"""
    global latest_frame
    with frame_lock:
        if latest_frame is None:
            return Response(status=503)
        
        # Optimize JPEG encoding
        encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 85]  # Reduced quality for speed
        ret, buffer = cv2.imencode('.jpg', latest_frame, encode_param)
        
        response = Response(buffer.tobytes(), mimetype='image/jpeg')
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
        return response

@app.route('/esp32_video_feed')
def esp32_video_feed():
    """Optimized video stream with frame buffering and intelligent delivery"""
    def generate():
        global frame_buffer, performance_stats
        last_frame_time = time.time()
        target_fps = 60
        frame_interval = 1.0 / target_fps
        
        while True:
            try:
                current_time = time.time()
                
                # Get frame from buffer if available
                frame_to_send = None
                with frame_lock:
                    if frame_buffer:
                        frame_to_send = frame_buffer.popleft()
                        if frame_timestamps:
                            frame_timestamps.popleft()
                
                if frame_to_send is not None:
                    # Optimize encoding for streaming
                    encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 80]
                    ret, buffer = cv2.imencode('.jpg', frame_to_send, encode_param)
                    frame_bytes = buffer.tobytes()
                    
                    # Calculate latency
                    performance_stats['latency'] = (time.time() - current_time) * 1000
                    
                    yield (b'--frame\r\n'
                           b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
                    
                    last_frame_time = current_time
                else:
                    # Send empty frame if no data available
                    yield (b'--frame\r\n'
                           b'Content-Type: image/jpeg\r\n\r\n' + b'\r\n')
                
                # Intelligent sleep based on target FPS
                sleep_time = max(0, frame_interval - (time.time() - current_time))
                if sleep_time > 0:
                    time.sleep(sleep_time)
                    
            except Exception as e:
                logger.error(f"Error in video feed: {e}")
                time.sleep(0.01)
    
    response = Response(generate(), mimetype='multipart/x-mixed-replace; boundary=frame')
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    return response

@app.route('/performance_stats')
def get_performance_stats():
    """Endpoint to get performance statistics"""
    return jsonify(performance_stats)

@sock.route('/ws')
def websocket(ws):
    """Optimized WebSocket handler with better error handling"""
    global latest_frame, clients
    clients.append(ws)
    logger.info(f"WebSocket client connected. Total clients: {len(clients)}")
    
    try:
        while True:
            data = ws.receive()
            if data is None:
                break
                
            try:
                # Handle binary data (frame from ESP32-CAM)
                if isinstance(data, bytes):
                    img = np.frombuffer(data, dtype=np.uint8)
                    frame = cv2.imdecode(img, cv2.IMREAD_COLOR)
                    
                    if frame is not None:
                        # Add frame to processing queue
                        if not esp32_frame_queue.full():
                            esp32_frame_queue.put(frame)
                        else:
                            # Drop oldest frame if queue is full
                            try:
                                esp32_frame_queue.get_nowait()
                                esp32_frame_queue.put(frame)
                            except:
                                pass
                                
            except Exception as e:
                logger.error(f"Error processing WebSocket message: {e}")
                
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
    finally:
        if ws in clients:
            clients.remove(ws)
        logger.info(f"WebSocket client disconnected. Total clients: {len(clients)}")

@app.route('/health')
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'fps': performance_stats['fps'],
        'buffer_size': performance_stats['buffer_size'],
        'clients': len(clients)
    })

if __name__ == '__main__':
    logger.info("Starting optimized Flask server...")
    app.run(host='0.0.0.0', port=3002, threaded=True, debug=False) 