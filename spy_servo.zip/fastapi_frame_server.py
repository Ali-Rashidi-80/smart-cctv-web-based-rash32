from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.responses import StreamingResponse, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import uvicorn
import asyncio
import cv2
import numpy as np
import time
import logging
from collections import deque
from typing import List, Optional
import json
from dataclasses import dataclass
from contextlib import asynccontextmanager

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Performance monitoring
@dataclass
class PerformanceStats:
    fps: float = 0.0
    buffer_size: int = 0
    latency: float = 0.0
    dropped_frames: int = 0
    total_frames: int = 0
    avg_frame_time: float = 0.0

# Global variables
frame_buffer = deque(maxlen=120)  # 2 seconds buffer at 60 FPS
frame_timestamps = deque(maxlen=120)
latest_frame: Optional[np.ndarray] = None
performance_stats = PerformanceStats()
active_connections: List[WebSocket] = []
frame_lock = asyncio.Lock()

# FastAPI app with lifespan management
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info("Starting FastAPI frame server...")
    yield
    # Shutdown
    logger.info("Shutting down FastAPI frame server...")

app = FastAPI(
    title="ESP32-CAM Frame Server",
    description="High-performance frame server with 60 FPS buffering",
    version="2.0.0",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def calculate_performance_stats():
    """Calculate real-time performance statistics"""
    global performance_stats
    
    current_time = time.time()
    if len(frame_timestamps) > 1:
        time_window = current_time - frame_timestamps[0]
        if time_window > 0:
            performance_stats.fps = len(frame_timestamps) / time_window
    
    performance_stats.buffer_size = len(frame_buffer)
    performance_stats.total_frames = len(frame_timestamps)
    
    if len(frame_timestamps) > 1:
        frame_times = [frame_timestamps[i] - frame_timestamps[i-1] 
                      for i in range(1, len(frame_timestamps))]
        performance_stats.avg_frame_time = sum(frame_times) / len(frame_times) * 1000

async def frame_processor():
    """Async frame processor for optimal performance"""
    global latest_frame, frame_buffer, frame_timestamps, performance_stats
    
    while True:
        try:
            await asyncio.sleep(0.001)  # 1ms sleep for async processing
            
            # Process frames in buffer
            if len(frame_buffer) > 100:  # Keep buffer at 80% capacity
                frame_buffer.popleft()
                if frame_timestamps:
                    frame_timestamps.popleft()
                performance_stats.dropped_frames += 1
            
            calculate_performance_stats()
            
        except Exception as e:
            logger.error(f"Error in frame processor: {e}")
            await asyncio.sleep(0.01)

@app.get("/")
async def root():
    """Root endpoint with server info"""
    return {
        "server": "FastAPI ESP32-CAM Frame Server",
        "version": "2.0.0",
        "endpoints": {
            "video_feed": "/esp32_video_feed",
            "single_frame": "/esp32_frame",
            "performance": "/performance_stats",
            "health": "/health"
        }
    }

@app.get("/esp32_frame")
async def get_single_frame():
    """Get single frame with optimized response"""
    global latest_frame
    
    if latest_frame is None:
        raise HTTPException(status_code=503, detail="No frame available")
    
    # Optimize JPEG encoding for speed
    encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 85]
    ret, buffer = cv2.imencode('.jpg', latest_frame, encode_param)
    
    return Response(
        content=buffer.tobytes(),
        media_type="image/jpeg",
        headers={
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Pragma": "no-cache",
            "Expires": "0"
        }
    )

@app.get("/esp32_video_feed")
async def video_feed():
    """High-performance video stream with intelligent frame delivery"""
    
    async def generate_frames():
        global frame_buffer, performance_stats
        
        target_fps = 60
        frame_interval = 1.0 / target_fps
        last_frame_time = time.time()
        
        while True:
            try:
                start_time = time.time()
                
                # Get frame from buffer
                frame_to_send = None
                async with frame_lock:
                    if frame_buffer:
                        frame_to_send = frame_buffer.popleft()
                        if frame_timestamps:
                            frame_timestamps.popleft()
                
                if frame_to_send is not None:
                    # Optimize encoding for streaming
                    encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 80]
                    ret, buffer = cv2.imencode('.jpg', frame_to_send, encode_param)
                    frame_bytes = buffer.tobytes()
                    
                    # Calculate processing latency
                    processing_time = time.time() - start_time
                    performance_stats.latency = processing_time * 1000
                    
                    yield (b'--frame\r\n'
                           b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
                    
                    last_frame_time = time.time()
                else:
                    # Send empty frame if buffer is empty
                    yield (b'--frame\r\n'
                           b'Content-Type: image/jpeg\r\n\r\n' + b'\r\n')
                
                # Intelligent sleep for target FPS
                elapsed = time.time() - start_time
                sleep_time = max(0, frame_interval - elapsed)
                if sleep_time > 0:
                    await asyncio.sleep(sleep_time)
                    
            except Exception as e:
                logger.error(f"Error in video feed: {e}")
                await asyncio.sleep(0.01)
    
    return StreamingResponse(
        generate_frames(),
        media_type="multipart/x-mixed-replace; boundary=frame",
        headers={
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Pragma": "no-cache",
            "Expires": "0"
        }
    )

@app.get("/performance_stats")
async def get_performance_stats():
    """Get real-time performance statistics"""
    return {
        "fps": round(performance_stats.fps, 2),
        "buffer_size": performance_stats.buffer_size,
        "latency_ms": round(performance_stats.latency, 2),
        "dropped_frames": performance_stats.dropped_frames,
        "total_frames": performance_stats.total_frames,
        "avg_frame_time_ms": round(performance_stats.avg_frame_time, 2),
        "active_connections": len(active_connections)
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "fps": round(performance_stats.fps, 2),
        "buffer_size": performance_stats.buffer_size,
        "active_connections": len(active_connections),
        "server_time": time.time()
    }

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """Optimized WebSocket handler for frame reception"""
    global latest_frame, frame_buffer, frame_timestamps, active_connections
    
    await websocket.accept()
    active_connections.append(websocket)
    logger.info(f"WebSocket client connected. Total clients: {len(active_connections)}")
    
    try:
        while True:
            # Receive data from ESP32-CAM
            data = await websocket.receive_bytes()
            
            try:
                # Process frame data
                img = np.frombuffer(data, dtype=np.uint8)
                frame = cv2.imdecode(img, cv2.IMREAD_COLOR)
                
                if frame is not None:
                    async with frame_lock:
                        latest_frame = frame
                        frame_buffer.append(frame)
                        frame_timestamps.append(time.time())
                        
                        # Maintain buffer size
                        if len(frame_buffer) > 110:  # Keep at 90% capacity
                            frame_buffer.popleft()
                            if frame_timestamps:
                                frame_timestamps.popleft()
                            performance_stats.dropped_frames += 1
                            
            except Exception as e:
                logger.error(f"Error processing WebSocket frame: {e}")
                
    except WebSocketDisconnect:
        logger.info("WebSocket client disconnected")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
    finally:
        if websocket in active_connections:
            active_connections.remove(websocket)
        logger.info(f"WebSocket client removed. Total clients: {len(active_connections)}")

@app.websocket("/ws_stats")
async def websocket_stats(websocket: WebSocket):
    """WebSocket endpoint for real-time performance stats"""
    await websocket.accept()
    
    try:
        while True:
            # Send performance stats every second
            stats = {
                "fps": round(performance_stats.fps, 2),
                "buffer_size": performance_stats.buffer_size,
                "latency_ms": round(performance_stats.latency, 2),
                "dropped_frames": performance_stats.dropped_frames,
                "active_connections": len(active_connections)
            }
            await websocket.send_text(json.dumps(stats))
            await asyncio.sleep(1)
    except WebSocketDisconnect:
        logger.info("Stats WebSocket disconnected")
    except Exception as e:
        logger.error(f"Stats WebSocket error: {e}")

# Start frame processor task
@app.on_event("startup")
async def startup_event():
    """Start background tasks on startup"""
    asyncio.create_task(frame_processor())

if __name__ == "__main__":
    uvicorn.run(
        "fastapi_frame_server:app",
        host="0.0.0.0",
        port=3003,
        reload=False,
        workers=1,
        loop="asyncio",
        access_log=True
    ) 