#!/usr/bin/env python3
"""
تست توکن جدید تولید شده
"""

import asyncio
import websockets
import json
import requests

async def test_new_token():
    """تست توکن جدید"""
    # دریافت توکن‌های فعلی
    try:
        # پسورد برای دسترسی به توکن‌ها
        token_password = "spy_servoo_secure_2024"
        response = requests.get(f"http://localhost:3000/tokens/{token_password}")
        tokens_data = response.json()
        
        if tokens_data.get("status") == "error":
            print(f"❌ خطا در دریافت توکن‌ها: {tokens_data['message']}")
            return
            
        print("🔍 توکن‌های فعلی:")
        print(f"📋 Pico tokens: {tokens_data['pico_tokens']}")
        print(f"📋 ESP32CAM tokens: {tokens_data['esp32cam_tokens']}")
        
        # استفاده از اولین توکن پیکو
        pico_token = tokens_data['pico_tokens'][0]
        print(f"🔑 توکن کامل پیکو: {pico_token}")
        
        # تست اتصال با توکن جدید
        url = "ws://localhost:3000/ws/pico"
        headers = {"Authorization": f"Bearer {pico_token}"}
        
        print(f"\n🔗 تست اتصال به: {url}")
        
        async with websockets.connect(url, extra_headers=headers) as websocket:
            print("✅ اتصال WebSocket موفق")
            
            # ارسال پیام اولیه
            initial_message = {
                "type": "connect",
                "device": "pico",
                "timestamp": "2025-07-29T14:04:00.000000",
                "version": "1.0",
                "servo1_angle": 90,
                "servo2_angle": 90,
                "auth_token": pico_token[:10] + "..."
            }
            await websocket.send(json.dumps(initial_message))
            print("📤 پیام اولیه ارسال شد")
            
            # دریافت پاسخ
            response = await websocket.recv()
            print(f"📥 پاسخ: {response}")
            
            # ارسال ping
            ping_message = {"type": "ping", "timestamp": "2025-07-29T14:04:00.000000"}
            await websocket.send(json.dumps(ping_message))
            print("📤 Ping ارسال شد")
            
            # دریافت pong
            pong_response = await websocket.recv()
            print(f"📥 Pong: {pong_response}")
            
            print("✅ تست توکن جدید موفق")
            
    except Exception as e:
        print(f"❌ خطا: {e}")

if __name__ == "__main__":
    asyncio.run(test_new_token()) 