#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Reset Rate Limiting Script
بازنشانی محدودیت نرخ
"""

import time
import threading

def reset_rate_limiting():
    """بازنشانی محدودیت نرخ"""
    print("🔄 بازنشانی محدودیت نرخ")
    print("=" * 50)
    
    # صبر کردن برای reset شدن rate limiting
    print("⏳ صبر کردن 60 ثانیه برای reset شدن rate limiting...")
    for i in range(60, 0, -1):
        print(f"   {i} ثانیه باقی مانده...", end='\r')
        time.sleep(1)
    print("\n✅ Rate limiting reset شد!")
    
    print("\n🎯 حالا می‌توانید تست‌ها را دوباره اجرا کنید")

if __name__ == "__main__":
    reset_rate_limiting() 