#!/usr/bin/env python3
"""
Simple Status Test
"""

import requests

BASE_URL = "http://localhost:3000"

def test_simple_status():
    """Simple test to check server response"""
    print("🔍 Simple Status Test")
    print("=" * 30)
    
    # Test 1: Health check
    print("\n1️⃣ Testing health endpoint...")
    try:
        response = requests.get(f"{BASE_URL}/health", timeout=5)
        print(f"   Status code: {response.status_code}")
        print(f"   Response: {response.text[:100]}...")
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    # Test 2: Get status without auth
    print("\n2️⃣ Testing status endpoint without auth...")
    try:
        response = requests.get(f"{BASE_URL}/get_status", timeout=5)
        print(f"   Status code: {response.status_code}")
        print(f"   Response: {response.text[:100]}...")
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    # Test 3: Login page
    print("\n3️⃣ Testing login page...")
    try:
        response = requests.get(f"{BASE_URL}/login", timeout=5)
        print(f"   Status code: {response.status_code}")
        print(f"   Content type: {response.headers.get('content-type', 'unknown')}")
        print(f"   Response length: {len(response.text)}")
    except Exception as e:
        print(f"   ❌ Error: {e}")

if __name__ == "__main__":
    test_simple_status() 