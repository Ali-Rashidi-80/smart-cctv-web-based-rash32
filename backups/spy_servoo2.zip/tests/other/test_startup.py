#!/usr/bin/env python3
"""
Test startup event and database initialization
"""

import asyncio
import aiosqlite
import os
import sys

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

async def test_startup_event():
    """Test if startup event would work correctly"""
    print("🔍 Testing startup event and database initialization...")
    print("=" * 60)
    
    try:
        # Test database connection
        conn = await aiosqlite.connect("smart_camera_system.db")
        print("✅ Database connection successful")
        
        # Check if tables exist
        cursor = await conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = await cursor.fetchall()
        table_names = [table[0] for table in tables]
        
        required_tables = [
            'users', 'camera_logs', 'password_recovery', 'servo_commands',
            'action_commands', 'device_mode_commands', 'manual_photos',
            'security_videos', 'user_settings'
        ]
        
        print("📊 Checking required tables:")
        missing_tables = []
        for table in required_tables:
            if table in table_names:
                print(f"   ✅ {table}")
            else:
                print(f"   ❌ {table} - missing")
                missing_tables.append(table)
        
        # Check admin user
        cursor = await conn.execute("SELECT COUNT(*) FROM users WHERE role = 'admin'")
        admin_count = await cursor.fetchone()
        if admin_count[0] > 0:
            print("   ✅ Admin user exists")
        else:
            print("   ❌ Admin user missing")
        
        # Check camera_logs entries
        cursor = await conn.execute("SELECT COUNT(*) FROM camera_logs")
        log_count = await cursor.fetchone()
        print(f"   📝 Camera logs entries: {log_count[0]}")
        
        await conn.close()
        
        if missing_tables:
            print(f"\n⚠️ Missing tables: {missing_tables}")
            print("💡 This indicates that startup event may not be working correctly")
            return False
        else:
            print("\n✅ All tables exist - startup event should work correctly")
            return True
            
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False

async def test_startup_event_simulation():
    """Simulate what startup event should do"""
    print("\n🔄 Simulating startup event...")
    print("=" * 60)
    
    try:
        # Import the startup event function
        from server_fastapi import startup_event
        print("✅ Startup event function imported successfully")
        
        # Note: We can't actually run the startup event without the full FastAPI app
        # But we can test the individual components
        
        # Test init_db function
        from server_fastapi import init_db
        print("✅ init_db function imported successfully")
        
        # Test migrate_all_tables function
        from server_fastapi import migrate_all_tables
        print("✅ migrate_all_tables function imported successfully")
        
        print("✅ All startup components are available")
        return True
        
    except Exception as e:
        print(f"❌ Startup event simulation failed: {e}")
        return False

async def main():
    """Main test function"""
    print("🚀 Testing startup event and database initialization...")
    print("=" * 60)
    
    # Test current database state
    db_ok = await test_startup_event()
    
    # Test startup event simulation
    startup_ok = await test_startup_event_simulation()
    
    print("\n" + "=" * 60)
    print("📋 SUMMARY:")
    print("=" * 60)
    
    if db_ok and startup_ok:
        print("🎉 All tests passed!")
        print("✅ Database is properly initialized")
        print("✅ Startup event components are available")
        print("✅ System should work correctly")
    elif db_ok:
        print("⚠️ Database is OK but startup event may have issues")
        print("💡 Try running the server to see if startup event works")
    else:
        print("❌ Database has issues")
        print("💡 Run: python reset_database.py")
        print("💡 Then run: python server_fastapi.py")

if __name__ == "__main__":
    asyncio.run(main()) 