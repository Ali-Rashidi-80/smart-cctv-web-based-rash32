#!/usr/bin/env python3
"""
🔧 Comprehensive Test Script for Smart Camera Security System Fixes
Tests all the fixes implemented for WebSocket authentication, Pico connection, and other issues
"""

import asyncio
import json
import time
import websockets
import requests
import subprocess
import sys
import os
from datetime import datetime

# Test configuration
SERVER_URL = "http://localhost:3000"
WS_URL = "ws://localhost:3000"
PICO_WS_URL = "ws://localhost:3001/ws/pico"
VIDEO_WS_URL = "ws://localhost:3000/ws/video"

# Test tokens
PICO_TOKEN = "rof642fr:5q\\0EKU@A@Tv"
ESP32CAM_TOKEN = "esp32cam_secure_token_2024"
INVALID_TOKEN = "invalid_token_123"

class ComprehensiveTestSuite:
    def __init__(self):
        self.test_results = []
        self.server_running = False
        
    def log_test(self, test_name, status, message=""):
        """Log test result"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        status_icon = "✅" if status == "PASS" else "❌" if status == "FAIL" else "⚠️"
        result = f"{timestamp} {status_icon} {test_name}: {status}"
        if message:
            result += f" - {message}"
        print(result)
        self.test_results.append({
            "test": test_name,
            "status": status,
            "message": message,
            "timestamp": timestamp
        })
        
    async def test_server_health(self):
        """Test server health endpoint"""
        try:
            response = requests.get(f"{SERVER_URL}/health", timeout=5)
            if response.status_code == 200:
                self.log_test("Server Health", "PASS", "Server is running and healthy")
                return True
            else:
                self.log_test("Server Health", "FAIL", f"Server returned status {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Server Health", "FAIL", f"Server not accessible: {e}")
            return False
            
    async def test_websocket_authentication_pico_valid(self):
        """Test Pico WebSocket with valid token"""
        try:
            headers = {"Authorization": f"Bearer {PICO_TOKEN}"}
            async with websockets.connect(PICO_WS_URL, extra_headers=headers) as websocket:
                # Send a test message
                test_message = {
                    "type": "ping",
                    "device": "pico",
                    "timestamp": datetime.now().isoformat()
                }
                await websocket.send(json.dumps(test_message))
                
                # Wait for response
                response = await asyncio.wait_for(websocket.recv(), timeout=5)
                data = json.loads(response)
                
                if data.get("type") == "ping":
                    self.log_test("Pico WebSocket (Valid Token)", "PASS", "Connection successful")
                    return True
                else:
                    self.log_test("Pico WebSocket (Valid Token)", "FAIL", f"Unexpected response: {data}")
                    return False
        except Exception as e:
            self.log_test("Pico WebSocket (Valid Token)", "FAIL", f"Connection failed: {e}")
            return False
            
    async def test_websocket_authentication_pico_invalid(self):
        """Test Pico WebSocket with invalid token"""
        try:
            headers = {"Authorization": f"Bearer {INVALID_TOKEN}"}
            async with websockets.connect(PICO_WS_URL, extra_headers=headers) as websocket:
                await websocket.send("test")
                self.log_test("Pico WebSocket (Invalid Token)", "FAIL", "Connection should have been rejected")
                return False
        except websockets.exceptions.ConnectionClosed as e:
            if e.code == 4001:
                self.log_test("Pico WebSocket (Invalid Token)", "PASS", "Connection properly rejected")
                return True
            else:
                self.log_test("Pico WebSocket (Invalid Token)", "FAIL", f"Wrong close code: {e.code}")
                return False
        except Exception as e:
            self.log_test("Pico WebSocket (Invalid Token)", "PASS", f"Connection rejected as expected: {e}")
            return True
            
    async def test_websocket_authentication_pico_no_token(self):
        """Test Pico WebSocket without token"""
        try:
            async with websockets.connect(PICO_WS_URL) as websocket:
                await websocket.send("test")
                self.log_test("Pico WebSocket (No Token)", "FAIL", "Connection should have been rejected")
                return False
        except websockets.exceptions.ConnectionClosed as e:
            if e.code == 4001:
                self.log_test("Pico WebSocket (No Token)", "PASS", "Connection properly rejected")
                return True
            else:
                self.log_test("Pico WebSocket (No Token)", "FAIL", f"Wrong close code: {e.code}")
                return False
        except Exception as e:
            self.log_test("Pico WebSocket (No Token)", "PASS", f"Connection rejected as expected: {e}")
            return True
            
    async def test_websocket_authentication_esp32cam_valid(self):
        """Test ESP32CAM WebSocket with valid token"""
        try:
            headers = {"Authorization": f"Bearer {ESP32CAM_TOKEN}"}
            esp32cam_ws_url = f"{WS_URL}/ws/esp32cam"
            async with websockets.connect(esp32cam_ws_url, extra_headers=headers) as websocket:
                # Send a test message
                test_message = {
                    "type": "ping",
                    "device": "esp32cam",
                    "timestamp": datetime.now().isoformat()
                }
                await websocket.send(json.dumps(test_message))
                
                # Wait for response
                response = await asyncio.wait_for(websocket.recv(), timeout=5)
                data = json.loads(response)
                
                if data.get("type") == "ping":
                    self.log_test("ESP32CAM WebSocket (Valid Token)", "PASS", "Connection successful")
                    return True
                else:
                    self.log_test("ESP32CAM WebSocket (Valid Token)", "FAIL", f"Unexpected response: {data}")
                    return False
        except Exception as e:
            self.log_test("ESP32CAM WebSocket (Valid Token)", "FAIL", f"Connection failed: {e}")
            return False
            
    async def test_websocket_authentication_esp32cam_invalid(self):
        """Test ESP32CAM WebSocket with invalid token"""
        try:
            headers = {"Authorization": f"Bearer {INVALID_TOKEN}"}
            esp32cam_ws_url = f"{WS_URL}/ws/esp32cam"
            async with websockets.connect(esp32cam_ws_url, extra_headers=headers) as websocket:
                await websocket.send("test")
                self.log_test("ESP32CAM WebSocket (Invalid Token)", "FAIL", "Connection should have been rejected")
                return False
        except websockets.exceptions.ConnectionClosed as e:
            if e.code == 4001:
                self.log_test("ESP32CAM WebSocket (Invalid Token)", "PASS", "Connection properly rejected")
                return True
            else:
                self.log_test("ESP32CAM WebSocket (Invalid Token)", "FAIL", f"Wrong close code: {e.code}")
                return False
        except Exception as e:
            self.log_test("ESP32CAM WebSocket (Invalid Token)", "PASS", f"Connection rejected as expected: {e}")
            return True
            
    async def test_websocket_video_localhost(self):
        """Test video WebSocket from localhost (should work without auth)"""
        try:
            async with websockets.connect(VIDEO_WS_URL) as websocket:
                # Wait for ping message
                response = await asyncio.wait_for(websocket.recv(), timeout=5)
                data = json.loads(response)
                
                if data.get("type") == "ping":
                    self.log_test("Video WebSocket (Localhost)", "PASS", "Connection successful without auth")
                    return True
                else:
                    self.log_test("Video WebSocket (Localhost)", "FAIL", f"Unexpected response: {data}")
                    return False
        except Exception as e:
            self.log_test("Video WebSocket (Localhost)", "FAIL", f"Connection failed: {e}")
            return False
            
    async def test_websocket_main_localhost(self):
        """Test main WebSocket from localhost (should work without auth)"""
        try:
            async with websockets.connect(f"{WS_URL}/ws") as websocket:
                # Send a test message
                test_message = {"type": "ping"}
                await websocket.send(json.dumps(test_message))
                
                # Wait for response
                response = await asyncio.wait_for(websocket.recv(), timeout=5)
                data = json.loads(response)
                
                if data.get("type") in ["ping", "pong", "status"]:
                    self.log_test("Main WebSocket (Localhost)", "PASS", "Connection successful without auth")
                    return True
                else:
                    self.log_test("Main WebSocket (Localhost)", "FAIL", f"Unexpected response: {data}")
                    return False
        except Exception as e:
            self.log_test("Main WebSocket (Localhost)", "FAIL", f"Connection failed: {e}")
            return False
            
    async def test_servo_command_endpoint(self):
        """Test servo command endpoint"""
        try:
            # First login to get a token
            login_data = {
                "username": "admin",
                "password": "admin123"
            }
            login_response = requests.post(f"{SERVER_URL}/login", json=login_data, timeout=5)
            
            if login_response.status_code != 200:
                self.log_test("Servo Command Endpoint", "SKIP", "Login failed, skipping test")
                return True
                
            # Get cookies from login response
            cookies = login_response.cookies
            
            # Test servo command
            servo_data = {
                "servo1": 90,
                "servo2": 90
            }
            servo_response = requests.post(f"{SERVER_URL}/set_servo", json=servo_data, cookies=cookies, timeout=5)
            
            if servo_response.status_code == 200:
                self.log_test("Servo Command Endpoint", "PASS", "Servo command accepted")
                return True
            else:
                self.log_test("Servo Command Endpoint", "FAIL", f"Servo command failed: {servo_response.status_code}")
                return False
        except Exception as e:
            self.log_test("Servo Command Endpoint", "FAIL", f"Test failed: {e}")
            return False
            
    async def test_pico_status_endpoint(self):
        """Test Pico status endpoint"""
        try:
            response = requests.get(f"{SERVER_URL}/pico/status", timeout=5)
            if response.status_code == 200:
                data = response.json()
                if "online" in data and "last_seen" in data:
                    self.log_test("Pico Status Endpoint", "PASS", "Status endpoint working")
                    return True
                else:
                    self.log_test("Pico Status Endpoint", "FAIL", "Invalid response format")
                    return False
            else:
                self.log_test("Pico Status Endpoint", "FAIL", f"Status endpoint failed: {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Pico Status Endpoint", "FAIL", f"Test failed: {e}")
            return False
            
    async def test_esp32cam_status_endpoint(self):
        """Test ESP32CAM status endpoint"""
        try:
            response = requests.get(f"{SERVER_URL}/esp32cam/status", timeout=5)
            if response.status_code == 200:
                data = response.json()
                if "online" in data and "last_seen" in data:
                    self.log_test("ESP32CAM Status Endpoint", "PASS", "Status endpoint working")
                    return True
                else:
                    self.log_test("ESP32CAM Status Endpoint", "FAIL", "Invalid response format")
                    return False
            else:
                self.log_test("ESP32CAM Status Endpoint", "FAIL", f"Status endpoint failed: {response.status_code}")
                return False
        except Exception as e:
            self.log_test("ESP32CAM Status Endpoint", "FAIL", f"Test failed: {e}")
            return False
            
    async def test_all_devices_status_endpoint(self):
        """Test all devices status endpoint"""
        try:
            response = requests.get(f"{SERVER_URL}/devices/status", timeout=5)
            if response.status_code == 200:
                data = response.json()
                if "pico" in data and "esp32cam" in data:
                    self.log_test("All Devices Status Endpoint", "PASS", "Status endpoint working")
                    return True
                else:
                    self.log_test("All Devices Status Endpoint", "FAIL", "Invalid response format")
                    return False
            else:
                self.log_test("All Devices Status Endpoint", "FAIL", f"Status endpoint failed: {response.status_code}")
                return False
        except Exception as e:
            self.log_test("All Devices Status Endpoint", "FAIL", f"Test failed: {e}")
            return False
            
    async def test_error_handling(self):
        """Test error handling for malformed requests"""
        try:
            # Test malformed JSON
            headers = {"Content-Type": "application/json"}
            response = requests.post(f"{SERVER_URL}/set_servo", data="invalid json", headers=headers, timeout=5)
            
            if response.status_code in [400, 422]:
                self.log_test("Error Handling", "PASS", "Properly handled malformed request")
                return True
            else:
                self.log_test("Error Handling", "FAIL", f"Unexpected response: {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Error Handling", "FAIL", f"Test failed: {e}")
            return False
            
    async def run_all_tests(self):
        """Run all tests"""
        print("🚀 Starting Comprehensive Test Suite...")
        print("=" * 60)
        
        # Test server health first
        if not await self.test_server_health():
            print("❌ Server is not running. Please start the server first.")
            return False
            
        # Run all tests
        tests = [
            self.test_websocket_authentication_pico_valid,
            self.test_websocket_authentication_pico_invalid,
            self.test_websocket_authentication_pico_no_token,
            self.test_websocket_authentication_esp32cam_valid,
            self.test_websocket_authentication_esp32cam_invalid,
            self.test_websocket_video_localhost,
            self.test_websocket_main_localhost,
            self.test_servo_command_endpoint,
            self.test_pico_status_endpoint,
            self.test_esp32cam_status_endpoint,
            self.test_all_devices_status_endpoint,
            self.test_error_handling
        ]
        
        passed = 0
        failed = 0
        skipped = 0
        
        for test in tests:
            try:
                result = await test()
                if result:
                    passed += 1
                else:
                    failed += 1
            except Exception as e:
                self.log_test(test.__name__, "FAIL", f"Test exception: {e}")
                failed += 1
                
            # Small delay between tests
            await asyncio.sleep(0.5)
            
        # Print summary
        print("=" * 60)
        print("📊 Test Summary:")
        print(f"✅ Passed: {passed}")
        print(f"❌ Failed: {failed}")
        print(f"⚠️ Skipped: {skipped}")
        print(f"📈 Total: {passed + failed + skipped}")
        
        if failed == 0:
            print("🎉 All tests passed! System is working correctly.")
            return True
        else:
            print("⚠️ Some tests failed. Please check the issues above.")
            return False
            
    def print_detailed_results(self):
        """Print detailed test results"""
        print("\n📋 Detailed Test Results:")
        print("=" * 60)
        for result in self.test_results:
            status_icon = "✅" if result["status"] == "PASS" else "❌" if result["status"] == "FAIL" else "⚠️"
            print(f"{result['timestamp']} {status_icon} {result['test']}: {result['status']}")
            if result["message"]:
                print(f"   └─ {result['message']}")

async def main():
    """Main test function"""
    test_suite = ComprehensiveTestSuite()
    
    try:
        success = await test_suite.run_all_tests()
        test_suite.print_detailed_results()
        
        if success:
            print("\n🎯 All fixes verified successfully!")
            print("✅ WebSocket authentication working")
            print("✅ Pico connection working")
            print("✅ ESP32CAM connection working")
            print("✅ Error handling improved")
            print("✅ Localhost bypass working")
        else:
            print("\n🔧 Some issues remain. Please check the failed tests above.")
            
    except KeyboardInterrupt:
        print("\n⏹️ Test interrupted by user")
    except Exception as e:
        print(f"\n💥 Test suite error: {e}")

if __name__ == "__main__":
    asyncio.run(main()) 