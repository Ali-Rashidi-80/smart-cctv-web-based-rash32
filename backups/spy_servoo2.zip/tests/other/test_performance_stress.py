#!/usr/bin/env python3
"""
تست‌های عملکرد و استرس
Performance & Stress Tests
"""

import sys
import os
import asyncio
import aiosqlite
import secrets
import time
import psutil
import threading
from datetime import datetime
from typing import List, Dict, Any
from concurrent.futures import ThreadPoolExecutor

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from server_fastapi import (
    init_db, 
    get_db_connection, 
    close_db_connection, 
    sanitize_input,
    create_access_token,
    verify_token,
    hash_password,
    verify_password,
    check_rate_limit,
    check_login_attempts
)

class PerformanceStressTester:
    def __init__(self):
        self.test_results = []
        self.performance_metrics = {}
        self.stress_test_results = []
        
    def log_test(self, test_name: str, passed: bool, details: str = "", metrics: Dict = None):
        """ثبت نتیجه تست"""
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status} {test_name}: {details}")
        self.test_results.append({
            "test": test_name,
            "passed": passed,
            "details": details,
            "metrics": metrics or {},
            "timestamp": datetime.now().isoformat()
        })

    async def test_database_performance(self):
        """تست عملکرد دیتابیس"""
        print("\n🗄️ تست عملکرد دیتابیس...")
        
        try:
            conn = await get_db_connection()
            
            # تست درج سریع
            start_time = time.time()
            users_created = 0
            
            for i in range(100):
                username = f"perf_user_{secrets.token_hex(8)}"
                email = f"{username}@test.com"
                password_hash = hash_password("test123")
                
                await conn.execute(
                    'INSERT INTO users (username, email, password_hash, role, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?)',
                    (username, email, password_hash, "user", True, datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                )
                users_created += 1
            
            await conn.commit()
            end_time = time.time()
            duration = end_time - start_time
            rate = users_created / duration
            
            self.log_test(
                "Database Insert Performance", 
                rate > 10,  # حداقل 10 درج در ثانیه
                f"Created {users_created} users in {duration:.2f}s ({rate:.2f} users/s)",
                {"users_created": users_created, "duration": duration, "rate": rate}
            )
            
            # تست جستجو
            start_time = time.time()
            cursor = await conn.execute("SELECT COUNT(*) FROM users WHERE role = ?", ("user",))
            result = await cursor.fetchone()
            end_time = time.time()
            query_duration = end_time - start_time
            
            self.log_test(
                "Database Query Performance",
                query_duration < 1.0,  # کمتر از 1 ثانیه
                f"Query completed in {query_duration:.3f}s",
                {"query_duration": query_duration, "result": result[0] if result else 0}
            )
            
            # پاکسازی
            await conn.execute("DELETE FROM users WHERE username LIKE 'perf_user_%'")
            await conn.commit()
            
            await close_db_connection(conn)
            
        except Exception as e:
            self.log_test("Database Performance", False, f"Error: {e}")

    async def test_password_hashing_performance(self):
        """تست عملکرد هش کردن رمز عبور"""
        print("\n🔐 تست عملکرد هش کردن رمز عبور...")
        
        passwords = [
            "simple123",
            "Complex@Password#2024",
            "VeryLongPasswordWithSpecialCharacters!@#$%^&*()",
            "123456789012345678901234567890",
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
        ]
        
        total_time = 0
        total_hashes = 0
        
        for password in passwords:
            start_time = time.time()
            hash_result = hash_password(password)
            end_time = time.time()
            
            if hash_result and hash_result.startswith("$2b$"):
                duration = end_time - start_time
                total_time += duration
                total_hashes += 1
                
                self.log_test(
                    f"Password Hashing - {password[:15]}...",
                    duration < 1.0,  # کمتر از 1 ثانیه
                    f"Hashed in {duration:.3f}s",
                    {"password_length": len(password), "duration": duration}
                )
            else:
                self.log_test(f"Password Hashing - {password[:15]}...", False, "Hashing failed")
        
        if total_hashes > 0:
            avg_time = total_time / total_hashes
            self.log_test(
                "Password Hashing Average Performance",
                avg_time < 0.5,  # میانگین کمتر از 0.5 ثانیه
                f"Average time: {avg_time:.3f}s per hash",
                {"total_hashes": total_hashes, "total_time": total_time, "avg_time": avg_time}
            )

    async def test_jwt_performance(self):
        """تست عملکرد JWT"""
        print("\n🔑 تست عملکرد JWT...")
        
        test_data = {"sub": "testuser", "role": "user", "ip": "192.168.1.1"}
        
        # تست ایجاد توکن
        start_time = time.time()
        tokens_created = 0
        
        for i in range(100):
            token = create_access_token(data=test_data)
            if token:
                tokens_created += 1
        
        end_time = time.time()
        duration = end_time - start_time
        creation_rate = tokens_created / duration
        
        self.log_test(
            "JWT Token Creation Performance",
            creation_rate > 50,  # حداقل 50 توکن در ثانیه
            f"Created {tokens_created} tokens in {duration:.2f}s ({creation_rate:.2f} tokens/s)",
            {"tokens_created": tokens_created, "duration": duration, "rate": creation_rate}
        )
        
        # تست verification
        if tokens_created > 0:
            token = create_access_token(data=test_data)
            start_time = time.time()
            verifications = 0
            
            for i in range(100):
                result = verify_token(token)
                if result:
                    verifications += 1
            
            end_time = time.time()
            duration = end_time - start_time
            verification_rate = verifications / duration
            
            self.log_test(
                "JWT Token Verification Performance",
                verification_rate > 100,  # حداقل 100 verification در ثانیه
                f"Verified {verifications} tokens in {duration:.2f}s ({verification_rate:.2f} verifications/s)",
                {"verifications": verifications, "duration": duration, "rate": verification_rate}
            )

    async def test_input_sanitization_performance(self):
        """تست عملکرد sanitization ورودی"""
        print("\n🛡️ تست عملکرد sanitization ورودی...")
        
        # تولید ورودی‌های تست
        test_inputs = []
        
        # ورودی‌های عادی
        for i in range(50):
            test_inputs.append(f"normal_input_{i}")
        
        # ورودی‌های با کاراکترهای خاص
        special_chars = "!@#$%^&*()_+-=[]{}|;:,.<>?`~"
        for i in range(50):
            test_inputs.append(f"special_input_{special_chars}_{i}")
        
        # ورودی‌های با حملات
        attacks = [
            "admin' OR '1'='1",
            "<script>alert('xss')</script>",
            "javascript:alert('xss')",
            "'; DROP TABLE users; --"
        ]
        for attack in attacks:
            for i in range(10):
                test_inputs.append(f"{attack}_{i}")
        
        start_time = time.time()
        sanitized_count = 0
        
        for input_str in test_inputs:
            sanitized = sanitize_input(input_str)
            if sanitized is not None:
                sanitized_count += 1
        
        end_time = time.time()
        duration = end_time - start_time
        sanitization_rate = sanitized_count / duration
        
        self.log_test(
            "Input Sanitization Performance",
            sanitization_rate > 100,  # حداقل 100 sanitization در ثانیه
            f"Sanitized {sanitized_count} inputs in {duration:.2f}s ({sanitization_rate:.2f} inputs/s)",
            {"inputs_sanitized": sanitized_count, "duration": duration, "rate": sanitization_rate}
        )

    async def test_rate_limiting_performance(self):
        """تست عملکرد Rate Limiting"""
        print("\n⏱️ تست عملکرد Rate Limiting...")
        
        test_ips = [f"192.168.1.{i}" for i in range(1, 21)]  # 20 IP مختلف
        
        start_time = time.time()
        checks_performed = 0
        
        # تست rate limiting برای IP های مختلف
        for ip in test_ips:
            for i in range(20):  # 20 درخواست برای هر IP
                result = check_rate_limit(ip)
                checks_performed += 1
        
        end_time = time.time()
        duration = end_time - start_time
        check_rate = checks_performed / duration
        
        self.log_test(
            "Rate Limiting Performance",
            check_rate > 100,  # حداقل 100 بررسی در ثانیه
            f"Performed {checks_performed} rate limit checks in {duration:.2f}s ({check_rate:.2f} checks/s)",
            {"checks_performed": checks_performed, "duration": duration, "rate": check_rate}
        )

    async def test_concurrent_operations(self):
        """تست عملیات همزمان"""
        print("\n🔄 تست عملیات همزمان...")
        
        async def concurrent_task(task_id: int):
            """وظیفه همزمان"""
            try:
                # ایجاد توکن
                token = create_access_token(data={"sub": f"user_{task_id}", "role": "user"})
                
                # بررسی توکن
                result = verify_token(token)
                
                # هش کردن رمز عبور
                password_hash = hash_password(f"password_{task_id}")
                
                # sanitization
                sanitized = sanitize_input(f"input_{task_id}")
                
                return True
            except Exception as e:
                return False
        
        # اجرای 50 وظیفه همزمان
        start_time = time.time()
        tasks = [concurrent_task(i) for i in range(50)]
        results = await asyncio.gather(*tasks)
        end_time = time.time()
        
        successful_tasks = sum(results)
        duration = end_time - start_time
        
        self.log_test(
            "Concurrent Operations Performance",
            successful_tasks == 50,  # تمام وظایف موفق
            f"Completed {successful_tasks}/50 concurrent tasks in {duration:.2f}s",
            {"successful_tasks": successful_tasks, "total_tasks": 50, "duration": duration}
        )

    async def test_memory_usage(self):
        """تست استفاده از حافظه"""
        print("\n💾 تست استفاده از حافظه...")
        
        process = psutil.Process()
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB
        
        # انجام عملیات سنگین
        operations = []
        for i in range(1000):
            # ایجاد توکن
            token = create_access_token(data={"sub": f"user_{i}", "role": "user"})
            
            # هش کردن رمز عبور
            password_hash = hash_password(f"password_{i}")
            
            # sanitization
            sanitized = sanitize_input(f"input_{i}")
            
            operations.append({
                "token": token,
                "hash": password_hash,
                "sanitized": sanitized
            })
        
        final_memory = process.memory_info().rss / 1024 / 1024  # MB
        memory_increase = final_memory - initial_memory
        
        self.log_test(
            "Memory Usage Test",
            memory_increase < 100,  # افزایش کمتر از 100 MB
            f"Memory increased by {memory_increase:.2f}MB ({initial_memory:.2f}MB -> {final_memory:.2f}MB)",
            {"initial_memory": initial_memory, "final_memory": final_memory, "increase": memory_increase}
        )

    async def test_stress_high_load(self):
        """تست استرس با بار بالا"""
        print("\n🔥 تست استرس با بار بالا...")
        
        async def stress_task(task_id: int):
            """وظیفه استرس"""
            try:
                # عملیات سنگین
                for i in range(10):
                    # ایجاد توکن
                    token = create_access_token(data={"sub": f"stress_user_{task_id}_{i}", "role": "user"})
                    
                    # بررسی توکن
                    result = verify_token(token)
                    
                    # هش کردن رمز عبور
                    password_hash = hash_password(f"stress_password_{task_id}_{i}")
                    
                    # sanitization
                    sanitized = sanitize_input(f"stress_input_{task_id}_{i}")
                    
                    # rate limiting
                    check_rate_limit(f"192.168.1.{task_id % 255}")
                    
                return True
            except Exception as e:
                return False
        
        # اجرای 100 وظیفه استرس همزمان
        start_time = time.time()
        tasks = [stress_task(i) for i in range(100)]
        results = await asyncio.gather(*tasks)
        end_time = time.time()
        
        successful_tasks = sum(results)
        duration = end_time - start_time
        
        self.log_test(
            "High Load Stress Test",
            successful_tasks >= 90,  # حداقل 90% موفق
            f"Completed {successful_tasks}/100 stress tasks in {duration:.2f}s",
            {"successful_tasks": successful_tasks, "total_tasks": 100, "duration": duration, "success_rate": successful_tasks/100}
        )

    async def test_database_stress(self):
        """تست استرس دیتابیس"""
        print("\n🗄️ تست استرس دیتابیس...")
        
        try:
            conn = await get_db_connection()
            
            # ایجاد کاربران تست
            start_time = time.time()
            users_created = 0
            
            for i in range(200):
                username = f"stress_user_{secrets.token_hex(4)}"
                email = f"{username}@test.com"
                password_hash = hash_password("test123")
                
                await conn.execute(
                    'INSERT INTO users (username, email, password_hash, role, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?)',
                    (username, email, password_hash, "user", True, datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                )
                users_created += 1
                
                # commit هر 50 کاربر
                if users_created % 50 == 0:
                    await conn.commit()
            
            await conn.commit()
            end_time = time.time()
            duration = end_time - start_time
            
            self.log_test(
                "Database Stress Test",
                duration < 30,  # کمتر از 30 ثانیه
                f"Created {users_created} users in {duration:.2f}s",
                {"users_created": users_created, "duration": duration, "rate": users_created/duration}
            )
            
            # پاکسازی
            await conn.execute("DELETE FROM users WHERE username LIKE 'stress_user_%'")
            await conn.commit()
            
            await close_db_connection(conn)
            
        except Exception as e:
            self.log_test("Database Stress Test", False, f"Error: {e}")

    async def run_all_tests(self):
        """اجرای تمام تست‌ها"""
        print("🔥 تست‌های عملکرد و استرس")
        print("=" * 60)
        
        # راه‌اندازی دیتابیس
        try:
            await init_db()
            print("✅ دیتابیس راه‌اندازی شد")
        except Exception as e:
            print(f"❌ خطا در راه‌اندازی دیتابیس: {e}")
            return False
        
        # اجرای تست‌ها
        await self.test_database_performance()
        await self.test_password_hashing_performance()
        await self.test_jwt_performance()
        await self.test_input_sanitization_performance()
        await self.test_rate_limiting_performance()
        await self.test_concurrent_operations()
        await self.test_memory_usage()
        await self.test_stress_high_load()
        await self.test_database_stress()
        
        # گزارش نهایی
        print("\n" + "=" * 60)
        print("📊 گزارش نهایی تست‌های عملکرد و استرس")
        print("=" * 60)
        
        passed = sum(1 for result in self.test_results if result["passed"])
        total = len(self.test_results)
        
        print(f"📈 آمار کلی:")
        print(f"   کل تست‌ها: {total}")
        print(f"   تست‌های موفق: {passed}")
        print(f"   تست‌های ناموفق: {total - passed}")
        print(f"   نرخ موفقیت: {(passed/total)*100:.1f}%")
        
        # معیارهای عملکرد
        print(f"\n⚡ معیارهای عملکرد:")
        for result in self.test_results:
            if result.get("metrics"):
                metrics = result["metrics"]
                if "rate" in metrics:
                    print(f"   {result['test']}: {metrics['rate']:.2f} ops/s")
                elif "duration" in metrics:
                    print(f"   {result['test']}: {metrics['duration']:.3f}s")
        
        print(f"\n💡 توصیه‌ها:")
        if passed == total:
            print("   - عملکرد سیستم در سطح عالی است!")
        else:
            print("   - برخی مشکلات عملکردی نیاز به بهینه‌سازی دارند")
        
        return passed == total

async def main():
    """تابع اصلی"""
    tester = PerformanceStressTester()
    success = await tester.run_all_tests()
    
    if success:
        print("\n🎉 تمام تست‌های عملکرد و استرس موفق بودند!")
    else:
        print("\n⚠️ برخی تست‌های عملکرد و استرس ناموفق بودند!")

if __name__ == "__main__":
    asyncio.run(main())