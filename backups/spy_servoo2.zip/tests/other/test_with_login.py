#!/usr/bin/env python3
"""
Test with Login
"""

import requests
import json

BASE_URL = "http://localhost:3000"

def test_with_login():
    """Test with proper login"""
    print("🔍 Test with Login")
    print("=" * 30)
    
    session = requests.Session()
    
    # Test 1: Login
    print("\n1️⃣ Logging in...")
    try:
        login_data = {
            "username": "rof642fr",
            "password": "5qEKU@A@Tv"
        }
        response = session.post(f"{BASE_URL}/login", json=login_data, timeout=5)
        print(f"   Status code: {response.status_code}")
        print(f"   Response: {response.text[:100]}...")
        
        if response.status_code == 200:
            print("   ✅ Login successful")
        else:
            print("   ❌ Login failed")
            return False
    except Exception as e:
        print(f"   ❌ Login error: {e}")
        return False
    
    # Test 2: Get status with session
    print("\n2️⃣ Getting status with session...")
    try:
        response = session.get(f"{BASE_URL}/get_status", timeout=5)
        print(f"   Status code: {response.status_code}")
        print(f"   Content type: {response.headers.get('content-type', 'unknown')}")
        
        if response.status_code == 200:
            try:
                data = response.json()
                pico_status = data.get("data", {}).get("pico_status", "unknown")
                print(f"   Pico status: {pico_status}")
                print("   ✅ Status retrieved successfully")
                return True
            except json.JSONDecodeError:
                print(f"   ❌ Response is not JSON: {response.text[:100]}...")
                return False
        else:
            print(f"   ❌ Failed to get status: {response.status_code}")
            print(f"   Response: {response.text[:100]}...")
            return False
    except Exception as e:
        print(f"   ❌ Error getting status: {e}")
        return False

if __name__ == "__main__":
    success = test_with_login()
    if success:
        print("\n🎉 Test successful!")
    else:
        print("\n❌ Test failed!") 