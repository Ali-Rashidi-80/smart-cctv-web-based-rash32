#!/usr/bin/env python3
"""
Check what's using port 3000
"""

import socket
import subprocess
import sys
import os

def check_port(port):
    """Check if a port is in use"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('localhost', port))
            return False  # Port is available
    except OSError:
        return True  # Port is in use

def get_process_using_port(port):
    """Get process information for a port (Windows)"""
    try:
        # Use netstat to find process using the port
        result = subprocess.run(
            ['netstat', '-ano'], 
            capture_output=True, 
            text=True, 
            check=True
        )
        
        lines = result.stdout.split('\n')
        for line in lines:
            if f':{port}' in line and 'LISTENING' in line:
                parts = line.split()
                if len(parts) >= 5:
                    pid = parts[-1]
                    try:
                        # Get process name from PID
                        task_result = subprocess.run(
                            ['tasklist', '/FI', f'PID eq {pid}', '/FO', 'CSV'], 
                            capture_output=True, 
                            text=True, 
                            check=True
                        )
                        task_lines = task_result.stdout.split('\n')
                        if len(task_lines) > 1:
                            process_info = task_lines[1].split(',')
                            if len(process_info) > 0:
                                process_name = process_info[0].strip('"')
                                return f"PID: {pid}, Process: {process_name}"
                    except:
                        return f"PID: {pid}"
        return "Unknown process"
    except Exception as e:
        return f"Error getting process info: {e}"

def main():
    port = 3000
    print(f"🔍 Checking port {port}...")
    
    if check_port(port):
        print(f"❌ Port {port} is in use")
        process_info = get_process_using_port(port)
        print(f"📋 Process info: {process_info}")
        
        print("\n💡 Solutions:")
        print("1. Stop the process using port 3000")
        print("2. Use a different port (server will automatically use 3001)")
        print("3. Kill the process if it's not needed")
        
        choice = input("\nDo you want to kill the process? (y/n): ").lower()
        if choice == 'y':
            try:
                # Get PID and kill process
                result = subprocess.run(['netstat', '-ano'], capture_output=True, text=True)
                lines = result.stdout.split('\n')
                for line in lines:
                    if f':{port}' in line and 'LISTENING' in line:
                        parts = line.split()
                        if len(parts) >= 5:
                            pid = parts[-1]
                            subprocess.run(['taskkill', '/PID', pid, '/F'])
                            print(f"✅ Killed process with PID {pid}")
                            break
            except Exception as e:
                print(f"❌ Error killing process: {e}")
    else:
        print(f"✅ Port {port} is available")

if __name__ == "__main__":
    main() 