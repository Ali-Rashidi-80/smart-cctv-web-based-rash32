#!/usr/bin/env python3
"""
تست فوق پیشرفته و جامع نهایی سیستم
Ultimate Comprehensive System Test
"""

import sys
import os
import asyncio
import secrets
import time
import json
import base64
from datetime import datetime, timedelta
from typing import Dict, List, Tuple

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from server_fastapi import (
    init_db, 
    get_db_connection,
    close_db_connection,
    sanitize_input,
    create_access_token,
    verify_token,
    hash_password,
    verify_password,
    check_rate_limit,
    check_login_attempts,
    record_login_attempt,
    insert_log,
    insert_servo_command,
    insert_action_command,
    insert_device_mode_command,
    insert_photo_to_db,
    create_or_get_google_user,
    GoogleUserInfo,
    get_google_auth_url,
    exchange_google_code_for_token,
    get_google_user_info,
    send_password_recovery_sms,
    get_jalali_now_str,
    execute_db_insert
)

class UltimateComprehensiveTester:
    """تست فوق پیشرفته و جامع سیستم"""
    
    def __init__(self):
        self.test_results = []
        self.performance_metrics = {}
        self.security_issues = []
        self.integration_issues = []
        self.start_time = time.time()
        
    def log_test(self, test_name: str, passed: bool, details: str = "", category: str = "general"):
        """ثبت نتیجه تست"""
        status = "✅ PASS" if passed else "❌ FAIL"
        result = {
            "name": test_name,
            "status": status,
            "passed": passed,
            "details": details,
            "category": category,
            "timestamp": datetime.now().isoformat()
        }
        self.test_results.append(result)
        print(f"{status} {test_name}: {details}")
        
    def log_security_issue(self, component: str, description: str, severity: str = "medium"):
        """ثبت مشکل امنیتی"""
        issue = {
            "component": component,
            "description": description,
            "severity": severity,
            "timestamp": datetime.now().isoformat()
        }
        self.security_issues.append(issue)
        print(f"🔒 SECURITY ISSUE - {component}: {description}")
        
    def log_integration_issue(self, component: str, description: str):
        """ثبت مشکل یکپارچگی"""
        issue = {
            "component": component,
            "description": description,
            "timestamp": datetime.now().isoformat()
        }
        self.integration_issues.append(issue)
        print(f"🔗 INTEGRATION ISSUE - {component}: {description}")
        
    def log_performance(self, metric: str, value: float, unit: str = ""):
        """ثبت معیار عملکرد"""
        self.performance_metrics[metric] = {"value": value, "unit": unit}
        print(f"⚡ PERFORMANCE - {metric}: {value} {unit}")

    async def test_database_integrity_advanced(self):
        """تست پیشرفته یکپارچگی دیتابیس"""
        print("\n🗄️ تست پیشرفته یکپارچگی دیتابیس...")
        
        try:
            conn = await get_db_connection()
            
            # بررسی تمام جداول
            tables = [
                "users", "password_recovery", "camera_logs", "servo_commands",
                "action_commands", "device_mode_commands", "manual_photos",
                "security_videos", "user_settings"
            ]
            
            for table in tables:
                # بررسی وجود جدول
                cursor = await conn.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table}'")
                result = await cursor.fetchone()
                if result:
                    # بررسی ساختار جدول
                    cursor = await conn.execute(f"PRAGMA table_info({table})")
                    columns = await cursor.fetchall()
                    if columns:
                        self.log_test(f"Database Table - {table}", True, f"{len(columns)} columns", "database")
                    else:
                        self.log_test(f"Database Table - {table}", False, "No columns found", "database")
                else:
                    self.log_test(f"Database Table - {table}", False, "Table not found", "database")
            
            # بررسی indexes
            cursor = await conn.execute("PRAGMA index_list(users)")
            indexes = await cursor.fetchall()
            username_indexes = [idx[1] for idx in indexes if 'username' in idx[1].lower()]
            if username_indexes:
                self.log_test("Username Unique Index", True, f"Found: {username_indexes}", "database")
            else:
                self.log_test("Username Unique Index", False, "No username index found", "database")
                self.log_security_issue("Database", "Missing username unique constraint", "high")
            
            # بررسی foreign keys
            cursor = await conn.execute("PRAGMA foreign_key_check")
            violations = await cursor.fetchall()
            if not violations:
                self.log_test("Foreign Key Integrity", True, "No violations found", "database")
            else:
                self.log_test("Foreign Key Integrity", False, f"{len(violations)} violations found", "database")
                self.log_integration_issue("Database", f"Foreign key violations: {violations}")
            
            await close_db_connection(conn)
            
        except Exception as e:
            self.log_test("Database Integrity", False, f"Error: {e}", "database")
            self.log_integration_issue("Database", f"Database integrity test failed: {e}")

    async def test_authentication_workflow_advanced(self):
        """تست پیشرفته جریان احراز هویت"""
        print("\n🔐 تست پیشرفته جریان احراز هویت...")
        
        # تست ثبت‌نام و لاگین
        test_username = f"advanced_user_{secrets.token_hex(4)}"
        test_email = f"{test_username}@test.com"
        test_password = "AdvancedTest123!@#"
        
        try:
            conn = await get_db_connection()
            
            # ایجاد کاربر
            password_hash = hash_password(test_password)
            await conn.execute(
                'INSERT INTO users (username, email, password_hash, role, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?)',
                (test_username, test_email, password_hash, "user", True, get_jalali_now_str())
            )
            await conn.commit()
            
            # تست لاگین موفق
            if verify_password(test_password, password_hash):
                self.log_test("Password Verification", True, "Password verified correctly", "authentication")
            else:
                self.log_test("Password Verification", False, "Password verification failed", "authentication")
                self.log_security_issue("Authentication", "Password verification failed", "critical")
            
            # تست ایجاد توکن
            token_data = {"sub": test_username, "role": "user", "ip": "192.168.1.100"}
            token = create_access_token(data=token_data)
            
            # تست verification توکن
            decoded_token = verify_token(token)
            if decoded_token and decoded_token.get("sub") == test_username:
                self.log_test("JWT Token Creation/Verification", True, "Token works correctly", "authentication")
            else:
                self.log_test("JWT Token Creation/Verification", False, "Token verification failed", "authentication")
                self.log_security_issue("Authentication", "JWT token verification failed", "critical")
            
            # تست توکن‌های نامعتبر
            invalid_tokens = ["", None, "invalid_token", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ0ZXN0In0.invalid"]
            for invalid_token in invalid_tokens:
                result = verify_token(invalid_token)
                if result is None:
                    self.log_test(f"Invalid Token Rejection - {str(invalid_token)[:20]}", True, "Invalid token rejected", "authentication")
                else:
                    self.log_test(f"Invalid Token Rejection - {str(invalid_token)[:20]}", False, "Invalid token accepted", "authentication")
                    self.log_security_issue("Authentication", f"Invalid token accepted: {invalid_token}", "high")
            
            # پاکسازی
            await conn.execute("DELETE FROM users WHERE username = ?", (test_username,))
            await conn.commit()
            await close_db_connection(conn)
            
        except Exception as e:
            self.log_test("Authentication Workflow", False, f"Error: {e}", "authentication")
            self.log_integration_issue("Authentication", f"Authentication workflow failed: {e}")

    async def test_google_oauth_advanced(self):
        """تست پیشرفته Google OAuth"""
        print("\n🌐 تست پیشرفته Google OAuth...")
        
        # تست ایجاد URL احراز هویت
        try:
            auth_url = await get_google_auth_url("test_state")
            if auth_url and "accounts.google.com" in auth_url:
                self.log_test("Google Auth URL Generation", True, "Auth URL generated correctly", "oauth")
            else:
                self.log_test("Google Auth URL Generation", False, "Invalid auth URL", "oauth")
                self.log_integration_issue("OAuth", "Failed to generate Google auth URL")
        except Exception as e:
            self.log_test("Google Auth URL Generation", False, f"Error: {e}", "oauth")
        
        # تست ایجاد کاربر Google
        try:
            google_user = GoogleUserInfo(
                id="test_google_id",
                email="test_google@test.com",
                name="Test Google User",
                picture="https://example.com/avatar.jpg",
                verified_email=True
            )
            
            result = await create_or_get_google_user(google_user)
            if result and "user_id" in result:
                self.log_test("Google User Creation", True, "Google user created/retrieved", "oauth")
            else:
                self.log_test("Google User Creation", False, "Failed to create Google user", "oauth")
                self.log_integration_issue("OAuth", "Failed to create Google user")
        except Exception as e:
            self.log_test("Google User Creation", False, f"Error: {e}", "oauth")
            self.log_integration_issue("OAuth", f"Google user creation failed: {e}")

    async def test_security_features_advanced(self):
        """تست پیشرفته ویژگی‌های امنیتی"""
        print("\n🛡️ تست پیشرفته ویژگی‌های امنیتی...")
        
        # تست Rate Limiting پیشرفته
        test_ip = "203.0.113.100"
        start_time = time.time()
        
        # تست 15 درخواست اول
        for i in range(15):
            result = check_rate_limit(test_ip)
            if not result:
                self.log_test(f"Rate Limiting - Request {i+1}", False, "Blocked too early", "security")
                break
        else:
            # تست درخواست 16 (باید مسدود شود)
            result = check_rate_limit(test_ip)
            if not result:
                self.log_test("Rate Limiting Advanced", True, "Rate limiting working correctly", "security")
            else:
                self.log_test("Rate Limiting Advanced", False, "Not blocked when should be", "security")
                self.log_security_issue("Rate Limiting", "Rate limiting not working correctly", "high")
        
        # تست Login Attempts پیشرفته
        test_ip = "203.0.113.200"
        
        # تست 6 تلاش اول
        for i in range(6):
            result = check_login_attempts(test_ip)
            if not result:
                self.log_test(f"Login Attempts - Attempt {i+1}", False, "Blocked too early", "security")
                break
            record_login_attempt(test_ip, False)
        else:
            # تست تلاش 7 (باید مسدود شود)
            result = check_login_attempts(test_ip)
            if not result:
                self.log_test("Login Attempts Advanced", True, "Login attempts limiting working correctly", "security")
            else:
                self.log_test("Login Attempts Advanced", False, "Not blocked when should be", "security")
                self.log_security_issue("Login Attempts", "Login attempts limiting not working correctly", "high")
        
        # تست Input Sanitization پیشرفته
        malicious_inputs = [
            ("<script>alert('xss')</script>", "XSS"),
            ("admin' OR '1'='1", "SQL Injection"),
            ("javascript:alert('xss')", "XSS"),
            ("'; DROP TABLE users; --", "SQL Injection"),
            ("<img src=x onerror=alert('xss')>", "XSS"),
            ("admin' UNION SELECT * FROM users", "SQL Injection")
        ]
        
        for malicious_input, attack_type in malicious_inputs:
            sanitized = sanitize_input(malicious_input)
            if sanitized != malicious_input:
                self.log_test(f"Input Sanitization - {attack_type}", True, "Malicious input sanitized", "security")
            else:
                self.log_test(f"Input Sanitization - {attack_type}", False, "Malicious input not sanitized", "security")
                self.log_security_issue("Input Sanitization", f"{attack_type} not prevented", "high")

    async def test_performance_stress_advanced(self):
        """تست پیشرفته عملکرد و استرس"""
        print("\n⚡ تست پیشرفته عملکرد و استرس...")
        
        # تست ایجاد کاربران در حجم بالا
        start_time = time.time()
        users_created = 0
        
        try:
            conn = await get_db_connection()
            
            for i in range(100):
                username = f"stress_user_{secrets.token_hex(4)}"
                email = f"{username}@test.com"
                password_hash = hash_password("test123")
                
                await conn.execute(
                    'INSERT INTO users (username, email, password_hash, role, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?)',
                    (username, email, password_hash, "user", True, get_jalali_now_str())
                )
                users_created += 1
            
            await conn.commit()
            end_time = time.time()
            time_taken = end_time - start_time
            users_per_second = users_created / time_taken
            
            self.log_test("Bulk User Creation", True, f"Created {users_created} users in {time_taken:.2f}s ({users_per_second:.2f} users/s)", "performance")
            self.log_performance("user_creation_rate", users_per_second, "users/s")
            
            # پاکسازی
            await conn.execute("DELETE FROM users WHERE username LIKE 'stress_user_%'")
            await conn.commit()
            await close_db_connection(conn)
            
        except Exception as e:
            self.log_test("Bulk User Creation", False, f"Error: {e}", "performance")
            self.log_integration_issue("Performance", f"Bulk user creation failed: {e}")
        
        # تست لاگین همزمان
        start_time = time.time()
        successful_logins = 0
        
        for i in range(50):
            try:
                password = "test123"
                hashed = hash_password(password)
                if verify_password(password, hashed):
                    successful_logins += 1
            except Exception:
                pass
        
        end_time = time.time()
        time_taken = end_time - start_time
        logins_per_second = successful_logins / time_taken
        
        self.log_test("Bulk Login Performance", True, f"{successful_logins}/50 logins in {time_taken:.2f}s ({logins_per_second:.2f} logins/s)", "performance")
        self.log_performance("login_rate", logins_per_second, "logins/s")

    async def test_system_operations_advanced(self):
        """تست پیشرفته عملیات سیستم"""
        print("\n⚙️ تست پیشرفته عملیات سیستم...")
        
        # تست کنترل سروو
        try:
            await insert_servo_command(90, 45)
            self.log_test("Servo Control", True, "Servo command inserted", "operations")
        except Exception as e:
            self.log_test("Servo Control", False, f"Error: {e}", "operations")
            self.log_integration_issue("Operations", f"Servo control failed: {e}")
        
        # تست کنترل عملیات
        try:
            await insert_action_command("test_action", 75)
            self.log_test("Action Control", True, "Action command inserted", "operations")
        except Exception as e:
            self.log_test("Action Control", False, f"Error: {e}", "operations")
            self.log_integration_issue("Operations", f"Action control failed: {e}")
        
        # تست حالت دستگاه
        try:
            await insert_device_mode_command("mobile")
            self.log_test("Device Mode Control", True, "Device mode command inserted", "operations")
        except Exception as e:
            self.log_test("Device Mode Control", False, f"Error: {e}", "operations")
            self.log_integration_issue("Operations", f"Device mode control failed: {e}")
        
        # تست مدیریت عکس
        try:
            filename = f"advanced_test_{secrets.token_hex(4)}.jpg"
            filepath = f"gallery/{filename}"
            await insert_photo_to_db(filename, filepath, 85, True, 60)
            self.log_test("Photo Management", True, f"Photo inserted: {filename}", "operations")
        except Exception as e:
            self.log_test("Photo Management", False, f"Error: {e}", "operations")
            self.log_integration_issue("Operations", f"Photo management failed: {e}")
        
        # تست سیستم لاگینگ
        try:
            test_message = f"Advanced test log {secrets.token_hex(4)}"
            await insert_log(test_message, "advanced_test", "system_test")
            self.log_test("Logging System", True, f"Log inserted: {test_message[:30]}...", "operations")
        except Exception as e:
            self.log_test("Logging System", False, f"Error: {e}", "operations")
            self.log_integration_issue("Operations", f"Logging system failed: {e}")

    async def test_edge_cases_advanced(self):
        """تست پیشرفته موارد خاص"""
        print("\n🔍 تست پیشرفته موارد خاص...")
        
        # تست ورودی‌های خالی و null
        empty_inputs = ["", "   ", None]
        for empty_input in empty_inputs:
            try:
                sanitized = sanitize_input(empty_input)
                if sanitized == "" or sanitized is None:
                    self.log_test(f"Empty Input Handling - {empty_input}", True, "Empty input handled correctly", "edge_cases")
                else:
                    self.log_test(f"Empty Input Handling - {empty_input}", False, "Empty input not handled correctly", "edge_cases")
            except Exception as e:
                self.log_test(f"Empty Input Handling - {empty_input}", False, f"Error: {e}", "edge_cases")
        
        # تست ورودی‌های طولانی
        long_input = "a" * 10000
        try:
            sanitized = sanitize_input(long_input)
            if len(sanitized) <= 10000:
                self.log_test("Long Input Handling", True, "Long input handled correctly", "edge_cases")
            else:
                self.log_test("Long Input Handling", False, "Long input not handled correctly", "edge_cases")
        except Exception as e:
            self.log_test("Long Input Handling", False, f"Error: {e}", "edge_cases")
        
        # تست کاراکترهای خاص
        special_chars = "!@#$%^&*()_+-=[]{}|;:,.<>?`~"
        try:
            sanitized = sanitize_input(special_chars)
            preserved_count = 0
            for char in special_chars:
                if char in sanitized or char.replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;').replace("'", '&#39;') in sanitized:
                    preserved_count += 1
            
            if preserved_count >= len(special_chars) * 0.8:
                self.log_test("Special Characters Handling", True, f"Special characters preserved ({preserved_count}/{len(special_chars)})", "edge_cases")
            else:
                self.log_test("Special Characters Handling", False, f"Special characters not preserved ({preserved_count}/{len(special_chars)})", "edge_cases")
        except Exception as e:
            self.log_test("Special Characters Handling", False, f"Error: {e}", "edge_cases")
        
        # تست کاراکترهای Unicode
        unicode_chars = "سلام دنیا 🌍 🚀 💻"
        try:
            sanitized = sanitize_input(unicode_chars)
            if sanitized == unicode_chars:
                self.log_test("Unicode Handling", True, "Unicode characters preserved", "edge_cases")
            else:
                self.log_test("Unicode Handling", False, "Unicode characters not preserved", "edge_cases")
        except Exception as e:
            self.log_test("Unicode Handling", False, f"Error: {e}", "edge_cases")

    async def test_integration_workflow_advanced(self):
        """تست پیشرفته جریان یکپارچگی"""
        print("\n🔄 تست پیشرفته جریان یکپارچگی...")
        
        # تست جریان کامل end-to-end
        test_username = f"integration_user_{secrets.token_hex(4)}"
        test_email = f"{test_username}@test.com"
        
        try:
            conn = await get_db_connection()
            
            # 1. ایجاد کاربر
            password_hash = hash_password("test123")
            await conn.execute(
                'INSERT INTO users (username, email, password_hash, role, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?)',
                (test_username, test_email, password_hash, "user", True, get_jalali_now_str())
            )
            await conn.commit()
            
            # 2. ایجاد توکن
            token_data = {"sub": test_username, "role": "user", "ip": "192.168.1.1"}
            token = create_access_token(data=token_data)
            
            # 3. بررسی توکن
            decoded_token = verify_token(token)
            if not decoded_token:
                self.log_test("Integration - Token Verification", False, "Token verification failed", "integration")
                return
            
            # 4. ثبت عملیات‌های مختلف
            await insert_servo_command(90, 45)
            await insert_action_command("integration_test", 50)
            await insert_device_mode_command("desktop")
            await insert_log("Integration test log", "integration", "system_test")
            
            # 5. بررسی در دیتابیس
            cursor = await conn.execute("SELECT COUNT(*) FROM servo_commands WHERE servo1 = 90 AND servo2 = 45")
            servo_count = await cursor.fetchone()
            
            cursor = await conn.execute("SELECT COUNT(*) FROM action_commands WHERE action = 'integration_test'")
            action_count = await cursor.fetchone()
            
            cursor = await conn.execute("SELECT COUNT(*) FROM device_mode_commands WHERE device_mode = 'desktop'")
            mode_count = await cursor.fetchone()
            
            if servo_count[0] > 0 and action_count[0] > 0 and mode_count[0] > 0:
                self.log_test("Integration Workflow", True, "All operations completed successfully", "integration")
            else:
                self.log_test("Integration Workflow", False, "Some operations failed", "integration")
                self.log_integration_issue("Integration", "Integration workflow incomplete")
            
            # پاکسازی
            await conn.execute("DELETE FROM users WHERE username = ?", (test_username,))
            await conn.commit()
            await close_db_connection(conn)
            
        except Exception as e:
            self.log_test("Integration Workflow", False, f"Error: {e}", "integration")
            self.log_integration_issue("Integration", f"Integration workflow failed: {e}")

    async def run_all_tests(self):
        """اجرای تمام تست‌ها"""
        print("🚀 شروع تست فوق پیشرفته و جامع نهایی")
        print("=" * 80)
        
        # راه‌اندازی دیتابیس
        try:
            await init_db()
            print("✅ دیتابیس راه‌اندازی شد")
        except Exception as e:
            print(f"❌ خطا در راه‌اندازی دیتابیس: {e}")
            return False
        
        # اجرای تست‌ها
        await self.test_database_integrity_advanced()
        await self.test_authentication_workflow_advanced()
        await self.test_google_oauth_advanced()
        await self.test_security_features_advanced()
        await self.test_performance_stress_advanced()
        await self.test_system_operations_advanced()
        await self.test_edge_cases_advanced()
        await self.test_integration_workflow_advanced()
        
        # محاسبه نتایج
        total_tests = len(self.test_results)
        passed_tests = len([r for r in self.test_results if r["passed"]])
        failed_tests = total_tests - passed_tests
        success_rate = (passed_tests / total_tests * 100) if total_tests > 0 else 0
        
        # گزارش نهایی
        print("\n" + "=" * 80)
        print("📊 گزارش نهایی تست فوق پیشرفته و جامع")
        print("=" * 80)
        
        print(f"📈 آمار کلی:")
        print(f"   کل تست‌ها: {total_tests}")
        print(f"   تست‌های موفق: {passed_tests}")
        print(f"   تست‌های ناموفق: {failed_tests}")
        print(f"   نرخ موفقیت: {success_rate:.1f}%")
        
        # آمار بر اساس دسته‌بندی
        categories = {}
        for result in self.test_results:
            cat = result["category"]
            if cat not in categories:
                categories[cat] = {"total": 0, "passed": 0}
            categories[cat]["total"] += 1
            if result["passed"]:
                categories[cat]["passed"] += 1
        
        print(f"\n📋 آمار بر اساس دسته‌بندی:")
        for category, stats in categories.items():
            cat_success_rate = (stats["passed"] / stats["total"] * 100) if stats["total"] > 0 else 0
            print(f"   {category}: {stats['passed']}/{stats['total']} ({cat_success_rate:.1f}%)")
        
        # معیارهای عملکرد
        if self.performance_metrics:
            print(f"\n⚡ معیارهای عملکرد:")
            for metric, data in self.performance_metrics.items():
                print(f"   {metric}: {data['value']:.2f} {data['unit']}")
        
        # مشکلات امنیتی
        if self.security_issues:
            print(f"\n🔒 مشکلات امنیتی ({len(self.security_issues)}):")
            for issue in self.security_issues:
                print(f"   - {issue['component']}: {issue['description']} (شدت: {issue['severity']})")
        else:
            print(f"\n✅ هیچ مشکل امنیتی یافت نشد!")
        
        # مشکلات یکپارچگی
        if self.integration_issues:
            print(f"\n🔗 مشکلات یکپارچگی ({len(self.integration_issues)}):")
            for issue in self.integration_issues:
                print(f"   - {issue['component']}: {issue['description']}")
        else:
            print(f"\n✅ هیچ مشکل یکپارچگی یافت نشد!")
        
        # زمان اجرا
        total_time = time.time() - self.start_time
        print(f"\n⏱️ زمان کل اجرا: {total_time:.2f} ثانیه")
        
        # نتیجه نهایی
        if success_rate >= 95 and not self.security_issues:
            print(f"\n🎉 سیستم در وضعیت عالی و آماده production است!")
            return True
        elif success_rate >= 90:
            print(f"\n✅ سیستم در وضعیت خوب است، بهبودهای جزئی توصیه می‌شود")
            return True
        else:
            print(f"\n⚠️ سیستم نیاز به بهبود دارد")
            return False

async def main():
    """تابع اصلی"""
    tester = UltimateComprehensiveTester()
    success = await tester.run_all_tests()
    
    # ذخیره نتایج در فایل
    results = {
        "timestamp": datetime.now().isoformat(),
        "success": success,
        "test_results": tester.test_results,
        "performance_metrics": tester.performance_metrics,
        "security_issues": tester.security_issues,
        "integration_issues": tester.integration_issues
    }
    
    try:
        with open("ultimate_test_results.json", "w", encoding="utf-8") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        print(f"\n💾 نتایج در فایل ultimate_test_results.json ذخیره شد")
    except Exception as e:
        print(f"\n⚠️ خطا در ذخیره نتایج: {e}")
    
    return success

if __name__ == "__main__":
    asyncio.run(main()) 