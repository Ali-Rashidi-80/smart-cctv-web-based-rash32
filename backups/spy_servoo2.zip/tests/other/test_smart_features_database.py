#!/usr/bin/env python3
"""
Test Smart Features Database Storage
"""

import asyncio
import aiosqlite
import json
from datetime import datetime

async def test_smart_features_database():
    """Test smart features database storage and retrieval"""
    print("🧪 Testing Smart Features Database Storage")
    print("=" * 50)
    
    try:
        # Connect to database
        conn = await aiosqlite.connect('smart_camera_system.db')
        
        # Test 1: Insert settings for admin user
        print("\n1️⃣ Testing admin user settings...")
        admin_settings = {
            'username': 'rof642fr',
            'ip': '127.0.0.1',
            'theme': 'dark',
            'language': 'fa',
            'servo1': 90,
            'servo2': 90,
            'smart_motion': True,
            'smart_tracking': False,
            'updated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        await conn.execute('''
            INSERT OR REPLACE INTO user_settings 
            (username, ip, theme, language, servo1, servo2, smart_motion, smart_tracking, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            admin_settings['username'], admin_settings['ip'], admin_settings['theme'],
            admin_settings['language'], admin_settings['servo1'], admin_settings['servo2'],
            admin_settings['smart_motion'], admin_settings['smart_tracking'], admin_settings['updated_at']
        ))
        await conn.commit()
        print("✅ Admin settings saved")
        
        # Test 2: Insert settings for regular user
        print("\n2️⃣ Testing regular user settings...")
        user_settings = {
            'username': 'testuser',
            'ip': '192.168.1.100',
            'theme': 'light',
            'language': 'en',
            'servo1': 45,
            'servo2': 135,
            'smart_motion': False,
            'smart_tracking': True,
            'updated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        await conn.execute('''
            INSERT OR REPLACE INTO user_settings 
            (username, ip, theme, language, servo1, servo2, smart_motion, smart_tracking, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            user_settings['username'], user_settings['ip'], user_settings['theme'],
            user_settings['language'], user_settings['servo1'], user_settings['servo2'],
            user_settings['smart_motion'], user_settings['smart_tracking'], user_settings['updated_at']
        ))
        await conn.commit()
        print("✅ Regular user settings saved")
        
        # Test 3: Retrieve admin settings
        print("\n3️⃣ Retrieving admin settings...")
        cursor = await conn.execute('''
            SELECT username, ip, theme, language, servo1, servo2, smart_motion, smart_tracking, updated_at
            FROM user_settings WHERE username = ?
        ''', ('rof642fr',))
        admin_data = await cursor.fetchone()
        
        if admin_data:
            print(f"✅ Admin settings retrieved:")
            print(f"   Username: {admin_data[0]}")
            print(f"   IP: {admin_data[1]}")
            print(f"   Theme: {admin_data[2]}")
            print(f"   Language: {admin_data[3]}")
            print(f"   Servo1: {admin_data[4]}°")
            print(f"   Servo2: {admin_data[5]}°")
            print(f"   Smart Motion: {admin_data[6]}")
            print(f"   Smart Tracking: {admin_data[7]}")
            print(f"   Updated: {admin_data[8]}")
        else:
            print("❌ Admin settings not found")
        
        # Test 4: Retrieve regular user settings
        print("\n4️⃣ Retrieving regular user settings...")
        cursor = await conn.execute('''
            SELECT username, ip, theme, language, servo1, servo2, smart_motion, smart_tracking, updated_at
            FROM user_settings WHERE username = ?
        ''', ('testuser',))
        user_data = await cursor.fetchone()
        
        if user_data:
            print(f"✅ Regular user settings retrieved:")
            print(f"   Username: {user_data[0]}")
            print(f"   IP: {user_data[1]}")
            print(f"   Theme: {user_data[2]}")
            print(f"   Language: {user_data[3]}")
            print(f"   Servo1: {user_data[4]}°")
            print(f"   Servo2: {user_data[5]}°")
            print(f"   Smart Motion: {user_data[6]}")
            print(f"   Smart Tracking: {user_data[7]}")
            print(f"   Updated: {user_data[8]}")
        else:
            print("❌ Regular user settings not found")
        
        # Test 5: Show all records
        print("\n5️⃣ All records in database:")
        cursor = await conn.execute('''
            SELECT username, ip, theme, language, servo1, servo2, smart_motion, smart_tracking, updated_at
            FROM user_settings ORDER BY updated_at DESC
        ''')
        all_records = await cursor.fetchall()
        
        if all_records:
            for i, record in enumerate(all_records, 1):
                print(f"   Record {i}: {record}")
        else:
            print("   No records found")
        
        await conn.close()
        print("\n🎉 Smart features database test completed successfully!")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_smart_features_database()) 