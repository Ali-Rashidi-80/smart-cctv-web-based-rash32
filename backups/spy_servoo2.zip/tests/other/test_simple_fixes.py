#!/usr/bin/env python3
"""
🔧 Simple Test Script for WebSocket Authentication Fixes
Tests the key fixes for Pico connection issues
"""

import asyncio
import json
import websockets
import requests
from datetime import datetime

# Test configuration
SERVER_URL = "http://localhost:3000"
PICO_WS_URL = "ws://localhost:3000/ws/pico"

# Test tokens
PICO_TOKEN = "rof642fr:5q\\0EKU@A@Tv"
INVALID_TOKEN = "invalid_token_123"

async def test_pico_websocket_connection():
    """Test Pico WebSocket connection with correct token"""
    print("🔧 Testing Pico WebSocket connection...")
    
    try:
        # Test with valid token
        headers = {"Authorization": f"Bearer {PICO_TOKEN}"}
        print(f"🔑 Using token: {PICO_TOKEN[:10]}...")
        
        async with websockets.connect(PICO_WS_URL, extra_headers=headers) as websocket:
            print("✅ WebSocket connection established!")
            
            # Send a test message
            test_message = {
                "type": "ping",
                "device": "pico",
                "timestamp": datetime.now().isoformat()
            }
            await websocket.send(json.dumps(test_message))
            print("📤 Test message sent")
            
            # Wait for response
            response = await asyncio.wait_for(websocket.recv(), timeout=5)
            data = json.loads(response)
            print(f"📥 Received response: {data}")
            
            if data.get("type") == "ping":
                print("✅ Pico WebSocket authentication working correctly!")
                return True
            else:
                print(f"⚠️ Unexpected response type: {data.get('type')}")
                return False
                
    except websockets.exceptions.ConnectionClosed as e:
        print(f"❌ Connection closed with code {e.code}: {e.reason}")
        return False
    except Exception as e:
        print(f"❌ Connection failed: {e}")
        return False

async def test_pico_websocket_invalid_token():
    """Test Pico WebSocket with invalid token"""
    print("\n🔧 Testing Pico WebSocket with invalid token...")
    
    try:
        headers = {"Authorization": f"Bearer {INVALID_TOKEN}"}
        print(f"🔑 Using invalid token: {INVALID_TOKEN}")
        
        async with websockets.connect(PICO_WS_URL, extra_headers=headers) as websocket:
            print("❌ Connection should have been rejected!")
            return False
            
    except websockets.exceptions.ConnectionClosed as e:
        if e.code == 4001:
            print("✅ Invalid token properly rejected!")
            return True
        else:
            print(f"⚠️ Wrong close code: {e.code}")
            return False
    except Exception as e:
        print(f"✅ Connection rejected as expected: {e}")
        return True

async def test_server_health():
    """Test server health"""
    print("🔧 Testing server health...")
    
    try:
        response = requests.get(f"{SERVER_URL}/health", timeout=5)
        if response.status_code == 200:
            print("✅ Server is healthy!")
            return True
        else:
            print(f"❌ Server returned status {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Server not accessible: {e}")
        return False

async def main():
    """Main test function"""
    print("🚀 Starting Simple WebSocket Authentication Tests...")
    print("=" * 60)
    
    # Test server health first
    if not await test_server_health():
        print("\n❌ Server is not running. Please start the server first.")
        print("💡 Run: python server_fastapi.py")
        return
    
    # Test valid token
    valid_result = await test_pico_websocket_connection()
    
    # Test invalid token
    invalid_result = await test_pico_websocket_invalid_token()
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 Test Results:")
    print(f"✅ Valid token test: {'PASS' if valid_result else 'FAIL'}")
    print(f"✅ Invalid token test: {'PASS' if invalid_result else 'FAIL'}")
    
    if valid_result and invalid_result:
        print("\n🎉 All tests passed! WebSocket authentication is working correctly.")
        print("✅ Pico should now be able to connect to the server.")
    else:
        print("\n⚠️ Some tests failed. Please check the issues above.")

if __name__ == "__main__":
    asyncio.run(main()) 