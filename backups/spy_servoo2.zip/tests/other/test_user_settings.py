#!/usr/bin/env python3
"""
Test User Settings Save and Load
"""

import requests
import json
import time

BASE_URL = "http://localhost:3000"

def test_user_settings():
    """Test user settings save and load functionality"""
    print("🔍 Test User Settings Save and Load")
    print("=" * 40)
    
    session = requests.Session()
    
    # Login
    login_data = {
        "username": "rof642fr",
        "password": "5qEKU@A@Tv"
    }
    
    try:
        response = session.post(f"{BASE_URL}/login", json=login_data, timeout=5)
        if response.status_code != 200:
            print("❌ Login failed")
            return False
        print("✅ Login successful")
    except Exception as e:
        print(f"❌ Login error: {e}")
        return False
    
    # Test 1: Get initial settings
    print("\n1️⃣ Getting initial settings...")
    try:
        response = session.get(f"{BASE_URL}/get_user_settings", timeout=5)
        if response.status_code == 200:
            initial_settings = response.json()
            print(f"   Initial settings: {json.dumps(initial_settings, indent=2)}")
        else:
            print(f"   ❌ Failed to get settings: {response.status_code}")
            return False
    except Exception as e:
        print(f"   ❌ Error getting settings: {e}")
        return False
    
    # Test 2: Save new settings
    print("\n2️⃣ Saving new settings...")
    new_settings = {
        "device_mode": "mobile",
        "theme": "dark",
        "language": "en",
        "servo1": 45,
        "servo2": 135
    }
    
    try:
        response = session.post(f"{BASE_URL}/save_user_settings", json=new_settings, timeout=5)
        if response.status_code == 200:
            result = response.json()
            print(f"   Save result: {json.dumps(result, indent=2)}")
            if result.get("success"):
                print("   ✅ Settings saved successfully")
            else:
                print("   ❌ Settings save failed")
                return False
        else:
            print(f"   ❌ Failed to save settings: {response.status_code}")
            print(f"   Response: {response.text}")
            return False
    except Exception as e:
        print(f"   ❌ Error saving settings: {e}")
        return False
    
    # Test 3: Get settings again to verify save
    print("\n3️⃣ Getting settings after save...")
    try:
        response = session.get(f"{BASE_URL}/get_user_settings", timeout=5)
        if response.status_code == 200:
            saved_settings = response.json()
            print(f"   Saved settings: {json.dumps(saved_settings, indent=2)}")
            
            # Check if settings were actually saved
            settings_match = True
            saved_settings_data = saved_settings.get("settings", {})
            for key, value in new_settings.items():
                if saved_settings_data.get(key) != value:
                    print(f"   ❌ Setting mismatch: {key} = {saved_settings_data.get(key)} (expected {value})")
                    settings_match = False
            
            if settings_match:
                print("   ✅ All settings match saved values")
            else:
                print("   ❌ Some settings don't match")
                return False
        else:
            print(f"   ❌ Failed to get settings: {response.status_code}")
            return False
    except Exception as e:
        print(f"   ❌ Error getting settings: {e}")
        return False
    
    # Test 4: Test different settings
    print("\n4️⃣ Testing different settings...")
    different_settings = {
        "device_mode": "desktop",
        "theme": "light",
        "language": "fa",
        "servo1": 90,
        "servo2": 90
    }
    
    try:
        response = session.post(f"{BASE_URL}/save_user_settings", json=different_settings, timeout=5)
        if response.status_code == 200:
            result = response.json()
            if result.get("success"):
                print("   ✅ Different settings saved successfully")
            else:
                print("   ❌ Different settings save failed")
                return False
        else:
            print(f"   ❌ Failed to save different settings: {response.status_code}")
            return False
    except Exception as e:
        print(f"   ❌ Error saving different settings: {e}")
        return False
    
    # Test 5: Verify different settings
    print("\n5️⃣ Verifying different settings...")
    try:
        response = session.get(f"{BASE_URL}/get_user_settings", timeout=5)
        if response.status_code == 200:
            final_settings = response.json()
            print(f"   Final settings: {json.dumps(final_settings, indent=2)}")
            
            # Check if settings were actually saved
            settings_match = True
            final_settings_data = final_settings.get("settings", {})
            for key, value in different_settings.items():
                if final_settings_data.get(key) != value:
                    print(f"   ❌ Setting mismatch: {key} = {final_settings_data.get(key)} (expected {value})")
                    settings_match = False
            
            if settings_match:
                print("   ✅ All different settings match saved values")
                return True
            else:
                print("   ❌ Some different settings don't match")
                return False
        else:
            print(f"   ❌ Failed to get final settings: {response.status_code}")
            return False
    except Exception as e:
        print(f"   ❌ Error getting final settings: {e}")
        return False

def main():
    print("🚀 User Settings Test")
    print("Testing if user settings save and load correctly...")
    print()
    
    success = test_user_settings()
    
    print()
    if success:
        print("🎉 USER SETTINGS WORK CORRECTLY!")
        print("✅ Settings save successfully")
        print("✅ Settings load correctly")
        print("✅ Settings persist after changes")
        print("✅ Database integration works")
    else:
        print("⚠️ USER SETTINGS HAVE ISSUES")
        print("❌ Settings save/load not working properly")
        print("❌ Database integration may be broken")
    
    print("\n🏁 Test completed!")

if __name__ == "__main__":
    main() 