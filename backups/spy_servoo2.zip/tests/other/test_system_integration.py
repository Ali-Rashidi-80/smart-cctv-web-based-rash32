#!/usr/bin/env python3
"""
تست‌های یکپارچگی سیستم
System Integration Tests
"""

import sys
import os
import asyncio
import aiosqlite
import secrets
import time
import json
from datetime import datetime, timedelta
from typing import List, Dict, Any

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from server_fastapi import (
    init_db, 
    get_db_connection, 
    close_db_connection, 
    sanitize_input,
    create_access_token,
    verify_token,
    hash_password,
    verify_password,
    check_rate_limit,
    check_login_attempts,
    record_login_attempt,
    insert_log,
    insert_servo_command,
    insert_action_command,
    insert_device_mode_command,
    insert_photo_to_db
)

class SystemIntegrationTester:
    def __init__(self):
        self.test_results = []
        self.integration_issues = []
        
    def log_test(self, test_name: str, passed: bool, details: str = ""):
        """ثبت نتیجه تست"""
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status} {test_name}: {details}")
        self.test_results.append({
            "test": test_name,
            "passed": passed,
            "details": details,
            "timestamp": datetime.now().isoformat()
        })
        
    def log_integration_issue(self, component: str, description: str):
        """ثبت مشکل یکپارچگی"""
        print(f"🔗 INTEGRATION ISSUE - {component}: {description}")
        self.integration_issues.append({
            "component": component,
            "description": description,
            "timestamp": datetime.now().isoformat()
        })

    async def test_user_workflow_integration(self):
        """تست یکپارچگی جریان کاربر"""
        print("\n👤 تست یکپارچگی جریان کاربر...")
        
        try:
            conn = await get_db_connection()
            
            # ایجاد کاربر تست
            test_username = f"integration_user_{secrets.token_hex(4)}"
            test_email = f"{test_username}@test.com"
            password_hash = hash_password("test123")
            
            # درج کاربر
            await conn.execute(
                'INSERT INTO users (username, email, password_hash, role, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?)',
                (test_username, test_email, password_hash, "user", True, datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
            )
            await conn.commit()
            
            # ایجاد توکن
            token_data = {"sub": test_username, "role": "user", "ip": "192.168.1.1"}
            token = create_access_token(data=token_data)
            
            # بررسی توکن
            decoded_token = verify_token(token)
            
            if decoded_token and decoded_token.get("sub") == test_username:
                self.log_test("User Workflow - Token Creation/Verification", True)
            else:
                self.log_test("User Workflow - Token Creation/Verification", False, "Token verification failed")
                self.log_integration_issue("Authentication", "Token verification failed")
            
            # ثبت لاگ
            await insert_log(f"Integration test for user {test_username}", "test", "integration")
            
            # پاکسازی
            await conn.execute("DELETE FROM users WHERE username = ?", (test_username,))
            await conn.commit()
            
            await close_db_connection(conn)
            
        except Exception as e:
            self.log_test("User Workflow Integration", False, f"Error: {e}")
            self.log_integration_issue("User Management", f"Error in user workflow: {e}")

    async def test_servo_control_integration(self):
        """تست یکپارچگی کنترل سروو"""
        print("\n⚙️ تست یکپارچگی کنترل سروو...")
        
        try:
            # تست درج دستور سروو
            servo1_angle = 90
            servo2_angle = 45
            
            await insert_servo_command(servo1_angle, servo2_angle)
            
            # بررسی در دیتابیس
            conn = await get_db_connection()
            cursor = await conn.execute(
                "SELECT servo1, servo2 FROM servo_commands ORDER BY id DESC LIMIT 1"
            )
            result = await cursor.fetchone()
            
            if result and result[0] == servo1_angle and result[1] == servo2_angle:
                self.log_test("Servo Control Integration", True, f"Servo1: {servo1_angle}°, Servo2: {servo2_angle}°")
            else:
                self.log_test("Servo Control Integration", False, "Servo command not saved correctly")
                self.log_integration_issue("Servo Control", "Servo command not saved correctly")
            
            await close_db_connection(conn)
            
        except Exception as e:
            self.log_test("Servo Control Integration", False, f"Error: {e}")
            self.log_integration_issue("Servo Control", f"Error in servo control: {e}")

    async def test_action_control_integration(self):
        """تست یکپارچگی کنترل عملیات"""
        print("\n🎮 تست یکپارچگی کنترل عملیات...")
        
        try:
            # تست درج دستور عملیات
            action = "test_action"
            intensity = 75
            
            await insert_action_command(action, intensity)
            
            # بررسی در دیتابیس
            conn = await get_db_connection()
            cursor = await conn.execute(
                "SELECT action, intensity FROM action_commands ORDER BY id DESC LIMIT 1"
            )
            result = await cursor.fetchone()
            
            if result and result[0] == action and result[1] == intensity:
                self.log_test("Action Control Integration", True, f"Action: {action}, Intensity: {intensity}%")
            else:
                self.log_test("Action Control Integration", False, "Action command not saved correctly")
                self.log_integration_issue("Action Control", "Action command not saved correctly")
            
            await close_db_connection(conn)
            
        except Exception as e:
            self.log_test("Action Control Integration", False, f"Error: {e}")
            self.log_integration_issue("Action Control", f"Error in action control: {e}")

    async def test_device_mode_integration(self):
        """تست یکپارچگی حالت دستگاه"""
        print("\n📱 تست یکپارچگی حالت دستگاه...")
        
        try:
            # تست درج دستور حالت دستگاه
            device_mode = "mobile"
            
            await insert_device_mode_command(device_mode)
            
            # بررسی در دیتابیس
            conn = await get_db_connection()
            cursor = await conn.execute(
                "SELECT device_mode FROM device_mode_commands ORDER BY id DESC LIMIT 1"
            )
            result = await cursor.fetchone()
            
            if result and result[0] == device_mode:
                self.log_test("Device Mode Integration", True, f"Device Mode: {device_mode}")
            else:
                self.log_test("Device Mode Integration", False, "Device mode command not saved correctly")
                self.log_integration_issue("Device Mode", "Device mode command not saved correctly")
            
            await close_db_connection(conn)
            
        except Exception as e:
            self.log_test("Device Mode Integration", False, f"Error: {e}")
            self.log_integration_issue("Device Mode", f"Error in device mode: {e}")

    async def test_photo_management_integration(self):
        """تست یکپارچگی مدیریت عکس"""
        print("\n📸 تست یکپارچگی مدیریت عکس...")
        
        try:
            # تست درج عکس
            filename = f"integration_test_{secrets.token_hex(4)}.jpg"
            filepath = f"gallery/{filename}"
            quality = 85
            flash_used = True
            intensity = 60
            
            await insert_photo_to_db(filename, filepath, quality, flash_used, intensity)
            
            # بررسی در دیتابیس
            conn = await get_db_connection()
            cursor = await conn.execute(
                "SELECT filename, filepath, quality, flash_used, flash_intensity FROM manual_photos ORDER BY id DESC LIMIT 1"
            )
            result = await cursor.fetchone()
            
            if result and result[0] == filename and result[1] == filepath:
                self.log_test("Photo Management Integration", True, f"Photo: {filename}")
            else:
                self.log_test("Photo Management Integration", False, "Photo not saved correctly")
                self.log_integration_issue("Photo Management", "Photo not saved correctly")
            
            await close_db_connection(conn)
            
        except Exception as e:
            self.log_test("Photo Management Integration", False, f"Error: {e}")
            self.log_integration_issue("Photo Management", f"Error in photo management: {e}")

    async def test_logging_integration(self):
        """تست یکپارچگی سیستم لاگینگ"""
        print("\n📝 تست یکپارچگی سیستم لاگینگ...")
        
        try:
            # تست درج لاگ
            test_message = f"Integration test log {secrets.token_hex(4)}"
            log_type = "integration_test"
            source = "system_integration"
            
            await insert_log(test_message, log_type, source)
            
            # بررسی در دیتابیس
            conn = await get_db_connection()
            cursor = await conn.execute(
                "SELECT message, log_type, source FROM camera_logs WHERE message LIKE ? ORDER BY id DESC LIMIT 1",
                (f"%{test_message[-8:]}%",)  # جستجو بر اساس بخشی از پیام
            )
            result = await cursor.fetchone()
            
            if result and test_message in result[0]:
                self.log_test("Logging Integration", True, f"Log: {test_message[:30]}...")
            else:
                self.log_test("Logging Integration", False, "Log not saved correctly")
                self.log_integration_issue("Logging", "Log not saved correctly")
            
            await close_db_connection(conn)
            
        except Exception as e:
            self.log_test("Logging Integration", False, f"Error: {e}")
            self.log_integration_issue("Logging", f"Error in logging: {e}")

    async def test_rate_limiting_integration(self):
        """تست یکپارچگی Rate Limiting"""
        print("\n⏱️ تست یکپارچگی Rate Limiting...")
        
        test_ip = "192.168.1.100"
        
        # تست rate limiting
        for i in range(15):
            result = check_rate_limit(test_ip)
            if i < 15:  # باید اجازه داده شود
                if not result:
                    self.log_test(f"Rate Limiting Integration - Request {i+1}", False, "Blocked too early")
                    self.log_integration_issue("Rate Limiting", f"Request {i+1} blocked too early")
                    break
            else:
                if result:
                    self.log_test(f"Rate Limiting Integration - Request {i+1}", False, "Not blocked when should be")
                    self.log_integration_issue("Rate Limiting", f"Request {i+1} not blocked when should be")
                    break
        else:
            self.log_test("Rate Limiting Integration", True, "Rate limiting working correctly")

    async def test_login_attempts_integration(self):
        """تست یکپارچگی Login Attempts"""
        print("\n🔐 تست یکپارچگی Login Attempts...")
        
        test_ip = "203.0.113.100"  # IP که در skip list نیست
        
        # تست login attempts
        for i in range(7):
            result = check_login_attempts(test_ip)
            if i < 6:  # باید اجازه داده شود
                if not result:
                    self.log_test(f"Login Attempts Integration - Attempt {i+1}", False, "Blocked too early")
                    self.log_integration_issue("Login Attempts", f"Attempt {i+1} blocked too early")
                    break
                # ثبت تلاش ناموفق
                record_login_attempt(test_ip, False)
            else:
                if result:
                    self.log_test(f"Login Attempts Integration - Attempt {i+1}", False, "Not blocked when should be")
                    self.log_integration_issue("Login Attempts", f"Attempt {i+1} not blocked when should be")
                    break
        else:
            self.log_test("Login Attempts Integration", True, "Login attempts limiting working correctly")

    async def test_database_consistency(self):
        """تست سازگاری دیتابیس"""
        print("\n🗄️ تست سازگاری دیتابیس...")
        
        try:
            conn = await get_db_connection()
            
            # بررسی جداول اصلی
            tables = [
                "users",
                "camera_logs", 
                "servo_commands",
                "action_commands",
                "device_mode_commands",
                "manual_photos",
                "security_videos",
                "user_settings"
            ]
            
            for table in tables:
                cursor = await conn.execute(f"SELECT COUNT(*) FROM {table}")
                result = await cursor.fetchone()
                if result is not None:
                    self.log_test(f"Database Consistency - {table}", True, f"Count: {result[0]}")
                else:
                    self.log_test(f"Database Consistency - {table}", False, "Table not accessible")
                    self.log_integration_issue("Database", f"Table {table} not accessible")
            
            # بررسی foreign key constraints
            cursor = await conn.execute("PRAGMA foreign_key_check")
            result = await cursor.fetchone()
            if result is None:
                self.log_test("Database Consistency - Foreign Keys", True, "No foreign key violations")
            else:
                self.log_test("Database Consistency - Foreign Keys", False, "Foreign key violations found")
                self.log_integration_issue("Database", "Foreign key violations found")
            
            await close_db_connection(conn)
            
        except Exception as e:
            self.log_test("Database Consistency", False, f"Error: {e}")
            self.log_integration_issue("Database", f"Error in database consistency: {e}")

    async def test_end_to_end_workflow(self):
        """تست جریان end-to-end"""
        print("\n🔄 تست جریان end-to-end...")
        
        try:
            # ایجاد کاربر
            test_username = f"e2e_user_{secrets.token_hex(4)}"
            test_email = f"{test_username}@test.com"
            password_hash = hash_password("test123")
            
            conn = await get_db_connection()
            await conn.execute(
                'INSERT INTO users (username, email, password_hash, role, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?)',
                (test_username, test_email, password_hash, "user", True, datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
            )
            await conn.commit()
            
            # ایجاد توکن
            token_data = {"sub": test_username, "role": "user", "ip": "192.168.1.1"}
            token = create_access_token(data=token_data)
            
            # بررسی توکن
            decoded_token = verify_token(token)
            
            if not decoded_token:
                self.log_test("End-to-End Workflow", False, "Token verification failed")
                self.log_integration_issue("End-to-End", "Token verification failed")
                return
            
            # ثبت لاگ
            await insert_log(f"E2E test for user {test_username}", "test", "e2e")
            
            # درج دستور سروو
            await insert_servo_command(90, 45)
            
            # درج دستور عملیات
            await insert_action_command("e2e_test", 50)
            
            # درج دستور حالت دستگاه
            await insert_device_mode_command("desktop")
            
            # بررسی تمام عملیات
            cursor = await conn.execute("SELECT COUNT(*) FROM users WHERE username = ?", (test_username,))
            user_count = (await cursor.fetchone())[0]
            
            cursor = await conn.execute("SELECT COUNT(*) FROM camera_logs WHERE source = 'e2e'")
            log_count = (await cursor.fetchone())[0]
            
            cursor = await conn.execute("SELECT COUNT(*) FROM servo_commands WHERE servo1 = 90 AND servo2 = 45")
            servo_count = (await cursor.fetchone())[0]
            
            cursor = await conn.execute("SELECT COUNT(*) FROM action_commands WHERE action = 'e2e_test'")
            action_count = (await cursor.fetchone())[0]
            
            cursor = await conn.execute("SELECT COUNT(*) FROM device_mode_commands WHERE device_mode = 'desktop'")
            mode_count = (await cursor.fetchone())[0]
            
            if all([user_count > 0, log_count > 0, servo_count > 0, action_count > 0, mode_count > 0]):
                self.log_test("End-to-End Workflow", True, "All operations completed successfully")
            else:
                self.log_test("End-to-End Workflow", False, "Some operations failed")
                self.log_integration_issue("End-to-End", "Some operations failed in workflow")
            
            # پاکسازی
            await conn.execute("DELETE FROM users WHERE username = ?", (test_username,))
            await conn.execute("DELETE FROM camera_logs WHERE source = 'e2e'")
            await conn.execute("DELETE FROM servo_commands WHERE servo1 = 90 AND servo2 = 45")
            await conn.execute("DELETE FROM action_commands WHERE action = 'e2e_test'")
            await conn.execute("DELETE FROM device_mode_commands WHERE device_mode = 'desktop'")
            await conn.commit()
            
            await close_db_connection(conn)
            
        except Exception as e:
            self.log_test("End-to-End Workflow", False, f"Error: {e}")
            self.log_integration_issue("End-to-End", f"Error in end-to-end workflow: {e}")

    async def run_all_tests(self):
        """اجرای تمام تست‌ها"""
        print("🔗 تست‌های یکپارچگی سیستم")
        print("=" * 60)
        
        # راه‌اندازی دیتابیس
        try:
            await init_db()
            print("✅ دیتابیس راه‌اندازی شد")
        except Exception as e:
            print(f"❌ خطا در راه‌اندازی دیتابیس: {e}")
            return False
        
        # اجرای تست‌ها
        await self.test_user_workflow_integration()
        await self.test_servo_control_integration()
        await self.test_action_control_integration()
        await self.test_device_mode_integration()
        await self.test_photo_management_integration()
        await self.test_logging_integration()
        await self.test_rate_limiting_integration()
        await self.test_login_attempts_integration()
        await self.test_database_consistency()
        await self.test_end_to_end_workflow()
        
        # گزارش نهایی
        print("\n" + "=" * 60)
        print("📊 گزارش نهایی تست‌های یکپارچگی سیستم")
        print("=" * 60)
        
        passed = sum(1 for result in self.test_results if result["passed"])
        total = len(self.test_results)
        
        print(f"📈 آمار کلی:")
        print(f"   کل تست‌ها: {total}")
        print(f"   تست‌های موفق: {passed}")
        print(f"   تست‌های ناموفق: {total - passed}")
        print(f"   نرخ موفقیت: {(passed/total)*100:.1f}%")
        
        if self.integration_issues:
            print(f"\n🔗 مشکلات یکپارچگی یافت شده: {len(self.integration_issues)}")
            for issue in self.integration_issues:
                print(f"   - {issue['component']}: {issue['description']}")
        else:
            print(f"\n✅ هیچ مشکل یکپارچگی یافت نشد!")
        
        print(f"\n💡 توصیه‌ها:")
        if passed == total and not self.integration_issues:
            print("   - سیستم یکپارچگی در سطح عالی است!")
        else:
            print("   - برخی مشکلات یکپارچگی نیاز به بررسی دارند")
        
        return passed == total and not self.integration_issues

async def main():
    """تابع اصلی"""
    tester = SystemIntegrationTester()
    success = await tester.run_all_tests()
    
    if success:
        print("\n🎉 تمام تست‌های یکپارچگی سیستم موفق بودند!")
    else:
        print("\n⚠️ برخی تست‌های یکپارچگی سیستم ناموفق بودند!")

if __name__ == "__main__":
    asyncio.run(main())