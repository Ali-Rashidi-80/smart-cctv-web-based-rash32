#!/usr/bin/env python3
"""
Simple server connectivity test
"""

import asyncio
import httpx
import json

async def test_server():
    base_url = "http://localhost:3001"
    
    print("🔍 Testing server connectivity...")
    
    try:
        async with httpx.AsyncClient() as client:
            print(f"📡 Connecting to {base_url}/health...")
            response = await client.get(f"{base_url}/health", timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                print(f"✅ Server is running!")
                print(f"📊 Status: {data.get('status', 'unknown')}")
                print(f"🕐 Timestamp: {data.get('timestamp', 'unknown')}")
                print(f"🔌 WebSocket: {data.get('websocket_endpoint', 'unknown')}")
                print(f"🌐 Port: {data.get('server_port', 'unknown')}")
                return True
            else:
                print(f"❌ Health check failed: {response.status_code}")
                return False
                
    except Exception as e:
        print(f"❌ Connection failed: {e}")
        return False

if __name__ == "__main__":
    success = asyncio.run(test_server())
    if success:
        print("\n🎉 Server test passed!")
    else:
        print("\n💥 Server test failed!") 