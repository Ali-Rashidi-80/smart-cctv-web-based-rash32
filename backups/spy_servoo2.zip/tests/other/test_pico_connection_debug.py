#!/usr/bin/env python3
"""
تست جامع اتصال پیکو به سرور WebSocket
این فایل برای دیباگ مشکلات اتصال پیکو طراحی شده است
"""

import asyncio
import websockets
import json
import time
import sys
import os
from datetime import datetime

# تنظیمات تست
SERVER_HOST = "localhost"
SERVER_PORT = 3000
PICO_WS_URL = f"ws://{SERVER_HOST}:{SERVER_PORT}/ws/pico"
AUTH_TOKEN = "rof642fr:5qEKU@A@Tv"  # همان توکن پیکو

class PicoConnectionTester:
    def __init__(self):
        self.connection_success = False
        self.auth_success = False
        self.message_sent = False
        self.message_received = False
        self.errors = []
        
    def log(self, message, level="INFO"):
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        print(f"[{timestamp}] {level}: {message}")
        
    async def test_basic_connection(self):
        """تست اتصال پایه بدون احراز هویت"""
        self.log("=== تست اتصال پایه ===")
        try:
            async with websockets.connect(PICO_WS_URL) as websocket:
                self.log("✅ اتصال WebSocket موفق (بدون احراز هویت)")
                self.connection_success = True
                
                # ارسال پیام تست
                test_message = {
                    "type": "test",
                    "message": "Connection test from Python client",
                    "timestamp": datetime.now().isoformat()
                }
                await websocket.send(json.dumps(test_message))
                self.log("📤 پیام تست ارسال شد")
                
                # دریافت پاسخ
                try:
                    response = await asyncio.wait_for(websocket.recv(), timeout=5.0)
                    self.log(f"📥 پاسخ دریافت شد: {response}")
                    self.message_received = True
                except asyncio.TimeoutError:
                    self.log("⚠️ هیچ پاسخی دریافت نشد (timeout)")
                    
        except Exception as e:
            self.log(f"❌ خطا در اتصال پایه: {e}", "ERROR")
            self.errors.append(f"Basic connection error: {e}")
            
    async def test_authenticated_connection(self):
        """تست اتصال با احراز هویت"""
        self.log("=== تست اتصال با احراز هویت ===")
        try:
            headers = {
                "Authorization": f"Bearer {AUTH_TOKEN}"
            }
            
            async with websockets.connect(PICO_WS_URL, extra_headers=headers) as websocket:
                self.log("✅ اتصال WebSocket با احراز هویت موفق")
                self.auth_success = True
                
                # ارسال پیام اولیه مشابه پیکو
                initial_message = {
                    "type": "connect",
                    "device": "pico",
                    "timestamp": datetime.now().isoformat(),
                    "version": "1.0",
                    "servo1_angle": 90,
                    "servo2_angle": 90,
                    "auth_token": AUTH_TOKEN[:10] + "..."
                }
                await websocket.send(json.dumps(initial_message))
                self.log("📤 پیام اولیه ارسال شد")
                self.message_sent = True
                
                # دریافت پاسخ‌های سرور
                for i in range(5):  # حداکثر 5 پیام
                    try:
                        response = await asyncio.wait_for(websocket.recv(), timeout=3.0)
                        self.log(f"📥 پیام {i+1} از سرور: {response}")
                        
                        # پردازش پاسخ
                        try:
                            data = json.loads(response)
                            if data.get("type") == "connection":
                                self.log("✅ پیام تایید اتصال دریافت شد")
                            elif data.get("type") == "ping":
                                self.log("📥 Ping دریافت شد، ارسال Pong...")
                                await websocket.send(json.dumps({"type": "pong"}))
                            elif data.get("type") == "error":
                                self.log(f"❌ خطا از سرور: {data.get('message')}", "ERROR")
                        except json.JSONDecodeError:
                            self.log(f"⚠️ پاسخ غیر JSON: {response}")
                            
                    except asyncio.TimeoutError:
                        self.log("⏰ timeout در انتظار پیام")
                        break
                        
        except Exception as e:
            self.log(f"❌ خطا در اتصال با احراز هویت: {e}", "ERROR")
            self.errors.append(f"Authenticated connection error: {e}")
            
    async def test_pico_simulation(self):
        """شبیه‌سازی کامل رفتار پیکو"""
        self.log("=== شبیه‌سازی رفتار پیکو ===")
        try:
            headers = {
                "Authorization": f"Bearer {AUTH_TOKEN}"
            }
            
            async with websockets.connect(PICO_WS_URL, extra_headers=headers) as websocket:
                self.log("✅ اتصال شبیه‌سازی پیکو موفق")
                
                # ارسال پیام اولیه
                initial_message = {
                    "type": "connect",
                    "device": "pico",
                    "timestamp": datetime.now().isoformat(),
                    "version": "1.0",
                    "servo1_angle": 90,
                    "servo2_angle": 90,
                    "auth_token": AUTH_TOKEN[:10] + "..."
                }
                await websocket.send(json.dumps(initial_message))
                self.log("📤 پیام اولیه ارسال شد")
                
                # حلقه اصلی شبیه‌سازی پیکو
                start_time = time.time()
                message_count = 0
                
                while time.time() - start_time < 30:  # 30 ثانیه تست
                    try:
                        # دریافت پیام از سرور
                        message = await asyncio.wait_for(websocket.recv(), timeout=5.0)
                        message_count += 1
                        self.log(f"📥 پیام {message_count}: {message}")
                        
                        try:
                            data = json.loads(message)
                            
                            if data.get("type") == "ping":
                                # پاسخ به ping
                                pong_message = {"type": "pong", "timestamp": datetime.now().isoformat()}
                                await websocket.send(json.dumps(pong_message))
                                self.log("📤 Pong ارسال شد")
                                
                            elif data.get("type") == "servo":
                                # پاسخ به دستور سروو
                                servo_cmd = data.get("command", {})
                                ack_message = {
                                    "type": "ack",
                                    "command_type": "servo",
                                    "status": "success",
                                    "servo1": servo_cmd.get("servo1", 90),
                                    "servo2": servo_cmd.get("servo2", 90),
                                    "timestamp": datetime.now().isoformat()
                                }
                                await websocket.send(json.dumps(ack_message))
                                self.log(f"📤 ACK سروو ارسال شد: {servo_cmd}")
                                
                            elif data.get("type") == "action":
                                # پاسخ به دستور اکشن
                                action_cmd = data.get("command", {})
                                ack_message = {
                                    "type": "ack",
                                    "command_type": "action",
                                    "status": "success",
                                    "action": action_cmd.get("action", ""),
                                    "intensity": action_cmd.get("intensity", 50),
                                    "timestamp": datetime.now().isoformat()
                                }
                                await websocket.send(json.dumps(ack_message))
                                self.log(f"📤 ACK اکشن ارسال شد: {action_cmd}")
                                
                            elif data.get("type") == "connection":
                                self.log("✅ پیام تایید اتصال دریافت شد")
                                
                            elif data.get("type") == "error":
                                self.log(f"❌ خطا از سرور: {data.get('message')}", "ERROR")
                                
                        except json.JSONDecodeError:
                            self.log(f"⚠️ پیام غیر JSON: {message}")
                            
                    except asyncio.TimeoutError:
                        # ارسال ping هر 10 ثانیه
                        if message_count % 2 == 0:
                            ping_message = {"type": "ping", "timestamp": datetime.now().isoformat()}
                            await websocket.send(json.dumps(ping_message))
                            self.log("📤 Ping ارسال شد")
                        continue
                        
                self.log(f"✅ شبیه‌سازی پیکو کامل شد. {message_count} پیام تبادل شد.")
                
        except Exception as e:
            self.log(f"❌ خطا در شبیه‌سازی پیکو: {e}", "ERROR")
            self.errors.append(f"Pico simulation error: {e}")
            
    async def test_server_status(self):
        """تست وضعیت سرور"""
        self.log("=== تست وضعیت سرور ===")
        try:
            import aiohttp
            
            # تست endpoint های مختلف
            async with aiohttp.ClientSession() as session:
                # تست health check
                try:
                    async with session.get(f"http://{SERVER_HOST}:{SERVER_PORT}/health") as response:
                        if response.status == 200:
                            data = await response.json()
                            self.log(f"✅ Health check موفق: {data}")
                        else:
                            self.log(f"⚠️ Health check ناموفق: {response.status}")
                except Exception as e:
                    self.log(f"❌ خطا در health check: {e}", "ERROR")
                
                # تست pico status
                try:
                    async with session.get(f"http://{SERVER_HOST}:{SERVER_PORT}/pico/status") as response:
                        if response.status == 200:
                            data = await response.json()
                            self.log(f"✅ Pico status: {data}")
                        else:
                            self.log(f"⚠️ Pico status ناموفق: {response.status}")
                except Exception as e:
                    self.log(f"❌ خطا در pico status: {e}", "ERROR")
                    
        except ImportError:
            self.log("⚠️ aiohttp نصب نیست، تست HTTP رد شد")
        except Exception as e:
            self.log(f"❌ خطا در تست وضعیت سرور: {e}", "ERROR")
            
    def print_summary(self):
        """چاپ خلاصه نتایج"""
        self.log("=== خلاصه نتایج ===")
        self.log(f"اتصال پایه: {'✅ موفق' if self.connection_success else '❌ ناموفق'}")
        self.log(f"احراز هویت: {'✅ موفق' if self.auth_success else '❌ ناموفق'}")
        self.log(f"ارسال پیام: {'✅ موفق' if self.message_sent else '❌ ناموفق'}")
        self.log(f"دریافت پیام: {'✅ موفق' if self.message_received else '❌ ناموفق'}")
        
        if self.errors:
            self.log("=== خطاها ===")
            for i, error in enumerate(self.errors, 1):
                self.log(f"{i}. {error}", "ERROR")
        else:
            self.log("✅ هیچ خطایی رخ نداد")
            
    async def run_all_tests(self):
        """اجرای تمام تست‌ها"""
        self.log("🚀 شروع تست‌های اتصال پیکو")
        self.log(f"سرور: {SERVER_HOST}:{SERVER_PORT}")
        self.log(f"WebSocket URL: {PICO_WS_URL}")
        self.log(f"توکن: {AUTH_TOKEN[:10]}...")
        
        await self.test_server_status()
        await self.test_basic_connection()
        await self.test_authenticated_connection()
        await self.test_pico_simulation()
        
        self.print_summary()

async def main():
    """تابع اصلی"""
    tester = PicoConnectionTester()
    await tester.run_all_tests()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n⏹️ تست توسط کاربر متوقف شد")
    except Exception as e:
        print(f"❌ خطای غیرمنتظره: {e}")
        sys.exit(1) 