#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Login Debug Script
دیباگ لاگین
"""

import requests
import json

def test_login_debug():
    """تست دیباگ لاگین"""
    base_url = "http://localhost:3000"
    
    print("🔍 دیباگ لاگین")
    print("=" * 50)
    
    # تست login با admin
    print("🔐 تست لاگین با admin...")
    try:
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        data = {
            "username": "admin",
            "password": "admin123"
        }
        response = requests.post(f"{base_url}/login", 
                               json=data, 
                               headers=headers)
        print(f"   وضعیت: {response.status_code}")
        print(f"   Content-Type: {response.headers.get('content-type')}")
        print(f"   پاسخ: {response.text}")
        
        if response.status_code == 200:
            print("   ✅ لاگین موفق بود!")
        else:
            print("   ❌ لاگین ناموفق بود")
            
    except Exception as e:
        print(f"   ❌ خطا: {e}")
    
    print()
    
    # تست login با کاربر ناموجود
    print("🔐 تست لاگین با کاربر ناموجود...")
    try:
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        data = {
            "username": "nonexistent",
            "password": "wrongpass"
        }
        response = requests.post(f"{base_url}/login", 
                               json=data, 
                               headers=headers)
        print(f"   وضعیت: {response.status_code}")
        print(f"   Content-Type: {response.headers.get('content-type')}")
        print(f"   پاسخ: {response.text}")
        
    except Exception as e:
        print(f"   ❌ خطا: {e}")

if __name__ == "__main__":
    test_login_debug() 