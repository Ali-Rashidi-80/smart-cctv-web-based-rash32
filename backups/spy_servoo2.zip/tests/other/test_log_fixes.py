#!/usr/bin/env python3
"""
Test script to verify that logging fixes work correctly
"""

import sys
import os
import time
import threading
from io import StringIO

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.dynamic_port_manager import DynamicPortManager

def test_logging_fixes():
    """Test that logging fixes reduce repetitive logs"""
    print("🧪 Testing logging fixes...")
    print("=" * 50)
    
    # Capture stdout to check logs
    original_stdout = sys.stdout
    captured_output = StringIO()
    sys.stdout = captured_output
    
    try:
        # Create a DynamicPortManager with background logging disabled
        print("Creating DynamicPortManager with background logging disabled...")
        port_manager = DynamicPortManager(
            start=3000, 
            end=3010, 
            refresh_interval=2,  # Short interval for testing
            enable_background_logging=False
        )
        
        # Wait for a few refresh cycles
        print("Waiting for background refresh cycles...")
        time.sleep(6)  # Wait for 3 refresh cycles (2 seconds each)
        
        # Get the captured output
        output = captured_output.getvalue()
        
        # Check that we don't have repetitive REFRESH and CLEANUP logs
        refresh_count = output.count("REFRESH")
        cleanup_count = output.count("CLEANUP")
        
        print(f"Refresh logs found: {refresh_count}")
        print(f"Cleanup logs found: {cleanup_count}")
        
        # Should only have INIT log, no repetitive REFRESH/CLEANUP
        if refresh_count == 0 and cleanup_count == 0:
            print("✅ Background logging successfully disabled - no repetitive logs")
        else:
            print(f"❌ Still found repetitive logs: {refresh_count} refresh, {cleanup_count} cleanup")
            return False
            
        # Test with background logging enabled
        print("\nTesting with background logging enabled...")
        captured_output2 = StringIO()
        sys.stdout = captured_output2
        
        port_manager2 = DynamicPortManager(
            start=3000, 
            end=3010, 
            refresh_interval=2,
            enable_background_logging=True
        )
        
        time.sleep(6)  # Wait for 3 refresh cycles
        
        output2 = captured_output2.getvalue()
        refresh_count2 = output2.count("REFRESH")
        cleanup_count2 = output2.count("CLEANUP")
        
        print(f"Refresh logs found: {refresh_count2}")
        print(f"Cleanup logs found: {cleanup_count2}")
        
        # Should have some logs but not too many
        if refresh_count2 > 0 and cleanup_count2 > 0:
            print("✅ Background logging enabled - logs are present")
        else:
            print("❌ Background logging not working properly")
            return False
            
        # Clean up
        port_manager.stop()
        port_manager2.stop()
        
        print("\n✅ All logging tests passed!")
        return True
        
    except Exception as e:
        print(f"❌ Error during testing: {e}")
        return False
    finally:
        # Restore stdout
        sys.stdout = original_stdout

def test_refresh_interval():
    """Test that refresh interval is properly set"""
    print("\n🧪 Testing refresh interval...")
    
    # Test default refresh interval
    port_manager = DynamicPortManager()
    if port_manager.refresh_interval == 60:
        print("✅ Default refresh interval is 60 seconds")
    else:
        print(f"❌ Default refresh interval is {port_manager.refresh_interval}, expected 60")
        return False
    
    # Test custom refresh interval
    port_manager2 = DynamicPortManager(refresh_interval=30)
    if port_manager2.refresh_interval == 30:
        print("✅ Custom refresh interval works correctly")
    else:
        print(f"❌ Custom refresh interval is {port_manager2.refresh_interval}, expected 30")
        return False
    
    port_manager.stop()
    port_manager2.stop()
    return True

if __name__ == "__main__":
    print("🧪 Testing DynamicPortManager logging fixes...")
    print("=" * 60)
    
    success = True
    
    # Test refresh interval
    if not test_refresh_interval():
        success = False
    
    # Test logging fixes
    if not test_logging_fixes():
        success = False
    
    print("\n" + "=" * 60)
    if success:
        print("🎉 All tests passed! Logging fixes are working correctly.")
    else:
        print("❌ Some tests failed. Please check the implementation.")
    
    sys.exit(0 if success else 1) 