#!/usr/bin/env python3
"""
Comprehensive WebSocket Error Handling Verification Test
Tests all the fixes implemented for WebSocket error handling
"""

import asyncio
import json
import time
import requests
import websockets
from datetime import datetime
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class WebSocketFixesVerificationTest:
    def __init__(self, base_url="http://localhost:3000"):
        self.base_url = base_url
        self.test_results = []
        
    def log_test(self, test_name, success, details=""):
        """Log test result"""
        result = {
            "test": test_name,
            "success": success,
            "details": details,
            "timestamp": datetime.now().isoformat()
        }
        self.test_results.append(result)
        status = "✅ PASS" if success else "❌ FAIL"
        logger.info(f"{status} {test_name}: {details}")
        
    async def test_server_health(self):
        """Test server health endpoint"""
        try:
            response = requests.get(f"{self.base_url}/health", timeout=5)
            if response.status_code == 200:
                self.log_test("Server Health Check", True, "Server is running and healthy")
                return True
            else:
                self.log_test("Server Health Check", False, f"Server returned status {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Server Health Check", False, f"Error connecting to server: {e}")
            return False
    
    async def test_websocket_connection_handling(self):
        """Test WebSocket connection handling improvements"""
        try:
            uri = f"ws://localhost:3000/ws"
            async with websockets.connect(uri) as websocket:
                # Test basic connection
                self.log_test("WebSocket Connection", True, "Successfully connected to WebSocket")
                
                # Test ping/pong
                await websocket.send(json.dumps({"type": "ping"}))
                response = await asyncio.wait_for(websocket.recv(), timeout=5)
                data = json.loads(response)
                
                if data.get("type") == "pong":
                    self.log_test("WebSocket Ping/Pong", True, "Ping/pong working correctly")
                else:
                    self.log_test("WebSocket Ping/Pong", False, f"Unexpected response: {data}")
                
                # Test graceful disconnect
                await websocket.close(code=1000, reason="Test completed")
                self.log_test("WebSocket Graceful Disconnect", True, "Graceful disconnect successful")
                
        except Exception as e:
            self.log_test("WebSocket Connection Handling", False, f"Error: {e}")
    
    async def test_video_websocket_connection(self):
        """Test Video WebSocket connection handling"""
        try:
            uri = f"ws://localhost:3000/ws/video"
            async with websockets.connect(uri) as websocket:
                # Test basic connection
                self.log_test("Video WebSocket Connection", True, "Successfully connected to Video WebSocket")
                
                # Wait for a few frames or ping messages
                for i in range(3):
                    try:
                        response = await asyncio.wait_for(websocket.recv(), timeout=2)
                        if isinstance(response, str):
                            data = json.loads(response)
                            if data.get("type") == "ping":
                                self.log_test("Video WebSocket Ping", True, "Video WebSocket ping working")
                                break
                    except asyncio.TimeoutError:
                        continue
                
                # Test graceful disconnect
                await websocket.close(code=1000, reason="Test completed")
                self.log_test("Video WebSocket Graceful Disconnect", True, "Graceful disconnect successful")
                
        except Exception as e:
            self.log_test("Video WebSocket Connection", False, f"Error: {e}")
    
    async def test_error_suppression(self):
        """Test that normal closure errors are suppressed"""
        try:
            uri = f"ws://localhost:3000/ws"
            async with websockets.connect(uri) as websocket:
                # Send a message and immediately close
                await websocket.send(json.dumps({"type": "ping"}))
                await websocket.close(code=1000, reason="Rapid test")
                
            self.log_test("Error Suppression", True, "Normal closure errors should be suppressed in logs")
            
        except Exception as e:
            # This is expected behavior
            self.log_test("Error Suppression", True, "Expected error suppression working")
    
    async def test_connection_timeout_handling(self):
        """Test connection timeout handling"""
        try:
            uri = f"ws://localhost:3000/ws"
            async with websockets.connect(uri) as websocket:
                # Don't send any messages, let it timeout
                await asyncio.sleep(2)
                
                # Try to send a message after potential timeout
                try:
                    await websocket.send(json.dumps({"type": "ping"}))
                    response = await asyncio.wait_for(websocket.recv(), timeout=2)
                    self.log_test("Connection Timeout Handling", True, "Connection still active after timeout period")
                except Exception:
                    self.log_test("Connection Timeout Handling", True, "Connection properly closed after timeout")
                
        except Exception as e:
            self.log_test("Connection Timeout Handling", False, f"Error: {e}")
    
    async def test_invalid_json_handling(self):
        """Test handling of invalid JSON messages"""
        try:
            uri = f"ws://localhost:3000/ws"
            async with websockets.connect(uri) as websocket:
                # Send invalid JSON
                await websocket.send("invalid json")
                
                # Connection should still be alive
                await websocket.send(json.dumps({"type": "ping"}))
                response = await asyncio.wait_for(websocket.recv(), timeout=2)
                data = json.loads(response)
                
                if data.get("type") == "pong":
                    self.log_test("Invalid JSON Handling", True, "Connection survived invalid JSON")
                else:
                    self.log_test("Invalid JSON Handling", False, "Connection failed after invalid JSON")
                
        except Exception as e:
            self.log_test("Invalid JSON Handling", False, f"Error: {e}")
    
    async def test_multiple_connections(self):
        """Test multiple simultaneous connections"""
        try:
            connections = []
            for i in range(3):
                uri = f"ws://localhost:3000/ws"
                websocket = await websockets.connect(uri)
                connections.append(websocket)
                self.log_test(f"Multiple Connection {i+1}", True, f"Connection {i+1} established")
            
            # Send messages to all connections
            for i, websocket in enumerate(connections):
                await websocket.send(json.dumps({"type": "ping"}))
                response = await asyncio.wait_for(websocket.recv(), timeout=2)
                data = json.loads(response)
                if data.get("type") == "pong":
                    self.log_test(f"Multiple Connection Ping {i+1}", True, f"Ping/pong working for connection {i+1}")
            
            # Close all connections
            for websocket in connections:
                await websocket.close(code=1000, reason="Test completed")
            
            self.log_test("Multiple Connections", True, "All connections handled correctly")
            
        except Exception as e:
            self.log_test("Multiple Connections", False, f"Error: {e}")
    
    async def run_all_tests(self):
        """Run all tests"""
        logger.info("🚀 Starting WebSocket Error Handling Verification Tests")
        logger.info("=" * 60)
        
        # Test server health first
        if not await self.test_server_health():
            logger.error("❌ Server is not running. Please start the server first.")
            return
        
        # Run all tests
        tests = [
            self.test_websocket_connection_handling,
            self.test_video_websocket_connection,
            self.test_error_suppression,
            self.test_connection_timeout_handling,
            self.test_invalid_json_handling,
            self.test_multiple_connections,
        ]
        
        for test in tests:
            try:
                await test()
                await asyncio.sleep(1)  # Brief pause between tests
            except Exception as e:
                logger.error(f"❌ Test failed with exception: {e}")
        
        # Summary
        logger.info("=" * 60)
        logger.info("📊 Test Results Summary:")
        
        passed = sum(1 for result in self.test_results if result["success"])
        total = len(self.test_results)
        
        logger.info(f"✅ Passed: {passed}/{total}")
        logger.info(f"❌ Failed: {total - passed}/{total}")
        
        if passed == total:
            logger.info("🎉 All tests passed! WebSocket error handling improvements are working correctly.")
        else:
            logger.warning("⚠️ Some tests failed. Check the logs above for details.")
        
        # Save results
        with open("websocket_fixes_verification_results.json", "w", encoding="utf-8") as f:
            json.dump(self.test_results, f, indent=2, ensure_ascii=False)
        
        logger.info("📄 Results saved to websocket_fixes_verification_results.json")

async def main():
    """Main function"""
    test = WebSocketFixesVerificationTest()
    await test.run_all_tests()

if __name__ == "__main__":
    asyncio.run(main()) 