#!/usr/bin/env python3
"""
تست endpoint سروو برای عیب‌یابی
"""

import requests
import json
import time

def login_and_get_token():
    """لاگین و دریافت توکن"""
    base_url = "http://localhost:3001"
    
    login_data = {
        "username": "rof642fr",
        "password": "5q\\0EKU@A@Tv"
    }
    
    try:
        response = requests.post(
            f"{base_url}/login",
            json=login_data,
            headers={'Content-Type': 'application/json'},
            timeout=10
        )
        
        if response.status_code == 200:
            data = response.json()
            token = data.get('access_token')
            if token:
                print(f"✅ لاگین موفق! توکن دریافت شد")
                return token
            else:
                print(f"❌ توکن در پاسخ یافت نشد: {data}")
                return None
        else:
            print(f"❌ خطا در لاگین: {response.status_code} - {response.text}")
            return None
            
    except Exception as e:
        print(f"❌ خطا در لاگین: {e}")
        return None

def test_servo_endpoint():
    """تست endpoint سروو"""
    base_url = "http://localhost:3001"
    
    # تست 1: بررسی وضعیت سرور
    print("🔍 تست 1: بررسی وضعیت سرور...")
    try:
        response = requests.get(f"{base_url}/health", timeout=5)
        print(f"✅ سرور در دسترس است: {response.status_code}")
    except Exception as e:
        print(f"❌ سرور در دسترس نیست: {e}")
        return
    
    # تست 2: لاگین و دریافت توکن
    print("\n🔍 تست 2: لاگین و دریافت توکن...")
    token = login_and_get_token()
    if not token:
        print("❌ نتوانستیم لاگین کنیم. تست متوقف می‌شود.")
        return
    
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {token}'
    }
    
    # تست 3: بررسی وضعیت پیکو
    print("\n🔍 تست 3: بررسی وضعیت پیکو...")
    try:
        response = requests.get(f"{base_url}/pico/status", headers=headers, timeout=5)
        print(f"📥 پاسخ سرور: {response.status_code}")
        print(f"📄 پاسخ خام: {response.text[:200]}...")
        
        if response.status_code == 200 and response.text.strip():
            try:
                data = response.json()
                print(f"✅ وضعیت پیکو: {data}")
            except json.JSONDecodeError as e:
                print(f"❌ خطا در parse JSON: {e}")
        else:
            print(f"❌ خطا در دریافت وضعیت پیکو: {response.status_code}")
    except Exception as e:
        print(f"❌ خطا در بررسی وضعیت پیکو: {e}")
    
    # تست 4: ارسال دستور سروو
    print("\n🔍 تست 4: ارسال دستور سروو...")
    servo_data = {
        "servo1": 90,
        "servo2": 90
    }
    
    try:
        response = requests.post(
            f"{base_url}/set_servo",
            json=servo_data,
            headers=headers,
            timeout=10
        )
        
        print(f"📤 ارسال داده: {servo_data}")
        print(f"📥 پاسخ سرور: {response.status_code}")
        print(f"📄 پاسخ خام: {response.text[:200]}...")
        
        if response.status_code == 200 and response.text.strip():
            try:
                data = response.json()
                print(f"✅ موفقیت: {data}")
            except json.JSONDecodeError as e:
                print(f"❌ خطا در parse JSON: {e}")
        else:
            print(f"❌ خطا: {response.text}")
            
    except Exception as e:
        print(f"❌ خطا در ارسال دستور سروو: {e}")
    
    # تست 5: ارسال دستور reset
    print("\n🔍 تست 5: ارسال دستور reset...")
    reset_data = {
        "servo1": 90,
        "servo2": 90
    }
    
    try:
        response = requests.post(
            f"{base_url}/set_servo",
            json=reset_data,
            headers=headers,
            timeout=10
        )
        
        print(f"📤 ارسال داده reset: {reset_data}")
        print(f"📥 پاسخ سرور: {response.status_code}")
        print(f"📄 پاسخ خام: {response.text[:200]}...")
        
        if response.status_code == 200 and response.text.strip():
            try:
                data = response.json()
                print(f"✅ موفقیت: {data}")
            except json.JSONDecodeError as e:
                print(f"❌ خطا در parse JSON: {e}")
        else:
            print(f"❌ خطا: {response.text}")
            
    except Exception as e:
        print(f"❌ خطا در ارسال دستور reset: {e}")

if __name__ == "__main__":
    print("🚀 شروع تست endpoint سروو...")
    test_servo_endpoint()
    print("\n✅ تست کامل شد!")