#!/usr/bin/env python3
"""
تست ساده برای دیباگ مشکل احراز هویت پیکو
"""

import asyncio
import websockets
import json
import sys

async def test_pico_auth():
    """تست ساده احراز هویت پیکو"""
    url = "ws://localhost:3000/ws/pico"
    token = "rof642fr:5qEKU@A@Tv"  # بدون null byte
    
    print(f"🔍 تست اتصال به: {url}")
    print(f"🔑 توکن: {token}")
    
    # تست 1: بدون احراز هویت
    print("\n=== تست 1: بدون احراز هویت ===")
    try:
        async with websockets.connect(url) as ws:
            print("✅ اتصال بدون احراز هویت موفق")
            await ws.send(json.dumps({"type": "test"}))
            response = await ws.recv()
            print(f"📥 پاسخ: {response}")
    except Exception as e:
        print(f"❌ خطا: {e}")
    
    # تست 2: با احراز هویت
    print("\n=== تست 2: با احراز هویت ===")
    try:
        headers = {"Authorization": f"Bearer {token}"}
        print(f"📤 هدر ارسالی: {headers}")
        
        async with websockets.connect(url, extra_headers=headers) as ws:
            print("✅ اتصال با احراز هویت موفق")
            await ws.send(json.dumps({"type": "test"}))
            response = await ws.recv()
            print(f"📥 پاسخ: {response}")
    except Exception as e:
        print(f"❌ خطا: {e}")
        print(f"🔍 نوع خطا: {type(e).__name__}")
    
    # تست 3: با هدر متفاوت
    print("\n=== تست 3: با هدر متفاوت ===")
    try:
        headers = {"authorization": f"Bearer {token}"}  # حروف کوچک
        print(f"📤 هدر ارسالی: {headers}")
        
        async with websockets.connect(url, extra_headers=headers) as ws:
            print("✅ اتصال با هدر متفاوت موفق")
            await ws.send(json.dumps({"type": "test"}))
            response = await ws.recv()
            print(f"📥 پاسخ: {response}")
    except Exception as e:
        print(f"❌ خطا: {e}")

if __name__ == "__main__":
    asyncio.run(test_pico_auth()) 