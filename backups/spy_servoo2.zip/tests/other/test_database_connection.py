#!/usr/bin/env python3
"""
Test database connection and tables
"""

import asyncio
import aiosqlite
import os
import sys

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

async def test_database():
    """Test database connection and tables"""
    print("🔍 Testing database connection and tables...")
    print("=" * 50)
    
    try:
        # Test database connection
        conn = await aiosqlite.connect("smart_camera_system.db")
        print("✅ Database connection successful")
        
        # Check tables
        cursor = await conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = await cursor.fetchall()
        table_names = [table[0] for table in tables]
        
        required_tables = ['users', 'camera_logs', 'password_recovery', 'servo_commands', 
                          'action_commands', 'device_mode_commands', 'manual_photos', 
                          'security_videos', 'user_settings']
        
        print("📊 Checking tables:")
        for table in required_tables:
            if table in table_names:
                print(f"   ✅ {table}")
            else:
                print(f"   ❌ {table} - missing")
        
        # Check admin user
        cursor = await conn.execute("SELECT COUNT(*) FROM users WHERE role = 'admin'")
        admin_count = await cursor.fetchone()
        if admin_count[0] > 0:
            print("   ✅ Admin user exists")
        else:
            print("   ❌ Admin user missing")
        
        # Check camera_logs entries
        cursor = await conn.execute("SELECT COUNT(*) FROM camera_logs")
        log_count = await cursor.fetchone()
        print(f"   📝 Camera logs entries: {log_count[0]}")
        
        # Test inserting a log entry
        try:
            await conn.execute(
                "INSERT INTO camera_logs (message, log_type, created_at, source) VALUES (?, ?, ?, ?)",
                ("Database connection test successful", "INFO", "1404-05-06 20:55:00", "test")
            )
            await conn.commit()
            print("   ✅ Test log entry inserted successfully")
        except Exception as e:
            print(f"   ❌ Failed to insert test log: {e}")
        
        await conn.close()
        print("✅ Database test completed successfully")
        return True
        
    except Exception as e:
        print(f"❌ Database test failed: {e}")
        return False

async def main():
    """Main test function"""
    print("🚀 Starting database connection test...")
    print("=" * 50)
    
    success = await test_database()
    
    if success:
        print("\n🎉 Database is working correctly!")
        print("✅ All tables exist")
        print("✅ Admin user exists")
        print("✅ Log entries can be inserted")
    else:
        print("\n❌ Database has issues")
        print("💡 Try running: python reset_database.py")

if __name__ == "__main__":
    asyncio.run(main()) 