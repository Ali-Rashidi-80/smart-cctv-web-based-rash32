#!/usr/bin/env python3
"""
Comprehensive User Settings Test
Tests all user settings including smart features, device mode, stream status, etc.
"""

import asyncio
import aiosqlite
import json
from datetime import datetime

async def test_comprehensive_user_settings():
    """Test comprehensive user settings storage and retrieval"""
    print("🧪 Comprehensive User Settings Test")
    print("=" * 60)
    
    try:
        # Connect to database
        conn = await aiosqlite.connect('smart_camera_system.db')
        
        # Test 1: Admin user with all settings
        print("\n1️⃣ Testing admin user with all settings...")
        admin_settings = {
            'username': 'rof642fr',
            'ip': '127.0.0.1',
            'theme': 'dark',
            'language': 'fa',
            'servo1': 90,
            'servo2': 90,
            'device_mode': 'desktop',
            'photo_quality': 85,
            'smart_motion': True,
            'smart_tracking': False,
            'stream_enabled': True,
            'flash_settings': json.dumps({
                'intensity': 75,
                'enabled': True
            }),
            'updated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        await conn.execute('''
            INSERT OR REPLACE INTO user_settings 
            (username, ip, theme, language, servo1, servo2, device_mode, photo_quality, 
             smart_motion, smart_tracking, stream_enabled, flash_settings, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            admin_settings['username'], admin_settings['ip'], admin_settings['theme'],
            admin_settings['language'], admin_settings['servo1'], admin_settings['servo2'],
            admin_settings['device_mode'], admin_settings['photo_quality'],
            admin_settings['smart_motion'], admin_settings['smart_tracking'],
            admin_settings['stream_enabled'], admin_settings['flash_settings'],
            admin_settings['updated_at']
        ))
        await conn.commit()
        print("✅ Admin settings saved")
        
        # Test 2: Regular user with different settings
        print("\n2️⃣ Testing regular user with different settings...")
        user_settings = {
            'username': 'testuser',
            'ip': '192.168.1.100',
            'theme': 'light',
            'language': 'en',
            'servo1': 45,
            'servo2': 135,
            'device_mode': 'mobile',
            'photo_quality': 95,
            'smart_motion': False,
            'smart_tracking': True,
            'stream_enabled': False,
            'flash_settings': json.dumps({
                'intensity': 25,
                'enabled': False
            }),
            'updated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        await conn.execute('''
            INSERT OR REPLACE INTO user_settings 
            (username, ip, theme, language, servo1, servo2, device_mode, photo_quality, 
             smart_motion, smart_tracking, stream_enabled, flash_settings, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            user_settings['username'], user_settings['ip'], user_settings['theme'],
            user_settings['language'], user_settings['servo1'], user_settings['servo2'],
            user_settings['device_mode'], user_settings['photo_quality'],
            user_settings['smart_motion'], user_settings['smart_tracking'],
            user_settings['stream_enabled'], user_settings['flash_settings'],
            user_settings['updated_at']
        ))
        await conn.commit()
        print("✅ Regular user settings saved")
        
        # Test 3: Retrieve admin settings
        print("\n3️⃣ Retrieving admin settings...")
        cursor = await conn.execute('''
            SELECT username, ip, theme, language, servo1, servo2, device_mode, photo_quality, 
                   smart_motion, smart_tracking, stream_enabled, flash_settings, updated_at
            FROM user_settings WHERE username = ?
        ''', ('rof642fr',))
        admin_data = await cursor.fetchone()
        
        if admin_data:
            print(f"✅ Admin settings retrieved:")
            print(f"   Username: {admin_data[0]}")
            print(f"   IP: {admin_data[1]}")
            print(f"   Theme: {admin_data[2]}")
            print(f"   Language: {admin_data[3]}")
            print(f"   Servo1: {admin_data[4]}°")
            print(f"   Servo2: {admin_data[5]}°")
            print(f"   Device Mode: {admin_data[6]}")
            print(f"   Photo Quality: {admin_data[7]}%")
            print(f"   Smart Motion: {admin_data[8]}")
            print(f"   Smart Tracking: {admin_data[9]}")
            print(f"   Stream Enabled: {admin_data[10]}")
            print(f"   Flash Settings: {admin_data[11]}")
            print(f"   Updated: {admin_data[12]}")
        else:
            print("❌ Admin settings not found")
        
        # Test 4: Retrieve regular user settings
        print("\n4️⃣ Retrieving regular user settings...")
        cursor = await conn.execute('''
            SELECT username, ip, theme, language, servo1, servo2, device_mode, photo_quality, 
                   smart_motion, smart_tracking, stream_enabled, flash_settings, updated_at
            FROM user_settings WHERE username = ?
        ''', ('testuser',))
        user_data = await cursor.fetchone()
        
        if user_data:
            print(f"✅ Regular user settings retrieved:")
            print(f"   Username: {user_data[0]}")
            print(f"   IP: {user_data[1]}")
            print(f"   Theme: {user_data[2]}")
            print(f"   Language: {user_data[3]}")
            print(f"   Servo1: {user_data[4]}°")
            print(f"   Servo2: {user_data[5]}°")
            print(f"   Device Mode: {user_data[6]}")
            print(f"   Photo Quality: {user_data[7]}%")
            print(f"   Smart Motion: {user_data[8]}")
            print(f"   Smart Tracking: {user_data[9]}")
            print(f"   Stream Enabled: {user_data[10]}")
            print(f"   Flash Settings: {user_data[11]}")
            print(f"   Updated: {user_data[12]}")
        else:
            print("❌ Regular user settings not found")
        
        # Test 5: Verify settings are different for each user
        print("\n5️⃣ Verifying settings isolation between users...")
        if admin_data and user_data:
            differences = []
            if admin_data[2] != user_data[2]:  # theme
                differences.append(f"Theme: {admin_data[2]} vs {user_data[2]}")
            if admin_data[3] != user_data[3]:  # language
                differences.append(f"Language: {admin_data[3]} vs {user_data[3]}")
            if admin_data[4] != user_data[4]:  # servo1
                differences.append(f"Servo1: {admin_data[4]}° vs {user_data[4]}°")
            if admin_data[5] != user_data[5]:  # servo2
                differences.append(f"Servo2: {admin_data[5]}° vs {user_data[5]}°")
            if admin_data[6] != user_data[6]:  # device_mode
                differences.append(f"Device Mode: {admin_data[6]} vs {user_data[6]}")
            if admin_data[7] != user_data[7]:  # photo_quality
                differences.append(f"Photo Quality: {admin_data[7]}% vs {user_data[7]}%")
            if admin_data[8] != user_data[8]:  # smart_motion
                differences.append(f"Smart Motion: {admin_data[8]} vs {user_data[8]}")
            if admin_data[9] != user_data[9]:  # smart_tracking
                differences.append(f"Smart Tracking: {admin_data[9]} vs {user_data[9]}")
            if admin_data[10] != user_data[10]:  # stream_enabled
                differences.append(f"Stream Enabled: {admin_data[10]} vs {user_data[10]}")
            
            if differences:
                print("✅ Settings are properly isolated:")
                for diff in differences:
                    print(f"   {diff}")
            else:
                print("❌ Settings are not different between users")
        else:
            print("❌ Cannot verify settings isolation - missing data")
        
        # Test 6: Show all records
        print("\n6️⃣ All records in database:")
        cursor = await conn.execute('''
            SELECT username, theme, language, device_mode, smart_motion, smart_tracking, stream_enabled, updated_at
            FROM user_settings ORDER BY updated_at DESC
        ''')
        all_records = await cursor.fetchall()
        
        if all_records:
            for i, record in enumerate(all_records, 1):
                print(f"   Record {i}: {record}")
        else:
            print("   No records found")
        
        await conn.close()
        print("\n🎉 Comprehensive user settings test completed successfully!")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_comprehensive_user_settings()) 