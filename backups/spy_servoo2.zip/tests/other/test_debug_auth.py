#!/usr/bin/env python3
"""
تست دیباگ تابع authenticate_websocket
"""

import sys
import os

# اضافه کردن مسیر پروژه به sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import the server module
from server_fastapi import PICO_AUTH_TOKENS, authenticate_websocket
import asyncio
from fastapi import WebSocket
from unittest.mock import Mock

async def test_auth_function():
    """تست مستقیم تابع authenticate_websocket"""
    print("🔍 تست تابع authenticate_websocket")
    print(f"📋 PICO_AUTH_TOKENS: {PICO_AUTH_TOKENS}")
    
    # تست توکن
    test_token = "rof642fr:5qEKU@A@Tv"
    print(f"🔑 توکن تست: {test_token}")
    print(f"✅ توکن در لیست: {test_token in PICO_AUTH_TOKENS}")
    
    # شبیه‌سازی WebSocket
    mock_websocket = Mock()
    mock_websocket.headers = {"authorization": f"Bearer {test_token}"}
    mock_websocket.client.host = "127.0.0.1"
    
    # تست تابع
    try:
        result = await authenticate_websocket(mock_websocket, "pico")
        print(f"✅ نتیجه احراز هویت: {result}")
    except Exception as e:
        print(f"❌ خطا در احراز هویت: {e}")

if __name__ == "__main__":
    asyncio.run(test_auth_function()) 