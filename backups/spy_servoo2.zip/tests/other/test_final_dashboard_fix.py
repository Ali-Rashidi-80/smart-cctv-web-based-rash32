#!/usr/bin/env python3
"""
Final comprehensive test for dashboard unauthorized fix
Tests the complete flow including Google OAuth and dashboard access
"""

import asyncio
import httpx
import json
import sys
import os
from datetime import datetime

# Add the parent directory to the path to import server modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

async def test_complete_dashboard_flow():
    """Test the complete dashboard access flow"""
    print("🧪 Testing Complete Dashboard Access Flow")
    print("=" * 50)
    
    base_url = "http://localhost:3000"
    
    async with httpx.AsyncClient(timeout=30.0) as client:
        try:
            # Test 1: Check server is running
            print("\n1️⃣ Checking server status...")
            response = await client.get(f"{base_url}/health")
            
            if response.status_code == 200:
                print("✅ Server is running and healthy")
            else:
                print(f"❌ Server not responding: {response.status_code}")
                return False
            
            # Test 2: Test login page
            print("\n2️⃣ Testing login page...")
            response = await client.get(f"{base_url}/login")
            
            if response.status_code == 200:
                print("✅ Login page accessible")
            else:
                print(f"❌ Login page error: {response.status_code}")
                return False
            
            # Test 3: Test Google OAuth redirect
            print("\n3️⃣ Testing Google OAuth redirect...")
            response = await client.get(f"{base_url}/auth/google", follow_redirects=False)
            
            if response.status_code in [302, 307]:
                oauth_url = response.headers.get("location", "")
                if "accounts.google.com" in oauth_url:
                    print("✅ Google OAuth redirect working correctly")
                else:
                    print(f"❌ Invalid OAuth URL: {oauth_url}")
                    return False
            else:
                print(f"❌ OAuth redirect failed: {response.status_code}")
                return False
            
            # Test 4: Test dashboard access without auth (should redirect)
            print("\n4️⃣ Testing dashboard access without authentication...")
            response = await client.get(f"{base_url}/dashboard", follow_redirects=False)
            
            if response.status_code == 302:
                location = response.headers.get("location", "")
                if "/login" in location:
                    print("✅ Unauthenticated dashboard access correctly redirected to login")
                else:
                    print(f"❌ Unexpected redirect location: {location}")
                    return False
            else:
                print(f"❌ Unexpected response: {response.status_code}")
                return False
            
            # Test 5: Test API endpoints without auth
            print("\n5️⃣ Testing API endpoints without authentication...")
            
            api_endpoints = ["/api/users", "/get_status", "/get_gallery"]
            for endpoint in api_endpoints:
                response = await client.get(f"{base_url}{endpoint}", follow_redirects=False)
                
                if response.status_code == 401:
                    print(f"✅ {endpoint} correctly returns 401 for unauthenticated access")
                else:
                    print(f"❌ {endpoint} unexpected response: {response.status_code}")
                    return False
            
            # Test 6: Test with various Accept headers
            print("\n6️⃣ Testing with various Accept headers...")
            
            headers_variations = [
                {"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"},
                {"Accept": "application/json,text/plain,*/*"},
                {"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,application/json;q=0.8,*/*;q=0.7"},
                {"Accept": "*/*"}
            ]
            
            for i, headers in enumerate(headers_variations, 1):
                response = await client.get(f"{base_url}/dashboard", headers=headers, follow_redirects=False)
                
                if response.status_code == 302:
                    print(f"✅ Accept header variation {i} handled correctly")
                else:
                    print(f"❌ Accept header variation {i} failed: {response.status_code}")
                    return False
            
            # Test 7: Test middleware behavior with different paths
            print("\n7️⃣ Testing middleware behavior...")
            
            test_paths = [
                ("/", "should redirect to login"),
                ("/dashboard", "should redirect to login"),
                ("/api/users", "should return 401"),
                ("/get_status", "should return 401"),
                ("/login", "should be accessible"),
                ("/health", "should be accessible"),
                ("/static/css/styles.css", "should be accessible")
            ]
            
            for path, expected in test_paths:
                response = await client.get(f"{base_url}{path}", follow_redirects=False)
                
                if path in ["/login", "/health", "/static/css/styles.css"]:
                    if response.status_code == 200:
                        print(f"✅ {path} {expected}")
                    else:
                        print(f"❌ {path} failed: {response.status_code}")
                        return False
                elif path.startswith("/api/"):
                    if response.status_code == 401:
                        print(f"✅ {path} {expected}")
                    else:
                        print(f"❌ {path} failed: {response.status_code}")
                        return False
                else:
                    if response.status_code == 302:
                        print(f"✅ {path} {expected}")
                    else:
                        print(f"❌ {path} failed: {response.status_code}")
                        return False
            
            print("\n🎉 All dashboard flow tests passed!")
            return True
            
        except Exception as e:
            print(f"❌ Test failed with exception: {e}")
            return False

async def test_google_oauth_callback_handling():
    """Test Google OAuth callback handling"""
    print("\n🔐 Testing Google OAuth Callback Handling")
    print("=" * 50)
    
    base_url = "http://localhost:3000"
    
    async with httpx.AsyncClient(timeout=30.0) as client:
        try:
            # Test 1: Get OAuth URL and extract state
            print("\n1️⃣ Getting OAuth URL...")
            response = await client.get(f"{base_url}/auth/google", follow_redirects=False)
            
            if response.status_code not in [302, 307]:
                print(f"❌ OAuth redirect failed: {response.status_code}")
                return False
            
            oauth_url = response.headers.get("location", "")
            state_start = oauth_url.find("state=") + 6
            state_end = oauth_url.find("&", state_start)
            if state_end == -1:
                state_end = len(oauth_url)
            state = oauth_url[state_start:state_end]
            
            print(f"✅ OAuth URL generated with state: {state[:20]}...")
            
            # Test 2: Test callback with invalid code
            print("\n2️⃣ Testing callback with invalid code...")
            callback_url = f"{base_url}/auth/google/callback?code=invalid_code&state={state}"
            response = await client.get(callback_url, follow_redirects=False)
            
            # Should handle gracefully (either redirect to login or show error)
            if response.status_code in [302, 400, 500]:
                print("✅ Callback handled invalid code gracefully")
            else:
                print(f"❌ Unexpected callback response: {response.status_code}")
                return False
            
            # Test 3: Test callback with missing parameters
            print("\n3️⃣ Testing callback with missing parameters...")
            response = await client.get(f"{base_url}/auth/google/callback", follow_redirects=False)
            
            if response.status_code in [302, 400, 500]:
                print("✅ Callback handled missing parameters gracefully")
            else:
                print(f"❌ Unexpected callback response: {response.status_code}")
                return False
            
            # Test 4: Test callback with invalid state
            print("\n4️⃣ Testing callback with invalid state...")
            callback_url = f"{base_url}/auth/google/callback?code=test_code&state=invalid_state"
            response = await client.get(callback_url, follow_redirects=False)
            
            if response.status_code in [302, 400, 500]:
                print("✅ Callback handled invalid state gracefully")
            else:
                print(f"❌ Unexpected callback response: {response.status_code}")
                return False
            
            print("\n✅ All OAuth callback tests passed!")
            return True
            
        except Exception as e:
            print(f"❌ OAuth callback test failed: {e}")
            return False

async def main():
    """Run all tests"""
    print("🚀 Starting Final Dashboard Fix Tests")
    print(f"⏰ Test started at: {datetime.now()}")
    print("=" * 60)
    
    # Test 1: Complete dashboard flow
    test1_result = await test_complete_dashboard_flow()
    
    # Test 2: OAuth callback handling
    test2_result = await test_google_oauth_callback_handling()
    
    print("\n" + "=" * 60)
    print("📊 Final Test Results Summary:")
    print(f"   Dashboard Flow Test: {'✅ PASS' if test1_result else '❌ FAIL'}")
    print(f"   OAuth Callback Test: {'✅ PASS' if test2_result else '❌ FAIL'}")
    
    if test1_result and test2_result:
        print("\n🎉 All tests passed! Dashboard unauthorized issue is completely fixed.")
        print("\n✅ The system is now ready for production use.")
        print("✅ Users can successfully:")
        print("   - Access the login page")
        print("   - Use Google OAuth login")
        print("   - Access the dashboard after authentication")
        print("   - Navigate without getting Unauthorized errors")
        return True
    else:
        print("\n❌ Some tests failed. Please check the issues above.")
        return False

if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1) 