#!/usr/bin/env python3
"""
تست نهایی فوق العاده - بررسی کامل سیستم
Super Ultimate Final Test - Complete System Check
"""

import sys
import os
import asyncio
import time
import json
import secrets
from datetime import datetime

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class SuperUltimateFinalTester:
    """تست نهایی فوق العاده"""
    
    def __init__(self):
        self.test_results = {}
        self.start_time = time.time()
        self.total_tests = 0
        self.passed_tests = 0
        
    def log_test(self, test_name: str, passed: bool, details: str = ""):
        """ثبت نتیجه تست"""
        status = "✅ PASS" if passed else "❌ FAIL"
        self.test_results[test_name] = {
            "passed": passed,
            "details": details,
            "timestamp": datetime.now().isoformat()
        }
        print(f"{status} {test_name}: {details}")
        if passed:
            self.passed_tests += 1
        self.total_tests += 1

    async def test_database_integrity(self):
        """تست یکپارچگی دیتابیس"""
        print("\n🗄️ تست یکپارچگی دیتابیس...")
        try:
            from server_fastapi import init_db, get_db_connection, close_db_connection
            
            await init_db()
            conn = await get_db_connection()
            
            # بررسی جداول اصلی
            tables = [
                "users", "password_recovery", "camera_logs", "servo_commands",
                "action_commands", "device_mode_commands", "manual_photos",
                "security_videos", "user_settings"
            ]
            
            all_tables_exist = True
            for table in tables:
                cursor = await conn.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table}'")
                result = await cursor.fetchone()
                if not result:
                    all_tables_exist = False
                    break
            
            if all_tables_exist:
                self.log_test("Database Tables", True, f"All {len(tables)} tables exist")
            else:
                self.log_test("Database Tables", False, "Some tables missing")
            
            # بررسی indexes
            cursor = await conn.execute("PRAGMA index_list(users)")
            indexes = await cursor.fetchall()
            username_indexes = [idx[1] for idx in indexes if 'username' in idx[1].lower()]
            if username_indexes:
                self.log_test("Username Unique Index", True, f"Found: {username_indexes}")
            else:
                self.log_test("Username Unique Index", False, "No username index found")
            
            # بررسی foreign keys
            cursor = await conn.execute("PRAGMA foreign_key_check")
            violations = await cursor.fetchall()
            if not violations:
                self.log_test("Foreign Key Integrity", True, "No violations found")
            else:
                self.log_test("Foreign Key Integrity", False, f"{len(violations)} violations found")
            
            await close_db_connection(conn)
            
        except Exception as e:
            self.log_test("Database Integrity", False, f"Error: {e}")

    async def test_authentication_system(self):
        """تست سیستم احراز هویت"""
        print("\n🔐 تست سیستم احراز هویت...")
        try:
            from server_fastapi import (
                hash_password, verify_password, create_access_token, 
                verify_token, sanitize_input, check_rate_limit, 
                check_login_attempts, record_login_attempt
            )
            
            # تست Password Hashing
            password = "test123"
            hashed = hash_password(password)
            if verify_password(password, hashed):
                self.log_test("Password Hashing", True, "Password hashing works correctly")
            else:
                self.log_test("Password Hashing", False, "Password hashing failed")
            
            # تست JWT Token
            token_data = {"sub": "testuser", "role": "user"}
            token = create_access_token(data=token_data)
            decoded = verify_token(token)
            if decoded and decoded.get("sub") == "testuser":
                self.log_test("JWT Token System", True, "JWT token creation/verification works")
            else:
                self.log_test("JWT Token System", False, "JWT token failed")
            
            # تست Input Sanitization
            malicious_inputs = [
                ("<script>alert('xss')</script>", "XSS"),
                ("admin' OR '1'='1", "SQL Injection"),
                ("javascript:alert('xss')", "XSS"),
                ("'; DROP TABLE users; --", "SQL Injection")
            ]
            
            all_sanitized = True
            for malicious_input, attack_type in malicious_inputs:
                sanitized = sanitize_input(malicious_input)
                if sanitized == malicious_input:
                    all_sanitized = False
                    break
            
            if all_sanitized:
                self.log_test("Input Sanitization", True, "All malicious inputs sanitized")
            else:
                self.log_test("Input Sanitization", False, "Some malicious inputs not sanitized")
            
            # تست Rate Limiting
            test_ip = "203.0.113.100"
            for i in range(15):
                result = check_rate_limit(test_ip)
                if not result:
                    self.log_test("Rate Limiting", False, f"Blocked too early at request {i+1}")
                    break
            else:
                # تست درخواست 16 (باید مسدود شود)
                result = check_rate_limit(test_ip)
                if not result:
                    self.log_test("Rate Limiting", True, "Rate limiting working correctly")
                else:
                    self.log_test("Rate Limiting", False, "Not blocked when should be")
            
            # تست Login Attempts
            test_ip = "203.0.113.200"
            for i in range(6):
                result = check_login_attempts(test_ip)
                if not result:
                    self.log_test("Login Attempts", False, f"Blocked too early at attempt {i+1}")
                    break
                record_login_attempt(test_ip, False)
            else:
                # تست تلاش 7 (باید مسدود شود)
                result = check_login_attempts(test_ip)
                if not result:
                    self.log_test("Login Attempts", True, "Login attempts limiting working correctly")
                else:
                    self.log_test("Login Attempts", False, "Not blocked when should be")
                
        except Exception as e:
            self.log_test("Authentication System", False, f"Error: {e}")

    async def test_google_oauth(self):
        """تست Google OAuth"""
        print("\n🌐 تست Google OAuth...")
        try:
            from server_fastapi import get_google_auth_url, GoogleUserInfo, create_or_get_google_user
            
            # تست ایجاد URL احراز هویت
            auth_url = await get_google_auth_url("test_state")
            if auth_url and "accounts.google.com" in auth_url:
                self.log_test("Google Auth URL", True, "Auth URL generated correctly")
            else:
                self.log_test("Google Auth URL", False, "Invalid auth URL")
            
            # تست ایجاد کاربر Google
            google_user = GoogleUserInfo(
                id="test_google_id",
                email="test_google@test.com",
                name="Test Google User",
                picture="https://example.com/avatar.jpg",
                verified_email=True
            )
            
            result = await create_or_get_google_user(google_user)
            if result and "user_id" in result:
                self.log_test("Google User Creation", True, "Google user created/retrieved")
            else:
                self.log_test("Google User Creation", False, "Failed to create Google user")
                
        except Exception as e:
            self.log_test("Google OAuth", False, f"Error: {e}")

    async def test_system_operations(self):
        """تست عملیات سیستم"""
        print("\n⚙️ تست عملیات سیستم...")
        try:
            from server_fastapi import (
                insert_servo_command, insert_action_command, 
                insert_device_mode_command, insert_photo_to_db, insert_log
            )
            
            # تست کنترل سروو
            await insert_servo_command(90, 45)
            self.log_test("Servo Control", True, "Servo command inserted")
            
            # تست کنترل عملیات
            await insert_action_command("test_action", 75)
            self.log_test("Action Control", True, "Action command inserted")
            
            # تست حالت دستگاه
            await insert_device_mode_command("mobile")
            self.log_test("Device Mode Control", True, "Device mode command inserted")
            
            # تست مدیریت عکس
            filename = f"final_test_{secrets.token_hex(4)}.jpg"
            filepath = f"gallery/{filename}"
            await insert_photo_to_db(filename, filepath, 85, True, 60)
            self.log_test("Photo Management", True, f"Photo inserted: {filename}")
            
            # تست سیستم لاگینگ
            test_message = f"Final test log {secrets.token_hex(4)}"
            await insert_log(test_message, "final_test", "system_test")
            self.log_test("Logging System", True, f"Log inserted: {test_message[:30]}...")
            
        except Exception as e:
            self.log_test("System Operations", False, f"Error: {e}")

    async def test_performance_metrics(self):
        """تست معیارهای عملکرد"""
        print("\n⚡ تست معیارهای عملکرد...")
        try:
            from server_fastapi import hash_password, sanitize_input
            
            # تست سرعت Password Hashing
            start_time = time.time()
            for i in range(50):
                password = f"test{i}"
                hash_password(password)
            end_time = time.time()
            time_taken = end_time - start_time
            hashes_per_second = 50 / time_taken
            
            if hashes_per_second > 5:  # حداقل 5 hash در ثانیه
                self.log_test("Password Hashing Performance", True, f"{hashes_per_second:.1f} hashes/s")
            else:
                self.log_test("Password Hashing Performance", False, f"Too slow: {hashes_per_second:.1f} hashes/s")
            
            # تست سرعت Input Sanitization
            start_time = time.time()
            for i in range(100):
                test_input = f"test_input_{i} with special chars <script>alert('xss')</script>"
                sanitize_input(test_input)
            end_time = time.time()
            time_taken = end_time - start_time
            sanitizations_per_second = 100 / time_taken
            
            if sanitizations_per_second > 1000:  # حداقل 1000 sanitization در ثانیه
                self.log_test("Input Sanitization Performance", True, f"{sanitizations_per_second:.1f} sanitizations/s")
            else:
                self.log_test("Input Sanitization Performance", False, f"Too slow: {sanitizations_per_second:.1f} sanitizations/s")
                
        except Exception as e:
            self.log_test("Performance Metrics", False, f"Error: {e}")

    async def test_edge_cases(self):
        """تست موارد خاص"""
        print("\n🔍 تست موارد خاص...")
        try:
            from server_fastapi import sanitize_input, verify_token
            
            # تست ورودی‌های خالی و null
            empty_inputs = ["", "   ", None]
            for empty_input in empty_inputs:
                try:
                    sanitized = sanitize_input(empty_input)
                    if sanitized == "" or sanitized is None:
                        self.log_test(f"Empty Input - {empty_input}", True, "Empty input handled correctly")
                    else:
                        self.log_test(f"Empty Input - {empty_input}", False, "Empty input not handled correctly")
                except Exception as e:
                    self.log_test(f"Empty Input - {empty_input}", False, f"Error: {e}")
            
            # تست ورودی‌های طولانی
            long_input = "a" * 10000
            try:
                sanitized = sanitize_input(long_input)
                if len(sanitized) <= 10000:
                    self.log_test("Long Input", True, "Long input handled correctly")
                else:
                    self.log_test("Long Input", False, "Long input not handled correctly")
            except Exception as e:
                self.log_test("Long Input", False, f"Error: {e}")
            
            # تست کاراکترهای خاص
            special_chars = "!@#$%^&*()_+-=[]{}|;:,.<>?`~"
            try:
                sanitized = sanitize_input(special_chars)
                preserved_count = 0
                for char in special_chars:
                    if char in sanitized or char.replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;').replace("'", '&#39;') in sanitized:
                        preserved_count += 1
                
                if preserved_count >= len(special_chars) * 0.8:
                    self.log_test("Special Characters", True, f"Special characters preserved ({preserved_count}/{len(special_chars)})")
                else:
                    self.log_test("Special Characters", False, f"Special characters not preserved ({preserved_count}/{len(special_chars)})")
            except Exception as e:
                self.log_test("Special Characters", False, f"Error: {e}")
            
            # تست کاراکترهای Unicode
            unicode_chars = "سلام دنیا 🌍 🚀 💻"
            try:
                sanitized = sanitize_input(unicode_chars)
                if sanitized == unicode_chars:
                    self.log_test("Unicode Characters", True, "Unicode characters preserved")
                else:
                    self.log_test("Unicode Characters", False, "Unicode characters not preserved")
            except Exception as e:
                self.log_test("Unicode Characters", False, f"Error: {e}")
            
            # تست توکن‌های نامعتبر
            invalid_tokens = ["", None, "invalid_token", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ0ZXN0In0.invalid"]
            for invalid_token in invalid_tokens:
                result = verify_token(invalid_token)
                if result is None:
                    self.log_test(f"Invalid Token - {str(invalid_token)[:20]}", True, "Invalid token rejected")
                else:
                    self.log_test(f"Invalid Token - {str(invalid_token)[:20]}", False, "Invalid token accepted")
                    
        except Exception as e:
            self.log_test("Edge Cases", False, f"Error: {e}")

    async def test_integration_workflow(self):
        """تست جریان یکپارچگی"""
        print("\n🔄 تست جریان یکپارچگی...")
        try:
            from server_fastapi import (
                init_db, get_db_connection, close_db_connection,
                hash_password, create_access_token, verify_token,
                insert_servo_command, insert_action_command, insert_log
            )
            
            # راه‌اندازی دیتابیس
            await init_db()
            conn = await get_db_connection()
            
            # ایجاد کاربر تست
            test_username = f"integration_user_{secrets.token_hex(4)}"
            test_email = f"{test_username}@test.com"
            password_hash = hash_password("test123")
            
            await conn.execute(
                'INSERT INTO users (username, email, password_hash, role, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?)',
                (test_username, test_email, password_hash, "user", True, "1404-05-07 01:00:00")
            )
            await conn.commit()
            
            # ایجاد توکن
            token_data = {"sub": test_username, "role": "user", "ip": "192.168.1.1"}
            token = create_access_token(data=token_data)
            
            # بررسی توکن
            decoded_token = verify_token(token)
            if not decoded_token:
                self.log_test("Integration - Token Verification", False, "Token verification failed")
                return
            
            # ثبت عملیات‌های مختلف
            await insert_servo_command(90, 45)
            await insert_action_command("integration_test", 50)
            await insert_log("Integration test log", "integration", "system_test")
            
            # بررسی در دیتابیس
            cursor = await conn.execute("SELECT COUNT(*) FROM servo_commands WHERE servo1 = 90 AND servo2 = 45")
            servo_count = await cursor.fetchone()
            
            cursor = await conn.execute("SELECT COUNT(*) FROM action_commands WHERE action = 'integration_test'")
            action_count = await cursor.fetchone()
            
            if servo_count[0] > 0 and action_count[0] > 0:
                self.log_test("Integration Workflow", True, "All operations completed successfully")
            else:
                self.log_test("Integration Workflow", False, "Some operations failed")
            
            # پاکسازی
            await conn.execute("DELETE FROM users WHERE username = ?", (test_username,))
            await conn.commit()
            await close_db_connection(conn)
            
        except Exception as e:
            self.log_test("Integration Workflow", False, f"Error: {e}")

    async def run_all_tests(self):
        """اجرای تمام تست‌ها"""
        print("🌟 شروع تست نهایی فوق العاده")
        print("=" * 80)
        
        # اجرای تست‌های مختلف
        await self.test_database_integrity()
        await self.test_authentication_system()
        await self.test_google_oauth()
        await self.test_system_operations()
        await self.test_performance_metrics()
        await self.test_edge_cases()
        await self.test_integration_workflow()
        
        # محاسبه نتایج
        success_rate = (self.passed_tests / self.total_tests * 100) if self.total_tests > 0 else 0
        total_time = time.time() - self.start_time
        
        # گزارش نهایی
        print("\n" + "=" * 80)
        print("📊 گزارش نهایی تست فوق العاده")
        print("=" * 80)
        
        print(f"📈 آمار کلی:")
        print(f"   کل تست‌ها: {self.total_tests}")
        print(f"   تست‌های موفق: {self.passed_tests}")
        print(f"   تست‌های ناموفق: {self.total_tests - self.passed_tests}")
        print(f"   نرخ موفقیت: {success_rate:.1f}%")
        print(f"   زمان کل اجرا: {total_time:.2f} ثانیه")
        
        # نمایش نتایج تفصیلی
        print(f"\n📋 نتایج تفصیلی:")
        for test_name, result in self.test_results.items():
            status = "✅ PASS" if result["passed"] else "❌ FAIL"
            print(f"   {status} {test_name}: {result['details']}")
        
        # نتیجه نهایی
        if success_rate >= 95:
            print(f"\n🎉 سیستم در وضعیت عالی و آماده production است!")
            print(f"🌟 تمام تست‌ها با موفقیت اجرا شدند!")
            return True
        elif success_rate >= 90:
            print(f"\n✅ سیستم در وضعیت خوب است، بهبودهای جزئی توصیه می‌شود")
            return True
        else:
            print(f"\n⚠️ سیستم نیاز به بهبود دارد")
            return False

async def main():
    """تابع اصلی"""
    tester = SuperUltimateFinalTester()
    success = await tester.run_all_tests()
    
    # ذخیره نتایج
    results = {
        "timestamp": datetime.now().isoformat(),
        "success": success,
        "total_tests": tester.total_tests,
        "passed_tests": tester.passed_tests,
        "success_rate": (tester.passed_tests / tester.total_tests * 100) if tester.total_tests > 0 else 0,
        "test_results": tester.test_results,
        "total_time": time.time() - tester.start_time
    }
    
    try:
        with open("super_ultimate_test_results.json", "w", encoding="utf-8") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        print(f"\n💾 نتایج در فایل super_ultimate_test_results.json ذخیره شد")
    except Exception as e:
        print(f"\n⚠️ خطا در ذخیره نتایج: {e}")
    
    return success

if __name__ == "__main__":
    asyncio.run(main()) 