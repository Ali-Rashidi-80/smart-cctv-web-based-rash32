#!/usr/bin/env python3
"""
Final Hidden Issues Test
Identify and verify fixes for all hidden and visible problems
"""

import asyncio
import aiosqlite
import json
import time
import sys
from datetime import datetime

async def test_hidden_issues():
    """Test for hidden and visible issues"""
    print("🔍 Testing Hidden and Visible Issues")
    print("=" * 50)
    
    results = []
    
    # Test 1: Database connection stability
    print("🧪 Test 1: Database Connection Stability")
    try:
        conn = await aiosqlite.connect('smart_camera_system.db')
        
        # Test PRAGMA settings
        cursor = await conn.execute("PRAGMA busy_timeout")
        timeout = await cursor.fetchone()
        
        cursor = await conn.execute("PRAGMA journal_mode")
        journal_mode = await cursor.fetchone()
        
        if timeout[0] >= 30000 and journal_mode[0] == 'wal':
            print("✅ Database connection stability verified")
            results.append(("Database Stability", "PASS"))
        else:
            print("❌ Database connection stability issues")
            results.append(("Database Stability", "FAIL"))
        
        await conn.close()
        
    except Exception as e:
        print(f"❌ Database stability test failed: {e}")
        results.append(("Database Stability", "FAIL"))
    
    # Test 2: Data validation edge cases
    print("\n🧪 Test 2: Data Validation Edge Cases")
    try:
        conn = await aiosqlite.connect('smart_camera_system.db')
        
        # Test with extreme values
        test_data = {
            'username': 'test_hidden_issues',
            'ip': '127.0.0.1',
            'theme': 'invalid_theme',
            'language': 'invalid_lang',
            'servo1': 999,
            'servo2': -999,
            'device_mode': 'invalid_mode',
            'photo_quality': 999,
            'smart_motion': 'not_bool',
            'smart_tracking': 'not_bool',
            'stream_enabled': 'not_bool'
        }
        
        # Insert test data
        await conn.execute('''
            INSERT OR REPLACE INTO user_settings 
            (username, ip, theme, language, servo1, servo2, device_mode, photo_quality, 
             smart_motion, smart_tracking, stream_enabled, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            test_data['username'], test_data['ip'], test_data['theme'],
            test_data['language'], test_data['servo1'], test_data['servo2'],
            test_data['device_mode'], test_data['photo_quality'],
            test_data['smart_motion'], test_data['smart_tracking'],
            test_data['stream_enabled'], datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        ))
        await conn.commit()
        
        # Retrieve and check
        cursor = await conn.execute('''
            SELECT theme, language, servo1, servo2, device_mode, photo_quality, 
                   smart_motion, smart_tracking, stream_enabled
            FROM user_settings WHERE username = ?
        ''', (test_data['username'],))
        result = await cursor.fetchone()
        
        if result:
            print("✅ Data validation edge cases handled")
            results.append(("Data Validation", "PASS"))
        else:
            print("❌ Data validation edge cases failed")
            results.append(("Data Validation", "FAIL"))
        
        # Clean up
        await conn.execute('DELETE FROM user_settings WHERE username = ?', (test_data['username'],))
        await conn.commit()
        await conn.close()
        
    except Exception as e:
        print(f"❌ Data validation test failed: {e}")
        results.append(("Data Validation", "FAIL"))
    
    # Test 3: Concurrent operations
    print("\n🧪 Test 3: Concurrent Operations")
    try:
        async def concurrent_operation(user_id: int):
            conn = await aiosqlite.connect('smart_camera_system.db')
            try:
                async with conn:
                    await conn.execute('''
                        INSERT OR REPLACE INTO user_settings 
                        (username, ip, theme, language, updated_at)
                        VALUES (?, ?, ?, ?, ?)
                    ''', (f'concurrent_test_{user_id}', '127.0.0.1', 'dark', 'en', 
                          datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
                    
                    await asyncio.sleep(0.1)
                    
                    cursor = await conn.execute('''
                        SELECT username FROM user_settings WHERE username = ?
                    ''', (f'concurrent_test_{user_id}',))
                    result = await cursor.fetchone()
                    
                    return result is not None
            finally:
                await conn.close()
        
        # Run 10 concurrent operations
        tasks = [concurrent_operation(i) for i in range(10)]
        results_concurrent = await asyncio.gather(*tasks, return_exceptions=True)
        
        success_count = sum(1 for r in results_concurrent if r is True)
        error_count = sum(1 for r in results_concurrent if isinstance(r, Exception))
        
        if success_count == 10 and error_count == 0:
            print("✅ Concurrent operations working")
            results.append(("Concurrent Operations", "PASS"))
        else:
            print(f"❌ Concurrent operations failed: Success={success_count}, Errors={error_count}")
            results.append(("Concurrent Operations", "FAIL"))
        
        # Clean up
        conn = await aiosqlite.connect('smart_camera_system.db')
        for i in range(10):
            await conn.execute('DELETE FROM user_settings WHERE username = ?', (f'concurrent_test_{i}',))
        await conn.commit()
        await conn.close()
        
    except Exception as e:
        print(f"❌ Concurrent operations test failed: {e}")
        results.append(("Concurrent Operations", "FAIL"))
    
    # Test 4: Error recovery
    print("\n🧪 Test 4: Error Recovery")
    try:
        conn = await aiosqlite.connect('smart_camera_system.db')
        
        # Test with invalid JSON
        test_user = "test_error_recovery"
        invalid_json = "{invalid: json, data}"
        
        await conn.execute('''
            INSERT OR REPLACE INTO user_settings 
            (username, ip, flash_settings, updated_at)
            VALUES (?, ?, ?, ?)
        ''', (test_user, '127.0.0.1', invalid_json, 
              datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
        await conn.commit()
        
        # Retrieve and validate
        cursor = await conn.execute('''
            SELECT flash_settings FROM user_settings WHERE username = ?
        ''', (test_user,))
        result = await cursor.fetchone()
        
        if result:
            print("✅ Error recovery working")
            results.append(("Error Recovery", "PASS"))
        else:
            print("❌ Error recovery failed")
            results.append(("Error Recovery", "FAIL"))
        
        # Clean up
        await conn.execute('DELETE FROM user_settings WHERE username = ?', (test_user,))
        await conn.commit()
        await conn.close()
        
    except Exception as e:
        print(f"❌ Error recovery test failed: {e}")
        results.append(("Error Recovery", "FAIL"))
    
    # Test 5: Memory management
    print("\n🧪 Test 5: Memory Management")
    try:
        # Test multiple connections
        connections = []
        for i in range(20):
            conn = await aiosqlite.connect('smart_camera_system.db')
            connections.append(conn)
            
            await conn.execute('''
                INSERT OR REPLACE INTO user_settings 
                (username, ip, theme, updated_at)
                VALUES (?, ?, ?, ?)
            ''', (f'memory_test_{i}', '127.0.0.1', 'light', 
                  datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            await conn.commit()
        
        # Close all connections
        for conn in connections:
            await conn.close()
        
        # Try to create new connection
        new_conn = await aiosqlite.connect('smart_camera_system.db')
        await new_conn.execute("SELECT 1")
        await new_conn.close()
        
        print("✅ Memory management working")
        results.append(("Memory Management", "PASS"))
        
        # Clean up
        conn = await aiosqlite.connect('smart_camera_system.db')
        for i in range(20):
            await conn.execute('DELETE FROM user_settings WHERE username = ?', (f'memory_test_{i}',))
        await conn.commit()
        await conn.close()
        
    except Exception as e:
        print(f"❌ Memory management test failed: {e}")
        results.append(("Memory Management", "FAIL"))
    
    # Generate final report
    print("\n" + "=" * 50)
    print("📊 HIDDEN ISSUES TEST REPORT")
    print("=" * 50)
    
    total_tests = len(results)
    passed_tests = len([r for r in results if r[1] == 'PASS'])
    failed_tests = len([r for r in results if r[1] == 'FAIL'])
    
    print(f"Total Tests: {total_tests}")
    print(f"Passed: {passed_tests} ✅")
    print(f"Failed: {failed_tests} ❌")
    print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
    
    print("\n📋 Test Results:")
    for test_name, status in results:
        emoji = "✅" if status == "PASS" else "❌"
        print(f"  {emoji} {test_name}: {status}")
    
    if failed_tests == 0:
        print("\n🎉 ALL HIDDEN ISSUES RESOLVED!")
        print("✅ No hidden issues found")
        print("✅ No visible issues found")
        print("✅ All edge cases handled")
        print("✅ Error recovery working")
        print("✅ Memory management optimized")
        print("🚀 Server is production-ready!")
        return True
    else:
        print(f"\n⚠️  {failed_tests} issue(s) still need attention:")
        for test_name, status in results:
            if status == "FAIL":
                print(f"  ❌ {test_name}")
        return False

async def main():
    """Run hidden issues test"""
    print("🚀 Starting Hidden Issues Test")
    print("=" * 50)
    
    success = await test_hidden_issues()
    return success

if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1) 