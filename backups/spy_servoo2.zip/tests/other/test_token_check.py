#!/usr/bin/env python3
"""
تست ساده بررسی توکن‌ها
"""

import sys
import os

# اضافه کردن مسیر پروژه به sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import the server module
from server_fastapi import PICO_AUTH_TOKENS

def test_tokens():
    """تست بررسی توکن‌ها"""
    print("🔍 بررسی توکن‌های پیکو")
    print(f"📋 PICO_AUTH_TOKENS: {PICO_AUTH_TOKENS}")
    print(f"📋 نوع: {type(PICO_AUTH_TOKENS)}")
    print(f"📋 طول: {len(PICO_AUTH_TOKENS)}")
    
    # تست توکن
    test_token = "rof642fr:5qEKU@A@Tv"
    print(f"\n🔑 توکن تست: '{test_token}'")
    print(f"📋 طول توکن: {len(test_token)}")
    print(f"📋 bytes: {test_token.encode()}")
    print(f"✅ توکن در لیست: {test_token in PICO_AUTH_TOKENS}")
    
    # بررسی هر توکن در لیست
    for i, token in enumerate(PICO_AUTH_TOKENS):
        print(f"\n🔑 توکن {i+1}: '{token}'")
        print(f"📋 طول: {len(token)}")
        print(f"📋 bytes: {token.encode()}")
        print(f"✅ تطابق: {token == test_token}")

if __name__ == "__main__":
    test_tokens() 