#!/usr/bin/env python3
"""
Test script for HTTPS endpoints
"""

import requests
import json
import sys
import urllib3

# Disable SSL warnings for testing
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Configuration
BASE_URL = "https://smart-cctv-rash32.chbk.app"

def test_health_endpoint():
    """Test the health endpoint"""
    print("🔍 Testing health endpoint...")
    
    try:
        response = requests.get(f"{BASE_URL}/health", timeout=10, verify=False)
        print(f"📊 Status Code: {response.status_code}")
        
        if response.status_code == 200:
            print("✅ Health endpoint working")
            try:
                data = response.json()
                print(f"📋 Response: {json.dumps(data, indent=2)}")
            except:
                print(f"📋 Response: {response.text}")
            return True
        else:
            print(f"❌ Health endpoint failed: {response.status_code}")
            print(f"📋 Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Health endpoint error: {e}")
        return False

def test_public_tokens_endpoint():
    """Test the public tokens endpoint"""
    print("\n🔍 Testing public tokens endpoint...")
    
    try:
        response = requests.get(f"{BASE_URL}/public/tokens", timeout=10, verify=False)
        print(f"📊 Status Code: {response.status_code}")
        
        if response.status_code == 200:
            print("✅ Public tokens endpoint working")
            try:
                data = response.json()
                print(f"📋 Pico tokens: {len(data.get('pico_tokens', []))}")
                print(f"📋 ESP32CAM tokens: {len(data.get('esp32cam_tokens', []))}")
                if data.get('pico_tokens'):
                    print(f"🔑 Sample Pico token: {data['pico_tokens'][0][:10]}...")
                return True
            except Exception as e:
                print(f"❌ JSON parsing error: {e}")
                return False
        else:
            print(f"❌ Public tokens endpoint failed: {response.status_code}")
            print(f"📋 Response: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Public tokens endpoint error: {e}")
        return False

def test_ports_endpoint():
    """Test the ports endpoint"""
    print("\n🔍 Testing ports endpoint...")
    
    try:
        response = requests.get(f"{BASE_URL}/ports", timeout=10, verify=False)
        print(f"📊 Status Code: {response.status_code}")
        
        if response.status_code == 200:
            print("✅ Ports endpoint working")
            try:
                data = response.json()
                print(f"📋 Response: {json.dumps(data, indent=2)}")
            except:
                print(f"📋 Response: {response.text}")
            return True
        else:
            print(f"❌ Ports endpoint failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Ports endpoint error: {e}")
        return False

def test_devices_status_endpoint():
    """Test the devices status endpoint"""
    print("\n🔍 Testing devices status endpoint...")
    
    try:
        response = requests.get(f"{BASE_URL}/devices/status", timeout=10, verify=False)
        print(f"📊 Status Code: {response.status_code}")
        
        if response.status_code == 200:
            print("✅ Devices status endpoint working")
            try:
                data = response.json()
                print(f"📋 Response: {json.dumps(data, indent=2)}")
            except:
                print(f"📋 Response: {response.text}")
            return True
        else:
            print(f"❌ Devices status endpoint failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Devices status endpoint error: {e}")
        return False

def test_ssl_certificate():
    """Test SSL certificate"""
    print("\n🔍 Testing SSL certificate...")
    
    try:
        response = requests.get(f"{BASE_URL}/health", timeout=10, verify=True)
        print("✅ SSL certificate is valid")
        return True
    except requests.exceptions.SSLError as e:
        print(f"⚠️ SSL certificate issue: {e}")
        print("💡 Using verify=False for testing")
        return False
    except Exception as e:
        print(f"❌ SSL test error: {e}")
        return False

def main():
    """Main test function"""
    print("🚀 Testing HTTPS endpoints")
    print("=" * 50)
    print(f"📍 Base URL: {BASE_URL}")
    
    results = {}
    
    # Test SSL certificate
    results['ssl'] = test_ssl_certificate()
    
    # Test endpoints
    results['health'] = test_health_endpoint()
    results['tokens'] = test_public_tokens_endpoint()
    results['ports'] = test_ports_endpoint()
    results['devices'] = test_devices_status_endpoint()
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 TEST RESULTS SUMMARY")
    print("=" * 50)
    
    for test, success in results.items():
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{test.upper()}: {status}")
    
    all_passed = all(results.values())
    
    if all_passed:
        print("\n🎉 All tests passed! Server is accessible via HTTPS.")
        print("💡 WebSocket connections should work with WSS://")
    else:
        print("\n❌ Some tests failed. Check server configuration.")
    
    return all_passed

if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n⏹️ Test interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n💥 Unexpected error: {e}")
        sys.exit(1) 