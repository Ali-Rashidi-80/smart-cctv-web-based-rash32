#!/usr/bin/env python3
"""
تست‌های امنیت پیشرفته
Advanced Security Tests
"""

import sys
import os
import asyncio
import aiosqlite
import secrets
import hashlib
import jwt
import time
from datetime import datetime, timedelta
from typing import List, Dict, Any

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from server_fastapi import (
    init_db, 
    get_db_connection, 
    close_db_connection, 
    sanitize_input,
    create_access_token,
    verify_token,
    hash_password,
    verify_password,
    check_rate_limit,
    check_login_attempts,
    record_login_attempt
)

class AdvancedSecurityTester:
    def __init__(self):
        self.test_results = []
        self.security_vulnerabilities = []
        self.performance_metrics = {}
        
    def log_test(self, test_name: str, passed: bool, details: str = ""):
        """ثبت نتیجه تست"""
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status} {test_name}: {details}")
        self.test_results.append({
            "test": test_name,
            "passed": passed,
            "details": details,
            "timestamp": datetime.now().isoformat()
        })
        
    def log_vulnerability(self, category: str, description: str):
        """ثبت آسیب‌پذیری امنیتی"""
        print(f"🚨 SECURITY VULNERABILITY - {category}: {description}")
        self.security_vulnerabilities.append({
            "category": category,
            "description": description,
            "timestamp": datetime.now().isoformat()
        })

    async def test_password_strength_validation(self):
        """تست اعتبارسنجی قدرت رمز عبور"""
        print("\n🔐 تست اعتبارسنجی قدرت رمز عبور...")
        
        weak_passwords = [
            "123456",
            "password",
            "qwerty",
            "abc123",
            "password123",
            "admin",
            "letmein",
            "welcome",
            "monkey",
            "123456789"
        ]
        
        strong_passwords = [
            "MySecurePass123!",
            "Complex@Password#2024",
            "Str0ng!P@ssw0rd",
            "Secure#Pass$2024",
            "MyP@ssw0rd!2024"
        ]
        
        # تست رمزهای ضعیف
        for password in weak_passwords:
            hash_result = hash_password(password)
            if hash_result and hash_result.startswith("$2b$"):
                self.log_test(f"Weak Password Hashing - {password[:10]}...", True)
            else:
                self.log_test(f"Weak Password Hashing - {password[:10]}...", False, "Hashing failed")
                
        # تست رمزهای قوی
        for password in strong_passwords:
            hash_result = hash_password(password)
            if hash_result and hash_result.startswith("$2b$"):
                self.log_test(f"Strong Password Hashing - {password[:10]}...", True)
            else:
                self.log_test(f"Strong Password Hashing - {password[:10]}...", False, "Hashing failed")

    async def test_jwt_token_security(self):
        """تست امنیت JWT tokens"""
        print("\n🔑 تست امنیت JWT tokens...")
        
        # تست ایجاد توکن با داده‌های مختلف
        test_cases = [
            {"sub": "user1", "role": "user", "ip": "192.168.1.1"},
            {"sub": "admin1", "role": "admin", "ip": "10.0.0.1"},
            {"sub": "test_user", "role": "user", "ip": "127.0.0.1"},
            {"sub": "special@user.com", "role": "user", "ip": "172.16.0.1"}
        ]
        
        for test_data in test_cases:
            token = create_access_token(data=test_data)
            if token:
                # تست verification
                decoded = verify_token(token)
                if decoded and decoded.get("sub") == test_data["sub"]:
                    self.log_test(f"JWT Token Creation/Verification - {test_data['sub']}", True)
                else:
                    self.log_test(f"JWT Token Creation/Verification - {test_data['sub']}", False, "Verification failed")
            else:
                self.log_test(f"JWT Token Creation/Verification - {test_data['sub']}", False, "Token creation failed")

    async def test_sql_injection_advanced(self):
        """تست پیشرفته SQL Injection"""
        print("\n🛡️ تست پیشرفته SQL Injection...")
        
        advanced_sql_attacks = [
            # Blind SQL Injection
            "admin' AND (SELECT COUNT(*) FROM users) > 0--",
            "admin' AND (SELECT LENGTH(username) FROM users LIMIT 1) > 0--",
            "admin' AND (SELECT SUBSTR(username,1,1) FROM users LIMIT 1) = 'a'--",
            
            # Time-based SQL Injection
            "admin' AND (SELECT SLEEP(1))--",
            "admin' WAITFOR DELAY '00:00:01'--",
            
            # Union-based SQL Injection
            "admin' UNION SELECT NULL,NULL,NULL--",
            "admin' UNION SELECT username,password,email FROM users--",
            
            # Error-based SQL Injection
            "admin' AND UPDATEXML(1,CONCAT(0x7e,(SELECT @@version),0x7e),1)--",
            "admin' AND EXTRACTVALUE(1,CONCAT(0x7e,(SELECT database()),0x7e))--",
            
            # Boolean-based SQL Injection
            "admin' AND 1=1--",
            "admin' AND 1=2--",
            "admin' OR 1=1--",
            "admin' OR 1=2--"
        ]
        
        for attack in advanced_sql_attacks:
            sanitized = sanitize_input(attack)
            if sanitized != attack:
                self.log_test(f"Advanced SQL Injection Prevention - {attack[:30]}...", True)
            else:
                self.log_test(f"Advanced SQL Injection Prevention - {attack[:30]}...", False, "Attack not prevented")
                self.log_vulnerability("SQL Injection", f"Advanced attack not prevented: {attack[:50]}")

    async def test_xss_advanced(self):
        """تست پیشرفته XSS"""
        print("\n🛡️ تست پیشرفته XSS...")
        
        advanced_xss_attacks = [
            # DOM-based XSS
            "javascript:alert('xss')",
            "javascript:void(alert('xss'))",
            "javascript:confirm('xss')",
            "javascript:prompt('xss')",
            
            # Event handlers
            "onload=alert('xss')",
            "onerror=alert('xss')",
            "onclick=alert('xss')",
            "onmouseover=alert('xss')",
            "onfocus=alert('xss')",
            "onblur=alert('xss')",
            "onchange=alert('xss')",
            "onsubmit=alert('xss')",
            
            # Advanced payloads
            "<svg onload=alert('xss')>",
            "<img src=x onerror=alert('xss')>",
            "<iframe src=javascript:alert('xss')>",
            "<object data=javascript:alert('xss')>",
            "<embed src=javascript:alert('xss')>",
            
            # Encoded payloads
            "&#x3C;script&#x3E;alert('xss')&#x3C;/script&#x3E;",
            "&#60;script&#62;alert('xss')&#60;/script&#62;",
            "%3Cscript%3Ealert('xss')%3C/script%3E",
            
            # Mixed case
            "<ScRiPt>alert('xss')</ScRiPt>",
            "<SCRIPT>alert('xss')</SCRIPT>",
            
            # Null byte injection
            "<script\x00>alert('xss')</script>",
            "<script\x0D>alert('xss')</script>",
            "<script\x0A>alert('xss')</script>"
        ]
        
        for attack in advanced_xss_attacks:
            sanitized = sanitize_input(attack)
            if "<" not in sanitized and ">" not in sanitized:
                self.log_test(f"Advanced XSS Prevention - {attack[:30]}...", True)
            else:
                self.log_test(f"Advanced XSS Prevention - {attack[:30]}...", False, "XSS not prevented")
                self.log_vulnerability("XSS", f"Advanced attack not prevented: {attack[:50]}")

    async def test_rate_limiting_advanced(self):
        """تست پیشرفته Rate Limiting"""
        print("\n⏱️ تست پیشرفته Rate Limiting...")
        
        # تست IP های مختلف
        test_ips = [
            "192.168.1.100",
            "10.0.0.50",
            "172.16.0.25",
            "203.0.113.10",
            "198.51.100.5"
        ]
        
        for ip in test_ips:
            # تست درخواست‌های عادی
            for i in range(10):
                result = check_rate_limit(ip)
                if result:
                    self.log_test(f"Rate Limit Normal - {ip} (request {i+1})", True)
                else:
                    self.log_test(f"Rate Limit Normal - {ip} (request {i+1})", False, "Blocked too early")
            
            # تست درخواست‌های بیش از حد
            for i in range(10, 20):
                result = check_rate_limit(ip)
                if not result:
                    self.log_test(f"Rate Limit Blocked - {ip} (request {i+1})", True)
                else:
                    self.log_test(f"Rate Limit Blocked - {ip} (request {i+1})", False, "Not blocked when should be")

    async def test_session_hijacking_prevention(self):
        """تست جلوگیری از Session Hijacking"""
        print("\n🔒 تست جلوگیری از Session Hijacking...")
        
        # تست توکن‌های منقضی شده
        expired_token_data = {
            "sub": "testuser",
            "role": "user",
            "ip": "192.168.1.1",
            "exp": datetime.utcnow() - timedelta(hours=1)  # منقضی شده
        }
        
        try:
            import jwt
            from server_fastapi import SECRET_KEY, ALGORITHM
            expired_token = jwt.encode(expired_token_data, SECRET_KEY, algorithm=ALGORITHM)
            result = verify_token(expired_token)
            if result is None:
                self.log_test("Expired Token Rejection", True)
            else:
                self.log_test("Expired Token Rejection", False, "Expired token accepted")
                self.log_vulnerability("Session Management", "Expired token accepted")
        except Exception as e:
            self.log_test("Expired Token Rejection", True, f"Exception handled: {e}")
        
        # تست توکن‌های دستکاری شده
        tampered_token_data = {
            "sub": "testuser",
            "role": "admin",  # تغییر نقش
            "ip": "192.168.1.1"
        }
        
        try:
            tampered_token = jwt.encode(tampered_token_data, SECRET_KEY, algorithm=ALGORITHM)
            # دستکاری توکن
            tampered_token = tampered_token[:-1] + "X"
            result = verify_token(tampered_token)
            if result is None:
                self.log_test("Tampered Token Rejection", True)
            else:
                self.log_test("Tampered Token Rejection", False, "Tampered token accepted")
                self.log_vulnerability("Session Management", "Tampered token accepted")
        except Exception as e:
            self.log_test("Tampered Token Rejection", True, f"Exception handled: {e}")

    async def test_privilege_escalation_prevention(self):
        """تست جلوگیری از Privilege Escalation"""
        print("\n🛡️ تست جلوگیری از Privilege Escalation...")
        
        # تست تغییر نقش در توکن
        user_token_data = {
            "sub": "normaluser",
            "role": "user",
            "ip": "192.168.1.1"
        }
        
        try:
            import jwt
            from server_fastapi import SECRET_KEY, ALGORITHM
            
            # ایجاد توکن کاربر عادی
            user_token = jwt.encode(user_token_data, SECRET_KEY, algorithm=ALGORITHM)
            
            # تلاش برای تغییر نقش
            decoded = jwt.decode(user_token, SECRET_KEY, algorithms=[ALGORITHM])
            decoded["role"] = "admin"  # تغییر نقش
            
            # ایجاد توکن جدید با نقش تغییر یافته
            modified_token = jwt.encode(decoded, SECRET_KEY, algorithm=ALGORITHM)
            
            # بررسی اینکه آیا تغییر نقش تشخیص داده می‌شود
            result = verify_token(modified_token)
            if result and result.get("role") == "admin":
                self.log_test("Privilege Escalation Prevention", False, "Role escalation possible")
                self.log_vulnerability("Authorization", "Role escalation possible through token modification")
            else:
                self.log_test("Privilege Escalation Prevention", True)
                
        except Exception as e:
            self.log_test("Privilege Escalation Prevention", True, f"Exception handled: {e}")

    async def test_database_injection_prevention(self):
        """تست جلوگیری از Database Injection"""
        print("\n🗄️ تست جلوگیری از Database Injection...")
        
        try:
            conn = await get_db_connection()
            
            # تست NoSQL Injection
            nosql_attacks = [
                '{"$gt": ""}',
                '{"$ne": null}',
                '{"$where": "1==1"}',
                '{"$regex": ".*"}',
                '{"$exists": true}'
            ]
            
            for attack in nosql_attacks:
                sanitized = sanitize_input(attack)
                if sanitized != attack:
                    self.log_test(f"NoSQL Injection Prevention - {attack[:20]}...", True)
                else:
                    self.log_test(f"NoSQL Injection Prevention - {attack[:20]}...", False, "Attack not prevented")
            
            # تست Command Injection
            command_attacks = [
                "; rm -rf /",
                "| cat /etc/passwd",
                "&& whoami",
                "|| id",
                "`whoami`",
                "$(id)",
                "| bash -c 'echo hacked'"
            ]
            
            for attack in command_attacks:
                sanitized = sanitize_input(attack)
                if sanitized != attack:
                    self.log_test(f"Command Injection Prevention - {attack[:20]}...", True)
                else:
                    self.log_test(f"Command Injection Prevention - {attack[:20]}...", False, "Attack not prevented")
            
            await close_db_connection(conn)
            
        except Exception as e:
            self.log_test("Database Injection Prevention", False, f"Error: {e}")

    async def test_csrf_prevention(self):
        """تست جلوگیری از CSRF"""
        print("\n🛡️ تست جلوگیری از CSRF...")
        
        # تست توکن‌های CSRF
        csrf_tokens = [
            "invalid_csrf_token",
            "1234567890abcdef",
            "csrf_token_12345",
            "",
            None
        ]
        
        for token in csrf_tokens:
            # شبیه‌سازی بررسی CSRF token
            if token and len(token) >= 16:
                self.log_test(f"CSRF Token Validation - {str(token)[:10]}...", True)
            else:
                self.log_test(f"CSRF Token Validation - {str(token)[:10]}...", False, "Weak CSRF token")

    async def test_file_upload_security(self):
        """تست امنیت آپلود فایل"""
        print("\n📁 تست امنیت آپلود فایل...")
        
        # تست فایل‌های خطرناک
        dangerous_files = [
            "malware.exe",
            "script.php",
            "shell.jsp",
            "backdoor.asp",
            "virus.bat",
            "trojan.cmd",
            "exploit.sh",
            "hack.py"
        ]
        
        for filename in dangerous_files:
            # شبیه‌سازی بررسی نوع فایل
            if filename.endswith(('.exe', '.php', '.jsp', '.asp', '.bat', '.cmd', '.sh', '.py')):
                self.log_test(f"Dangerous File Detection - {filename}", True)
            else:
                self.log_test(f"Dangerous File Detection - {filename}", False, "Dangerous file not detected")

    async def run_all_tests(self):
        """اجرای تمام تست‌ها"""
        print("🔧 تست‌های امنیت پیشرفته")
        print("=" * 60)
        
        # راه‌اندازی دیتابیس
        try:
            await init_db()
            print("✅ دیتابیس راه‌اندازی شد")
        except Exception as e:
            print(f"❌ خطا در راه‌اندازی دیتابیس: {e}")
            return False
        
        # اجرای تست‌ها
        await self.test_password_strength_validation()
        await self.test_jwt_token_security()
        await self.test_sql_injection_advanced()
        await self.test_xss_advanced()
        await self.test_rate_limiting_advanced()
        await self.test_session_hijacking_prevention()
        await self.test_privilege_escalation_prevention()
        await self.test_database_injection_prevention()
        await self.test_csrf_prevention()
        await self.test_file_upload_security()
        
        # گزارش نهایی
        print("\n" + "=" * 60)
        print("📊 گزارش نهایی تست‌های امنیت پیشرفته")
        print("=" * 60)
        
        passed = sum(1 for result in self.test_results if result["passed"])
        total = len(self.test_results)
        
        print(f"📈 آمار کلی:")
        print(f"   کل تست‌ها: {total}")
        print(f"   تست‌های موفق: {passed}")
        print(f"   تست‌های ناموفق: {total - passed}")
        print(f"   نرخ موفقیت: {(passed/total)*100:.1f}%")
        
        if self.security_vulnerabilities:
            print(f"\n🚨 آسیب‌پذیری‌های امنیتی یافت شده: {len(self.security_vulnerabilities)}")
            for vuln in self.security_vulnerabilities:
                print(f"   - {vuln['category']}: {vuln['description']}")
        else:
            print(f"\n✅ هیچ آسیب‌پذیری امنیتی یافت نشد!")
        
        print(f"\n💡 توصیه‌ها:")
        if passed == total:
            print("   - سیستم امنیت در سطح عالی است!")
        else:
            print("   - برخی مشکلات امنیتی نیاز به بررسی دارند")
        
        return passed == total

async def main():
    """تابع اصلی"""
    tester = AdvancedSecurityTester()
    success = await tester.run_all_tests()
    
    if success:
        print("\n🎉 تمام تست‌های امنیت پیشرفته موفق بودند!")
    else:
        print("\n⚠️ برخی تست‌های امنیت پیشرفته ناموفق بودند!")

if __name__ == "__main__":
    asyncio.run(main())