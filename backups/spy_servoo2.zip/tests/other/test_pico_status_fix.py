#!/usr/bin/env python3
"""
Test Pico Status Fix
"""

import asyncio
import json
import time
import websockets
import requests

WS_URL = "ws://localhost:3000/ws/pico"
AUTH_TOKEN = "rof642fr:5qEKU@A@Tv"
BASE_URL = "http://localhost:3000"

async def test_pico_status_fix():
    """Test if Pico status detection is working correctly"""
    print("🔍 Testing Pico Status Fix")
    print("=" * 40)
    
    # Create session and login
    session = requests.Session()
    login_data = {
        "username": "rof642fr",
        "password": "5qEKU@A@Tv"
    }
    
    try:
        response = session.post(f"{BASE_URL}/login", json=login_data, timeout=5)
        if response.status_code != 200:
            print("❌ Login failed")
            return False
        print("✅ Login successful")
    except Exception as e:
        print(f"❌ Login error: {e}")
        return False
    
    # Test 1: Check initial status (should be offline)
    print("\n1️⃣ Checking initial status...")
    try:
        response = session.get(f"{BASE_URL}/get_status", timeout=5)
        
        if response.status_code == 200:
            data = response.json()
            initial_status = data.get("data", {}).get("pico_status", "unknown")
            print(f"   Initial Pico status: {initial_status}")
        else:
            print(f"   ❌ Failed to get status: {response.status_code}")
            return False
    except Exception as e:
        print(f"   ❌ Error getting initial status: {e}")
        return False
    
    # Test 2: Connect Pico and check status
    print("\n2️⃣ Connecting Pico and checking status...")
    try:
        headers = {"Authorization": f"Bearer {AUTH_TOKEN}"}
        async with websockets.connect(WS_URL, extra_headers=headers) as websocket:
            print("   ✅ Pico connected")
            
            # Send connection message
            await websocket.send(json.dumps({
                "type": "connect",
                "device": "pico",
                "version": "1.0"
            }))
            
            # Wait for connection ack
            try:
                response = await asyncio.wait_for(websocket.recv(), timeout=2.0)
                data = json.loads(response)
                if data.get("type") == "connection_ack":
                    print("   ✅ Connection acknowledged")
                else:
                    print(f"   ⚠️ Unexpected response: {data.get('type')}")
            except asyncio.TimeoutError:
                print("   ⚠️ No connection ack received")
            
            # Wait a moment for status to update
            await asyncio.sleep(1)
            
            # Check status again
            response = session.get(f"{BASE_URL}/get_status", timeout=5)
            if response.status_code == 200:
                data = response.json()
                connected_status = data.get("data", {}).get("pico_status", "unknown")
                last_seen = data.get("data", {}).get("pico_last_seen", "unknown")
                print(f"   Connected Pico status: {connected_status}")
                print(f"   Last seen: {last_seen}")
                
                if connected_status == "online":
                    print("   ✅ Status correctly shows ONLINE!")
                    status_fixed = True
                else:
                    print("   ❌ Status still shows OFFLINE")
                    status_fixed = False
            else:
                print(f"   ❌ Failed to get status: {response.status_code}")
                status_fixed = False
                
    except Exception as e:
        print(f"   ❌ Error connecting Pico: {e}")
        status_fixed = False
    
    # Test 3: Disconnect and check status
    print("\n3️⃣ Disconnecting and checking status...")
    await asyncio.sleep(2)  # Wait for disconnect
    
    try:
        response = session.get(f"{BASE_URL}/get_status", timeout=5)
        if response.status_code == 200:
            data = response.json()
            final_status = data.get("data", {}).get("pico_status", "unknown")
            print(f"   Final Pico status: {final_status}")
            
            if final_status == "offline":
                print("   ✅ Status correctly shows OFFLINE after disconnect!")
                disconnect_fixed = True
            else:
                print("   ❌ Status still shows ONLINE after disconnect")
                disconnect_fixed = False
        else:
            print(f"   ❌ Failed to get final status: {response.status_code}")
            disconnect_fixed = False
    except Exception as e:
        print(f"   ❌ Error getting final status: {e}")
        disconnect_fixed = False
    
    # Calculate overall result
    print("\n📊 Test Results:")
    print(f"   Connection Status Detection: {'✅ PASS' if status_fixed else '❌ FAIL'}")
    print(f"   Disconnect Status Detection: {'✅ PASS' if disconnect_fixed else '❌ FAIL'}")
    
    overall_success = status_fixed and disconnect_fixed
    print(f"\n🎯 Overall Result: {'✅ SUCCESS' if overall_success else '❌ FAILED'}")
    
    return overall_success

async def main():
    print("🚀 Pico Status Fix Test")
    print("Testing if Pico online/offline detection works correctly...")
    print()
    
    success = await test_pico_status_fix()
    
    print()
    if success:
        print("🎉 PICO STATUS DETECTION FIXED!")
        print("✅ Pico shows ONLINE when connected")
        print("✅ Pico shows OFFLINE when disconnected")
        print("✅ Status updates correctly in real-time")
        print("\n🏆 Pico status detection is now working properly!")
    else:
        print("⚠️ PICO STATUS DETECTION STILL HAS ISSUES")
        print("❌ Status detection needs more work")
    
    print("\n🏁 Test completed!")

if __name__ == "__main__":
    asyncio.run(main()) 