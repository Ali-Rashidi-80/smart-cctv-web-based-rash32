import pytest
import asyncio
import websockets

WS_URL = "ws://localhost:3000/ws/pico"  # اگر پورت متفاوت است، اصلاح شود

@pytest.mark.asyncio
async def test_pico_websocket_connection():
    try:
        async with websockets.connect(WS_URL, ping_interval=None) as websocket:
            # ارسال پیام تست (در صورت نیاز)
            test_message = "ping"
            await websocket.send(test_message)
            # دریافت پاسخ (در صورت پیاده‌سازی سمت سرور)
            try:
                response = await asyncio.wait_for(websocket.recv(), timeout=3)
                assert response is not None
                print(f"[TEST] Received response: {response}")
            except asyncio.TimeoutError:
                # اگر پاسخ نداد، فقط اتصال را بررسی می‌کنیم
                print("[TEST] No response received, but connection established.")
    except Exception as e:
        pytest.fail(f"WebSocket connection to /ws/pico failed: {e}") 