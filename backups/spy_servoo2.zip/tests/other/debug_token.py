#!/usr/bin/env python3
"""
🔍 Debug Script for Token Authentication
Checks the exact token values and authentication logic
"""

import os

# Print the exact token values
print("🔍 Debugging Token Values...")
print("=" * 50)

# Check environment variable
env_token = os.getenv("PICO_AUTH_TOKENS")
print(f"Environment PICO_AUTH_TOKENS: {env_token}")

# Default token string
default_token_string = "m78jmdzu:2G/O\\S'W]_E],pico_secure_token_2024,rof642fr:5\0EKU@A@Tv"
print(f"Default token string: {default_token_string}")

# Split tokens
tokens = default_token_string.split(",")
print(f"Split tokens: {tokens}")

# Check each token
for i, token in enumerate(tokens):
    print(f"Token {i+1}: '{token}' (length: {len(token)})")
    # Show hex representation
    hex_repr = ' '.join([f'{ord(c):02x}' for c in token])
    print(f"  Hex: {hex_repr}")

# Test the specific Pico token
pico_token = "rof642fr:5\0EKU@A@Tv"
print(f"\n🔑 Pico token from client: '{pico_token}' (length: {len(pico_token)})")
pico_hex = ' '.join([f'{ord(c):02x}' for c in pico_token])
print(f"  Hex: {pico_hex}")

# Check if token is in the list
is_valid = pico_token in tokens
print(f"\n✅ Token valid: {is_valid}")

# Check each token individually
for i, token in enumerate(tokens):
    if pico_token == token:
        print(f"✅ Match found at position {i+1}")
        break
else:
    print("❌ No exact match found")
    
    # Check for partial matches
    print("\n🔍 Checking for partial matches...")
    for i, token in enumerate(tokens):
        if "rof642fr" in token:
            print(f"  Partial match at position {i+1}: '{token}'")
            print(f"  Client token: '{pico_token}'")
            print(f"  Server token: '{token}'")
            print(f"  Equal: {pico_token == token}")

print("\n" + "=" * 50)
print("🔍 Debug complete!") 