#!/usr/bin/env python3
"""
Simple test to verify startup event and database initialization
"""

import asyncio
import aiosqlite
import os
import sys

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

async def test_startup_components():
    """Test if startup components are available and working"""
    print("🔍 Testing startup components...")
    print("=" * 60)
    
    try:
        # Test database connection
        conn = await aiosqlite.connect("smart_camera_system.db")
        print("✅ Database connection successful")
        
        # Check if tables exist
        cursor = await conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = await cursor.fetchall()
        table_names = [table[0] for table in tables]
        
        required_tables = [
            'users', 'camera_logs', 'password_recovery', 'servo_commands',
            'action_commands', 'device_mode_commands', 'manual_photos',
            'security_videos', 'user_settings'
        ]
        
        print("📊 Checking required tables:")
        missing_tables = []
        for table in required_tables:
            if table in table_names:
                print(f"   ✅ {table}")
            else:
                print(f"   ❌ {table} - missing")
                missing_tables.append(table)
        
        # Check admin user
        cursor = await conn.execute("SELECT COUNT(*) FROM users WHERE role = 'admin'")
        admin_count = await cursor.fetchone()
        if admin_count[0] > 0:
            print("   ✅ Admin user exists")
        else:
            print("   ❌ Admin user missing")
        
        await conn.close()
        
        if missing_tables:
            print(f"\n⚠️ Missing tables: {missing_tables}")
            print("💡 This indicates that startup event may not be working correctly")
            return False
        else:
            print("\n✅ All tables exist - startup event should work correctly")
            return True
            
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False

async def test_startup_functions():
    """Test if startup functions can be imported and executed"""
    print("\n🚀 Testing startup functions...")
    print("=" * 60)
    
    try:
        # Test imports
        from server_fastapi import init_db, migrate_all_tables
        print("✅ Startup functions imported successfully")
        
        # Test init_db function
        print("🔄 Testing init_db function...")
        await init_db()
        print("✅ init_db function executed successfully")
        
        # Test migrate_all_tables function
        print("🔄 Testing migrate_all_tables function...")
        await migrate_all_tables()
        print("✅ migrate_all_tables function executed successfully")
        
        return True
        
    except Exception as e:
        print(f"❌ Startup functions test failed: {e}")
        return False

async def main():
    """Main test function"""
    print("🚀 Startup Event and Database Verification Test")
    print("=" * 60)
    
    # Test current database state
    db_ok = await test_startup_components()
    
    # Test startup functions
    startup_ok = await test_startup_functions()
    
    print("\n" + "=" * 60)
    print("📋 SUMMARY:")
    print("=" * 60)
    
    if db_ok and startup_ok:
        print("🎉 All tests passed!")
        print("✅ Database is properly initialized")
        print("✅ Startup event components are working")
        print("✅ System should work correctly")
        print("\n💡 You can now run: python server_fastapi.py")
    elif db_ok:
        print("⚠️ Database is OK but startup functions may have issues")
        print("💡 Try running the server to see if startup event works")
    else:
        print("❌ Database has issues")
        print("💡 Run: python reset_database.py")
        print("💡 Then run: python server_fastapi.py")

if __name__ == "__main__":
    asyncio.run(main()) 