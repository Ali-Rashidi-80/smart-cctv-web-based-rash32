#!/usr/bin/env python3
"""
تست خودکار و مستمر
Automated Continuous Testing System
"""

import sys
import os
import asyncio
import time
import json
import schedule
import threading
from datetime import datetime, timedelta
from typing import List, Dict, Any
import logging

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# تنظیم logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('tests/continuous_test.log'),
        logging.StreamHandler()
    ]
)

class AutomatedContinuousTester:
    def __init__(self):
        self.test_history = []
        self.current_status = "IDLE"
        self.last_test_time = None
        self.test_interval_minutes = 30  # تست هر 30 دقیقه
        self.max_history_size = 100
        
    def log_test_result(self, test_name: str, success: bool, details: str = "", duration: float = 0):
        """ثبت نتیجه تست"""
        result = {
            "test_name": test_name,
            "success": success,
            "details": details,
            "duration": duration,
            "timestamp": datetime.now().isoformat()
        }
        
        self.test_history.append(result)
        
        # محدود کردن اندازه تاریخچه
        if len(self.test_history) > self.max_history_size:
            self.test_history = self.test_history[-self.max_history_size:]
        
        status = "✅ PASS" if success else "❌ FAIL"
        logging.info(f"{status} {test_name}: {details} ({duration:.2f}s)")
        
        return result

    async def quick_security_check(self):
        """بررسی سریع امنیت"""
        start_time = time.time()
        
        try:
            from server_fastapi import (
                sanitize_input,
                create_access_token,
                verify_token,
                hash_password,
                verify_password
            )
            
            # تست sanitization
            test_input = "admin' OR '1'='1"
            sanitized = sanitize_input(test_input)
            sanitization_ok = sanitized != test_input
            
            # تست JWT
            token_data = {"sub": "testuser", "role": "user"}
            token = create_access_token(data=token_data)
            decoded = verify_token(token)
            jwt_ok = decoded and decoded.get("sub") == "testuser"
            
            # تست password hashing
            password = "test123"
            hashed = hash_password(password)
            verify_ok = verify_password(password, hashed)
            
            duration = time.time() - start_time
            success = sanitization_ok and jwt_ok and verify_ok
            
            return self.log_test_result(
                "Quick Security Check",
                success,
                f"Sanitization: {sanitization_ok}, JWT: {jwt_ok}, Password: {verify_ok}",
                duration
            )
            
        except Exception as e:
            duration = time.time() - start_time
            return self.log_test_result(
                "Quick Security Check",
                False,
                f"Error: {e}",
                duration
            )

    async def quick_database_check(self):
        """بررسی سریع دیتابیس"""
        start_time = time.time()
        
        try:
            from server_fastapi import init_db, get_db_connection, close_db_connection
            
            await init_db()
            conn = await get_db_connection()
            
            # بررسی جداول اصلی
            tables = ["users", "camera_logs", "servo_commands"]
            table_checks = []
            
            for table in tables:
                cursor = await conn.execute(f"SELECT COUNT(*) FROM {table}")
                result = await cursor.fetchone()
                table_checks.append(result is not None)
            
            await close_db_connection(conn)
            
            duration = time.time() - start_time
            success = all(table_checks)
            
            return self.log_test_result(
                "Quick Database Check",
                success,
                f"Tables checked: {len(table_checks)}, All OK: {success}",
                duration
            )
            
        except Exception as e:
            duration = time.time() - start_time
            return self.log_test_result(
                "Quick Database Check",
                False,
                f"Error: {e}",
                duration
            )

    async def quick_performance_check(self):
        """بررسی سریع عملکرد"""
        start_time = time.time()
        
        try:
            from server_fastapi import (
                sanitize_input,
                create_access_token,
                verify_token,
                hash_password
            )
            
            # تست عملکرد sanitization
            sanitization_start = time.time()
            for i in range(100):
                sanitize_input(f"test_input_{i}")
            sanitization_time = time.time() - sanitization_start
            
            # تست عملکرد JWT
            jwt_start = time.time()
            for i in range(50):
                token = create_access_token(data={"sub": f"user_{i}", "role": "user"})
                verify_token(token)
            jwt_time = time.time() - jwt_start
            
            # تست عملکرد password hashing
            hash_start = time.time()
            for i in range(10):
                hash_password(f"password_{i}")
            hash_time = time.time() - hash_start
            
            duration = time.time() - start_time
            
            # بررسی معیارهای عملکرد
            sanitization_ok = sanitization_time < 1.0  # کمتر از 1 ثانیه
            jwt_ok = jwt_time < 2.0  # کمتر از 2 ثانیه
            hash_ok = hash_time < 5.0  # کمتر از 5 ثانیه
            
            success = sanitization_ok and jwt_ok and hash_ok
            
            return self.log_test_result(
                "Quick Performance Check",
                success,
                f"Sanitization: {sanitization_time:.3f}s, JWT: {jwt_time:.3f}s, Hash: {hash_time:.3f}s",
                duration
            )
            
        except Exception as e:
            duration = time.time() - start_time
            return self.log_test_result(
                "Quick Performance Check",
                False,
                f"Error: {e}",
                duration
            )

    async def run_continuous_test_cycle(self):
        """اجرای یک چرخه تست مستمر"""
        logging.info("🔄 شروع چرخه تست مستمر...")
        self.current_status = "RUNNING"
        
        cycle_start_time = time.time()
        results = []
        
        # اجرای تست‌های سریع
        results.append(await self.quick_security_check())
        results.append(await self.quick_database_check())
        results.append(await self.quick_performance_check())
        
        cycle_duration = time.time() - cycle_start_time
        successful_tests = sum(1 for result in results if result["success"])
        total_tests = len(results)
        
        self.current_status = "COMPLETED"
        self.last_test_time = datetime.now()
        
        logging.info(f"✅ چرخه تست مستمر تکمیل شد: {successful_tests}/{total_tests} موفق ({cycle_duration:.2f}s)")
        
        # ذخیره نتایج
        self.save_test_results(results)
        
        return {
            "cycle_duration": cycle_duration,
            "successful_tests": successful_tests,
            "total_tests": total_tests,
            "success_rate": (successful_tests/total_tests)*100 if total_tests > 0 else 0,
            "results": results
        }

    def save_test_results(self, results: List[Dict]):
        """ذخیره نتایج تست"""
        try:
            results_file = "tests/continuous_test_results.json"
            
            # خواندن نتایج قبلی
            existing_results = []
            if os.path.exists(results_file):
                with open(results_file, 'r', encoding='utf-8') as f:
                    existing_results = json.load(f)
            
            # اضافه کردن نتایج جدید
            cycle_result = {
                "timestamp": datetime.now().isoformat(),
                "results": results,
                "summary": {
                    "total_tests": len(results),
                    "successful_tests": sum(1 for r in results if r["success"]),
                    "duration": sum(r["duration"] for r in results)
                }
            }
            
            existing_results.append(cycle_result)
            
            # محدود کردن اندازه فایل
            if len(existing_results) > 50:
                existing_results = existing_results[-50:]
            
            # ذخیره
            with open(results_file, 'w', encoding='utf-8') as f:
                json.dump(existing_results, f, indent=2, ensure_ascii=False)
                
        except Exception as e:
            logging.error(f"خطا در ذخیره نتایج: {e}")

    def get_test_statistics(self):
        """دریافت آمار تست"""
        if not self.test_history:
            return {
                "total_tests": 0,
                "successful_tests": 0,
                "failed_tests": 0,
                "success_rate": 0,
                "average_duration": 0
            }
        
        total_tests = len(self.test_history)
        successful_tests = sum(1 for result in self.test_history if result["success"])
        failed_tests = total_tests - successful_tests
        success_rate = (successful_tests/total_tests)*100 if total_tests > 0 else 0
        average_duration = sum(result["duration"] for result in self.test_history) / total_tests
        
        return {
            "total_tests": total_tests,
            "successful_tests": successful_tests,
            "failed_tests": failed_tests,
            "success_rate": success_rate,
            "average_duration": average_duration
        }

    def print_status(self):
        """چاپ وضعیت فعلی"""
        stats = self.get_test_statistics()
        
        print("\n" + "=" * 60)
        print("📊 وضعیت تست مستمر")
        print("=" * 60)
        print(f"وضعیت فعلی: {self.current_status}")
        print(f"آخرین تست: {self.last_test_time.strftime('%Y-%m-%d %H:%M:%S') if self.last_test_time else 'هیچ'}")
        print(f"فاصله تست: {self.test_interval_minutes} دقیقه")
        print(f"\nآمار کلی:")
        print(f"   کل تست‌ها: {stats['total_tests']}")
        print(f"   موفق: {stats['successful_tests']}")
        print(f"   ناموفق: {stats['failed_tests']}")
        print(f"   نرخ موفقیت: {stats['success_rate']:.1f}%")
        print(f"   میانگین زمان: {stats['average_duration']:.3f} ثانیه")

    def start_continuous_testing(self):
        """شروع تست مستمر"""
        logging.info("🚀 شروع سیستم تست مستمر...")
        
        # تنظیم schedule
        schedule.every(self.test_interval_minutes).minutes.do(self.run_scheduled_test)
        
        # اجرای تست اولیه
        asyncio.run(self.run_continuous_test_cycle())
        
        # شروع loop
        while True:
            try:
                schedule.run_pending()
                time.sleep(60)  # بررسی هر دقیقه
            except KeyboardInterrupt:
                logging.info("⏹️ توقف تست مستمر...")
                break
            except Exception as e:
                logging.error(f"خطا در تست مستمر: {e}")
                time.sleep(60)

    def run_scheduled_test(self):
        """اجرای تست زمان‌بندی شده"""
        asyncio.run(self.run_continuous_test_cycle())

    async def run_single_cycle(self):
        """اجرای یک چرخه تست"""
        return await self.run_continuous_test_cycle()

async def main():
    """تابع اصلی"""
    tester = AutomatedContinuousTester()
    
    # اجرای یک چرخه تست
    result = await tester.run_single_cycle()
    
    # چاپ وضعیت
    tester.print_status()
    
    # چاپ نتیجه
    print(f"\n📈 نتیجه چرخه اخیر:")
    print(f"   تست‌های موفق: {result['successful_tests']}/{result['total_tests']}")
    print(f"   نرخ موفقیت: {result['success_rate']:.1f}%")
    print(f"   زمان کل: {result['cycle_duration']:.2f} ثانیه")
    
    if result['success_rate'] == 100:
        print("🎉 تمام تست‌ها موفق بودند!")
    else:
        print("⚠️ برخی تست‌ها ناموفق بودند")

if __name__ == "__main__":
    asyncio.run(main())