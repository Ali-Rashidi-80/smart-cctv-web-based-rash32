#!/usr/bin/env python3
"""
تست مستقیم Google OAuth
Direct Google OAuth Test
"""

import asyncio
import httpx
import json
import time
from datetime import datetime

async def test_google_oauth_flow():
    """تست مستقیم جریان Google OAuth"""
    print("🔐 تست مستقیم Google OAuth")
    print("=" * 50)
    
    base_url = "http://localhost:3000"
    
    async with httpx.AsyncClient() as client:
        try:
            # Test 1: Check Google OAuth redirect
            print("1️⃣ تست Google OAuth redirect...")
            response = await client.get(f"{base_url}/auth/google", follow_redirects=False)
            
            if response.status_code == 302:
                redirect_url = response.headers.get('location', '')
                if 'accounts.google.com' in redirect_url:
                    print("✅ Google OAuth redirect صحیح است")
                    print(f"   URL: {redirect_url[:100]}...")
                else:
                    print(f"❌ Google OAuth redirect نامعتبر: {redirect_url}")
                    return False
            else:
                print(f"❌ Google OAuth redirect: {response.status_code}")
                return False
            
            # Test 2: Check callback with invalid parameters
            print("\n2️⃣ تست callback با پارامترهای نامعتبر...")
            response = await client.get(f"{base_url}/auth/google/callback?code=invalid&state=invalid", follow_redirects=False)
            
            if response.status_code in [302, 307]:
                redirect_url = response.headers.get('location', '')
                if 'error=google_auth_failed' in redirect_url:
                    print("✅ callback نامعتبر به درستی مدیریت می‌شود")
                else:
                    print(f"⚠️ callback نامعتبر: {redirect_url}")
            else:
                print(f"❌ callback نامعتبر: {response.status_code}")
                return False
            
            # Test 3: Check dashboard access without auth
            print("\n3️⃣ تست دسترسی به dashboard بدون احراز هویت...")
            response = await client.get(f"{base_url}/dashboard", follow_redirects=False)
            
            if response.status_code == 302:
                redirect_url = response.headers.get('location', '')
                if '/login' in redirect_url:
                    print("✅ dashboard بدون احراز هویت به درستی redirect می‌کند")
                else:
                    print(f"⚠️ redirect نامعتبر: {redirect_url}")
            else:
                print(f"❌ dashboard بدون احراز هویت: {response.status_code}")
                return False
            
            # Test 4: Check login page
            print("\n4️⃣ تست صفحه لاگین...")
            response = await client.get(f"{base_url}/login")
            
            if response.status_code == 200:
                print("✅ صفحه لاگین قابل دسترس است")
            else:
                print(f"❌ صفحه لاگین: {response.status_code}")
                return False
            
            # Test 5: Check if login page contains Google OAuth button
            if "google" in response.text.lower() or "oauth" in response.text.lower():
                print("✅ صفحه لاگین شامل دکمه Google OAuth است")
            else:
                print("⚠️ صفحه لاگین ممکن است شامل دکمه Google OAuth نباشد")
            
            print("\n🎉 تمام تست‌های Google OAuth موفق بودند!")
            return True
            
        except Exception as e:
            print(f"❌ خطا در تست: {e}")
            return False

async def test_middleware_behavior():
    """تست رفتار middleware"""
    print("\n🔧 تست رفتار Middleware")
    print("=" * 50)
    
    base_url = "http://localhost:3000"
    
    async with httpx.AsyncClient() as client:
        try:
            # Test various headers
            test_cases = [
                {"name": "بدون header", "headers": {}},
                {"name": "Accept: application/json", "headers": {"Accept": "application/json"}},
                {"name": "Content-Type: application/json", "headers": {"Content-Type": "application/json"}},
                {"name": "هر دو header", "headers": {"Accept": "application/json", "Content-Type": "application/json"}}
            ]
            
            for test_case in test_cases:
                print(f"🔍 تست {test_case['name']}...")
                response = await client.get(f"{base_url}/dashboard", headers=test_case['headers'], follow_redirects=False)
                print(f"   Status: {response.status_code}")
                
                if response.status_code == 302:
                    redirect_url = response.headers.get('location', '')
                    print(f"   Redirect: {redirect_url}")
                
                await asyncio.sleep(0.1)
            
            print("✅ تمام تست‌های middleware موفق بودند!")
            return True
            
        except Exception as e:
            print(f"❌ خطا در تست middleware: {e}")
            return False

async def main():
    """تابع اصلی"""
    print("🚀 شروع تست مستقیم Google OAuth")
    print("=" * 60)
    
    # Wait for server to be ready
    await asyncio.sleep(3)
    
    # Run tests
    oauth_success = await test_google_oauth_flow()
    middleware_success = await test_middleware_behavior()
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 خلاصه نتایج تست")
    print("=" * 60)
    
    print(f"Google OAuth Flow: {'✅ PASS' if oauth_success else '❌ FAIL'}")
    print(f"Middleware Behavior: {'✅ PASS' if middleware_success else '❌ FAIL'}")
    
    if oauth_success and middleware_success:
        print("\n🎉 تمام تست‌ها موفق بودند!")
        print("✅ Google OAuth آماده است!")
        print("✅ مشکل Unauthorized حل شد!")
        return True
    else:
        print("\n⚠️ برخی تست‌ها ناموفق بودند")
        return False

if __name__ == "__main__":
    success = asyncio.run(main())
    exit(0 if success else 1)