#!/usr/bin/env python3
"""
Quick test script for basic functionality
"""

import os
import sys
import sqlite3
import json
import time
from datetime import datetime

def test_environment():
    """Test environment variables"""
    print("🔍 Testing environment...")
    
    required_vars = ['SECRET_KEY', 'ADMIN_USERNAME', 'ADMIN_PASSWORD']
    missing_vars = []
    
    for var in required_vars:
        if var in os.environ:
            print(f"✅ {var}: Set")
        else:
            print(f"❌ {var}: Missing")
            missing_vars.append(var)
    
    if missing_vars:
        print(f"⚠️ Missing environment variables: {missing_vars}")
        return False
    else:
        print("✅ All required environment variables are set")
        return True

def test_database():
    """Test database connectivity and tables"""
    print("\n🗄️ Testing database...")
    
    try:
        # Check if database file exists
        db_path = "smart_camera_system.db"
        if not os.path.exists(db_path):
            print(f"❌ Database file not found: {db_path}")
            return False
        
        print(f"✅ Database file exists: {db_path}")
        
        # Connect to database
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [row[0] for row in cursor.fetchall()]
        
        required_tables = [
            'users', 'camera_logs', 'password_recovery', 
            'servo_commands', 'action_commands', 'device_mode_commands',
            'manual_photos', 'security_videos', 'user_settings'
        ]
        
        missing_tables = []
        for table in required_tables:
            if table in tables:
                print(f"✅ Table {table}: Exists")
            else:
                print(f"❌ Table {table}: Missing")
                missing_tables.append(table)
        
        if missing_tables:
            print(f"⚠️ Missing tables: {missing_tables}")
            return False
        
        # Check admin user
        cursor.execute("SELECT username FROM users WHERE role = 'admin'")
        admin_users = cursor.fetchall()
        
        if admin_users:
            print(f"✅ Admin user exists: {admin_users[0][0]}")
        else:
            print("❌ No admin user found")
            return False
        
        conn.close()
        print("✅ Database test passed")
        return True
        
    except Exception as e:
        print(f"❌ Database test failed: {e}")
        return False

def test_directories():
    """Test required directories"""
    print("\n📁 Testing directories...")
    
    required_dirs = [
        'gallery', 'security_videos', 'logs', 'backups'
    ]
    
    missing_dirs = []
    for dir_name in required_dirs:
        if os.path.exists(dir_name):
            print(f"✅ Directory {dir_name}: Exists")
        else:
            print(f"❌ Directory {dir_name}: Missing")
            missing_dirs.append(dir_name)
    
    if missing_dirs:
        print(f"⚠️ Missing directories: {missing_dirs}")
        return False
    else:
        print("✅ All required directories exist")
        return True

def test_imports():
    """Test required Python packages"""
    print("\n📦 Testing imports...")
    
    required_packages = [
        'fastapi', 'uvicorn', 'sqlite3', 'httpx', 'websockets',
        'asyncio', 'json', 'datetime', 'logging'
    ]
    
    missing_packages = []
    for package in required_packages:
        try:
            __import__(package)
            print(f"✅ Package {package}: Available")
        except ImportError:
            print(f"❌ Package {package}: Missing")
            missing_packages.append(package)
    
    if missing_packages:
        print(f"⚠️ Missing packages: {missing_packages}")
        return False
    else:
        print("✅ All required packages are available")
        return True

def generate_report(results):
    """Generate test report"""
    print("\n" + "="*60)
    print("📊 گزارش تست سریع سیستم دوربین هوشمند")
    print("="*60)
    
    total_tests = len(results)
    passed_tests = sum(1 for r in results if r["status"])
    failed_tests = total_tests - passed_tests
    
    success_rate = (passed_tests / total_tests) * 100 if total_tests > 0 else 0
    
    print(f"📈 کل تست‌ها: {total_tests}")
    print(f"✅ موفق: {passed_tests}")
    print(f"❌ ناموفق: {failed_tests}")
    print(f"📊 نرخ موفقیت: {success_rate:.1f}%")
    print("="*60)
    
    print("\n📋 جزئیات نتایج:")
    for result in results:
        status_icon = "✅" if result["status"] else "❌"
        print(f"{status_icon} {result['test']}: {'PASS' if result['status'] else 'FAIL'}")
        if result["details"]:
            print(f"   📝 {result['details']}")
    
    # Save report
    report_data = {
        "timestamp": datetime.now().isoformat(),
        "summary": {
            "total": total_tests,
            "passed": passed_tests,
            "failed": failed_tests,
            "success_rate": success_rate
        },
        "results": results
    }
    
    with open("quick_test_report.json", "w", encoding="utf-8") as f:
        json.dump(report_data, f, ensure_ascii=False, indent=2)
    
    print(f"\n💾 گزارش در فایل quick_test_report.json ذخیره شد")
    
    return success_rate >= 80

def main():
    """Main test function"""
    print("🚀 شروع تست سریع سیستم دوربین هوشمند...")
    print("="*60)
    
    results = []
    
    # Run tests
    results.append({
        "test": "Environment Variables",
        "status": test_environment(),
        "details": "Checking required environment variables"
    })
    
    results.append({
        "test": "Database",
        "status": test_database(),
        "details": "Testing database connectivity and tables"
    })
    
    results.append({
        "test": "Directories",
        "status": test_directories(),
        "details": "Checking required directories"
    })
    
    results.append({
        "test": "Python Packages",
        "status": test_imports(),
        "details": "Testing required package imports"
    })
    
    # Generate report
    success = generate_report(results)
    
    if success:
        print("\n🎉 تست‌ها با موفقیت تکمیل شد!")
        print("💡 سیستم آماده راه‌اندازی است.")
        return True
    else:
        print("\n⚠️ برخی تست‌ها ناموفق بودند.")
        print("🔧 لطفاً مشکلات را برطرف کنید.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1) 