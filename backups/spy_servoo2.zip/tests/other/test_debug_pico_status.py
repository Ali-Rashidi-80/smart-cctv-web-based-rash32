#!/usr/bin/env python3
"""
Debug Pico Status
"""

import requests
import json

BASE_URL = "http://localhost:3000"

def debug_pico_status():
    """Debug Pico status"""
    print("🔍 Debug Pico Status")
    print("=" * 30)
    
    session = requests.Session()
    
    # Login
    login_data = {
        "username": "rof642fr",
        "password": "5qEKU@A@Tv"
    }
    
    try:
        response = session.post(f"{BASE_URL}/login", json=login_data, timeout=5)
        if response.status_code != 200:
            print("❌ Login failed")
            return
        print("✅ Login successful")
    except Exception as e:
        print(f"❌ Login error: {e}")
        return
    
    # Test 1: Get status
    print("\n1️⃣ Getting status...")
    try:
        response = session.get(f"{BASE_URL}/get_status", timeout=5)
        if response.status_code == 200:
            data = response.json()
            pico_data = data.get("data", {})
            print(f"   Pico status: {pico_data.get('pico_status', 'unknown')}")
            print(f"   Pico last seen: {pico_data.get('pico_last_seen', 'unknown')}")
            print(f"   Full data: {json.dumps(pico_data, indent=2)}")
        else:
            print(f"   ❌ Failed: {response.status_code}")
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    # Test 2: Get devices status
    print("\n2️⃣ Getting devices status...")
    try:
        response = session.get(f"{BASE_URL}/devices/status", timeout=5)
        if response.status_code == 200:
            data = response.json()
            print(f"   Devices status: {json.dumps(data, indent=2)}")
        else:
            print(f"   ❌ Failed: {response.status_code}")
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    # Test 3: Get pico status specifically
    print("\n3️⃣ Getting Pico status specifically...")
    try:
        response = session.get(f"{BASE_URL}/pico/status", timeout=5)
        if response.status_code == 200:
            data = response.json()
            print(f"   Pico specific status: {json.dumps(data, indent=2)}")
        else:
            print(f"   ❌ Failed: {response.status_code}")
    except Exception as e:
        print(f"   ❌ Error: {e}")

if __name__ == "__main__":
    debug_pico_status() 