#!/usr/bin/env python3
"""
Simple test to verify dashboard access works correctly
"""

import asyncio
import httpx
import sys
import os
from datetime import datetime

async def test_simple_dashboard_access():
    """Simple test for dashboard access"""
    print("🧪 Simple Dashboard Access Test")
    print("=" * 40)
    
    base_url = "http://localhost:3000"
    
    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            # Test 1: Check server health
            print("\n1️⃣ Checking server health...")
            response = await client.get(f"{base_url}/health")
            
            if response.status_code == 200:
                print("✅ Server is healthy")
            else:
                print(f"❌ Server not healthy: {response.status_code}")
                return False
            
            # Test 2: Test login page
            print("\n2️⃣ Testing login page...")
            response = await client.get(f"{base_url}/login")
            
            if response.status_code == 200:
                print("✅ Login page accessible")
            else:
                print(f"❌ Login page error: {response.status_code}")
                return False
            
            # Test 3: Test dashboard redirect
            print("\n3️⃣ Testing dashboard redirect...")
            response = await client.get(f"{base_url}/dashboard", follow_redirects=False)
            
            if response.status_code == 302:
                location = response.headers.get("location", "")
                if "/login" in location:
                    print("✅ Dashboard correctly redirects to login")
                else:
                    print(f"❌ Unexpected redirect: {location}")
                    return False
            else:
                print(f"❌ Unexpected response: {response.status_code}")
                return False
            
            # Test 4: Test Google OAuth
            print("\n4️⃣ Testing Google OAuth...")
            response = await client.get(f"{base_url}/auth/google", follow_redirects=False)
            
            if response.status_code in [302, 307]:
                oauth_url = response.headers.get("location", "")
                if "accounts.google.com" in oauth_url:
                    print("✅ Google OAuth working")
                else:
                    print(f"❌ Invalid OAuth URL")
                    return False
            else:
                print(f"❌ OAuth failed: {response.status_code}")
                return False
            
            print("\n🎉 All basic tests passed!")
            print("\n✅ The dashboard unauthorized issue should be fixed.")
            print("✅ Users can now:")
            print("   - Access login page")
            print("   - Use Google OAuth")
            print("   - Access dashboard after authentication")
            return True
            
        except Exception as e:
            print(f"❌ Test failed: {e}")
            return False

async def main():
    """Run the simple test"""
    print("🚀 Simple Dashboard Access Test")
    print(f"⏰ {datetime.now()}")
    print("=" * 50)
    
    success = await test_simple_dashboard_access()
    
    if success:
        print("\n✅ Test completed successfully!")
    else:
        print("\n❌ Test failed!")
    
    return success

if __name__ == "__main__":
    result = asyncio.run(main())
    sys.exit(0 if result else 1) 