#!/usr/bin/env python3
"""
تست نهایی جامع - اجرای تمام تست‌ها
Comprehensive Final Test - Run All Test Suites
"""

import sys
import os
import asyncio
import time
import json
from datetime import datetime
from typing import List, Dict, Any

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class ComprehensiveFinalTester:
    def __init__(self):
        self.all_results = {}
        self.final_report = {}
        self.start_time = None
        self.end_time = None
        
    def print_header(self, title: str):
        """چاپ هدر"""
        print("\n" + "=" * 80)
        print(f"🔧 {title}")
        print("=" * 80)
    
    def print_section(self, title: str):
        """چاپ بخش"""
        print(f"\n📋 {title}")
        print("-" * 60)
    
    async def run_test_suite(self, test_file: str, suite_name: str) -> Dict:
        """اجرای یک مجموعه تست"""
        self.print_section(f"اجرای {suite_name}")
        
        try:
            # اجرای تست با subprocess
            import subprocess
            result = subprocess.run(
                [sys.executable, test_file],
                capture_output=True,
                text=True,
                timeout=300  # 5 دقیقه timeout
            )
            
            success = result.returncode == 0
            output = result.stdout
            error = result.stderr
            
            print(f"✅ {suite_name} تکمیل شد")
            if error:
                print(f"⚠️ هشدارها: {error[:200]}...")
            
            return {
                "suite": suite_name,
                "file": test_file,
                "success": success,
                "output": output,
                "error": error,
                "return_code": result.returncode
            }
            
        except subprocess.TimeoutExpired:
            print(f"❌ {suite_name} timeout شد")
            return {
                "suite": suite_name,
                "file": test_file,
                "success": False,
                "output": "",
                "error": "Timeout after 5 minutes",
                "return_code": -1
            }
        except Exception as e:
            print(f"❌ خطا در اجرای {suite_name}: {e}")
            return {
                "suite": suite_name,
                "file": test_file,
                "success": False,
                "output": "",
                "error": str(e),
                "return_code": -1
            }

    async def run_all_test_suites(self):
        """اجرای تمام مجموعه‌های تست"""
        self.print_header("تست نهایی جامع - اجرای تمام تست‌ها")
        
        test_suites = [
            ("tests/test_comprehensive_login_system.py", "تست جامع سیستم لاگین"),
            ("tests/test_final_verification.py", "تست نهایی تایید"),
            ("tests/test_advanced_security.py", "تست‌های امنیت پیشرفته"),
            ("tests/test_performance_stress.py", "تست‌های عملکرد و استرس"),
            ("tests/test_system_integration.py", "تست‌های یکپارچگی سیستم")
        ]
        
        print(f"🚀 شروع اجرای {len(test_suites)} مجموعه تست...")
        
        for test_file, suite_name in test_suites:
            if os.path.exists(test_file):
                result = await self.run_test_suite(test_file, suite_name)
                self.all_results[suite_name] = result
            else:
                print(f"⚠️ فایل تست {test_file} یافت نشد")
                self.all_results[suite_name] = {
                    "suite": suite_name,
                    "file": test_file,
                    "success": False,
                    "output": "",
                    "error": "Test file not found",
                    "return_code": -1
                }

    def analyze_results(self):
        """تحلیل نتایج"""
        self.print_section("تحلیل نتایج")
        
        total_suites = len(self.all_results)
        successful_suites = sum(1 for result in self.all_results.values() if result["success"])
        failed_suites = total_suites - successful_suites
        
        print(f"📊 آمار کلی:")
        print(f"   کل مجموعه‌های تست: {total_suites}")
        print(f"   مجموعه‌های موفق: {successful_suites}")
        print(f"   مجموعه‌های ناموفق: {failed_suites}")
        print(f"   نرخ موفقیت: {(successful_suites/total_suites)*100:.1f}%")
        
        print(f"\n📋 جزئیات هر مجموعه:")
        for suite_name, result in self.all_results.items():
            status = "✅ موفق" if result["success"] else "❌ ناموفق"
            print(f"   {status} {suite_name}")
            if not result["success"] and result["error"]:
                print(f"      خطا: {result['error'][:100]}...")

    def generate_final_report(self):
        """تولید گزارش نهایی"""
        self.print_section("گزارش نهایی")
        
        total_suites = len(self.all_results)
        successful_suites = sum(1 for result in self.all_results.values() if result["success"])
        
        # محاسبه زمان کل
        duration = self.end_time - self.start_time if self.start_time and self.end_time else 0
        
        self.final_report = {
            "timestamp": datetime.now().isoformat(),
            "duration_seconds": duration,
            "total_test_suites": total_suites,
            "successful_suites": successful_suites,
            "failed_suites": total_suites - successful_suites,
            "success_rate": (successful_suites/total_suites)*100 if total_suites > 0 else 0,
            "overall_status": "PASS" if successful_suites == total_suites else "FAIL",
            "detailed_results": self.all_results
        }
        
        print(f"🎯 نتیجه نهایی:")
        if successful_suites == total_suites:
            print(f"   🎉 تمام تست‌ها موفق بودند!")
            print(f"   ✅ سیستم کاملاً آماده است!")
        else:
            print(f"   ⚠️ {failed_suites} مجموعه تست ناموفق بودند")
            print(f"   🔧 نیاز به بررسی بیشتر")
        
        print(f"\n⏱️ زمان کل اجرا: {duration:.2f} ثانیه")
        print(f"📈 نرخ موفقیت کلی: {self.final_report['success_rate']:.1f}%")

    def save_report(self):
        """ذخیره گزارش"""
        self.print_section("ذخیره گزارش")
        
        # ذخیره گزارش JSON
        report_file = f"tests/final_test_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        try:
            with open(report_file, 'w', encoding='utf-8') as f:
                json.dump(self.final_report, f, indent=2, ensure_ascii=False)
            print(f"✅ گزارش JSON ذخیره شد: {report_file}")
        except Exception as e:
            print(f"❌ خطا در ذخیره گزارش JSON: {e}")
        
        # ذخیره گزارش متنی
        text_report_file = f"tests/final_test_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        try:
            with open(text_report_file, 'w', encoding='utf-8') as f:
                f.write("گزارش نهایی تست جامع\n")
                f.write("=" * 50 + "\n\n")
                f.write(f"تاریخ: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"زمان کل: {self.final_report.get('duration_seconds', 0):.2f} ثانیه\n")
                f.write(f"کل مجموعه‌های تست: {self.final_report.get('total_test_suites', 0)}\n")
                f.write(f"موفق: {self.final_report.get('successful_suites', 0)}\n")
                f.write(f"ناموفق: {self.final_report.get('failed_suites', 0)}\n")
                f.write(f"نرخ موفقیت: {self.final_report.get('success_rate', 0):.1f}%\n\n")
                
                f.write("جزئیات هر مجموعه:\n")
                f.write("-" * 30 + "\n")
                for suite_name, result in self.all_results.items():
                    status = "✅ موفق" if result["success"] else "❌ ناموفق"
                    f.write(f"{status} {suite_name}\n")
                    if not result["success"] and result["error"]:
                        f.write(f"  خطا: {result['error']}\n")
                    f.write("\n")
            
            print(f"✅ گزارش متنی ذخیره شد: {text_report_file}")
        except Exception as e:
            print(f"❌ خطا در ذخیره گزارش متنی: {e}")

    def print_recommendations(self):
        """چاپ توصیه‌ها"""
        self.print_section("توصیه‌ها")
        
        successful_suites = sum(1 for result in self.all_results.values() if result["success"])
        total_suites = len(self.all_results)
        
        if successful_suites == total_suites:
            print("🎉 سیستم کاملاً آماده و امن است!")
            print("✅ تمام تست‌ها موفق بودند")
            print("✅ هیچ آسیب‌پذیری امنیتی یافت نشد")
            print("✅ عملکرد سیستم در سطح عالی است")
            print("✅ یکپارچگی سیستم کامل است")
            print("\n🚀 آماده برای deployment در محیط production!")
            
        elif successful_suites >= total_suites * 0.8:  # 80% موفق
            print("👍 سیستم در وضعیت خوب است")
            print("⚠️ برخی مشکلات جزئی نیاز به بررسی دارند")
            print("🔧 توصیه می‌شود مشکلات باقی‌مانده حل شوند")
            
        else:
            print("⚠️ سیستم نیاز به بررسی جدی دارد")
            print("❌ مشکلات زیادی یافت شده")
            print("🔧 توصیه می‌شود قبل از deployment مشکلات حل شوند")

    async def run_comprehensive_test(self):
        """اجرای تست جامع"""
        self.start_time = time.time()
        
        try:
            # اجرای تمام مجموعه‌های تست
            await self.run_all_test_suites()
            
            # تحلیل نتایج
            self.analyze_results()
            
            # تولید گزارش نهایی
            self.generate_final_report()
            
            # ذخیره گزارش
            self.save_report()
            
            # چاپ توصیه‌ها
            self.print_recommendations()
            
        except Exception as e:
            print(f"❌ خطا در اجرای تست جامع: {e}")
        finally:
            self.end_time = time.time()

async def main():
    """تابع اصلی"""
    tester = ComprehensiveFinalTester()
    await tester.run_comprehensive_test()

if __name__ == "__main__":
    asyncio.run(main())