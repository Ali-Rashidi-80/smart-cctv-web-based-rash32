#!/usr/bin/env python3
"""
Final Verification Test
Verify all fixes are working correctly
"""

import asyncio
import aiosqlite
import json
import time
from datetime import datetime

async def test_final_verification():
    """Test final verification of all fixes"""
    print("🔍 Final Verification Test")
    print("=" * 50)
    
    results = []
    
    # Test 1: Database connection stability
    print("🧪 Test 1: Database Connection Stability")
    try:
        conn = await aiosqlite.connect('smart_camera_system.db')
        
        # Check PRAGMA settings
        cursor = await conn.execute("PRAGMA busy_timeout")
        timeout = await cursor.fetchone()
        
        cursor = await conn.execute("PRAGMA journal_mode")
        journal_mode = await cursor.fetchone()
        
        cursor = await conn.execute("PRAGMA locking_mode")
        locking_mode = await cursor.fetchone()
        
        if timeout[0] >= 60000 and journal_mode[0] == 'wal' and locking_mode[0] == 'normal':
            print("✅ Database connection stability verified")
            results.append(("Database Stability", "PASS"))
        else:
            print(f"❌ Database connection stability issues: timeout={timeout[0]}, journal={journal_mode[0]}, locking={locking_mode[0]}")
            results.append(("Database Stability", "FAIL"))
        
        await conn.close()
        
    except Exception as e:
        print(f"❌ Database stability test failed: {e}")
        results.append(("Database Stability", "FAIL"))
    
    # Test 2: Data validation
    print("\n🧪 Test 2: Data Validation")
    try:
        conn = await aiosqlite.connect('smart_camera_system.db')
        
        # Test with invalid data
        test_data = {
            'username': 'test_final_verification',
            'ip': '127.0.0.1',
            'theme': 'invalid_theme',
            'language': 'invalid_lang',
            'servo1': 999,
            'servo2': -999,
            'device_mode': 'invalid_mode',
            'photo_quality': 999,
            'smart_motion': 'not_bool',
            'smart_tracking': 'not_bool',
            'stream_enabled': 'not_bool'
        }
        
        # Insert test data
        await conn.execute('''
            INSERT OR REPLACE INTO user_settings 
            (username, ip, theme, language, servo1, servo2, device_mode, photo_quality, 
             smart_motion, smart_tracking, stream_enabled, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            test_data['username'], test_data['ip'], test_data['theme'],
            test_data['language'], test_data['servo1'], test_data['servo2'],
            test_data['device_mode'], test_data['photo_quality'],
            test_data['smart_motion'], test_data['smart_tracking'],
            test_data['stream_enabled'], datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        ))
        await conn.commit()
        
        # Retrieve and check if data was handled properly
        cursor = await conn.execute('''
            SELECT theme, language, servo1, servo2, device_mode, photo_quality, 
                   smart_motion, smart_tracking, stream_enabled
            FROM user_settings WHERE username = ?
        ''', (test_data['username'],))
        result = await cursor.fetchone()
        
        if result:
            theme, language, servo1, servo2, device_mode, photo_quality, smart_motion, smart_tracking, stream_enabled = result
            
            # Check if values are within expected ranges (validation happens in the endpoint)
            valid = True
            if servo1 < 0 or servo1 > 180:
                valid = False
            if servo2 < 0 or servo2 > 180:
                valid = False
            if theme not in ['light', 'dark']:
                valid = False
            if language not in ['fa', 'en']:
                valid = False
            if device_mode not in ['desktop', 'mobile']:
                valid = False
            if photo_quality < 1 or photo_quality > 100:
                valid = False
            
            if valid:
                print("✅ Data validation working")
                results.append(("Data Validation", "PASS"))
            else:
                print(f"❌ Data validation failed: theme={theme}, language={language}, servo1={servo1}, servo2={servo2}, device_mode={device_mode}, photo_quality={photo_quality}")
                results.append(("Data Validation", "FAIL"))
        else:
            print("❌ Data validation failed: No data retrieved")
            results.append(("Data Validation", "FAIL"))
        
        # Clean up
        await conn.execute('DELETE FROM user_settings WHERE username = ?', (test_data['username'],))
        await conn.commit()
        await conn.close()
        
    except Exception as e:
        print(f"❌ Data validation test failed: {e}")
        results.append(("Data Validation", "FAIL"))
    
    # Test 3: Concurrent operations
    print("\n🧪 Test 3: Concurrent Operations")
    try:
        async def concurrent_operation(user_id: int):
            conn = await aiosqlite.connect('smart_camera_system.db')
            try:
                async with conn:
                    await conn.execute('''
                        INSERT OR REPLACE INTO user_settings 
                        (username, ip, theme, language, updated_at)
                        VALUES (?, ?, ?, ?, ?)
                    ''', (f'concurrent_final_{user_id}', '127.0.0.1', 'dark', 'en', 
                          datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
                    
                    await asyncio.sleep(0.01)
                    
                    cursor = await conn.execute('''
                        SELECT username FROM user_settings WHERE username = ?
                    ''', (f'concurrent_final_{user_id}',))
                    result = await cursor.fetchone()
                    
                    return result is not None
            finally:
                await conn.close()
        
        # Run 15 concurrent operations
        tasks = [concurrent_operation(i) for i in range(15)]
        results_concurrent = await asyncio.gather(*tasks, return_exceptions=True)
        
        success_count = sum(1 for r in results_concurrent if r is True)
        error_count = sum(1 for r in results_concurrent if isinstance(r, Exception))
        
        if success_count >= 10 and error_count <= 5:  # Allow some errors due to concurrency
            print(f"✅ Concurrent operations working: Success={success_count}, Errors={error_count}")
            results.append(("Concurrent Operations", "PASS"))
        else:
            print(f"❌ Concurrent operations failed: Success={success_count}, Errors={error_count}")
            results.append(("Concurrent Operations", "FAIL"))
        
        # Clean up
        conn = await aiosqlite.connect('smart_camera_system.db')
        for i in range(15):
            await conn.execute('DELETE FROM user_settings WHERE username = ?', (f'concurrent_final_{i}',))
        await conn.commit()
        await conn.close()
        
    except Exception as e:
        print(f"❌ Concurrent operations test failed: {e}")
        results.append(("Concurrent Operations", "FAIL"))
    
    # Test 4: Error recovery
    print("\n🧪 Test 4: Error Recovery")
    try:
        conn = await aiosqlite.connect('smart_camera_system.db')
        
        # Test with invalid JSON
        test_user = "test_error_recovery_final"
        invalid_json = "{invalid: json, data}"
        
        await conn.execute('''
            INSERT OR REPLACE INTO user_settings 
            (username, ip, flash_settings, updated_at)
            VALUES (?, ?, ?, ?)
        ''', (test_user, '127.0.0.1', invalid_json, 
              datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
        await conn.commit()
        
        # Retrieve and check
        cursor = await conn.execute('''
            SELECT flash_settings FROM user_settings WHERE username = ?
        ''', (test_user,))
        result = await cursor.fetchone()
        
        if result:
            print("✅ Error recovery working")
            results.append(("Error Recovery", "PASS"))
        else:
            print("❌ Error recovery failed")
            results.append(("Error Recovery", "FAIL"))
        
        # Clean up
        await conn.execute('DELETE FROM user_settings WHERE username = ?', (test_user,))
        await conn.commit()
        await conn.close()
        
    except Exception as e:
        print(f"❌ Error recovery test failed: {e}")
        results.append(("Error Recovery", "FAIL"))
    
    # Test 5: Performance under load
    print("\n🧪 Test 5: Performance Under Load")
    try:
        start_time = time.time()
        
        conn = await aiosqlite.connect('smart_camera_system.db')
        for i in range(50):
            await conn.execute('''
                INSERT OR REPLACE INTO user_settings 
                (username, ip, theme, language, updated_at)
                VALUES (?, ?, ?, ?, ?)
            ''', (f'perf_final_{i}', '127.0.0.1', 'light', 'fa', 
                  datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            await conn.commit()
        
        await conn.close()
        
        end_time = time.time()
        duration = end_time - start_time
        
        if duration < 10.0:  # Should complete within 10 seconds
            print(f"✅ Performance under load working: {duration:.2f}s for 50 operations")
            results.append(("Performance", "PASS"))
        else:
            print(f"❌ Performance under load failed: {duration:.2f}s for 50 operations")
            results.append(("Performance", "FAIL"))
        
        # Clean up
        conn = await aiosqlite.connect('smart_camera_system.db')
        for i in range(50):
            await conn.execute('DELETE FROM user_settings WHERE username = ?', (f'perf_final_{i}',))
        await conn.commit()
        await conn.close()
        
    except Exception as e:
        print(f"❌ Performance test failed: {e}")
        results.append(("Performance", "FAIL"))
    
    # Generate final report
    print("\n" + "=" * 50)
    print("📊 FINAL VERIFICATION REPORT")
    print("=" * 50)
    
    total_tests = len(results)
    passed_tests = len([r for r in results if r[1] == 'PASS'])
    failed_tests = len([r for r in results if r[1] == 'FAIL'])
    
    print(f"Total Tests: {total_tests}")
    print(f"Passed: {passed_tests} ✅")
    print(f"Failed: {failed_tests} ❌")
    print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
    
    print("\n📋 Test Results:")
    for test_name, status in results:
        emoji = "✅" if status == "PASS" else "❌"
        print(f"  {emoji} {test_name}: {status}")
    
    if failed_tests == 0:
        print("\n🎉 ALL TESTS PASSED! SYSTEM IS FULLY FIXED!")
        print("✅ Database locking issues resolved")
        print("✅ Data validation working correctly")
        print("✅ Concurrent operations stable")
        print("✅ Error recovery functioning")
        print("✅ Performance optimized")
        print("🚀 System is production-ready!")
        return True
    else:
        print(f"\n⚠️  {failed_tests} test(s) still need attention:")
        for test_name, status in results:
            if status == "FAIL":
                print(f"  ❌ {test_name}")
        return False

async def main():
    """Run final verification test"""
    print("🚀 Starting Final Verification Test")
    print("=" * 50)
    
    success = await test_final_verification()
    return success

if __name__ == "__main__":
    success = asyncio.run(main())
    exit(0 if success else 1) 