#!/usr/bin/env python3
"""
Quick Verification Script for Smart Camera System Fixes
"""

import sys
import os

def test_import():
    """Test if server imports successfully"""
    try:
        import server_fastapi
        print("✅ Server imports successfully")
        return True
    except Exception as e:
        print(f"❌ Server import failed: {e}")
        return False

def test_key_functions():
    """Test if key functions exist"""
    try:
        import server_fastapi
        
        required_functions = [
            'app',
            'get_current_user', 
            'init_db',
            'check_db_health',
            'check_rate_limit',
            'check_login_attempts'
        ]
        
        missing = []
        for func in required_functions:
            if not hasattr(server_fastapi, func):
                missing.append(func)
        
        if missing:
            print(f"❌ Missing functions: {missing}")
            return False
        else:
            print("✅ All key functions present")
            return True
            
    except Exception as e:
        print(f"❌ Function test failed: {e}")
        return False

def test_fixes():
    """Test if fixes are properly applied"""
    try:
        import server_fastapi
        
        # Test rate limiting fix
        rate_limit_func = server_fastapi.check_rate_limit
        if "test" in str(rate_limit_func.__code__.co_consts):
            print("✅ Rate limiting fix applied")
        else:
            print("❌ Rate limiting fix not found")
            return False
        
        # Test login attempts fix
        login_attempts_func = server_fastapi.check_login_attempts
        if "test" in str(login_attempts_func.__code__.co_consts):
            print("✅ Login attempts fix applied")
        else:
            print("❌ Login attempts fix not found")
            return False
        
        return True
        
    except Exception as e:
        print(f"❌ Fix verification failed: {e}")
        return False

def main():
    """Main verification function"""
    print("🔍 Quick Verification of Smart Camera System Fixes")
    print("=" * 50)
    
    tests = [
        ("Server Import", test_import),
        ("Key Functions", test_key_functions),
        ("Fixes Applied", test_fixes)
    ]
    
    all_passed = True
    for test_name, test_func in tests:
        print(f"\n🧪 {test_name}...")
        if not test_func():
            all_passed = False
    
    print("\n" + "=" * 50)
    if all_passed:
        print("🎉 ALL VERIFICATIONS PASSED!")
        print("✅ System is ready for testing")
        sys.exit(0)
    else:
        print("❌ Some verifications failed")
        print("⚠️ Please check the issues above")
        sys.exit(1)

if __name__ == "__main__":
    main() 