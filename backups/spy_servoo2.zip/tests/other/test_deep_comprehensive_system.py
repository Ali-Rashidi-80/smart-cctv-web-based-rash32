#!/usr/bin/env python3
"""
Deep and Comprehensive System Test
Tests all aspects of the system including authentication, authorization, API endpoints, and security features
"""

import asyncio
import httpx
import json
import sys
import os
import time
from datetime import datetime

# Add the parent directory to the path to import server modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class DeepSystemTester:
    def __init__(self):
        self.base_url = "http://localhost:3000"
        self.test_results = {}
        self.start_time = datetime.now()
        
    async def test_server_health_and_startup(self):
        """Test server health and startup processes"""
        print("🏥 Testing Server Health and Startup")
        print("=" * 50)
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            try:
                # Test 1: Health endpoint
                print("\n1️⃣ Testing health endpoint...")
                response = await client.get(f"{self.base_url}/health")
                
                if response.status_code == 200:
                    print("✅ Health endpoint working")
                    self.test_results['health'] = True
                else:
                    print(f"❌ Health endpoint failed: {response.status_code}")
                    self.test_results['health'] = False
                    return False
                
                # Test 2: Ports endpoint
                print("\n2️⃣ Testing ports endpoint...")
                response = await client.get(f"{self.base_url}/ports")
                
                if response.status_code == 200:
                    ports_data = response.json()
                    print(f"✅ Ports endpoint working: {ports_data}")
                    self.test_results['ports'] = True
                else:
                    print(f"❌ Ports endpoint failed: {response.status_code}")
                    self.test_results['ports'] = False
                
                # Test 3: Device status endpoints
                print("\n3️⃣ Testing device status endpoints...")
                
                status_endpoints = [
                    "/esp32cam/status",
                    "/pico/status", 
                    "/devices/status"
                ]
                
                for endpoint in status_endpoints:
                    response = await client.get(f"{self.base_url}{endpoint}")
                    if response.status_code == 200:
                        print(f"✅ {endpoint} working")
                    else:
                        print(f"❌ {endpoint} failed: {response.status_code}")
                
                self.test_results['device_status'] = True
                return True
                
            except Exception as e:
                print(f"❌ Server health test failed: {e}")
                self.test_results['health'] = False
                return False
    
    async def test_authentication_system(self):
        """Test the complete authentication system"""
        print("\n🔐 Testing Authentication System")
        print("=" * 50)
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            try:
                # Test 1: Login page access
                print("\n1️⃣ Testing login page...")
                response = await client.get(f"{self.base_url}/login")
                
                if response.status_code == 200:
                    print("✅ Login page accessible")
                    self.test_results['login_page'] = True
                else:
                    print(f"❌ Login page failed: {response.status_code}")
                    self.test_results['login_page'] = False
                    return False
                
                # Test 2: Google OAuth redirect
                print("\n2️⃣ Testing Google OAuth redirect...")
                response = await client.get(f"{self.base_url}/auth/google", follow_redirects=False)
                
                if response.status_code in [302, 307]:
                    oauth_url = response.headers.get("location", "")
                    if "accounts.google.com" in oauth_url:
                        print("✅ Google OAuth redirect working")
                        
                        # Extract state parameter
                        if "state=" in oauth_url:
                            state_start = oauth_url.find("state=") + 6
                            state_end = oauth_url.find("&", state_start)
                            if state_end == -1:
                                state_end = len(oauth_url)
                            state = oauth_url[state_start:state_end]
                            print(f"✅ State parameter: {state[:20]}...")
                        
                        self.test_results['google_oauth'] = True
                    else:
                        print(f"❌ Invalid OAuth URL: {oauth_url}")
                        self.test_results['google_oauth'] = False
                        return False
                else:
                    print(f"❌ OAuth redirect failed: {response.status_code}")
                    self.test_results['google_oauth'] = False
                    return False
                
                # Test 3: OAuth callback handling
                print("\n3️⃣ Testing OAuth callback handling...")
                callback_url = f"{self.base_url}/auth/google/callback?code=test_code&state=test_state"
                response = await client.get(callback_url, follow_redirects=False)
                
                if response.status_code in [302, 307, 400, 500]:
                    print("✅ OAuth callback handles invalid parameters gracefully")
                    self.test_results['oauth_callback'] = True
                else:
                    print(f"❌ OAuth callback unexpected response: {response.status_code}")
                    self.test_results['oauth_callback'] = False
                
                return True
                
            except Exception as e:
                print(f"❌ Authentication test failed: {e}")
                return False
    
    async def test_authorization_and_middleware(self):
        """Test authorization and middleware behavior"""
        print("\n🛡️ Testing Authorization and Middleware")
        print("=" * 50)
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            try:
                # Test 1: Unauthenticated access to protected endpoints
                print("\n1️⃣ Testing unauthenticated access...")
                
                protected_endpoints = [
                    ("/dashboard", "should redirect to login"),
                    ("/", "should redirect to login"),
                    ("/api/users", "should return 401"),
                    ("/get_status", "should return 401"),
                    ("/get_gallery", "should return 401"),
                    ("/get_videos", "should return 401"),
                    ("/get_logs", "should return 401"),
                    ("/system/performance", "should return 401")
                ]
                
                for endpoint, expected in protected_endpoints:
                    response = await client.get(f"{self.base_url}{endpoint}", follow_redirects=False)
                    
                    if endpoint.startswith("/api/"):
                        if response.status_code == 401:
                            print(f"✅ {endpoint} {expected}")
                        else:
                            print(f"❌ {endpoint} failed: {response.status_code}")
                            return False
                    else:
                        if response.status_code == 302:
                            location = response.headers.get("location", "")
                            if "/login" in location:
                                print(f"✅ {endpoint} {expected}")
                            else:
                                print(f"❌ {endpoint} unexpected redirect: {location}")
                                return False
                        else:
                            print(f"❌ {endpoint} failed: {response.status_code}")
                            return False
                
                # Test 2: Public endpoints access
                print("\n2️⃣ Testing public endpoints...")
                
                public_endpoints = [
                    ("/login", "should be accessible"),
                    ("/health", "should be accessible"),
                    ("/static/css/styles.css", "should be accessible"),
                    ("/gallery/test.jpg", "should be accessible"),
                    ("/security_videos/test.mp4", "should be accessible")
                ]
                
                for endpoint, expected in public_endpoints:
                    response = await client.get(f"{self.base_url}{endpoint}", follow_redirects=False)
                    
                    if response.status_code in [200, 404]:  # 404 is OK for non-existent files
                        print(f"✅ {endpoint} {expected}")
                    else:
                        print(f"❌ {endpoint} failed: {response.status_code}")
                
                # Test 3: Accept header variations
                print("\n3️⃣ Testing Accept header variations...")
                
                headers_variations = [
                    {"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"},
                    {"Accept": "application/json,text/plain,*/*"},
                    {"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,application/json;q=0.8,*/*;q=0.7"},
                    {"Accept": "*/*"},
                    {"Accept": "application/json"},
                    {"Accept": "text/html"}
                ]
                
                for i, headers in enumerate(headers_variations, 1):
                    response = await client.get(f"{self.base_url}/dashboard", headers=headers, follow_redirects=False)
                    
                    if response.status_code == 302:
                        print(f"✅ Accept header variation {i} handled correctly")
                    else:
                        print(f"❌ Accept header variation {i} failed: {response.status_code}")
                
                self.test_results['authorization'] = True
                return True
                
            except Exception as e:
                print(f"❌ Authorization test failed: {e}")
                return False
    
    async def test_api_endpoints(self):
        """Test API endpoints functionality"""
        print("\n🔌 Testing API Endpoints")
        print("=" * 50)
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            try:
                # Test 1: API endpoints without authentication
                print("\n1️⃣ Testing API endpoints without auth...")
                
                api_endpoints = [
                    "/api/users",
                    "/api/users/create",
                    "/api/users/test/toggle"
                ]
                
                for endpoint in api_endpoints:
                    response = await client.get(f"{self.base_url}{endpoint}", follow_redirects=False)
                    
                    if response.status_code == 401:
                        print(f"✅ {endpoint} correctly returns 401")
                    else:
                        print(f"❌ {endpoint} unexpected response: {response.status_code}")
                
                # Test 2: POST endpoints without authentication
                print("\n2️⃣ Testing POST endpoints without auth...")
                
                post_endpoints = [
                    ("/login", {"username": "test", "password": "test"}),
                    ("/register", {"username": "test", "phone": "09123456789", "password": "test123456"}),
                    ("/recover-password", {"phone": "09123456789"}),
                    ("/set_servo", {"servo1": 90, "servo2": 90}),
                    ("/set_action", {"action": "test", "intensity": 50}),
                    ("/manual_photo", {"quality": 80, "flash": False, "intensity": 50})
                ]
                
                for endpoint, data in post_endpoints:
                    response = await client.post(f"{self.base_url}{endpoint}", json=data, follow_redirects=False)
                    
                    # For public endpoints, expect 200/422/400
                    # For protected endpoints, expect 401 or 302 (redirect to login)
                    if endpoint in ["/login", "/register", "/recover-password"]:
                        if response.status_code in [401, 422, 400, 200]:  # Public endpoints
                        print(f"✅ {endpoint} handled correctly")
                    else:
                        print(f"❌ {endpoint} unexpected response: {response.status_code}")
                    else:
                        if response.status_code in [401, 302]:  # Protected endpoints should return 401 or redirect
                            print(f"✅ {endpoint} correctly requires authentication")
                        else:
                            print(f"❌ {endpoint} unexpected response: {response.status_code}")
                
                self.test_results['api_endpoints'] = True
                return True
                
            except Exception as e:
                print(f"❌ API endpoints test failed: {e}")
                return False
    
    async def test_security_features(self):
        """Test security features and headers"""
        print("\n🔒 Testing Security Features")
        print("=" * 50)
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            try:
                # Test 1: Security headers
                print("\n1️⃣ Testing security headers...")
                
                response = await client.get(f"{self.base_url}/login")
                
                security_headers = [
                    "X-Content-Type-Options",
                    "X-Frame-Options", 
                    "X-XSS-Protection",
                    "Strict-Transport-Security",
                    "Content-Security-Policy",
                    "Referrer-Policy",
                    "Permissions-Policy"
                ]
                
                missing_headers = []
                for header in security_headers:
                    if header not in response.headers:
                        missing_headers.append(header)
                
                if not missing_headers:
                    print("✅ All security headers present")
                    self.test_results['security_headers'] = True
                else:
                    print(f"❌ Missing security headers: {missing_headers}")
                    self.test_results['security_headers'] = False
                
                # Test 2: Rate limiting (basic test)
                print("\n2️⃣ Testing rate limiting...")
                
                # Make multiple rapid requests
                responses = []
                for i in range(10):
                    response = await client.get(f"{self.base_url}/login")
                    responses.append(response.status_code)
                
                # Check if any requests were rate limited
                if 429 in responses:
                    print("✅ Rate limiting working")
                    self.test_results['rate_limiting'] = True
                else:
                    print("⚠️ Rate limiting not triggered (may be disabled for localhost)")
                    self.test_results['rate_limiting'] = True  # Not a failure
                
                # Test 3: CORS headers
                print("\n3️⃣ Testing CORS headers...")
                
                response = await client.get(f"{self.base_url}/health")
                
                if "Access-Control-Allow-Origin" in response.headers:
                    print("✅ CORS headers present")
                    self.test_results['cors'] = True
                else:
                    print("⚠️ CORS headers not present (may not be needed for same-origin)")
                    self.test_results['cors'] = True  # Not a failure
                
                return True
                
            except Exception as e:
                print(f"❌ Security test failed: {e}")
                return False
    
    async def test_websocket_endpoints(self):
        """Test WebSocket endpoints"""
        print("\n🔌 Testing WebSocket Endpoints")
        print("=" * 50)
        
        try:
            # Test 1: WebSocket HTTP guard
            print("\n1️⃣ Testing WebSocket HTTP guard...")
            
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(f"{self.base_url}/ws")
                
                if response.status_code in [200, 400, 405]:
                    print("✅ WebSocket HTTP guard responding")
                    self.test_results['websocket_guard'] = True
                else:
                    print(f"❌ WebSocket HTTP guard failed: {response.status_code}")
                    self.test_results['websocket_guard'] = False
            
            # Note: Full WebSocket testing would require a WebSocket client
            # For now, we just test the HTTP guard endpoint
            
            return True
            
        except Exception as e:
            print(f"❌ WebSocket test failed: {e}")
            return False
    
    async def test_database_and_storage(self):
        """Test database and storage functionality"""
        print("\n💾 Testing Database and Storage")
        print("=" * 50)
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            try:
                # Test 1: Database health (indirectly through endpoints)
                print("\n1️⃣ Testing database health...")
                
                # Test endpoints that use database
                db_dependent_endpoints = [
                    "/health",
                    "/ports"
                ]
                
                for endpoint in db_dependent_endpoints:
                    response = await client.get(f"{self.base_url}{endpoint}")
                    
                    if response.status_code == 200:
                        print(f"✅ {endpoint} working (database accessible)")
                    else:
                        print(f"❌ {endpoint} failed: {response.status_code}")
                
                # Test 2: Static file serving
                print("\n2️⃣ Testing static file serving...")
                
                static_files = [
                    "/static/css/styles.css",
                    "/static/js/script.js",
                    "/static/images/logo.png"
                ]
                
                for file_path in static_files:
                    response = await client.get(f"{self.base_url}{file_path}", follow_redirects=False)
                    
                    if response.status_code in [200, 404]:  # 404 is OK for non-existent files
                        print(f"✅ {file_path} accessible")
                    else:
                        print(f"❌ {file_path} failed: {response.status_code}")
                
                # Test 3: Gallery and security videos endpoints
                print("\n3️⃣ Testing gallery and security videos...")
                
                media_endpoints = [
                    "/gallery/test.jpg",
                    "/security_videos/test.mp4"
                ]
                
                for endpoint in media_endpoints:
                    response = await client.get(f"{self.base_url}{endpoint}", follow_redirects=False)
                    
                    if response.status_code in [200, 404]:  # 404 is OK for non-existent files
                        print(f"✅ {endpoint} accessible")
                    else:
                        print(f"❌ {endpoint} failed: {response.status_code}")
                
                self.test_results['database_storage'] = True
                return True
                
            except Exception as e:
                print(f"❌ Database and storage test failed: {e}")
                return False
    
    async def run_all_tests(self):
        """Run all comprehensive tests"""
        print("🚀 Starting Deep and Comprehensive System Test")
        print(f"⏰ Test started at: {self.start_time}")
        print("=" * 80)
        
        test_functions = [
            ("Server Health", self.test_server_health_and_startup),
            ("Authentication", self.test_authentication_system),
            ("Authorization", self.test_authorization_and_middleware),
            ("API Endpoints", self.test_api_endpoints),
            ("Security Features", self.test_security_features),
            ("WebSocket Endpoints", self.test_websocket_endpoints),
            ("Database and Storage", self.test_database_and_storage)
        ]
        
        results = {}
        
        for test_name, test_func in test_functions:
            print(f"\n{'='*20} {test_name} {'='*20}")
            try:
                result = await test_func()
                results[test_name] = result
            except Exception as e:
                print(f"❌ {test_name} test failed with exception: {e}")
                results[test_name] = False
        
        # Generate comprehensive report
        self.generate_report(results)
        
        return results
    
    def generate_report(self, results):
        """Generate comprehensive test report"""
        print("\n" + "=" * 80)
        print("📊 DEEP AND COMPREHENSIVE SYSTEM TEST REPORT")
        print("=" * 80)
        
        end_time = datetime.now()
        duration = end_time - self.start_time
        
        print(f"⏱️ Test Duration: {duration}")
        print(f"🕐 Started: {self.start_time}")
        print(f"🕐 Finished: {end_time}")
        print()
        
        # Test results summary
        print("📋 Test Results Summary:")
        print("-" * 40)
        
        passed_tests = 0
        total_tests = len(results)
        
        for test_name, result in results.items():
            status = "✅ PASS" if result else "❌ FAIL"
            print(f"   {test_name:<25} {status}")
            if result:
                passed_tests += 1
        
        print()
        print(f"📈 Overall Results: {passed_tests}/{total_tests} tests passed")
        
        success_rate = (passed_tests / total_tests) * 100
        print(f"📊 Success Rate: {success_rate:.1f}%")
        
        # Detailed results
        print("\n🔍 Detailed Results:")
        print("-" * 40)
        
        for test_name, result in results.items():
            if result:
                print(f"✅ {test_name}: All checks passed")
            else:
                print(f"❌ {test_name}: Some checks failed")
        
        # System status
        print("\n🏥 System Status:")
        print("-" * 40)
        
        if success_rate >= 90:
            print("🟢 EXCELLENT: System is in excellent condition")
            print("✅ Ready for production use")
        elif success_rate >= 80:
            print("🟡 GOOD: System is in good condition")
            print("⚠️ Minor issues detected, but generally functional")
        elif success_rate >= 70:
            print("🟠 FAIR: System has some issues")
            print("⚠️ Some functionality may be affected")
        else:
            print("🔴 POOR: System has significant issues")
            print("❌ Requires attention before production use")
        
        print("\n" + "=" * 80)
        
        return success_rate >= 80

async def main():
    """Main test runner"""
    tester = DeepSystemTester()
    results = await tester.run_all_tests()
    
    # Determine overall success
    passed_tests = sum(1 for result in results.values() if result)
    total_tests = len(results)
    success_rate = (passed_tests / total_tests) * 100
    
    return success_rate >= 80

if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)