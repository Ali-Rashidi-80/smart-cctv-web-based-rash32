#!/usr/bin/env python3
"""
تست تأیید حل خطاهای لاگین و خروج
Error Fixes Verification Test
"""

import asyncio
import aiohttp
import json
import time
from datetime import datetime

class ErrorFixesTest:
    def __init__(self):
        self.base_url = "http://localhost:3000"
        self.session = None
        self.test_results = []
        
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    def log_test(self, test_name: str, status: str, details: str = ""):
        """Log test result"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        result = {
            "timestamp": timestamp,
            "test": test_name,
            "status": status,
            "details": details
        }
        self.test_results.append(result)
        
        # Color coding
        status_colors = {
            "PASS": "\033[92m",
            "FAIL": "\033[91m",
            "WARN": "\033[93m"
        }
        
        color = status_colors.get(status, "\033[0m")
        reset = "\033[0m"
        
        print(f"{color}[{timestamp}] {status}{reset} {test_name}")
        if details:
            print(f"    {details}")
    
    async def test_csp_headers(self):
        """Test 1: Content Security Policy Headers"""
        try:
            async with self.session.get(f"{self.base_url}/health") as response:
                csp_header = response.headers.get("Content-Security-Policy", "")
                
                if "'unsafe-eval'" in csp_header:
                    self.log_test("CSP Headers", "PASS", "CSP includes unsafe-eval for extension compatibility")
                    return True
                else:
                    self.log_test("CSP Headers", "FAIL", f"CSP missing unsafe-eval: {csp_header}")
                    return False
        except Exception as e:
            self.log_test("CSP Headers", "FAIL", f"Error: {str(e)}")
            return False
    
    async def test_google_oauth_flow(self):
        """Test 2: Google OAuth Flow"""
        try:
            # Test OAuth redirect
            async with self.session.get(f"{self.base_url}/auth/google", allow_redirects=False) as response:
                if response.status == 302:
                    redirect_url = response.headers.get('Location', '')
                    if 'accounts.google.com' in redirect_url:
                        self.log_test("Google OAuth", "PASS", "OAuth redirects to Google correctly")
                        return True
                    else:
                        self.log_test("Google OAuth", "FAIL", f"Invalid redirect URL: {redirect_url}")
                        return False
                else:
                    self.log_test("Google OAuth", "FAIL", f"Expected 302, got {response.status}")
                    return False
        except Exception as e:
            self.log_test("Google OAuth", "FAIL", f"Error: {str(e)}")
            return False
    
    async def test_logout_functionality(self):
        """Test 3: Logout Functionality"""
        try:
            # Test logout endpoint
            async with self.session.post(f"{self.base_url}/logout", allow_redirects=False) as response:
                if response.status in [200, 302]:
                    self.log_test("Logout Function", "PASS", f"Logout works (Status: {response.status})")
                    return True
                else:
                    self.log_test("Logout Function", "FAIL", f"Unexpected status: {response.status}")
                    return False
        except Exception as e:
            self.log_test("Logout Function", "FAIL", f"Error: {str(e)}")
            return False
    
    async def test_protected_endpoints(self):
        """Test 4: Protected Endpoints Authentication"""
        protected_endpoints = [
            "/dashboard",
            "/get_user_settings",
            "/get_gallery"
        ]
        
        all_passed = True
        for endpoint in protected_endpoints:
            try:
                async with self.session.get(f"{self.base_url}{endpoint}", allow_redirects=False) as response:
                    if response.status == 302:
                        self.log_test(f"Protected: {endpoint}", "PASS", "Properly redirects to login")
                    else:
                        self.log_test(f"Protected: {endpoint}", "FAIL", f"Unexpected status: {response.status}")
                        all_passed = False
            except Exception as e:
                self.log_test(f"Protected: {endpoint}", "FAIL", f"Error: {str(e)}")
                all_passed = False
        
        return all_passed
    
    async def test_static_files(self):
        """Test 5: Static Files Serving"""
        static_files = [
            "/static/css/index/styles.css",
            "/static/js/index/script.js"
        ]
        
        all_passed = True
        for file_path in static_files:
            try:
                async with self.session.get(f"{self.base_url}{file_path}") as response:
                    if response.status == 200:
                        self.log_test(f"Static File: {file_path}", "PASS", "File served successfully")
                    else:
                        self.log_test(f"Static File: {file_path}", "FAIL", f"Status: {response.status}")
                        all_passed = False
            except Exception as e:
                self.log_test(f"Static File: {file_path}", "FAIL", f"Error: {str(e)}")
                all_passed = False
        
        return all_passed
    
    async def test_error_handling(self):
        """Test 6: Error Handling"""
        try:
            # Test non-existent endpoint
            async with self.session.get(f"{self.base_url}/nonexistent", allow_redirects=False) as response:
                if response.status in [302, 404]:
                    self.log_test("Error Handling", "PASS", f"Proper error response: {response.status}")
                    return True
                else:
                    self.log_test("Error Handling", "FAIL", f"Unexpected status: {response.status}")
                    return False
        except Exception as e:
            self.log_test("Error Handling", "FAIL", f"Error: {str(e)}")
            return False
    
    def generate_report(self):
        """Generate test report"""
        total_tests = len(self.test_results)
        passed_tests = len([r for r in self.test_results if r["status"] == "PASS"])
        failed_tests = len([r for r in self.test_results if r["status"] == "FAIL"])
        
        print("\n" + "="*60)
        print("🔧 ERROR FIXES VERIFICATION REPORT")
        print("="*60)
        print(f"📊 Summary:")
        print(f"   Total Tests: {total_tests}")
        print(f"   ✅ Passed: {passed_tests}")
        print(f"   ❌ Failed: {failed_tests}")
        print(f"   📈 Success Rate: {(passed_tests/total_tests*100):.1f}%")
        
        if failed_tests > 0:
            print(f"\n❌ FAILED TESTS:")
            for result in self.test_results:
                if result["status"] == "FAIL":
                    print(f"   • {result['test']}: {result['details']}")
        
        print(f"\n🎯 RECOMMENDATIONS:")
        if failed_tests == 0:
            print("   ✅ All error fixes are working correctly!")
            print("   ✅ Chrome Extension errors are suppressed")
            print("   ✅ CSP headers are properly configured")
            print("   ✅ Login/Logout flow works correctly")
        else:
            print("   🔧 Some issues still need attention")
        
        print("="*60)
        
        return failed_tests == 0

async def main():
    """Main test execution"""
    print("🔧 Testing Error Fixes...")
    print("="*60)
    
    async with ErrorFixesTest() as tester:
        # Run all tests
        tests = [
            ("CSP Headers", tester.test_csp_headers),
            ("Google OAuth", tester.test_google_oauth_flow),
            ("Logout Function", tester.test_logout_functionality),
            ("Protected Endpoints", tester.test_protected_endpoints),
            ("Static Files", tester.test_static_files),
            ("Error Handling", tester.test_error_handling)
        ]
        
        for test_name, test_func in tests:
            print(f"\n🔍 Testing: {test_name}")
            print("-" * 40)
            await test_func()
            await asyncio.sleep(0.5)
        
        # Generate final report
        success = tester.generate_report()
        
        if success:
            print("\n🎉 ALL ERROR FIXES VERIFIED! System is working correctly.")
            return 0
        else:
            print("\n❌ Some error fixes need attention.")
            return 1

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    exit(exit_code) 