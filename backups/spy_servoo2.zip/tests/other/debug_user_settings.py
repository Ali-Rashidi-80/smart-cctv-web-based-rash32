#!/usr/bin/env python3
"""
Debug User Settings Database
"""

import sqlite3
import json

def debug_user_settings():
    """Debug user_settings table"""
    print("🔍 Debug User Settings Database")
    print("=" * 40)
    
    try:
        conn = sqlite3.connect('smart_camera_system.db')
        cursor = conn.cursor()
        
        # Check table structure
        print("\n1️⃣ Table structure:")
        cursor.execute("PRAGMA table_info(user_settings)")
        columns = cursor.fetchall()
        for col in columns:
            print(f"   {col[1]} ({col[2]})")
        
        # Check all records
        print("\n2️⃣ All records:")
        cursor.execute("SELECT * FROM user_settings ORDER BY updated_at DESC")
        records = cursor.fetchall()
        
        if not records:
            print("   No records found")
        else:
            for i, record in enumerate(records):
                print(f"   Record {i+1}: {record}")
        
        # Check specific IP
        print("\n3️⃣ Records for localhost:")
        cursor.execute("SELECT * FROM user_settings WHERE ip = '127.0.0.1' ORDER BY updated_at DESC")
        localhost_records = cursor.fetchall()
        
        if not localhost_records:
            print("   No records for localhost")
        else:
            for i, record in enumerate(localhost_records):
                print(f"   Record {i+1}: {record}")
        
        # Check recent records
        print("\n4️⃣ Recent records:")
        cursor.execute("SELECT ip, theme, language, device_mode, servo1, servo2, updated_at FROM user_settings ORDER BY updated_at DESC LIMIT 5")
        recent_records = cursor.fetchall()
        
        if not recent_records:
            print("   No recent records")
        else:
            for i, record in enumerate(recent_records):
                print(f"   Record {i+1}: {record}")
        
        conn.close()
        
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    debug_user_settings() 