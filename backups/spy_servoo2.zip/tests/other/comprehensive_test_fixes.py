#!/usr/bin/env python3
"""
Comprehensive Test Script for Smart Camera System
Tests all fixes and verifies system functionality
"""

import asyncio
import sys
import os
import time
import subprocess
from pathlib import Path

def run_command(cmd, description):
    """Run a command and return success status"""
    print(f"\n🔧 {description}")
    print(f"Running: {cmd}")
    
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=60)
        if result.returncode == 0:
            print(f"✅ {description} - SUCCESS")
            return True
        else:
            print(f"❌ {description} - FAILED")
            print(f"Error: {result.stderr}")
            return False
    except subprocess.TimeoutExpired:
        print(f"⏰ {description} - TIMEOUT")
        return False
    except Exception as e:
        print(f"💥 {description} - EXCEPTION: {e}")
        return False

def test_imports():
    """Test if all modules import successfully"""
    print("\n📦 Testing Module Imports...")
    
    modules_to_test = [
        "server_fastapi",
        "aiosqlite",
        "fastapi",
        "uvicorn",
        "pydantic",
        "jinja2",
        "pyotp",
        "jdatetime",
        "arabic_reshaper",
        "bidi",
        "psutil"
    ]
    
    failed_imports = []
    for module in modules_to_test:
        try:
            __import__(module)
            print(f"✅ {module}")
        except ImportError as e:
            print(f"❌ {module}: {e}")
            failed_imports.append(module)
    
    if failed_imports:
        print(f"\n⚠️ Failed imports: {failed_imports}")
        return False
    else:
        print("✅ All imports successful")
        return True

def test_database():
    """Test database functionality"""
    print("\n🗄️ Testing Database...")
    
    try:
        import aiosqlite
        import tempfile
        
        # Create temporary database
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp_db:
            db_path = tmp_db.name
        
        async def test_db_operations():
            # Test connection
            conn = await aiosqlite.connect(db_path)
            
            # Test table creation
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS test_table (
                    id INTEGER PRIMARY KEY,
                    name TEXT NOT NULL,
                    created_at TEXT
                )
            """)
            
            # Test insert
            await conn.execute(
                "INSERT INTO test_table (name, created_at) VALUES (?, ?)",
                ("test_user", "2024-01-01 12:00:00")
            )
            
            # Test select
            cursor = await conn.execute("SELECT * FROM test_table WHERE name = ?", ("test_user",))
            row = await cursor.fetchone()
            
            await conn.close()
            
            # Cleanup
            os.unlink(db_path)
            
            return row is not None
        
        result = asyncio.run(test_db_operations())
        if result:
            print("✅ Database operations successful")
            return True
        else:
            print("❌ Database operations failed")
            return False
            
    except Exception as e:
        print(f"❌ Database test failed: {e}")
        return False

def test_server_startup():
    """Test server startup without errors"""
    print("\n🚀 Testing Server Startup...")
    
    try:
        import server_fastapi
        
        # Test if server can be imported and basic functions exist
        required_functions = [
            'app',
            'get_current_user',
            'init_db',
            'check_db_health'
        ]
        
        for func_name in required_functions:
            if hasattr(server_fastapi, func_name):
                print(f"✅ {func_name}")
            else:
                print(f"❌ {func_name} not found")
                return False
        
        print("✅ Server startup test successful")
        return True
        
    except Exception as e:
        print(f"❌ Server startup test failed: {e}")
        return False

def run_pytest_tests():
    """Run pytest tests and analyze results"""
    print("\n🧪 Running Pytest Tests...")
    
    # Run tests with coverage
    cmd = "python -m pytest tests/test_server_fastapi.py -v --tb=short --maxfail=5"
    success = run_command(cmd, "Running pytest tests")
    
    if success:
        print("✅ Pytest tests completed")
    else:
        print("⚠️ Some tests failed - checking specific issues...")
        
        # Run individual failing tests
        failing_tests = [
            "test_index",
            "test_error_handling", 
            "test_upload_photo_formats",
            "test_delete_file_invalid_names",
            "test_boundary_values_servo"
        ]
        
        for test_name in failing_tests:
            cmd = f"python -m pytest tests/test_server_fastapi.py::{test_name} -v --tb=short"
            run_command(cmd, f"Testing {test_name}")
    
    return success

def test_file_structure():
    """Test if all required files exist"""
    print("\n📁 Testing File Structure...")
    
    required_files = [
        "server_fastapi.py",
        "requirements.txt",
        "templates/index.html",
        "templates/login.html",
        "static/css/index/styles.css",
        "static/js/index/script.js",
        "tests/test_server_fastapi.py"
    ]
    
    missing_files = []
    for file_path in required_files:
        if os.path.exists(file_path):
            print(f"✅ {file_path}")
        else:
            print(f"❌ {file_path} - MISSING")
            missing_files.append(file_path)
    
    if missing_files:
        print(f"\n⚠️ Missing files: {missing_files}")
        return False
    else:
        print("✅ All required files present")
        return True

def test_dependencies():
    """Test if all dependencies are installed"""
    print("\n📋 Testing Dependencies...")
    
    try:
        import pkg_resources
        
        with open('requirements.txt', 'r') as f:
            requirements = [line.strip() for line in f if line.strip() and not line.startswith('#')]
        
        missing_deps = []
        for req in requirements:
            try:
                pkg_resources.require(req)
                print(f"✅ {req}")
            except pkg_resources.DistributionNotFound:
                print(f"❌ {req} - NOT INSTALLED")
                missing_deps.append(req)
        
        if missing_deps:
            print(f"\n⚠️ Missing dependencies: {missing_deps}")
            print("Run: pip install -r requirements.txt")
            return False
        else:
            print("✅ All dependencies installed")
            return True
            
    except Exception as e:
        print(f"❌ Dependency test failed: {e}")
        return False

def generate_test_report(results):
    """Generate a test report"""
    print("\n" + "="*60)
    print("📊 COMPREHENSIVE TEST REPORT")
    print("="*60)
    
    total_tests = len(results)
    passed_tests = sum(1 for result in results.values() if result)
    failed_tests = total_tests - passed_tests
    
    print(f"Total Tests: {total_tests}")
    print(f"Passed: {passed_tests} ✅")
    print(f"Failed: {failed_tests} ❌")
    print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
    
    print("\nDetailed Results:")
    for test_name, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"  {test_name}: {status}")
    
    if failed_tests == 0:
        print("\n🎉 ALL TESTS PASSED! System is ready for production.")
    else:
        print(f"\n⚠️ {failed_tests} tests failed. Please review the issues above.")
    
    return failed_tests == 0

def main():
    """Main test function"""
    print("🔍 SMART CAMERA SYSTEM - COMPREHENSIVE TEST SUITE")
    print("="*60)
    
    # Run all tests
    test_results = {
        "Module Imports": test_imports(),
        "File Structure": test_file_structure(),
        "Dependencies": test_dependencies(),
        "Database Operations": test_database(),
        "Server Startup": test_server_startup(),
        "Pytest Tests": run_pytest_tests()
    }
    
    # Generate report
    all_passed = generate_test_report(test_results)
    
    # Exit with appropriate code
    sys.exit(0 if all_passed else 1)

if __name__ == "__main__":
    main() 