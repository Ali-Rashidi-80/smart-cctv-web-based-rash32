#!/usr/bin/env python3
"""
Final test to verify all fixes are working correctly
"""

import asyncio
import httpx
import json
import sys
import os
from datetime import datetime

async def test_final_fixes():
    """Test all the fixes that were applied"""
    print("🔧 Testing Final Fixes Verification")
    print("=" * 50)
    
    base_url = "http://localhost:3000"
    
    async with httpx.AsyncClient(timeout=30.0) as client:
        try:
            # Test 1: Device status endpoints (should be public now)
            print("\n1️⃣ Testing device status endpoints...")
            
            device_endpoints = [
                "/esp32cam/status",
                "/pico/status", 
                "/devices/status"
            ]
            
            for endpoint in device_endpoints:
                response = await client.get(f"{base_url}{endpoint}")
                
                if response.status_code == 200:
                    data = response.json()
                    print(f"✅ {endpoint} working: {data.get('status', 'N/A')}")
                else:
                    print(f"❌ {endpoint} failed: {response.status_code}")
                    return False
            
            # Test 2: WebSocket HTTP guard (should be public now)
            print("\n2️⃣ Testing WebSocket HTTP guard...")
            
            response = await client.get(f"{base_url}/ws")
            
            if response.status_code == 400:
                print("✅ WebSocket HTTP guard working correctly")
            else:
                print(f"❌ WebSocket HTTP guard failed: {response.status_code}")
                return False
            
            # Test 3: SMS service error handling (should not break the flow)
            print("\n3️⃣ Testing SMS service error handling...")
            
            # Test password recovery endpoint
            recovery_data = {"phone": "09123456789"}
            response = await client.post(f"{base_url}/recover-password", json=recovery_data)
            
            if response.status_code in [200, 400, 422]:
                print("✅ Password recovery endpoint working (SMS errors handled gracefully)")
            else:
                print(f"❌ Password recovery endpoint failed: {response.status_code}")
                return False
            
            # Test 4: Authentication system
            print("\n4️⃣ Testing authentication system...")
            
            # Test login page
            response = await client.get(f"{base_url}/login")
            if response.status_code == 200:
                print("✅ Login page accessible")
            else:
                print(f"❌ Login page failed: {response.status_code}")
                return False
            
            # Test Google OAuth
            response = await client.get(f"{base_url}/auth/google", follow_redirects=False)
            if response.status_code in [302, 307]:
                print("✅ Google OAuth working")
            else:
                print(f"❌ Google OAuth failed: {response.status_code}")
                return False
            
            # Test 5: Authorization middleware
            print("\n5️⃣ Testing authorization middleware...")
            
            # Test protected endpoints
            protected_endpoints = [
                ("/dashboard", "should redirect to login"),
                ("/api/users", "should return 401"),
                ("/get_status", "should return 401")
            ]
            
            for endpoint, expected in protected_endpoints:
                response = await client.get(f"{base_url}{endpoint}", follow_redirects=False)
                
                if endpoint.startswith("/api/"):
                    if response.status_code == 401:
                        print(f"✅ {endpoint} {expected}")
                    else:
                        print(f"❌ {endpoint} failed: {response.status_code}")
                        return False
                else:
                    if response.status_code == 302:
                        location = response.headers.get("location", "")
                        if "/login" in location:
                            print(f"✅ {endpoint} {expected}")
                        else:
                            print(f"❌ {endpoint} unexpected redirect: {location}")
                            return False
                    else:
                        print(f"❌ {endpoint} failed: {response.status_code}")
                        return False
            
            # Test 6: Public endpoints
            print("\n6️⃣ Testing public endpoints...")
            
            public_endpoints = [
                ("/health", "should be accessible"),
                ("/ports", "should be accessible"),
                ("/static/css/styles.css", "should be accessible")
            ]
            
            for endpoint, expected in public_endpoints:
                response = await client.get(f"{base_url}{endpoint}", follow_redirects=False)
                
                if response.status_code in [200, 404]:  # 404 is OK for non-existent files
                    print(f"✅ {endpoint} {expected}")
                else:
                    print(f"❌ {endpoint} failed: {response.status_code}")
            
            print("\n🎉 All fixes verified successfully!")
            return True
            
        except Exception as e:
            print(f"❌ Test failed with exception: {e}")
            return False

async def main():
    """Main test runner"""
    print("🚀 Final Fixes Verification Test")
    print(f"⏰ {datetime.now()}")
    print("=" * 60)
    
    success = await test_final_fixes()
    
    if success:
        print("\n✅ All fixes are working correctly!")
        print("\n🎉 System is fully operational and ready for production!")
        print("\n✅ Fixed issues:")
        print("   - Device status endpoints are now public")
        print("   - WebSocket HTTP guard is accessible")
        print("   - SMS service errors are handled gracefully")
        print("   - Authentication system is working")
        print("   - Authorization middleware is functioning")
        print("   - All public endpoints are accessible")
    else:
        print("\n❌ Some fixes are not working correctly!")
    
    return success

if __name__ == "__main__":
    result = asyncio.run(main())
    sys.exit(0 if result else 1)