#!/usr/bin/env python3
"""
تست امنیتی endpoint توکن‌ها
"""

import requests

def test_token_security():
    """تست امنیتی endpoint توکن‌ها"""
    print("🔒 تست امنیتی endpoint توکن‌ها")
    print("=" * 50)
    
    # تست 1: دسترسی بدون پسورد (باید redirect شود)
    print("\n1️⃣ تست دسترسی بدون پسورد:")
    try:
        response = requests.get("http://localhost:3000/tokens", allow_redirects=False)
        print(f"   Status: {response.status_code}")
        if response.status_code in [302, 401]:
            print("   ✅ امنیت: دسترسی بدون پسورد مسدود شد")
        else:
            print("   ❌ امنیت: دسترسی بدون پسورد باید مسدود شود")
    except Exception as e:
        print(f"   ❌ خطا: {e}")
    
    # تست 2: دسترسی با پسورد اشتباه
    print("\n2️⃣ تست دسترسی با پسورد اشتباه:")
    try:
        response = requests.get("http://localhost:3000/tokens/wrong_password")
        data = response.json()
        print(f"   Status: {response.status_code}")
        if data.get("status") == "error" and "Invalid password" in data.get("message", ""):
            print("   ✅ امنیت: پسورد اشتباه رد شد")
        else:
            print("   ❌ امنیت: پسورد اشتباه باید رد شود")
    except Exception as e:
        print(f"   ❌ خطا: {e}")
    
    # تست 3: دسترسی با پسورد صحیح
    print("\n3️⃣ تست دسترسی با پسورد صحیح:")
    try:
        response = requests.get("http://localhost:3000/tokens/spy_servoo_secure_2024")
        data = response.json()
        print(f"   Status: {response.status_code}")
        if "pico_tokens" in data and "esp32cam_tokens" in data:
            print("   ✅ امنیت: پسورد صحیح پذیرفته شد")
            print(f"   📋 تعداد توکن‌های پیکو: {len(data['pico_tokens'])}")
            print(f"   📋 تعداد توکن‌های ESP32CAM: {len(data['esp32cam_tokens'])}")
        else:
            print("   ❌ امنیت: پسورد صحیح باید پذیرفته شود")
    except Exception as e:
        print(f"   ❌ خطا: {e}")
    
    # تست 4: تست پسوردهای مختلف
    print("\n4️⃣ تست پسوردهای مختلف:")
    test_passwords = [
        "admin",
        "password",
        "123456",
        "spy_servoo",
        "secure",
        "token",
        "pico",
        "esp32cam"
    ]
    
    for pwd in test_passwords:
        try:
            response = requests.get(f"http://localhost:3000/tokens/{pwd}")
            data = response.json()
            if data.get("status") == "error":
                print(f"   ✅ '{pwd}': رد شد")
            else:
                print(f"   ❌ '{pwd}': پذیرفته شد (نباید پذیرفته شود)")
        except Exception as e:
            print(f"   ❌ '{pwd}': خطا - {e}")
    
    print("\n" + "=" * 50)
    print("🏁 تست امنیتی پایان یافت")

if __name__ == "__main__":
    test_token_security() 