#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SMS System Test Script
تست سیستم پیامک برای بازیابی رمز عبور
"""

import os
import asyncio
import logging
from datetime import datetime
import jdatetime
from melipayamak import Api
from dotenv import load_dotenv

# تنظیم لاگ‌گذاری
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# بارگذاری متغیرهای محیطی
load_dotenv()

# تنظیمات SMS
SMS_USERNAME = os.getenv('SMS_USERNAME')
SMS_PASSWORD = os.getenv('SMS_PASSWORD')
SMS_SENDER_NUMBER = os.getenv('SMS_SENDER_NUMBER')

def print_sms_config():
    """نمایش تنظیمات SMS"""
    print("🔧 تنظیمات SMS:")
    print(f"   SMS_USERNAME: {SMS_USERNAME or 'Not Set'}")
    print(f"   SMS_PASSWORD: {'Set' if SMS_PASSWORD else 'Not Set'}")
    print(f"   SMS_SENDER_NUMBER: {SMS_SENDER_NUMBER or 'Not Set'}")
    print()

async def test_sms_send(phone: str, message: str) -> tuple[bool, str]:
    """
    تابع تست ارسال پیامک
    
    ورودی‌ها:
        phone (str): شماره تلفن در فرمت بین‌المللی (مثلاً +989966902209)
        message (str): پیام برای ارسال
    
    خروجی:
        tuple[bool, str]: (وضعیت موفقیت, پیام خطا در صورت وجود)
    """
    try:
        if not all([SMS_USERNAME, SMS_PASSWORD, SMS_SENDER_NUMBER]):
            logger.error("تنظیمات پیامک ناقص است")
            return False, "خطا در تنظیمات پیامک: اطلاعات API ناقص است."
        
        # تبدیل شماره تلفن به فرمت محلی ایران
        sms_phone = '0' + phone[3:] if phone.startswith('+989') else phone
        logger.info(f"در حال آماده‌سازی برای ارسال پیامک به {sms_phone}")
        
        # مقداردهی API ملّی‌پرداز
        api = Api(SMS_USERNAME, SMS_PASSWORD)
        sms = api.sms()
        
        # ارسال پیامک
        response = sms.send(sms_phone, SMS_SENDER_NUMBER, message)
        logger.info(f"پاسخ API پیامک برای {sms_phone}: {response}")
        
        # بررسی خطا در پاسخ
        if response and 'error' in str(response).lower():
            logger.error(f"ارسال پیامک به {sms_phone} ناموفق بود: {response}")
            return False, f"خطا در ارسال پیامک: {response}"
        
        logger.info(f"پیامک با موفقیت به {sms_phone} ارسال شد")
        return True, ""
    
    except Exception as e:
        logger.error(f"خطا در ارسال پیامک به {phone}: {str(e)}")
        return False, f"خطایی در ارسال پیامک رخ داد: {str(e)}"

def create_attractive_sms_message(username: str, token: str) -> str:
    """ایجاد پیام جذاب برای SMS"""
    current_time = datetime.now()
    
    # تبدیل صحیح تاریخ میلادی به جلالی
    jalali_date = jdatetime.date.fromgregorian(date=current_time.date())
    jdate = jalali_date.strftime('%Y/%m/%d')
    
    day_of_week_farsi = {
        'Monday': 'دوشنبه', 'Tuesday': 'سه‌شنبه', 'Wednesday': 'چهارشنبه',
        'Thursday': 'پنج‌شنبه', 'Friday': 'جمعه', 'Saturday': 'شنبه', 'Sunday': 'یکشنبه'
    }
    day_of_week = day_of_week_farsi[current_time.strftime('%A')]
    formatted_time = current_time.strftime('%H:%M:%S')
    
    message = (
        f"🔐 سیستم هوشمند دوربین امنیتی 🔐\n"
        f"سلام {username} عزیز 👋\n\n"
        f"📱 درخواست بازیابی رمز عبور شما دریافت شد\n"
        f"🔑 کد بازیابی: {token}\n\n"
        f"⏰ تاریخ: {jdate} ({day_of_week})\n"
        f"🕐 ساعت: {formatted_time}\n\n"
        f"⚠️ این کد تا 24 ساعت معتبر است\n"
        f"🔒 اگر شما این درخواست را نکرده‌اید، نادیده بگیرید\n\n"
        f"💎 با تشکر از اعتماد شما\n"
        f"🚀 تیم پشتیبانی سیستم هوشمند\n"
        f"📞 پشتیبانی: 09204963846"
    )
    
    return message

async def test_password_recovery_sms():
    """تست کامل سیستم بازیابی رمز عبور با SMS"""
    print("🧪 تست سیستم بازیابی رمز عبور با SMS")
    print("=" * 50)
    
    # شماره تلفن آزمایشی
    test_phone = "+989966902209"
    test_username = "کاربر تست"
    test_token = "123456"
    
    print(f"📱 شماره تلفن تست: {test_phone}")
    print(f"👤 نام کاربری: {test_username}")
    print(f"🔑 کد بازیابی: {test_token}")
    print()
    
    # ایجاد پیام جذاب
    message = create_attractive_sms_message(test_username, test_token)
    
    print("📝 پیام ایجاد شده:")
    print("-" * 30)
    print(message)
    print("-" * 30)
    print()
    
    # ارسال پیامک
    print("🚀 در حال ارسال پیامک...")
    success, error = await test_sms_send(test_phone, message)
    
    if success:
        print("✅ پیامک با موفقیت ارسال شد!")
        print("📱 لطفاً گوشی خود را بررسی کنید")
    else:
        print(f"❌ خطا در ارسال پیامک: {error}")
        print("🔧 لطفاً تنظیمات SMS را بررسی کنید")

async def test_simple_sms():
    """تست ساده پیامک"""
    print("🧪 تست ساده پیامک")
    print("=" * 30)
    
    test_phone = "+989966902209"
    simple_message = "تست سیستم پیامک - سیستم هوشمند دوربین امنیتی"
    
    print(f"📱 شماره: {test_phone}")
    print(f"📝 پیام: {simple_message}")
    print()
    
    success, error = await test_sms_send(test_phone, simple_message)
    
    if success:
        print("✅ پیامک ساده با موفقیت ارسال شد!")
    else:
        print(f"❌ خطا: {error}")

async def main():
    """تابع اصلی"""
    print("🚀 شروع تست سیستم SMS")
    print("=" * 50)
    print()
    
    # نمایش تنظیمات
    print_sms_config()
    
    # بررسی تنظیمات
    if not all([SMS_USERNAME, SMS_PASSWORD, SMS_SENDER_NUMBER]):
        print("❌ تنظیمات SMS ناقص است!")
        print("🔧 لطفاً متغیرهای محیطی زیر را تنظیم کنید:")
        print("   SMS_USERNAME=your_username")
        print("   SMS_PASSWORD=your_password")
        print("   SMS_SENDER_NUMBER=your_sender")
        print()
        print("💡 می‌توانید فایل .env ایجاد کنید:")
        print("   echo 'SMS_USERNAME=your_username' > .env")
        print("   echo 'SMS_PASSWORD=your_password' >> .env")
        print("   echo 'SMS_SENDER_NUMBER=your_sender' >> .env")
        return
    
    print("✅ تنظیمات SMS کامل است!")
    print()
    
    # تست ساده
    await test_simple_sms()
    print()
    
    # تست کامل
    await test_password_recovery_sms()
    print()
    
    print("🏁 تست کامل شد!")

if __name__ == "__main__":
    asyncio.run(main()) 