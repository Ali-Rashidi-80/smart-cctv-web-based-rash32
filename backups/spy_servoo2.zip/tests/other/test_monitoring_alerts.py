#!/usr/bin/env python3
"""
تست‌های مانیتورینگ و هشدار
Monitoring & Alert Tests
"""

import sys
import os
import asyncio
import time
import psutil
import json
from datetime import datetime, timedelta
from typing import List, Dict, Any

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class MonitoringAlertTester:
    def __init__(self):
        self.test_results = []
        self.alerts = []
        self.metrics = {}
        
    def log_test(self, test_name: str, passed: bool, details: str = "", metrics: Dict = None):
        """ثبت نتیجه تست"""
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status} {test_name}: {details}")
        self.test_results.append({
            "test": test_name,
            "passed": passed,
            "details": details,
            "metrics": metrics or {},
            "timestamp": datetime.now().isoformat()
        })
        
    def log_alert(self, alert_type: str, message: str, severity: str = "WARNING"):
        """ثبت هشدار"""
        print(f"🚨 {severity} - {alert_type}: {message}")
        self.alerts.append({
            "type": alert_type,
            "message": message,
            "severity": severity,
            "timestamp": datetime.now().isoformat()
        })

    async def test_system_resources(self):
        """تست منابع سیستم"""
        print("\n💻 تست منابع سیستم...")
        
        try:
            # CPU Usage
            cpu_percent = psutil.cpu_percent(interval=1)
            cpu_ok = cpu_percent < 80
            
            self.log_test(
                "CPU Usage",
                cpu_ok,
                f"CPU Usage: {cpu_percent:.1f}%",
                {"cpu_percent": cpu_percent, "threshold": 80}
            )
            
            if not cpu_ok:
                self.log_alert("System Resources", f"High CPU usage: {cpu_percent:.1f}%", "WARNING")
            
            # Memory Usage
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            memory_ok = memory_percent < 85
            
            self.log_test(
                "Memory Usage",
                memory_ok,
                f"Memory Usage: {memory_percent:.1f}% ({memory.used / 1024 / 1024 / 1024:.1f}GB / {memory.total / 1024 / 1024 / 1024:.1f}GB)",
                {"memory_percent": memory_percent, "memory_used_gb": memory.used / 1024 / 1024 / 1024, "threshold": 85}
            )
            
            if not memory_ok:
                self.log_alert("System Resources", f"High memory usage: {memory_percent:.1f}%", "WARNING")
            
            # Disk Usage
            disk = psutil.disk_usage('/')
            disk_percent = (disk.used / disk.total) * 100
            disk_ok = disk_percent < 90
            
            self.log_test(
                "Disk Usage",
                disk_ok,
                f"Disk Usage: {disk_percent:.1f}% ({disk.used / 1024 / 1024 / 1024:.1f}GB / {disk.total / 1024 / 1024 / 1024:.1f}GB)",
                {"disk_percent": disk_percent, "disk_used_gb": disk.used / 1024 / 1024 / 1024, "threshold": 90}
            )
            
            if not disk_ok:
                self.log_alert("System Resources", f"High disk usage: {disk_percent:.1f}%", "CRITICAL")
            
            # Network Connections
            connections = len(psutil.net_connections())
            network_ok = connections < 1000
            
            self.log_test(
                "Network Connections",
                network_ok,
                f"Active connections: {connections}",
                {"connections": connections, "threshold": 1000}
            )
            
            if not network_ok:
                self.log_alert("System Resources", f"High number of network connections: {connections}", "WARNING")
            
        except Exception as e:
            self.log_test("System Resources", False, f"Error: {e}")
            self.log_alert("System Resources", f"Error monitoring system resources: {e}", "ERROR")

    async def test_database_health(self):
        """تست سلامت دیتابیس"""
        print("\n🗄️ تست سلامت دیتابیس...")
        
        try:
            from server_fastapi import get_db_connection, close_db_connection
            
            # تست اتصال
            start_time = time.time()
            conn = await get_db_connection()
            connection_time = time.time() - start_time
            
            connection_ok = connection_time < 5.0  # کمتر از 5 ثانیه
            
            self.log_test(
                "Database Connection",
                connection_ok,
                f"Connection time: {connection_time:.3f}s",
                {"connection_time": connection_time, "threshold": 5.0}
            )
            
            if not connection_ok:
                self.log_alert("Database Health", f"Slow database connection: {connection_time:.3f}s", "WARNING")
            
            # تست اندازه دیتابیس
            cursor = await conn.execute("SELECT COUNT(*) FROM users")
            user_count = (await cursor.fetchone())[0]
            
            cursor = await conn.execute("SELECT COUNT(*) FROM camera_logs")
            log_count = (await cursor.fetchone())[0]
            
            cursor = await conn.execute("SELECT COUNT(*) FROM servo_commands")
            servo_count = (await cursor.fetchone())[0]
            
            # بررسی اندازه جداول
            tables_ok = user_count < 10000 and log_count < 100000 and servo_count < 5000
            
            self.log_test(
                "Database Size",
                tables_ok,
                f"Users: {user_count}, Logs: {log_count}, Servo: {servo_count}",
                {"user_count": user_count, "log_count": log_count, "servo_count": servo_count}
            )
            
            if not tables_ok:
                self.log_alert("Database Health", f"Large database tables - Users: {user_count}, Logs: {log_count}", "WARNING")
            
            # تست عملکرد query
            start_time = time.time()
            cursor = await conn.execute("SELECT * FROM users LIMIT 10")
            await cursor.fetchall()
            query_time = time.time() - start_time
            
            query_ok = query_time < 1.0  # کمتر از 1 ثانیه
            
            self.log_test(
                "Database Query Performance",
                query_ok,
                f"Query time: {query_time:.3f}s",
                {"query_time": query_time, "threshold": 1.0}
            )
            
            if not query_ok:
                self.log_alert("Database Health", f"Slow database query: {query_time:.3f}s", "WARNING")
            
            await close_db_connection(conn)
            
        except Exception as e:
            self.log_test("Database Health", False, f"Error: {e}")
            self.log_alert("Database Health", f"Database health check failed: {e}", "ERROR")

    async def test_application_performance(self):
        """تست عملکرد اپلیکیشن"""
        print("\n⚡ تست عملکرد اپلیکیشن...")
        
        try:
            from server_fastapi import (
                sanitize_input,
                create_access_token,
                verify_token,
                hash_password,
                verify_password
            )
            
            # تست عملکرد sanitization
            start_time = time.time()
            for i in range(100):
                sanitize_input(f"test_input_{i}")
            sanitization_time = time.time() - start_time
            sanitization_rate = 100 / sanitization_time
            
            sanitization_ok = sanitization_rate > 50  # حداقل 50 عملیات در ثانیه
            
            self.log_test(
                "Input Sanitization Performance",
                sanitization_ok,
                f"Rate: {sanitization_rate:.1f} ops/s",
                {"rate": sanitization_rate, "threshold": 50}
            )
            
            if not sanitization_ok:
                self.log_alert("Application Performance", f"Slow input sanitization: {sanitization_rate:.1f} ops/s", "WARNING")
            
            # تست عملکرد JWT
            start_time = time.time()
            for i in range(50):
                token = create_access_token(data={"sub": f"user_{i}", "role": "user"})
                verify_token(token)
            jwt_time = time.time() - start_time
            jwt_rate = 50 / jwt_time
            
            jwt_ok = jwt_rate > 20  # حداقل 20 عملیات در ثانیه
            
            self.log_test(
                "JWT Performance",
                jwt_ok,
                f"Rate: {jwt_rate:.1f} ops/s",
                {"rate": jwt_rate, "threshold": 20}
            )
            
            if not jwt_ok:
                self.log_alert("Application Performance", f"Slow JWT operations: {jwt_rate:.1f} ops/s", "WARNING")
            
            # تست عملکرد password hashing
            start_time = time.time()
            for i in range(10):
                hash_password(f"password_{i}")
            hash_time = time.time() - start_time
            hash_rate = 10 / hash_time
            
            hash_ok = hash_rate > 1  # حداقل 1 عملیات در ثانیه
            
            self.log_test(
                "Password Hashing Performance",
                hash_ok,
                f"Rate: {hash_rate:.1f} ops/s",
                {"rate": hash_rate, "threshold": 1}
            )
            
            if not hash_ok:
                self.log_alert("Application Performance", f"Slow password hashing: {hash_rate:.1f} ops/s", "WARNING")
            
        except Exception as e:
            self.log_test("Application Performance", False, f"Error: {e}")
            self.log_alert("Application Performance", f"Performance test failed: {e}", "ERROR")

    async def test_security_monitoring(self):
        """تست مانیتورینگ امنیت"""
        print("\n🛡️ تست مانیتورینگ امنیت...")
        
        try:
            from server_fastapi import check_rate_limit, check_login_attempts
            
            # تست rate limiting
            test_ip = "192.168.1.100"
            rate_limit_violations = 0
            
            for i in range(20):  # تلاش برای 20 درخواست
                result = check_rate_limit(test_ip)
                if not result:
                    rate_limit_violations += 1
            
            rate_limit_ok = rate_limit_violations > 0  # باید حداقل یک بار مسدود شود
            
            self.log_test(
                "Rate Limiting Monitoring",
                rate_limit_ok,
                f"Violations: {rate_limit_violations}/20",
                {"violations": rate_limit_violations, "total_attempts": 20}
            )
            
            if not rate_limit_ok:
                self.log_alert("Security Monitoring", "Rate limiting not working properly", "CRITICAL")
            
            # تست login attempts
            test_ip2 = "192.168.1.200"
            login_violations = 0
            
            for i in range(10):  # تلاش برای 10 login
                result = check_login_attempts(test_ip2)
                if not result:
                    login_violations += 1
            
            login_ok = login_violations > 0  # باید حداقل یک بار مسدود شود
            
            self.log_test(
                "Login Attempts Monitoring",
                login_ok,
                f"Violations: {login_violations}/10",
                {"violations": login_violations, "total_attempts": 10}
            )
            
            if not login_ok:
                self.log_alert("Security Monitoring", "Login attempts limiting not working properly", "CRITICAL")
            
        except Exception as e:
            self.log_test("Security Monitoring", False, f"Error: {e}")
            self.log_alert("Security Monitoring", f"Security monitoring test failed: {e}", "ERROR")

    async def test_error_monitoring(self):
        """تست مانیتورینگ خطاها"""
        print("\n🚨 تست مانیتورینگ خطاها...")
        
        try:
            # بررسی فایل‌های لاگ
            log_files = [
                "logs/app_2025-07-28.log",
                "logs/db_2025-07-28.log",
                "logs/uvicorn.error_2025-07-28.log"
            ]
            
            error_counts = {}
            
            for log_file in log_files:
                if os.path.exists(log_file):
                    try:
                        with open(log_file, 'r', encoding='utf-8') as f:
                            content = f.read()
                            error_count = content.lower().count('error')
                            error_counts[log_file] = error_count
                    except Exception as e:
                        error_counts[log_file] = -1  # خطا در خواندن فایل
                else:
                    error_counts[log_file] = 0  # فایل وجود ندارد
            
            # بررسی تعداد خطاها
            total_errors = sum(error_counts.values())
            errors_ok = total_errors < 100  # کمتر از 100 خطا
            
            self.log_test(
                "Error Monitoring",
                errors_ok,
                f"Total errors: {total_errors}",
                {"total_errors": total_errors, "error_details": error_counts, "threshold": 100}
            )
            
            if not errors_ok:
                self.log_alert("Error Monitoring", f"High number of errors: {total_errors}", "WARNING")
            
            # بررسی خطاهای بحرانی
            critical_errors = 0
            for log_file, count in error_counts.items():
                if count > 50:  # بیش از 50 خطا در یک فایل
                    critical_errors += 1
            
            critical_ok = critical_errors == 0
            
            self.log_test(
                "Critical Error Monitoring",
                critical_ok,
                f"Files with critical errors: {critical_errors}",
                {"critical_files": critical_errors}
            )
            
            if not critical_ok:
                self.log_alert("Error Monitoring", f"Critical errors in {critical_errors} log files", "CRITICAL")
            
        except Exception as e:
            self.log_test("Error Monitoring", False, f"Error: {e}")
            self.log_alert("Error Monitoring", f"Error monitoring test failed: {e}", "ERROR")

    async def test_availability_monitoring(self):
        """تست مانیتورینگ دسترسی"""
        print("\n🌐 تست مانیتورینگ دسترسی...")
        
        try:
            # تست دسترسی به فایل‌های مهم
            critical_files = [
                "server_fastapi.py",
                "smart_camera_system.db",
                "admin_credentials.txt",
                "requirements.txt"
            ]
            
            file_access_issues = 0
            
            for file_path in critical_files:
                if not os.path.exists(file_path):
                    file_access_issues += 1
                    self.log_alert("Availability", f"Critical file missing: {file_path}", "CRITICAL")
            
            file_access_ok = file_access_issues == 0
            
            self.log_test(
                "Critical Files Availability",
                file_access_ok,
                f"Missing files: {file_access_issues}",
                {"missing_files": file_access_issues}
            )
            
            # تست دسترسی به دایرکتوری‌ها
            critical_dirs = [
                "logs",
                "gallery",
                "security_videos",
                "static",
                "templates"
            ]
            
            dir_access_issues = 0
            
            for dir_path in critical_dirs:
                if not os.path.exists(dir_path) or not os.path.isdir(dir_path):
                    dir_access_issues += 1
                    self.log_alert("Availability", f"Critical directory missing: {dir_path}", "WARNING")
            
            dir_access_ok = dir_access_issues == 0
            
            self.log_test(
                "Critical Directories Availability",
                dir_access_ok,
                f"Missing directories: {dir_access_issues}",
                {"missing_directories": dir_access_issues}
            )
            
        except Exception as e:
            self.log_test("Availability Monitoring", False, f"Error: {e}")
            self.log_alert("Availability Monitoring", f"Availability test failed: {e}", "ERROR")

    async def run_all_monitoring_tests(self):
        """اجرای تمام تست‌های مانیتورینگ"""
        print("🔍 تست‌های مانیتورینگ و هشدار")
        print("=" * 60)
        
        # اجرای تست‌ها
        await self.test_system_resources()
        await self.test_database_health()
        await self.test_application_performance()
        await self.test_security_monitoring()
        await self.test_error_monitoring()
        await self.test_availability_monitoring()
        
        # گزارش نهایی
        print("\n" + "=" * 60)
        print("📊 گزارش نهایی مانیتورینگ")
        print("=" * 60)
        
        passed = sum(1 for result in self.test_results if result["passed"])
        total = len(self.test_results)
        
        print(f"📈 آمار کلی:")
        print(f"   کل تست‌ها: {total}")
        print(f"   تست‌های موفق: {passed}")
        print(f"   تست‌های ناموفق: {total - passed}")
        print(f"   نرخ موفقیت: {(passed/total)*100:.1f}%")
        
        if self.alerts:
            print(f"\n🚨 هشدارها ({len(self.alerts)}):")
            for alert in self.alerts:
                print(f"   {alert['severity']} - {alert['type']}: {alert['message']}")
        else:
            print(f"\n✅ هیچ هشداری یافت نشد!")
        
        print(f"\n💡 توصیه‌ها:")
        if passed == total and not self.alerts:
            print("   - سیستم در وضعیت عالی است!")
        elif self.alerts:
            print("   - برخی هشدارها نیاز به بررسی دارند")
        else:
            print("   - برخی تست‌های مانیتورینگ ناموفق بودند")
        
        return passed == total

async def main():
    """تابع اصلی"""
    tester = MonitoringAlertTester()
    success = await tester.run_all_monitoring_tests()
    
    if success:
        print("\n🎉 تمام تست‌های مانیتورینگ موفق بودند!")
    else:
        print("\n⚠️ برخی تست‌های مانیتورینگ ناموفق بودند!")

if __name__ == "__main__":
    asyncio.run(main())