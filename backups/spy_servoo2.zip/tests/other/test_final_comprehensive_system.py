#!/usr/bin/env python3
"""
Final Comprehensive System Test
Tests all aspects of the Smart Camera Security System
"""

import asyncio
import aiosqlite
import json
import httpx
from datetime import datetime

class FinalSystemTest:
    def __init__(self):
        self.base_url = "http://localhost:3001"
        self.test_results = []
        
    def log_test(self, test_name: str, status: str, details: str = ""):
        """Log test results"""
        result = {
            "test": test_name,
            "status": status,
            "details": details,
            "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        self.test_results.append(result)
        
        # Print with emoji
        emoji = "✅" if status == "PASS" else "❌" if status == "FAIL" else "⚠️"
        print(f"{emoji} {test_name}: {status}")
        if details:
            print(f"   Details: {details}")
        print()

    async def test_database_structure(self):
        """Test 1: Database structure and tables"""
        print("🧪 Test 1: Database Structure")
        print("=" * 40)
        
        try:
            conn = await aiosqlite.connect('smart_camera_system.db')
            
            # Check user_settings table structure
            cursor = await conn.execute("PRAGMA table_info(user_settings)")
            columns = await cursor.fetchall()
            
            required_columns = [
                'id', 'username', 'ip', 'theme', 'language', 'flash_settings',
                'servo1', 'servo2', 'device_mode', 'photo_quality',
                'smart_motion', 'smart_tracking', 'stream_enabled', 'updated_at'
            ]
            
            found_columns = [col[1] for col in columns]
            missing_columns = [col for col in required_columns if col not in found_columns]
            
            if not missing_columns:
                self.log_test("Database Structure", "PASS", f"All {len(required_columns)} required columns found")
            else:
                self.log_test("Database Structure", "FAIL", f"Missing columns: {missing_columns}")
            
            # Check other tables
            tables = ['users', 'camera_logs', 'servo_commands', 'action_commands', 'device_mode_commands']
            for table in tables:
                try:
                    await conn.execute(f"SELECT COUNT(*) FROM {table}")
                    self.log_test(f"Table {table}", "PASS", "Table exists and accessible")
                except Exception as e:
                    self.log_test(f"Table {table}", "FAIL", f"Error: {str(e)}")
            
            await conn.close()
            
        except Exception as e:
            self.log_test("Database Structure", "FAIL", f"Database error: {str(e)}")

    async def test_user_settings_storage(self):
        """Test 2: User settings storage and retrieval"""
        print("🧪 Test 2: User Settings Storage")
        print("=" * 40)
        
        try:
            conn = await aiosqlite.connect('smart_camera_system.db')
            
            # Test admin user settings
            admin_settings = {
                'username': 'rof642fr',
                'ip': '127.0.0.1',
                'theme': 'dark',
                'language': 'fa',
                'servo1': 90,
                'servo2': 90,
                'device_mode': 'desktop',
                'photo_quality': 85,
                'smart_motion': True,
                'smart_tracking': False,
                'stream_enabled': True,
                'flash_settings': json.dumps({'intensity': 75, 'enabled': True}),
                'updated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
            await conn.execute('''
                INSERT OR REPLACE INTO user_settings 
                (username, ip, theme, language, servo1, servo2, device_mode, photo_quality, 
                 smart_motion, smart_tracking, stream_enabled, flash_settings, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                admin_settings['username'], admin_settings['ip'], admin_settings['theme'],
                admin_settings['language'], admin_settings['servo1'], admin_settings['servo2'],
                admin_settings['device_mode'], admin_settings['photo_quality'],
                admin_settings['smart_motion'], admin_settings['smart_tracking'],
                admin_settings['stream_enabled'], admin_settings['flash_settings'],
                admin_settings['updated_at']
            ))
            await conn.commit()
            
            # Retrieve and verify
            cursor = await conn.execute('''
                SELECT username, theme, language, servo1, servo2, device_mode, 
                       photo_quality, smart_motion, smart_tracking, stream_enabled
                FROM user_settings WHERE username = ?
            ''', ('rof642fr',))
            data = await cursor.fetchone()
            
            if data and data[0] == 'rof642fr':
                self.log_test("User Settings Storage", "PASS", "Admin settings saved and retrieved successfully")
            else:
                self.log_test("User Settings Storage", "FAIL", "Failed to save or retrieve admin settings")
            
            await conn.close()
            
        except Exception as e:
            self.log_test("User Settings Storage", "FAIL", f"Error: {str(e)}")

    async def test_smart_features_database(self):
        """Test 3: Smart features database operations"""
        print("🧪 Test 3: Smart Features Database")
        print("=" * 40)
        
        try:
            conn = await aiosqlite.connect('smart_camera_system.db')
            
            # Test smart features for different users (using unique names)
            test_cases = [
                ('test_smart_user1', True, False),
                ('test_smart_user2', False, True),
                ('test_smart_user3', True, True)
            ]
            
            for username, motion, tracking in test_cases:
                await conn.execute('''
                    INSERT OR REPLACE INTO user_settings 
                    (username, ip, smart_motion, smart_tracking, updated_at)
                    VALUES (?, ?, ?, ?, ?)
                ''', (username, '127.0.0.1', motion, tracking, datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            
            await conn.commit()
            
            # Verify smart features are stored correctly
            cursor = await conn.execute('''
                SELECT username, smart_motion, smart_tracking 
                FROM user_settings WHERE username IN ('test_smart_user1', 'test_smart_user2', 'test_smart_user3')
                ORDER BY username
            ''')
            results = await cursor.fetchall()
            
            if len(results) == 3:
                self.log_test("Smart Features Database", "PASS", f"All {len(results)} smart feature records saved correctly")
            else:
                self.log_test("Smart Features Database", "FAIL", f"Expected 3 records, got {len(results)}")
            
            # Clean up test data
            for username, _, _ in test_cases:
                await conn.execute('DELETE FROM user_settings WHERE username = ?', (username,))
            await conn.commit()
            
            await conn.close()
            
        except Exception as e:
            self.log_test("Smart Features Database", "FAIL", f"Error: {str(e)}")

    async def test_server_import(self):
        """Test 4: Server import and basic functionality"""
        print("🧪 Test 4: Server Import")
        print("=" * 40)
        
        try:
            import server_fastapi
            from server_fastapi import app, init_db
            
            self.log_test("Server Import", "PASS", "Server imports successfully")
            
            # Test database initialization
            await init_db()
            self.log_test("Database Initialization", "PASS", "Database initialized successfully")
            
        except Exception as e:
            self.log_test("Server Import", "FAIL", f"Error: {str(e)}")

    async def test_api_endpoints(self):
        """Test 5: API endpoints availability"""
        print("🧪 Test 5: API Endpoints")
        print("=" * 40)
        
        try:
            import server_fastapi
            from server_fastapi import app
            
            # Check if critical endpoints exist
            routes = [route.path for route in app.routes]
            
            required_endpoints = [
                '/get_user_settings',
                '/save_user_settings',
                '/set_smart_features',
                '/get_smart_features',
                '/health',
                '/get_status'
            ]
            
            missing_endpoints = [ep for ep in required_endpoints if ep not in routes]
            
            if not missing_endpoints:
                self.log_test("API Endpoints", "PASS", f"All {len(required_endpoints)} required endpoints found")
            else:
                self.log_test("API Endpoints", "FAIL", f"Missing endpoints: {missing_endpoints}")
                
        except Exception as e:
            self.log_test("API Endpoints", "FAIL", f"Error: {str(e)}")

    async def test_user_isolation(self):
        """Test 6: User settings isolation"""
        print("🧪 Test 6: User Settings Isolation")
        print("=" * 40)
        
        try:
            conn = await aiosqlite.connect('smart_camera_system.db')
            
            # Create different settings for different users (using unique names and different values)
            users_data = [
                ('test_isolate_admin1', 'dark', 'fa', 90, 90, 'desktop', True, False),
                ('test_isolate_user1', 'light', 'en', 45, 135, 'mobile', False, True),
                ('test_isolate_user2', 'light', 'fa', 180, 0, 'desktop', True, True)
            ]
            
            for username, theme, lang, servo1, servo2, device_mode, motion, tracking in users_data:
                await conn.execute('''
                    INSERT OR REPLACE INTO user_settings 
                    (username, ip, theme, language, servo1, servo2, device_mode, smart_motion, smart_tracking, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (username, '127.0.0.1', theme, lang, servo1, servo2, device_mode, motion, tracking, datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            
            await conn.commit()
            
            # Verify each user has their own settings
            cursor = await conn.execute('''
                SELECT username, theme, language, servo1, servo2, device_mode, smart_motion, smart_tracking
                FROM user_settings WHERE username IN ('test_isolate_admin1', 'test_isolate_user1', 'test_isolate_user2')
                ORDER BY username
            ''')
            results = await cursor.fetchall()
            
            if len(results) == 3:
                # Check that at least some settings are different (not all identical)
                themes = [r[1] for r in results]
                languages = [r[2] for r in results]
                servo1s = [r[3] for r in results]
                
                # Check if at least one setting type has different values
                if len(set(themes)) > 1 or len(set(languages)) > 1 or len(set(servo1s)) > 1:
                    self.log_test("User Settings Isolation", "PASS", "Users have different settings")
                else:
                    self.log_test("User Settings Isolation", "FAIL", "All users have identical settings")
            else:
                self.log_test("User Settings Isolation", "FAIL", f"Expected 3 users, got {len(results)}")
            
            # Clean up test data
            for username, _, _, _, _, _, _, _ in users_data:
                await conn.execute('DELETE FROM user_settings WHERE username = ?', (username,))
            await conn.commit()
            
            await conn.close()
            
        except Exception as e:
            self.log_test("User Settings Isolation", "FAIL", f"Error: {str(e)}")

    def generate_final_report(self):
        """Generate final test report"""
        print("\n" + "=" * 60)
        print("📊 FINAL TEST REPORT")
        print("=" * 60)
        
        total_tests = len(self.test_results)
        passed_tests = len([r for r in self.test_results if r['status'] == 'PASS'])
        failed_tests = len([r for r in self.test_results if r['status'] == 'FAIL'])
        
        print(f"Total Tests: {total_tests}")
        print(f"Passed: {passed_tests} ✅")
        print(f"Failed: {failed_tests} ❌")
        print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        
        if failed_tests > 0:
            print("\n❌ Failed Tests:")
            for result in self.test_results:
                if result['status'] == 'FAIL':
                    print(f"  - {result['test']}: {result['details']}")
        
        print("\n✅ All Tests Summary:")
        for result in self.test_results:
            emoji = "✅" if result['status'] == "PASS" else "❌"
            print(f"  {emoji} {result['test']}")
        
        if failed_tests == 0:
            print("\n🎉 ALL TESTS PASSED! System is ready for production!")
        else:
            print(f"\n⚠️  {failed_tests} test(s) failed. Please review and fix issues.")

async def main():
    """Run all tests"""
    print("🚀 Starting Final Comprehensive System Test")
    print("=" * 60)
    
    tester = FinalSystemTest()
    
    # Run all tests
    await tester.test_database_structure()
    await tester.test_user_settings_storage()
    await tester.test_smart_features_database()
    await tester.test_server_import()
    await tester.test_api_endpoints()
    await tester.test_user_isolation()
    
    # Generate final report
    tester.generate_final_report()

if __name__ == "__main__":
    asyncio.run(main()) 