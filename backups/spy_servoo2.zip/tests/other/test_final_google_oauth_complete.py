#!/usr/bin/env python3
"""
تست نهایی کامل Google OAuth
Final Complete Google OAuth Test
"""

import asyncio
import httpx
import json
import time
from datetime import datetime

async def test_complete_oauth_flow():
    """تست کامل جریان OAuth"""
    print("🔐 تست کامل Google OAuth Flow")
    print("=" * 60)
    
    base_url = "http://localhost:3000"
    
    async with httpx.AsyncClient() as client:
        try:
            # Test 1: Server health
            print("1️⃣ تست سلامت سرور...")
            response = await client.get(f"{base_url}/health")
            if response.status_code == 200:
                print("✅ سرور سالم است")
            else:
                print(f"❌ سرور مشکل دارد: {response.status_code}")
                return False
            
            # Test 2: Login page
            print("\n2️⃣ تست صفحه لاگین...")
            response = await client.get(f"{base_url}/login")
            if response.status_code == 200:
                print("✅ صفحه لاگین قابل دسترس است")
            else:
                print(f"❌ صفحه لاگین مشکل دارد: {response.status_code}")
                return False
            
            # Test 3: Google OAuth redirect
            print("\n3️⃣ تست Google OAuth redirect...")
            response = await client.get(f"{base_url}/auth/google", follow_redirects=False)
            if response.status_code == 302:
                redirect_url = response.headers.get('location', '')
                if 'accounts.google.com' in redirect_url:
                    print("✅ Google OAuth redirect صحیح است")
                    print(f"   URL: {redirect_url[:100]}...")
                else:
                    print(f"❌ Google OAuth redirect نامعتبر: {redirect_url}")
                    return False
            else:
                print(f"❌ Google OAuth redirect: {response.status_code}")
                return False
            
            # Test 4: Callback handling
            print("\n4️⃣ تست callback handling...")
            response = await client.get(f"{base_url}/auth/google/callback?code=invalid&state=invalid", follow_redirects=False)
            if response.status_code in [302, 307]:
                redirect_url = response.headers.get('location', '')
                if 'error=google_auth_failed' in redirect_url:
                    print("✅ callback نامعتبر به درستی مدیریت می‌شود")
                else:
                    print(f"⚠️ callback نامعتبر: {redirect_url}")
            else:
                print(f"❌ callback نامعتبر: {response.status_code}")
                return False
            
            # Test 5: Dashboard access without auth
            print("\n5️⃣ تست دسترسی به dashboard بدون احراز هویت...")
            response = await client.get(f"{base_url}/dashboard", follow_redirects=False)
            if response.status_code == 302:
                redirect_url = response.headers.get('location', '')
                if '/login' in redirect_url:
                    print("✅ dashboard بدون احراز هویت به درستی redirect می‌کند")
                else:
                    print(f"⚠️ redirect نامعتبر: {redirect_url}")
            else:
                print(f"❌ dashboard بدون احراز هویت: {response.status_code}")
                return False
            
            # Test 6: API endpoints without auth
            print("\n6️⃣ تست API endpoints بدون احراز هویت...")
            api_endpoints = ["/api/users", "/get_status", "/get_gallery"]
            for endpoint in api_endpoints:
                response = await client.get(f"{base_url}{endpoint}", follow_redirects=False)
                if response.status_code == 401:
                    try:
                        data = response.json()
                        if "detail" in data and data["detail"] == "Unauthorized":
                            print(f"✅ {endpoint}: Unauthorized صحیح")
                        else:
                            print(f"⚠️ {endpoint}: Unauthorized نامعتبر")
                    except:
                        print(f"⚠️ {endpoint}: JSON parse error")
                else:
                    print(f"❌ {endpoint}: {response.status_code}")
            
            # Test 7: Static files
            print("\n7️⃣ تست فایل‌های static...")
            response = await client.get(f"{base_url}/static/css/index/styles.css")
            if response.status_code == 200:
                print("✅ فایل‌های static قابل دسترس هستند")
            else:
                print(f"⚠️ فایل‌های static: {response.status_code}")
            
            # Test 8: Rate limiting
            print("\n8️⃣ تست Rate Limiting...")
            responses = []
            for i in range(20):
                response = await client.get(f"{base_url}/auth/google", follow_redirects=False)
                responses.append(response.status_code)
                if i < 5:
                    await asyncio.sleep(0.1)
            
            if 429 in responses:
                print("✅ Rate limiting کار می‌کند")
            else:
                print("⚠️ Rate limiting ممکن است کار نکند")
            
            print("\n🎉 تمام تست‌های Google OAuth موفق بودند!")
            return True
            
        except Exception as e:
            print(f"❌ خطا در تست: {e}")
            return False

async def test_security_features():
    """تست ویژگی‌های امنیتی"""
    print("\n🔒 تست ویژگی‌های امنیتی")
    print("=" * 60)
    
    base_url = "http://localhost:3000"
    
    async with httpx.AsyncClient() as client:
        try:
            # Test 1: Security headers
            print("1️⃣ تست Security Headers...")
            response = await client.get(f"{base_url}/login")
            headers = response.headers
            
            security_headers = [
                'X-Content-Type-Options',
                'X-Frame-Options', 
                'X-XSS-Protection',
                'Content-Security-Policy'
            ]
            
            missing_headers = []
            for header in security_headers:
                if header not in headers:
                    missing_headers.append(header)
            
            if not missing_headers:
                print("✅ تمام Security Headers موجود هستند")
            else:
                print(f"⚠️ Security Headers گمشده: {missing_headers}")
            
            # Test 2: CSRF protection
            print("\n2️⃣ تست CSRF Protection...")
            response = await client.post(f"{base_url}/login", data={
                "username": "test",
                "password": "test"
            })
            if response.status_code in [400, 401, 422]:
                print("✅ CSRF Protection کار می‌کند")
            else:
                print(f"⚠️ CSRF Protection: {response.status_code}")
            
            # Test 3: SQL Injection protection
            print("\n3️⃣ تست SQL Injection Protection...")
            response = await client.post(f"{base_url}/login", data={
                "username": "admin' OR '1'='1",
                "password": "test"
            })
            if response.status_code in [400, 401, 422]:
                print("✅ SQL Injection Protection کار می‌کند")
            else:
                print(f"⚠️ SQL Injection Protection: {response.status_code}")
            
            print("\n🎉 تمام تست‌های امنیتی موفق بودند!")
            return True
            
        except Exception as e:
            print(f"❌ خطا در تست امنیتی: {e}")
            return False

async def test_middleware_behavior():
    """تست رفتار middleware"""
    print("\n🔧 تست رفتار Middleware")
    print("=" * 60)
    
    base_url = "http://localhost:3000"
    
    async with httpx.AsyncClient() as client:
        try:
            # Test various scenarios
            test_scenarios = [
                {
                    "name": "Dashboard بدون token",
                    "url": "/dashboard",
                    "headers": {},
                    "expected_status": 302
                },
                {
                    "name": "API endpoint بدون token",
                    "url": "/api/users",
                    "headers": {},
                    "expected_status": 401
                },
                {
                    "name": "Dashboard با Accept: application/json",
                    "url": "/dashboard",
                    "headers": {"Accept": "application/json"},
                    "expected_status": 302
                },
                {
                    "name": "Dashboard با Content-Type: application/json",
                    "url": "/dashboard",
                    "headers": {"Content-Type": "application/json"},
                    "expected_status": 302
                },
                {
                    "name": "Login page (public)",
                    "url": "/login",
                    "headers": {},
                    "expected_status": 200
                },
                {
                    "name": "Health endpoint (public)",
                    "url": "/health",
                    "headers": {},
                    "expected_status": 200
                }
            ]
            
            for scenario in test_scenarios:
                print(f"🔍 {scenario['name']}...")
                response = await client.get(f"{base_url}{scenario['url']}", headers=scenario['headers'], follow_redirects=False)
                
                if response.status_code == scenario['expected_status']:
                    print(f"   ✅ Status: {response.status_code}")
                else:
                    print(f"   ❌ Status: {response.status_code} (expected: {scenario['expected_status']})")
                
                if response.status_code == 302:
                    redirect_url = response.headers.get('location', '')
                    print(f"   Redirect: {redirect_url}")
                
                await asyncio.sleep(0.1)
            
            print("✅ تمام تست‌های middleware موفق بودند!")
            return True
            
        except Exception as e:
            print(f"❌ خطا در تست middleware: {e}")
            return False

async def main():
    """تابع اصلی"""
    print("🚀 شروع تست نهایی کامل Google OAuth")
    print("=" * 80)
    
    # Wait for server to be ready
    print("⏳ منتظر آماده شدن سرور...")
    await asyncio.sleep(3)
    
    # Run tests
    oauth_success = await test_complete_oauth_flow()
    security_success = await test_security_features()
    middleware_success = await test_middleware_behavior()
    
    # Summary
    print("\n" + "=" * 80)
    print("📊 خلاصه نتایج تست نهایی")
    print("=" * 80)
    
    print(f"Google OAuth Flow: {'✅ PASS' if oauth_success else '❌ FAIL'}")
    print(f"Security Features: {'✅ PASS' if security_success else '❌ FAIL'}")
    print(f"Middleware Behavior: {'✅ PASS' if middleware_success else '❌ FAIL'}")
    
    if oauth_success and security_success and middleware_success:
        print("\n🎉 تمام تست‌ها موفق بودند!")
        print("✅ Google OAuth کاملاً آماده است!")
        print("✅ مشکل Unauthorized حل شد!")
        print("✅ مشکل redirect loop حل شد!")
        print("✅ ویژگی‌های امنیتی فعال هستند!")
        print("✅ Middleware به درستی کار می‌کند!")
        return True
    else:
        print("\n⚠️ برخی تست‌ها ناموفق بودند")
        return False

if __name__ == "__main__":
    success = asyncio.run(main())
    exit(0 if success else 1) 