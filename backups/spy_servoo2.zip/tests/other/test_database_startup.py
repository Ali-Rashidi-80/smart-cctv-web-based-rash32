#!/usr/bin/env python3
"""
Test database startup and initialization
"""

import asyncio
import aiosqlite
import os
import sys
import logging

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Set up basic logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def test_database_connection():
    """Test database connection and basic operations"""
    print("🔍 Testing database connection...")
    print("=" * 60)
    
    try:
        conn = await aiosqlite.connect("smart_camera_system.db")
        print("✅ Database connection successful")
        
        # Test basic query
        cursor = await conn.execute("SELECT sqlite_version()")
        version = await cursor.fetchone()
        print(f"✅ SQLite version: {version[0]}")
        
        await conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Database connection failed: {e}")
        return False

async def test_database_tables():
    """Test if all required tables exist"""
    print("\n📊 Testing database tables...")
    print("=" * 60)
    
    try:
        conn = await aiosqlite.connect("smart_camera_system.db")
        
        # Get all tables
        cursor = await conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = await cursor.fetchall()
        table_names = [table[0] for table in tables]
        
        print(f"📋 Found {len(table_names)} tables: {', '.join(table_names)}")
        
        required_tables = [
            'users', 'camera_logs', 'password_recovery', 'servo_commands',
            'action_commands', 'device_mode_commands', 'manual_photos',
            'security_videos', 'user_settings'
        ]
        
        print("\n🔍 Checking required tables:")
        missing_tables = []
        for table in required_tables:
            if table in table_names:
                print(f"   ✅ {table}")
            else:
                print(f"   ❌ {table} - missing")
                missing_tables.append(table)
        
        await conn.close()
        
        if missing_tables:
            print(f"\n⚠️ Missing tables: {missing_tables}")
            return False, missing_tables
        else:
            print("\n✅ All required tables exist")
            return True, []
            
    except Exception as e:
        print(f"❌ Table check failed: {e}")
        return False, []

async def test_admin_user():
    """Test if admin user exists"""
    print("\n👤 Testing admin user...")
    print("=" * 60)
    
    try:
        conn = await aiosqlite.connect("smart_camera_system.db")
        
        cursor = await conn.execute("SELECT COUNT(*) FROM users WHERE role = 'admin'")
        admin_count = await cursor.fetchone()
        
        if admin_count[0] > 0:
            print("✅ Admin user exists")
            
            # Get admin details
            cursor = await conn.execute("SELECT username, is_active, created_at FROM users WHERE role = 'admin' LIMIT 1")
            admin = await cursor.fetchone()
            if admin:
                print(f"   Username: {admin[0]}")
                print(f"   Active: {admin[1]}")
                print(f"   Created: {admin[2]}")
        else:
            print("❌ Admin user missing")
        
        await conn.close()
        return admin_count[0] > 0
        
    except Exception as e:
        print(f"❌ Admin user check failed: {e}")
        return False

async def test_camera_logs():
    """Test camera_logs table"""
    print("\n📝 Testing camera_logs table...")
    print("=" * 60)
    
    try:
        conn = await aiosqlite.connect("smart_camera_system.db")
        
        cursor = await conn.execute("SELECT COUNT(*) FROM camera_logs")
        log_count = await cursor.fetchone()
        print(f"📊 Total camera logs: {log_count[0]}")
        
        if log_count[0] > 0:
            # Get recent logs
            cursor = await conn.execute("""
                SELECT message, log_type, source, created_at 
                FROM camera_logs 
                ORDER BY created_at DESC 
                LIMIT 5
            """)
            recent_logs = await cursor.fetchall()
            
            print("\n📋 Recent logs:")
            for log in recent_logs:
                print(f"   {log[3]}: [{log[2]}] {log[1]} - {log[0][:50]}...")
        
        await conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Camera logs check failed: {e}")
        return False

async def test_startup_functions():
    """Test if startup functions can be imported"""
    print("\n🚀 Testing startup functions...")
    print("=" * 60)
    
    try:
        # Test imports
        from server_fastapi import init_db, migrate_all_tables, startup_event
        print("✅ All startup functions imported successfully")
        
        # Test init_db function
        print("🔄 Testing init_db function...")
        await init_db()
        print("✅ init_db function executed successfully")
        
        # Test migrate_all_tables function
        print("🔄 Testing migrate_all_tables function...")
        await migrate_all_tables()
        print("✅ migrate_all_tables function executed successfully")
        
        return True
        
    except Exception as e:
        print(f"❌ Startup functions test failed: {e}")
        return False

async def main():
    """Main test function"""
    print("🚀 Comprehensive Database Startup Test")
    print("=" * 60)
    
    results = {}
    
    # Test database connection
    results['connection'] = await test_database_connection()
    
    # Test tables
    results['tables_ok'], missing_tables = await test_database_tables()
    
    # Test admin user
    results['admin_ok'] = await test_admin_user()
    
    # Test camera logs
    results['logs_ok'] = await test_camera_logs()
    
    # Test startup functions
    results['startup_ok'] = await test_startup_functions()
    
    print("\n" + "=" * 60)
    print("📋 FINAL SUMMARY:")
    print("=" * 60)
    
    all_passed = all(results.values())
    
    print(f"🔗 Database Connection: {'✅ PASS' if results['connection'] else '❌ FAIL'}")
    print(f"📊 Database Tables: {'✅ PASS' if results['tables_ok'] else '❌ FAIL'}")
    print(f"👤 Admin User: {'✅ PASS' if results['admin_ok'] else '❌ FAIL'}")
    print(f"📝 Camera Logs: {'✅ PASS' if results['logs_ok'] else '❌ FAIL'}")
    print(f"🚀 Startup Functions: {'✅ PASS' if results['startup_ok'] else '❌ FAIL'}")
    
    if all_passed:
        print("\n🎉 ALL TESTS PASSED!")
        print("✅ Database is properly initialized")
        print("✅ Startup event should work correctly")
        print("✅ System is ready to run")
    else:
        print("\n⚠️ SOME TESTS FAILED!")
        if not results['connection']:
            print("💡 Database connection failed - check if database file exists")
        if not results['tables_ok']:
            print(f"💡 Missing tables: {missing_tables}")
            print("💡 Run: python reset_database.py")
        if not results['admin_ok']:
            print("💡 Admin user missing - check admin_credentials.txt")
        if not results['startup_ok']:
            print("💡 Startup functions failed - check server_fastapi.py")
        
        print("\n🔧 RECOMMENDED ACTIONS:")
        print("1. Run: python reset_database.py")
        print("2. Run: python server_fastapi.py")
        print("3. Check logs for any errors")

if __name__ == "__main__":
    asyncio.run(main()) 