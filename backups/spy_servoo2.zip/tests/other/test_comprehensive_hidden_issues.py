#!/usr/bin/env python3
"""
Comprehensive Hidden Issues Test
Identify and fix all hidden and visible problems in the server
"""

import asyncio
import aiosqlite
import json
import time
import sys
import os
from datetime import datetime
from typing import Dict, List, Any

class ComprehensiveServerTest:
    def __init__(self):
        self.results = []
        self.db_path = 'smart_camera_system.db'
        self.test_users = []
        
    async def log_test(self, test_name: str, status: str, details: str = ""):
        """Log test results"""
        emoji = "✅" if status == "PASS" else "❌"
        print(f"{emoji} {test_name}: {status}")
        if details:
            print(f"   Details: {details}")
        self.results.append((test_name, status, details))
    
    async def test_database_schema_integrity(self):
        """Test database schema integrity"""
        print("\n🔍 Testing Database Schema Integrity")
        print("-" * 40)
        
        try:
            conn = await aiosqlite.connect(self.db_path)
            
            # Check if user_settings table exists and has correct columns
            cursor = await conn.execute("PRAGMA table_info(user_settings)")
            columns = await cursor.fetchall()
            
            required_columns = {
                'username': 'TEXT',
                'ip': 'TEXT', 
                'theme': 'TEXT',
                'language': 'TEXT',
                'servo1': 'INTEGER',
                'servo2': 'INTEGER',
                'device_mode': 'TEXT',
                'photo_quality': 'INTEGER',
                'smart_motion': 'BOOLEAN',
                'smart_tracking': 'BOOLEAN',
                'stream_enabled': 'BOOLEAN',
                'flash_settings': 'TEXT',
                'updated_at': 'TEXT'
            }
            
            found_columns = {col[1]: col[2] for col in columns}
            missing_columns = []
            
            for col_name, col_type in required_columns.items():
                if col_name not in found_columns:
                    missing_columns.append(col_name)
            
            if missing_columns:
                await self.log_test("Database Schema", "FAIL", f"Missing columns: {missing_columns}")
            else:
                await self.log_test("Database Schema", "PASS", "All required columns present")
            
            await conn.close()
            
        except Exception as e:
            await self.log_test("Database Schema", "FAIL", f"Error: {e}")
    
    async def test_data_validation_edge_cases(self):
        """Test edge cases in data validation"""
        print("\n🔍 Testing Data Validation Edge Cases")
        print("-" * 40)
        
        try:
            conn = await aiosqlite.connect(self.db_path)
            
            # Test extreme values
            test_cases = [
                {
                    'name': 'Extreme Servo Values',
                    'data': {'servo1': 999, 'servo2': -999},
                    'expected': {'servo1': 180, 'servo2': 0}
                },
                {
                    'name': 'Invalid Theme',
                    'data': {'theme': 'invalid_theme_123'},
                    'expected': {'theme': 'light'}
                },
                {
                    'name': 'Invalid Language',
                    'data': {'language': 'xyz'},
                    'expected': {'language': 'fa'}
                },
                {
                    'name': 'Invalid Device Mode',
                    'data': {'device_mode': 'tablet'},
                    'expected': {'device_mode': 'desktop'}
                },
                {
                    'name': 'Invalid Photo Quality',
                    'data': {'photo_quality': 999},
                    'expected': {'photo_quality': 100}
                }
            ]
            
            for test_case in test_cases:
                test_user = f"test_edge_{test_case['name'].lower().replace(' ', '_')}"
                self.test_users.append(test_user)
                
                # Insert test data
                await conn.execute('''
                    INSERT OR REPLACE INTO user_settings 
                    (username, ip, theme, language, servo1, servo2, device_mode, photo_quality, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    test_user, '127.0.0.1',
                    test_case['data'].get('theme', 'light'),
                    test_case['data'].get('language', 'fa'),
                    test_case['data'].get('servo1', 90),
                    test_case['data'].get('servo2', 90),
                    test_case['data'].get('device_mode', 'desktop'),
                    test_case['data'].get('photo_quality', 80),
                    datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                ))
                await conn.commit()
                
                # Retrieve and validate
                cursor = await conn.execute('''
                    SELECT theme, language, servo1, servo2, device_mode, photo_quality
                    FROM user_settings WHERE username = ?
                ''', (test_user,))
                result = await cursor.fetchone()
                
                if result:
                    # Check if values are within expected ranges
                    theme, language, servo1, servo2, device_mode, photo_quality = result
                    
                    valid = True
                    if servo1 < 0 or servo1 > 180:
                        valid = False
                    if servo2 < 0 or servo2 > 180:
                        valid = False
                    if theme not in ['light', 'dark']:
                        valid = False
                    if language not in ['fa', 'en']:
                        valid = False
                    if device_mode not in ['desktop', 'mobile']:
                        valid = False
                    if photo_quality < 1 or photo_quality > 100:
                        valid = False
                    
                    if valid:
                        await self.log_test(f"Edge Case: {test_case['name']}", "PASS")
                    else:
                        await self.log_test(f"Edge Case: {test_case['name']}", "FAIL", 
                                          f"Invalid values: theme={theme}, language={language}, servo1={servo1}, servo2={servo2}, device_mode={device_mode}, photo_quality={photo_quality}")
                else:
                    await self.log_test(f"Edge Case: {test_case['name']}", "FAIL", "No data retrieved")
            
            await conn.close()
            
        except Exception as e:
            await self.log_test("Data Validation Edge Cases", "FAIL", f"Error: {e}")
    
    async def test_concurrent_access_simulation(self):
        """Test concurrent database access"""
        print("\n🔍 Testing Concurrent Access Simulation")
        print("-" * 40)
        
        try:
            # Simulate multiple concurrent operations
            async def concurrent_operation(user_id: int):
                conn = await aiosqlite.connect(self.db_path)
                try:
                    async with conn:
                        await conn.execute('''
                            INSERT OR REPLACE INTO user_settings 
                            (username, ip, theme, language, updated_at)
                            VALUES (?, ?, ?, ?, ?)
                        ''', (f'concurrent_user_{user_id}', '127.0.0.1', 'dark', 'en', 
                              datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
                        
                        # Simulate some processing time
                        await asyncio.sleep(0.1)
                        
                        # Read back the data
                        cursor = await conn.execute('''
                            SELECT username FROM user_settings WHERE username = ?
                        ''', (f'concurrent_user_{user_id}',))
                        result = await cursor.fetchone()
                        
                        if result:
                            self.test_users.append(f'concurrent_user_{user_id}')
                            return True
                        return False
                finally:
                    await conn.close()
            
            # Run 10 concurrent operations
            tasks = [concurrent_operation(i) for i in range(10)]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            success_count = sum(1 for r in results if r is True)
            error_count = sum(1 for r in results if isinstance(r, Exception))
            
            if success_count == 10 and error_count == 0:
                await self.log_test("Concurrent Access", "PASS", f"All {success_count} operations successful")
            else:
                await self.log_test("Concurrent Access", "FAIL", 
                                  f"Success: {success_count}, Errors: {error_count}")
            
        except Exception as e:
            await self.log_test("Concurrent Access", "FAIL", f"Error: {e}")
    
    async def test_memory_leaks_and_connections(self):
        """Test for memory leaks and connection issues"""
        print("\n🔍 Testing Memory Leaks and Connections")
        print("-" * 40)
        
        try:
            # Test multiple connection creation and cleanup
            connections = []
            for i in range(20):
                conn = await aiosqlite.connect(self.db_path)
                connections.append(conn)
                
                # Perform some operations
                await conn.execute('''
                    INSERT OR REPLACE INTO user_settings 
                    (username, ip, theme, updated_at)
                    VALUES (?, ?, ?, ?)
                ''', (f'memory_test_{i}', '127.0.0.1', 'light', 
                      datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
                await conn.commit()
                
                self.test_users.append(f'memory_test_{i}')
            
            # Close all connections
            for conn in connections:
                await conn.close()
            
            # Try to create new connections to ensure cleanup worked
            new_conn = await aiosqlite.connect(self.db_path)
            await new_conn.execute("SELECT 1")
            await new_conn.close()
            
            await self.log_test("Memory Leaks", "PASS", "All connections properly closed")
            
        except Exception as e:
            await self.log_test("Memory Leaks", "FAIL", f"Error: {e}")
    
    async def test_error_recovery_scenarios(self):
        """Test various error recovery scenarios"""
        print("\n🔍 Testing Error Recovery Scenarios")
        print("-" * 40)
        
        try:
            conn = await aiosqlite.connect(self.db_path)
            
            # Test 1: Invalid JSON in flash_settings
            test_user = "test_error_recovery"
            self.test_users.append(test_user)
            
            invalid_json = "{invalid: json, data}"
            await conn.execute('''
                INSERT OR REPLACE INTO user_settings 
                (username, ip, flash_settings, updated_at)
                VALUES (?, ?, ?, ?)
            ''', (test_user, '127.0.0.1', invalid_json, 
                  datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            await conn.commit()
            
            # Try to retrieve and validate
            cursor = await conn.execute('''
                SELECT flash_settings FROM user_settings WHERE username = ?
            ''', (test_user,))
            result = await cursor.fetchone()
            
            if result:
                flash_settings = result[0]
                try:
                    json.loads(flash_settings)
                    await self.log_test("Invalid JSON Recovery", "PASS")
                except json.JSONDecodeError:
                    await self.log_test("Invalid JSON Recovery", "FAIL", "JSON validation failed")
            else:
                await self.log_test("Invalid JSON Recovery", "FAIL", "No data retrieved")
            
            # Test 2: Null values handling
            await conn.execute('''
                INSERT OR REPLACE INTO user_settings 
                (username, ip, theme, language, servo1, servo2, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (test_user, '127.0.0.1', None, None, None, None, 
                  datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            await conn.commit()
            
            cursor = await conn.execute('''
                SELECT theme, language, servo1, servo2 FROM user_settings WHERE username = ?
            ''', (test_user,))
            result = await cursor.fetchone()
            
            if result:
                theme, language, servo1, servo2 = result
                if theme is None and language is None and servo1 is None and servo2 is None:
                    await self.log_test("Null Values Handling", "PASS")
                else:
                    await self.log_test("Null Values Handling", "FAIL", 
                                      f"Unexpected values: {result}")
            else:
                await self.log_test("Null Values Handling", "FAIL", "No data retrieved")
            
            await conn.close()
            
        except Exception as e:
            await self.log_test("Error Recovery", "FAIL", f"Error: {e}")
    
    async def test_performance_under_load(self):
        """Test performance under load"""
        print("\n🔍 Testing Performance Under Load")
        print("-" * 40)
        
        try:
            start_time = time.time()
            
            # Perform 100 rapid operations
            conn = await aiosqlite.connect(self.db_path)
            for i in range(100):
                await conn.execute('''
                    INSERT OR REPLACE INTO user_settings 
                    (username, ip, theme, language, updated_at)
                    VALUES (?, ?, ?, ?, ?)
                ''', (f'perf_test_{i}', '127.0.0.1', 'light', 'fa', 
                      datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
                await conn.commit()
                self.test_users.append(f'perf_test_{i}')
            
            await conn.close()
            
            end_time = time.time()
            duration = end_time - start_time
            
            if duration < 5.0:  # Should complete within 5 seconds
                await self.log_test("Performance Under Load", "PASS", 
                                  f"Completed 100 operations in {duration:.2f}s")
            else:
                await self.log_test("Performance Under Load", "FAIL", 
                                  f"Too slow: {duration:.2f}s for 100 operations")
            
        except Exception as e:
            await self.log_test("Performance Under Load", "FAIL", f"Error: {e}")
    
    async def cleanup_test_data(self):
        """Clean up all test data"""
        print("\n🧹 Cleaning up test data...")
        
        try:
            conn = await aiosqlite.connect(self.db_path)
            
            for user in self.test_users:
                await conn.execute('DELETE FROM user_settings WHERE username = ?', (user,))
            
            await conn.commit()
            await conn.close()
            
            print(f"✅ Cleaned up {len(self.test_users)} test records")
            
        except Exception as e:
            print(f"❌ Cleanup failed: {e}")
    
    async def generate_comprehensive_report(self):
        """Generate comprehensive test report"""
        print("\n" + "=" * 60)
        print("📊 COMPREHENSIVE SERVER ISSUES TEST REPORT")
        print("=" * 60)
        
        total_tests = len(self.results)
        passed_tests = len([r for r in self.results if r[1] == 'PASS'])
        failed_tests = len([r for r in self.results if r[1] == 'FAIL'])
        
        print(f"Total Tests: {total_tests}")
        print(f"Passed: {passed_tests} ✅")
        print(f"Failed: {failed_tests} ❌")
        print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        
        print("\n📋 Detailed Results:")
        for test_name, status, details in self.results:
            emoji = "✅" if status == "PASS" else "❌"
            print(f"  {emoji} {test_name}: {status}")
            if details:
                print(f"     └─ {details}")
        
        if failed_tests == 0:
            print("\n🎉 ALL TESTS PASSED! SERVER IS ROBUST AND READY!")
            print("✅ No hidden issues found")
            print("✅ No visible issues found")
            print("✅ All edge cases handled")
            print("✅ Performance is optimal")
            print("🚀 Server is production-ready!")
        else:
            print(f"\n⚠️  {failed_tests} issue(s) need attention:")
            for test_name, status, details in self.results:
                if status == "FAIL":
                    print(f"  ❌ {test_name}: {details}")
        
        return failed_tests == 0

async def main():
    """Run comprehensive server test"""
    print("🚀 Starting Comprehensive Hidden Issues Test")
    print("=" * 60)
    
    tester = ComprehensiveServerTest()
    
    try:
        # Run all tests
        await tester.test_database_schema_integrity()
        await tester.test_data_validation_edge_cases()
        await tester.test_concurrent_access_simulation()
        await tester.test_memory_leaks_and_connections()
        await tester.test_error_recovery_scenarios()
        await tester.test_performance_under_load()
        
        # Generate report
        success = await tester.generate_comprehensive_report()
        
        # Cleanup
        await tester.cleanup_test_data()
        
        return success
        
    except Exception as e:
        print(f"❌ Test suite failed: {e}")
        await tester.cleanup_test_data()
        return False

if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1) 