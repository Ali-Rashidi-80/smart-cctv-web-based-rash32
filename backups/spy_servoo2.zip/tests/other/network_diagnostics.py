#!/usr/bin/env python3
"""
Network diagnostics script for external server connectivity
"""

import socket
import requests
import subprocess
import sys
import time

def check_dns_resolution():
    """Check DNS resolution for the external domain"""
    print("🔍 Checking DNS resolution...")
    
    try:
        hostname = "services.gen6.chabokan.net"
        ip = socket.gethostbyname(hostname)
        print(f"✅ DNS resolution: {hostname} -> {ip}")
        return ip
    except socket.gaierror as e:
        print(f"❌ DNS resolution failed: {e}")
        return None

def check_port_connectivity(host, port):
    """Check if a port is reachable"""
    print(f"🔍 Checking port {port} connectivity to {host}...")
    
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(10)
        result = sock.connect_ex((host, port))
        sock.close()
        
        if result == 0:
            print(f"✅ Port {port} is open and reachable")
            return True
        else:
            print(f"❌ Port {port} is not reachable (error code: {result})")
            return False
    except Exception as e:
        print(f"❌ Port connectivity test failed: {e}")
        return False

def check_http_endpoints(host, port):
    """Check HTTP endpoints"""
    base_url = f"http://{host}:{port}"
    
    print(f"🔍 Checking HTTP endpoints on {base_url}...")
    
    endpoints = [
        ("/health", "Health check"),
        ("/public/tokens", "Public tokens"),
        ("/ports", "Ports info"),
        ("/devices/status", "Devices status")
    ]
    
    results = {}
    
    for endpoint, description in endpoints:
        try:
            url = f"{base_url}{endpoint}"
            print(f"   Testing {description} ({endpoint})...")
            
            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                print(f"   ✅ {description}: OK (200)")
                results[endpoint] = True
            else:
                print(f"   ⚠️ {description}: Status {response.status_code}")
                results[endpoint] = False
                
        except requests.exceptions.ConnectionError:
            print(f"   ❌ {description}: Connection failed")
            results[endpoint] = False
        except requests.exceptions.Timeout:
            print(f"   ⏰ {description}: Timeout")
            results[endpoint] = False
        except Exception as e:
            print(f"   ❌ {description}: Error - {e}")
            results[endpoint] = False
    
    return results

def check_local_server():
    """Check if local server is running"""
    print("🔍 Checking local server...")
    
    try:
        response = requests.get("http://localhost:3000/health", timeout=5)
        if response.status_code == 200:
            print("✅ Local server is running on port 3000")
            return True
        else:
            print(f"⚠️ Local server responded with status: {response.status_code}")
            return False
    except:
        print("❌ Local server is not running on port 3000")
        return False

def check_firewall():
    """Check firewall status (Windows)"""
    print("🔍 Checking firewall status...")
    
    try:
        # Check Windows Firewall status
        result = subprocess.run(
            ["netsh", "advfirewall", "show", "allprofiles", "state"], 
            capture_output=True, 
            text=True, 
            timeout=10
        )
        
        if result.returncode == 0:
            print("✅ Firewall status check completed")
            if "ON" in result.stdout:
                print("⚠️ Firewall is ON - may block external connections")
            else:
                print("✅ Firewall is OFF")
        else:
            print("⚠️ Could not check firewall status")
            
    except Exception as e:
        print(f"⚠️ Firewall check failed: {e}")

def test_websocket_connection(host, port):
    """Test WebSocket connection"""
    print(f"🔍 Testing WebSocket connection to {host}:{port}...")
    
    try:
        import websockets
        import asyncio
        import json
        
        async def test_ws():
            try:
                uri = f"ws://{host}:{port}/ws/pico"
                async with websockets.connect(uri, timeout=10) as websocket:
                    print("✅ WebSocket connection successful")
                    
                    # Send a test message
                    test_msg = {"type": "ping"}
                    await websocket.send(json.dumps(test_msg))
                    print("📤 Sent ping message")
                    
                    # Wait for response
                    try:
                        response = await asyncio.wait_for(websocket.recv(), timeout=5)
                        print(f"📥 Received response: {response}")
                        return True
                    except asyncio.TimeoutError:
                        print("⚠️ No response received")
                        return False
                        
            except Exception as e:
                print(f"❌ WebSocket connection failed: {e}")
                return False
        
        return asyncio.run(test_ws())
        
    except ImportError:
        print("⚠️ websockets library not available - skipping WebSocket test")
        return None
    except Exception as e:
        print(f"❌ WebSocket test failed: {e}")
        return False

def generate_report(host, port, results):
    """Generate diagnostic report"""
    print("\n" + "="*60)
    print("📊 NETWORK DIAGNOSTICS REPORT")
    print("="*60)
    
    print(f"Target: {host}:{port}")
    print(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    
    print("\n🔍 Connectivity Summary:")
    if results.get('dns_resolved'):
        print("✅ DNS resolution: Working")
    else:
        print("❌ DNS resolution: Failed")
    
    if results.get('port_open'):
        print("✅ Port connectivity: Working")
    else:
        print("❌ Port connectivity: Failed")
    
    print("\n🌐 HTTP Endpoints:")
    for endpoint, working in results.get('http_endpoints', {}).items():
        status = "✅ Working" if working else "❌ Failed"
        print(f"   {endpoint}: {status}")
    
    if results.get('websocket_test') is not None:
        ws_status = "✅ Working" if results['websocket_test'] else "❌ Failed"
        print(f"\n🔌 WebSocket: {ws_status}")
    
    print("\n💡 Recommendations:")
    
    if not results.get('dns_resolved'):
        print("   1. Check DNS configuration")
        print("   2. Verify domain name is correct")
    
    if not results.get('port_open'):
        print("   1. Ensure server is running on the target port")
        print("   2. Check firewall settings")
        print("   3. Verify network connectivity")
    
    if not results.get('local_server'):
        print("   1. Start the local server first")
        print("   2. Use: python start_external_server_simple.py")
    
    print("\n🔧 Next Steps:")
    print("   1. If local server is not running, start it")
    print("   2. If external server is not accessible, check server configuration")
    print("   3. Test with: python test_external_websocket.py")

def main():
    """Main diagnostic function"""
    print("🌐 Network Diagnostics for External Server")
    print("="*50)
    
    host = "services.gen6.chabokan.net"
    port = 6970
    
    results = {}
    
    # Step 1: Check DNS
    ip = check_dns_resolution()
    results['dns_resolved'] = ip is not None
    
    if not ip:
        print("\n❌ Cannot resolve domain name. Stopping diagnostics.")
        return False
    
    # Step 2: Check port connectivity
    results['port_open'] = check_port_connectivity(ip, port)
    
    # Step 3: Check HTTP endpoints
    results['http_endpoints'] = check_http_endpoints(host, port)
    
    # Step 4: Check local server
    results['local_server'] = check_local_server()
    
    # Step 5: Check firewall
    check_firewall()
    
    # Step 6: Test WebSocket (if port is open)
    if results['port_open']:
        results['websocket_test'] = test_websocket_connection(host, port)
    
    # Generate report
    generate_report(host, port, results)
    
    return True

if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n⏹️ Diagnostics interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n💥 Unexpected error: {e}")
        sys.exit(1) 