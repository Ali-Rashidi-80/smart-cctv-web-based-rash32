#!/usr/bin/env python3
"""
🔍 Direct Token Test
Tests the token validation directly against the server
"""

import requests
import json

# Test configuration
SERVER_URL = "http://localhost:3000"

def test_token_validation():
    """Test token validation directly"""
    print("🔍 Testing Token Validation Directly...")
    print("=" * 50)
    
    # Test the exact token that should work
    test_token = "rof642fr:5\0EKU@A@Tv"
    print(f"🔑 Testing token: '{test_token}'")
    
    # Try to connect to the WebSocket endpoint via HTTP upgrade
    headers = {
        "Authorization": f"Bearer {test_token}",
        "Upgrade": "websocket",
        "Connection": "Upgrade",
        "Sec-WebSocket-Key": "dGhlIHNhbXBsZSBub25jZQ==",
        "Sec-WebSocket-Version": "13"
    }
    
    try:
        response = requests.get(f"{SERVER_URL}/ws/pico", headers=headers, timeout=5)
        print(f"📡 Response status: {response.status_code}")
        print(f"📡 Response headers: {dict(response.headers)}")
        
        if response.status_code == 101:
            print("✅ WebSocket upgrade successful!")
        elif response.status_code == 403:
            print("❌ WebSocket upgrade failed - 403 Forbidden")
            print("🔍 This suggests the token is being rejected")
        else:
            print(f"⚠️ Unexpected status code: {response.status_code}")
            
    except Exception as e:
        print(f"❌ Request failed: {e}")
    
    print("\n" + "=" * 50)

if __name__ == "__main__":
    test_token_validation() 