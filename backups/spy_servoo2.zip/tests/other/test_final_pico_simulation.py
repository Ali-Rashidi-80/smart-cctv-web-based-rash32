#!/usr/bin/env python3
"""
تست نهایی شبیه‌سازی کامل پیکو
"""

import asyncio
import websockets
import json
import time
from datetime import datetime

# تنظیمات
SERVER_HOST = "localhost"
SERVER_PORT = 3000
PICO_WS_URL = f"ws://{SERVER_HOST}:{SERVER_PORT}/ws/pico"
AUTH_TOKEN = "rof642fr:5qEKU@A@Tv"

class PicoSimulator:
    def __init__(self):
        self.servo1_angle = 90
        self.servo2_angle = 90
        self.connected = False
        self.message_count = 0
        
    def log(self, message):
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        print(f"[{timestamp}] PICO: {message}")
        
    async def simulate_pico(self):
        """شبیه‌سازی کامل رفتار پیکو"""
        self.log("🚀 شروع شبیه‌سازی پیکو")
        
        headers = {"Authorization": f"Bearer {AUTH_TOKEN}"}
        
        try:
            async with websockets.connect(PICO_WS_URL, extra_headers=headers) as websocket:
                self.log("✅ اتصال WebSocket موفق")
                self.connected = True
                
                # ارسال پیام اولیه
                initial_message = {
                    "type": "connect",
                    "device": "pico",
                    "timestamp": datetime.now().isoformat(),
                    "version": "1.0",
                    "servo1_angle": self.servo1_angle,
                    "servo2_angle": self.servo2_angle,
                    "auth_token": AUTH_TOKEN[:10] + "..."
                }
                await websocket.send(json.dumps(initial_message))
                self.log("📤 پیام اولیه ارسال شد")
                
                # حلقه اصلی شبیه‌سازی
                start_time = time.time()
                last_ping = time.time()
                
                while time.time() - start_time < 60:  # 60 ثانیه تست
                    try:
                        current_time = time.time()
                        
                        # ارسال ping هر 15 ثانیه
                        if current_time - last_ping > 15:
                            ping_message = {"type": "ping", "timestamp": datetime.now().isoformat()}
                            await websocket.send(json.dumps(ping_message))
                            last_ping = current_time
                            self.log("📤 Ping ارسال شد")
                        
                        # دریافت پیام از سرور
                        try:
                            message = await asyncio.wait_for(websocket.recv(), timeout=5.0)
                            self.message_count += 1
                            self.log(f"📥 پیام {self.message_count}: {message}")
                            
                            data = json.loads(message)
                            
                            if data.get("type") == "connection":
                                self.log("✅ پیام تایید اتصال دریافت شد")
                                
                            elif data.get("type") == "connection_ack":
                                self.log("✅ پیام تایید اتصال اولیه دریافت شد")
                                
                            elif data.get("type") == "pong":
                                self.log("📥 Pong از سرور دریافت شد")
                                
                            elif data.get("type") == "servo":
                                # پردازش دستور سروو
                                servo_cmd = data.get("command", {})
                                self.servo1_angle = servo_cmd.get("servo1", self.servo1_angle)
                                self.servo2_angle = servo_cmd.get("servo2", self.servo2_angle)
                                
                                self.log(f"🎛️ دستور سروو دریافت شد: servo1={self.servo1_angle}, servo2={self.servo2_angle}")
                                
                                # ارسال ACK
                                ack_message = {
                                    "type": "ack",
                                    "command_type": "servo",
                                    "status": "success",
                                    "servo1": self.servo1_angle,
                                    "servo2": self.servo2_angle,
                                    "timestamp": datetime.now().isoformat()
                                }
                                await websocket.send(json.dumps(ack_message))
                                self.log("📤 ACK سروو ارسال شد")
                                
                            elif data.get("type") == "action":
                                # پردازش دستور اکشن
                                action_cmd = data.get("command", {})
                                action = action_cmd.get("action", "")
                                intensity = action_cmd.get("intensity", 50)
                                
                                self.log(f"⚡ دستور اکشن دریافت شد: {action} (شدت: {intensity})")
                                
                                # ارسال ACK
                                ack_message = {
                                    "type": "ack",
                                    "command_type": "action",
                                    "status": "success",
                                    "action": action,
                                    "intensity": intensity,
                                    "timestamp": datetime.now().isoformat()
                                }
                                await websocket.send(json.dumps(ack_message))
                                self.log("📤 ACK اکشن ارسال شد")
                                
                            elif data.get("type") == "error":
                                self.log(f"❌ خطا از سرور: {data.get('message')}")
                                
                            else:
                                self.log(f"⚠️ پیام ناشناخته: {data.get('type')}")
                                
                        except asyncio.TimeoutError:
                            # timeout طبیعی - ادامه حلقه
                            continue
                            
                    except Exception as e:
                        self.log(f"❌ خطا در حلقه اصلی: {e}")
                        break
                        
                self.log(f"✅ شبیه‌سازی کامل شد. {self.message_count} پیام تبادل شد.")
                
        except Exception as e:
            self.log(f"❌ خطا در شبیه‌سازی: {e}")
            
    def print_summary(self):
        """چاپ خلاصه نتایج"""
        self.log("=== خلاصه شبیه‌سازی ===")
        self.log(f"اتصال: {'✅ موفق' if self.connected else '❌ ناموفق'}")
        self.log(f"تعداد پیام‌ها: {self.message_count}")
        self.log(f"زاویه سروو 1: {self.servo1_angle}°")
        self.log(f"زاویه سروو 2: {self.servo2_angle}°")

async def main():
    """تابع اصلی"""
    simulator = PicoSimulator()
    await simulator.simulate_pico()
    simulator.print_summary()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n⏹️ شبیه‌سازی توسط کاربر متوقف شد")
    except Exception as e:
        print(f"❌ خطای غیرمنتظره: {e}") 