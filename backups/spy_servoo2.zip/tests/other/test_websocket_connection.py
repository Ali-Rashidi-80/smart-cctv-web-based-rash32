#!/usr/bin/env python3
"""
Test WebSocket Connection
"""

import asyncio
import json
import time
import websockets
import requests

WS_URL = "ws://localhost:3000/ws/pico"
AUTH_TOKEN = "rof642fr:5qEKU@A@Tv"
BASE_URL = "http://localhost:3000"

async def test_websocket_connection():
    """Test WebSocket connection and status update"""
    print("🔍 Test WebSocket Connection")
    print("=" * 40)
    
    # Create session and login
    session = requests.Session()
    login_data = {
        "username": "rof642fr",
        "password": "5qEKU@A@Tv"
    }
    
    try:
        response = session.post(f"{BASE_URL}/login", json=login_data, timeout=5)
        if response.status_code != 200:
            print("❌ Login failed")
            return False
        print("✅ Login successful")
    except Exception as e:
        print(f"❌ Login error: {e}")
        return False
    
    # Check initial status
    print("\n1️⃣ Initial status...")
    try:
        response = session.get(f"{BASE_URL}/get_status", timeout=5)
        if response.status_code == 200:
            data = response.json()
            initial_status = data.get("data", {}).get("pico_status", "unknown")
            print(f"   Initial Pico status: {initial_status}")
        else:
            print(f"   ❌ Failed to get status: {response.status_code}")
            return False
    except Exception as e:
        print(f"   ❌ Error getting status: {e}")
        return False
    
    # Connect WebSocket
    print("\n2️⃣ Connecting WebSocket...")
    try:
        headers = {"Authorization": f"Bearer {AUTH_TOKEN}"}
        async with websockets.connect(WS_URL, extra_headers=headers) as websocket:
            print("   ✅ WebSocket connected")
            
            # Send connection message
            await websocket.send(json.dumps({
                "type": "connect",
                "device": "pico",
                "version": "1.0"
            }))
            
            # Wait for connection ack
            try:
                response = await asyncio.wait_for(websocket.recv(), timeout=2.0)
                data = json.loads(response)
                if data.get("type") == "connection_ack":
                    print("   ✅ Connection acknowledged")
                else:
                    print(f"   ⚠️ Unexpected response: {data.get('type')}")
            except asyncio.TimeoutError:
                print("   ⚠️ No connection ack received")
            
            # Wait for status to update
            print("\n3️⃣ Waiting for status update...")
            await asyncio.sleep(2)
            
            # Check status multiple times
            for i in range(3):
                try:
                    response = session.get(f"{BASE_URL}/get_status", timeout=5)
                    if response.status_code == 200:
                        data = response.json()
                        connected_status = data.get("data", {}).get("pico_status", "unknown")
                        last_seen = data.get("data", {}).get("pico_last_seen", "unknown")
                        print(f"   Check {i+1}: status={connected_status}, last_seen={last_seen}")
                        
                        if connected_status == "online":
                            print("   ✅ Status correctly shows ONLINE!")
                            return True
                    else:
                        print(f"   ❌ Failed to get status: {response.status_code}")
                except Exception as e:
                    print(f"   ❌ Error getting status: {e}")
                
                await asyncio.sleep(1)
            
            print("   ❌ Status never showed ONLINE")
            return False
                
    except Exception as e:
        print(f"   ❌ Error connecting WebSocket: {e}")
        return False

async def main():
    print("🚀 WebSocket Connection Test")
    print("Testing if WebSocket connection updates system state...")
    print()
    
    success = await test_websocket_connection()
    
    print()
    if success:
        print("🎉 WEBSOCKET CONNECTION WORKS!")
        print("✅ WebSocket connects successfully")
        print("✅ System state updates correctly")
        print("✅ Status shows ONLINE when connected")
    else:
        print("⚠️ WEBSOCKET CONNECTION HAS ISSUES")
        print("❌ System state not updating properly")
    
    print("\n🏁 Test completed!")

if __name__ == "__main__":
    asyncio.run(main()) 