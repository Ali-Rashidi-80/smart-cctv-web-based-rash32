#!/usr/bin/env python3
"""
تست نهایی ساده برای تایید عملکرد سیستم
Simple Final Verification Test
"""

import sys
import os
import asyncio
from datetime import datetime

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from server_fastapi import (
    init_db, 
    sanitize_input,
    create_access_token,
    verify_token,
    hash_password,
    verify_password,
    check_rate_limit,
    check_login_attempts
)

async def main():
    """تابع اصلی"""
    print("🔧 تست نهایی ساده")
    print("=" * 50)
    
    # راه‌اندازی دیتابیس
    try:
        await init_db()
        print("✅ دیتابیس راه‌اندازی شد")
    except Exception as e:
        print(f"❌ خطا در راه‌اندازی دیتابیس: {e}")
        return False
    
    # تست‌های اصلی
    tests_passed = 0
    total_tests = 0
    
    # تست 1: Password Hashing
    total_tests += 1
    try:
        password = "test123"
        hashed = hash_password(password)
        if verify_password(password, hashed):
            print("✅ Password Hashing: OK")
            tests_passed += 1
        else:
            print("❌ Password Hashing: FAILED")
    except Exception as e:
        print(f"❌ Password Hashing: ERROR - {e}")
    
    # تست 2: JWT Token
    total_tests += 1
    try:
        token_data = {"sub": "testuser", "role": "user"}
        token = create_access_token(data=token_data)
        decoded = verify_token(token)
        if decoded and decoded.get("sub") == "testuser":
            print("✅ JWT Token: OK")
            tests_passed += 1
        else:
            print("❌ JWT Token: FAILED")
    except Exception as e:
        print(f"❌ JWT Token: ERROR - {e}")
    
    # تست 3: Input Sanitization
    total_tests += 1
    try:
        test_input = "admin' OR '1'='1"
        sanitized = sanitize_input(test_input)
        if sanitized != test_input:
            print("✅ Input Sanitization: OK")
            tests_passed += 1
        else:
            print("❌ Input Sanitization: FAILED")
    except Exception as e:
        print(f"❌ Input Sanitization: ERROR - {e}")
    
    # تست 4: Rate Limiting
    total_tests += 1
    try:
        test_ip = "192.168.1.100"
        # تست 10 درخواست اول
        for i in range(10):
            result = check_rate_limit(test_ip)
            if not result:
                print(f"❌ Rate Limiting: Blocked too early at request {i+1}")
                break
        else:
            # تست درخواست 11 (باید مسدود شود)
            result = check_rate_limit(test_ip)
            if not result:
                print("✅ Rate Limiting: OK")
                tests_passed += 1
            else:
                print("❌ Rate Limiting: Not blocked when should be")
    except Exception as e:
        print(f"❌ Rate Limiting: ERROR - {e}")
    
    # تست 5: Login Attempts
    total_tests += 1
    try:
        test_ip = "192.168.1.200"
        # تست 5 تلاش اول
        for i in range(5):
            result = check_login_attempts(test_ip)
            if not result:
                print(f"❌ Login Attempts: Blocked too early at attempt {i+1}")
                break
        else:
            # تست تلاش 6 (باید مسدود شود)
            result = check_login_attempts(test_ip)
            if not result:
                print("✅ Login Attempts: OK")
                tests_passed += 1
            else:
                print("❌ Login Attempts: Not blocked when should be")
    except Exception as e:
        print(f"❌ Login Attempts: ERROR - {e}")
    
    # گزارش نهایی
    print("\n" + "=" * 50)
    print("📊 گزارش نهایی")
    print("=" * 50)
    print(f"تست‌های موفق: {tests_passed}/{total_tests}")
    print(f"نرخ موفقیت: {(tests_passed/total_tests)*100:.1f}%")
    
    if tests_passed == total_tests:
        print("🎉 تمام تست‌ها موفق بودند!")
        print("✅ سیستم آماده است!")
        return True
    else:
        print("⚠️ برخی تست‌ها ناموفق بودند")
        return False

if __name__ == "__main__":
    asyncio.run(main()) 