#!/usr/bin/env python3
"""
تست فوق عمیق و جامع سیستم
Comprehensive Deep System Test
"""

import asyncio
import aiohttp
import json
import time
import sys
import os
from datetime import datetime
from typing import Dict, List, Any

class ComprehensiveSystemTest:
    def __init__(self):
        self.base_url = "http://localhost:3000"
        self.session = None
        self.test_results = []
        self.start_time = time.time()
        
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    def log_test(self, test_name: str, status: str, details: str = "", duration: float = 0):
        """Log test result with timestamp"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        result = {
            "timestamp": timestamp,
            "test": test_name,
            "status": status,
            "details": details,
            "duration": f"{duration:.3f}s"
        }
        self.test_results.append(result)
        
        # Color coding for console output
        status_colors = {
            "PASS": "\033[92m",  # Green
            "FAIL": "\033[91m",  # Red
            "WARN": "\033[93m",  # Yellow
            "INFO": "\033[94m"   # Blue
        }
        
        color = status_colors.get(status, "\033[0m")
        reset = "\033[0m"
        
        print(f"{color}[{timestamp}] {status}{reset} {test_name} ({duration:.3f}s)")
        if details:
            print(f"    {details}")
    
    async def test_server_health(self) -> bool:
        """Test 1: Server Health Check"""
        start_time = time.time()
        try:
            async with self.session.get(f"{self.base_url}/health") as response:
                duration = time.time() - start_time
                if response.status == 200:
                    data = await response.json()
                    self.log_test("Server Health", "PASS", f"Status: {data.get('status')}", duration)
                    return True
                else:
                    self.log_test("Server Health", "FAIL", f"Status: {response.status}", duration)
                    return False
        except Exception as e:
            duration = time.time() - start_time
            self.log_test("Server Health", "FAIL", f"Error: {str(e)}", duration)
            return False
    
    async def test_public_endpoints(self) -> bool:
        """Test 2: Public Endpoints Accessibility"""
        public_endpoints = [
            "/health",
            "/esp32cam/status", 
            "/pico/status",
            "/devices/status",
            "/ws"
        ]
        
        all_passed = True
        for endpoint in public_endpoints:
            start_time = time.time()
            try:
                async with self.session.get(f"{self.base_url}{endpoint}") as response:
                    duration = time.time() - start_time
                    if endpoint == "/ws":
                        # WebSocket endpoint should return 400 for HTTP requests
                        if response.status == 400:
                            self.log_test(f"Public Endpoint: {endpoint}", "PASS", f"WebSocket endpoint (Status: {response.status})", duration)
                        else:
                            self.log_test(f"Public Endpoint: {endpoint}", "FAIL", f"Status: {response.status}", duration)
                            all_passed = False
                    else:
                    if response.status in [200, 302, 307]:
                        self.log_test(f"Public Endpoint: {endpoint}", "PASS", f"Status: {response.status}", duration)
                    else:
                        self.log_test(f"Public Endpoint: {endpoint}", "FAIL", f"Status: {response.status}", duration)
                        all_passed = False
            except Exception as e:
                duration = time.time() - start_time
                self.log_test(f"Public Endpoint: {endpoint}", "FAIL", f"Error: {str(e)}", duration)
                all_passed = False
        
        return all_passed
    
    async def test_translations(self) -> bool:
        """Test 3: Translation System"""
        languages = ["fa", "en"]
        all_passed = True
        
        for lang in languages:
            start_time = time.time()
            try:
                async with self.session.get(f"{self.base_url}/get_translations?lang={lang}") as response:
                    duration = time.time() - start_time
                    if response.status == 200:
                        try:
                        data = await response.json()
                        
                        # Check for profile translations
                        profile_keys = [
                            "profileTitle", "profileUsername", "profileRole", 
                            "profileOnline", "profileSettings", "profileHelp", 
                            "profileAbout", "profileLogout", "footerProfileMobile"
                        ]
                        
                        missing_keys = [key for key in profile_keys if key not in data]
                        
                        if not missing_keys:
                            self.log_test(f"Translations ({lang})", "PASS", f"All {len(profile_keys)} profile keys found", duration)
                        else:
                            self.log_test(f"Translations ({lang})", "FAIL", f"Missing keys: {missing_keys}", duration)
                            all_passed = False
                        except Exception as json_error:
                            # If JSON parsing fails, check if it's a redirect to login
                            if response.status == 302 or "login" in str(response.url):
                                self.log_test(f"Translations ({lang})", "PASS", f"Redirected to login (expected for unauthorized)", duration)
                            else:
                                self.log_test(f"Translations ({lang})", "FAIL", f"JSON parse error: {str(json_error)}", duration)
                                all_passed = False
                    else:
                        self.log_test(f"Translations ({lang})", "FAIL", f"Status: {response.status}", duration)
                        all_passed = False
            except Exception as e:
                duration = time.time() - start_time
                self.log_test(f"Translations ({lang})", "FAIL", f"Error: {str(e)}", duration)
                all_passed = False
        
        return all_passed
    
    async def test_google_oauth_flow(self) -> bool:
        """Test 4: Google OAuth Flow"""
        start_time = time.time()
        try:
            # Test OAuth redirect
            async with self.session.get(f"{self.base_url}/auth/google", allow_redirects=False) as response:
                duration = time.time() - start_time
                if response.status in [302, 307]:
                    redirect_url = response.headers.get('Location', '')
                    if 'accounts.google.com' in redirect_url:
                        self.log_test("Google OAuth Redirect", "PASS", f"Redirects to Google (Status: {response.status})", duration)
                        return True
                    else:
                        self.log_test("Google OAuth Redirect", "FAIL", f"Invalid redirect URL: {redirect_url}", duration)
                        return False
                else:
                    self.log_test("Google OAuth Redirect", "FAIL", f"Expected redirect, got: {response.status}", duration)
                    return False
        except Exception as e:
            duration = time.time() - start_time
            self.log_test("Google OAuth Redirect", "FAIL", f"Error: {str(e)}", duration)
            return False
    
    async def test_oauth_callback_errors(self) -> bool:
        """Test 5: OAuth Callback Error Handling"""
        error_cases = [
            {"code": "", "state": ""},
            {"code": "invalid", "state": "invalid"},
            {"code": "test", "state": "expired"}
        ]
        
        all_passed = True
        for case in error_cases:
            start_time = time.time()
            try:
                params = f"?code={case['code']}&state={case['state']}"
                async with self.session.get(f"{self.base_url}/auth/google/callback{params}", allow_redirects=False) as response:
                    duration = time.time() - start_time
                    if response.status in [302, 307, 400, 401, 500]:
                        self.log_test(f"OAuth Callback Error ({case})", "PASS", f"Proper response status: {response.status}", duration)
                    else:
                        self.log_test(f"OAuth Callback Error ({case})", "FAIL", f"Unexpected status: {response.status}", duration)
                        all_passed = False
            except Exception as e:
                duration = time.time() - start_time
                self.log_test(f"OAuth Callback Error ({case})", "FAIL", f"Error: {str(e)}", duration)
                all_passed = False
        
        return all_passed
    
    async def test_logout_functionality(self) -> bool:
        """Test 6: Logout Functionality"""
        start_time = time.time()
        try:
            # Test logout endpoint
            async with self.session.post(f"{self.base_url}/logout", allow_redirects=False) as response:
                duration = time.time() - start_time
                if response.status in [200, 302, 307]:
                    self.log_test("Logout Endpoint", "PASS", f"Logout successful (Status: {response.status})", duration)
                    return True
                else:
                    self.log_test("Logout Endpoint", "FAIL", f"Unexpected status: {response.status}", duration)
                    return False
        except Exception as e:
            duration = time.time() - start_time
            self.log_test("Logout Endpoint", "FAIL", f"Error: {str(e)}", duration)
            return False
    
    async def test_protected_endpoints_unauthorized(self) -> bool:
        """Test 7: Protected Endpoints - Unauthorized Access"""
        protected_endpoints = [
            "/dashboard",
            "/get_user_settings",
            "/get_gallery",
            "/get_videos",
            "/get_logs",
            "/set_servo",
            "/set_action"
        ]
        
        all_passed = True
        for endpoint in protected_endpoints:
            start_time = time.time()
            try:
                if endpoint in ["/set_servo", "/set_action"]:
                    # POST endpoints
                    async with self.session.post(f"{self.base_url}{endpoint}", json={}, allow_redirects=False) as response:
                        duration = time.time() - start_time
                        if response.status in [302, 401, 422]:
                            self.log_test(f"Protected POST: {endpoint}", "PASS", f"Proper unauthorized response: {response.status}", duration)
                        else:
                            self.log_test(f"Protected POST: {endpoint}", "FAIL", f"Unexpected status: {response.status}", duration)
                            all_passed = False
                else:
                    # GET endpoints - use allow_redirects=False to see actual status
                    async with self.session.get(f"{self.base_url}{endpoint}", allow_redirects=False) as response:
                        duration = time.time() - start_time
                        if response.status in [302, 401]:
                            self.log_test(f"Protected GET: {endpoint}", "PASS", f"Proper unauthorized response: {response.status}", duration)
                        else:
                            self.log_test(f"Protected GET: {endpoint}", "FAIL", f"Unexpected status: {response.status}", duration)
                            all_passed = False
            except Exception as e:
                duration = time.time() - start_time
                self.log_test(f"Protected Endpoint: {endpoint}", "FAIL", f"Error: {str(e)}", duration)
                all_passed = False
        
        return all_passed
    
    async def test_database_operations(self) -> bool:
        """Test 8: Database Operations"""
        start_time = time.time()
        try:
            # Test database health through user settings endpoint
            # This will test the robust_db_endpoint decorator
            async with self.session.get(f"{self.base_url}/get_user_settings", allow_redirects=False) as response:
                duration = time.time() - start_time
                if response.status in [401, 302]:  # Expected for unauthorized access
                    self.log_test("Database Operations", "PASS", f"Database accessible (Status: {response.status})", duration)
                    return True
                elif response.status == 200:
                    try:
                    data = await response.json()
                    if "settings" in data:
                        self.log_test("Database Operations", "PASS", "Database operations working", duration)
                        return True
                    else:
                        self.log_test("Database Operations", "FAIL", "Invalid response format", duration)
                            return False
                    except Exception as json_error:
                        self.log_test("Database Operations", "FAIL", f"JSON parse error: {str(json_error)}", duration)
                        return False
                else:
                    self.log_test("Database Operations", "FAIL", f"Unexpected status: {response.status}", duration)
                    return False
        except Exception as e:
            duration = time.time() - start_time
            self.log_test("Database Operations", "FAIL", f"Error: {str(e)}", duration)
            return False
    
    async def test_websocket_endpoints(self) -> bool:
        """Test 9: WebSocket Endpoints"""
        websocket_endpoints = [
            "/ws",
            "/ws/pico",
            "/ws/esp32cam",
            "/ws/video"
        ]
        
        all_passed = True
        for endpoint in websocket_endpoints:
            start_time = time.time()
            try:
                # Test WebSocket upgrade
                async with self.session.get(f"{self.base_url}{endpoint}") as response:
                    duration = time.time() - start_time
                    if response.status in [200, 302, 307, 400, 404, 426]:  # 426 = Upgrade Required
                        self.log_test(f"WebSocket: {endpoint}", "PASS", f"WebSocket endpoint accessible (Status: {response.status})", duration)
                    else:
                        self.log_test(f"WebSocket: {endpoint}", "FAIL", f"Unexpected status: {response.status}", duration)
                        all_passed = False
            except Exception as e:
                duration = time.time() - start_time
                self.log_test(f"WebSocket: {endpoint}", "FAIL", f"Error: {str(e)}", duration)
                all_passed = False
        
        return all_passed
    
    async def test_static_files(self) -> bool:
        """Test 10: Static Files Serving"""
        static_files = [
            "/static/css/index/styles.css",
            "/static/js/index/script.js",
            "/static/images/logo.png"
        ]
        
        all_passed = True
        for file_path in static_files:
            start_time = time.time()
            try:
                async with self.session.get(f"{self.base_url}{file_path}") as response:
                    duration = time.time() - start_time
                    if response.status == 200:
                        self.log_test(f"Static File: {file_path}", "PASS", f"File served successfully", duration)
                    else:
                        self.log_test(f"Static File: {file_path}", "FAIL", f"Status: {response.status}", duration)
                        all_passed = False
            except Exception as e:
                duration = time.time() - start_time
                self.log_test(f"Static File: {file_path}", "FAIL", f"Error: {str(e)}", duration)
                all_passed = False
        
        return all_passed
    
    async def test_error_handling(self) -> bool:
        """Test 11: Error Handling"""
        error_cases = [
            "/nonexistent_endpoint",
            "/static/nonexistent.css",
            "/api/invalid"
        ]
        
        all_passed = True
        for endpoint in error_cases:
            start_time = time.time()
            try:
                async with self.session.get(f"{self.base_url}{endpoint}", allow_redirects=False) as response:
                    duration = time.time() - start_time
                    if response.status in [302, 404, 405, 401, 500]:
                        self.log_test(f"Error Handling: {endpoint}", "PASS", f"Proper error response: {response.status}", duration)
                    else:
                        self.log_test(f"Error Handling: {endpoint}", "FAIL", f"Unexpected status: {response.status}", duration)
                        all_passed = False
            except Exception as e:
                duration = time.time() - start_time
                self.log_test(f"Error Handling: {endpoint}", "FAIL", f"Error: {str(e)}", duration)
                all_passed = False
        
        return all_passed
    
    async def test_performance_metrics(self) -> bool:
        """Test 12: Performance and Response Times"""
        endpoints_to_test = [
            "/health",
            "/get_translations?lang=fa",
            "/esp32cam/status",
            "/pico/status"
        ]
        
        all_passed = True
        for endpoint in endpoints_to_test:
            start_time = time.time()
            try:
                async with self.session.get(f"{self.base_url}{endpoint}") as response:
                    duration = time.time() - start_time
                    if response.status in [200, 302, 307]:
                        if duration < 2.0:  # Should respond within 2 seconds
                            self.log_test(f"Performance: {endpoint}", "PASS", f"Response time: {duration:.3f}s", duration)
                        else:
                            self.log_test(f"Performance: {endpoint}", "WARN", f"Slow response: {duration:.3f}s", duration)
                    else:
                        self.log_test(f"Performance: {endpoint}", "FAIL", f"Status: {response.status}", duration)
                        all_passed = False
            except Exception as e:
                duration = time.time() - start_time
                self.log_test(f"Performance: {endpoint}", "FAIL", f"Error: {str(e)}", duration)
                all_passed = False
        
        return all_passed
    
    def generate_report(self):
        """Generate comprehensive test report"""
        total_tests = len(self.test_results)
        passed_tests = len([r for r in self.test_results if r["status"] == "PASS"])
        failed_tests = len([r for r in self.test_results if r["status"] == "FAIL"])
        warning_tests = len([r for r in self.test_results if r["status"] == "WARN"])
        
        total_duration = time.time() - self.start_time
        
        print("\n" + "="*80)
        print("🔍 COMPREHENSIVE SYSTEM TEST REPORT")
        print("="*80)
        print(f"📊 Test Summary:")
        print(f"   Total Tests: {total_tests}")
        print(f"   ✅ Passed: {passed_tests}")
        print(f"   ❌ Failed: {failed_tests}")
        print(f"   ⚠️  Warnings: {warning_tests}")
        print(f"   📈 Success Rate: {(passed_tests/total_tests*100):.1f}%")
        print(f"   ⏱️  Total Duration: {total_duration:.2f}s")
        
        if failed_tests > 0:
            print(f"\n❌ FAILED TESTS:")
            for result in self.test_results:
                if result["status"] == "FAIL":
                    print(f"   • {result['test']}: {result['details']}")
        
        if warning_tests > 0:
            print(f"\n⚠️  WARNINGS:")
            for result in self.test_results:
                if result["status"] == "WARN":
                    print(f"   • {result['test']}: {result['details']}")
        
        print(f"\n🎯 RECOMMENDATIONS:")
        if failed_tests == 0:
            print("   ✅ All tests passed! System is working correctly.")
        else:
            print("   🔧 Review failed tests and fix issues.")
        
        if warning_tests > 0:
            print("   ⚡ Consider optimizing slow endpoints.")
        
        print("="*80)
        
        # Save detailed report to file
        report_data = {
            "timestamp": datetime.now().isoformat(),
            "summary": {
                "total_tests": total_tests,
                "passed": passed_tests,
                "failed": failed_tests,
                "warnings": warning_tests,
                "success_rate": (passed_tests/total_tests*100),
                "total_duration": total_duration
            },
            "results": self.test_results
        }
        
        with open("test_comprehensive_report.json", "w", encoding="utf-8") as f:
            json.dump(report_data, f, indent=2, ensure_ascii=False)
        
        print(f"📄 Detailed report saved to: test_comprehensive_report.json")
        
        return failed_tests == 0

async def main():
    """Main test execution"""
    print("🚀 Starting Comprehensive System Test...")
    print("="*80)
    
    async with ComprehensiveSystemTest() as tester:
        # Run all tests
        tests = [
            ("Server Health", tester.test_server_health),
            ("Public Endpoints", tester.test_public_endpoints),
            ("Translation System", tester.test_translations),
            ("Google OAuth Flow", tester.test_google_oauth_flow),
            ("OAuth Callback Errors", tester.test_oauth_callback_errors),
            ("Logout Functionality", tester.test_logout_functionality),
            ("Protected Endpoints", tester.test_protected_endpoints_unauthorized),
            ("Database Operations", tester.test_database_operations),
            ("WebSocket Endpoints", tester.test_websocket_endpoints),
            ("Static Files", tester.test_static_files),
            ("Error Handling", tester.test_error_handling),
            ("Performance Metrics", tester.test_performance_metrics)
        ]
        
        for test_name, test_func in tests:
            print(f"\n🔍 Running: {test_name}")
            print("-" * 50)
            await test_func()
            await asyncio.sleep(0.5)  # Small delay between tests
        
        # Generate final report
        success = tester.generate_report()
        
        if success:
            print("\n🎉 ALL TESTS PASSED! System is fully operational.")
            sys.exit(0)
        else:
            print("\n❌ Some tests failed. Please review the report above.")
            sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main()) 