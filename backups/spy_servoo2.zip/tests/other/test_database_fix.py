#!/usr/bin/env python3
"""
Test Database Migration Fix
Tests the database migration fixes for user_settings table
"""

import asyncio
import aiosqlite
import json
from datetime import datetime

async def test_database_migration():
    """Test database migration fixes"""
    print("🧪 Testing Database Migration Fixes")
    print("=" * 50)
    
    try:
        # Connect to database
        conn = await aiosqlite.connect('smart_camera_system.db')
        
        # Test 1: Check current table structure
        print("\n1️⃣ Checking current table structure...")
        cursor = await conn.execute("PRAGMA table_info(user_settings)")
        columns = await cursor.fetchall()
        current_columns = [col[1] for col in columns]
        print(f"Current columns: {current_columns}")
        
        # Test 2: Check if smart_motion and smart_tracking columns exist
        print("\n2️⃣ Checking smart features columns...")
        if 'smart_motion' in current_columns:
            print("✅ smart_motion column exists")
        else:
            print("❌ smart_motion column missing")
            
        if 'smart_tracking' in current_columns:
            print("✅ smart_tracking column exists")
        else:
            print("❌ smart_tracking column missing")
        
        # Test 3: Insert test data
        print("\n3️⃣ Testing data insertion...")
        test_username = 'test_migration_user'
        test_data = {
            'username': test_username,
            'ip': '127.0.0.1',
            'theme': 'dark',
            'language': 'fa',
            'servo1': 90,
            'servo2': 90,
            'device_mode': 'desktop',
            'photo_quality': 85,
            'smart_motion': True,
            'smart_tracking': False,
            'stream_enabled': True,
            'flash_settings': json.dumps({'intensity': 75, 'enabled': True}),
            'updated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        try:
            await conn.execute('''
                INSERT OR REPLACE INTO user_settings 
                (username, ip, theme, language, servo1, servo2, device_mode, photo_quality, 
                 smart_motion, smart_tracking, stream_enabled, flash_settings, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                test_data['username'], test_data['ip'], test_data['theme'],
                test_data['language'], test_data['servo1'], test_data['servo2'],
                test_data['device_mode'], test_data['photo_quality'],
                test_data['smart_motion'], test_data['smart_tracking'],
                test_data['stream_enabled'], test_data['flash_settings'],
                test_data['updated_at']
            ))
            await conn.commit()
            print("✅ Test data inserted successfully")
        except Exception as e:
            print(f"❌ Failed to insert test data: {e}")
        
        # Test 4: Retrieve test data
        print("\n4️⃣ Testing data retrieval...")
        try:
            cursor = await conn.execute('''
                SELECT username, ip, theme, language, servo1, servo2, device_mode, photo_quality, 
                       smart_motion, smart_tracking, stream_enabled, flash_settings, updated_at
                FROM user_settings WHERE username = ?
            ''', (test_username,))
            row = await cursor.fetchone()
            
            if row:
                print("✅ Test data retrieved successfully")
                print(f"   Username: {row[0]}")
                print(f"   Theme: {row[2]}")
                print(f"   Smart Motion: {row[8]}")
                print(f"   Smart Tracking: {row[9]}")
                print(f"   Stream Enabled: {row[10]}")
            else:
                print("❌ No test data found")
        except Exception as e:
            print(f"❌ Failed to retrieve test data: {e}")
        
        # Test 5: Clean up test data
        print("\n5️⃣ Cleaning up test data...")
        try:
            await conn.execute('DELETE FROM user_settings WHERE username = ?', (test_username,))
            await conn.commit()
            print("✅ Test data cleaned up")
        except Exception as e:
            print(f"❌ Failed to clean up test data: {e}")
        
        await conn.close()
        print("\n✅ Database migration test completed successfully")
        
    except Exception as e:
        print(f"❌ Database migration test failed: {e}")

if __name__ == "__main__":
    asyncio.run(test_database_migration()) 