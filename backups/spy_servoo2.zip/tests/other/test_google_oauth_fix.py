#!/usr/bin/env python3
"""
تست Google OAuth Fix
Google OAuth Fix Test
"""

import asyncio
import httpx
import json
import time
from datetime import datetime

async def test_google_oauth_flow():
    """تست جریان Google OAuth"""
    print("🔐 تست Google OAuth Flow")
    print("=" * 50)
    
    base_url = "http://localhost:3000"
    
    async with httpx.AsyncClient() as client:
        try:
            # Test 1: Check if Google OAuth redirect endpoint is accessible
            print("1️⃣ تست دسترسی به Google OAuth redirect...")
            response = await client.get(f"{base_url}/auth/google", follow_redirects=False)
            
            if response.status_code == 302:
                print("✅ Google OAuth redirect endpoint accessible")
                print(f"   Redirect URL: {response.headers.get('location', 'N/A')}")
        else:
                print(f"❌ Unexpected status code: {response.status_code}")
        return False

            # Test 2: Check if callback endpoint is accessible
            print("\n2️⃣ تست دسترسی به Google OAuth callback...")
            response = await client.get(f"{base_url}/auth/google/callback?code=test&state=test", follow_redirects=False)
            
            if response.status_code in [302, 307]:
                print("✅ Google OAuth callback endpoint accessible")
                redirect_url = response.headers.get('location', '')
                if 'error=google_auth_failed' in redirect_url:
                    print("✅ Properly handling invalid callback parameters")
                else:
                    print(f"⚠️ Unexpected redirect: {redirect_url}")
        else:
                print(f"❌ Unexpected status code: {response.status_code}")
            return False
        
            # Test 3: Test rate limiting
            print("\n3️⃣ تست Rate Limiting برای Google OAuth...")
            responses = []
            for i in range(20):  # Try more than the limit
                response = await client.get(f"{base_url}/auth/google", follow_redirects=False)
                responses.append(response.status_code)
            
            # Check if rate limiting is working
            if 429 in responses:
                print("✅ Rate limiting is working")
        else:
                print("⚠️ Rate limiting might not be working properly")
            
            # Test 4: Test login page accessibility
            print("\n4️⃣ تست دسترسی به صفحه لاگین...")
            response = await client.get(f"{base_url}/login", follow_redirects=False)
            
            if response.status_code == 200:
                print("✅ Login page accessible")
        else:
                print(f"❌ Login page not accessible: {response.status_code}")
            return False
        
            # Test 5: Test dashboard redirect for unauthenticated users
            print("\n5️⃣ تست redirect به لاگین برای کاربران غیرمجاز...")
            response = await client.get(f"{base_url}/dashboard", follow_redirects=False)
            
            if response.status_code == 302:
                redirect_url = response.headers.get('location', '')
                if '/login' in redirect_url:
                    print("✅ Properly redirecting unauthenticated users to login")
                else:
                    print(f"⚠️ Unexpected redirect: {redirect_url}")
            else:
                print(f"❌ Unexpected status code: {response.status_code}")
                return False
            
            print("\n🎉 تمام تست‌های Google OAuth موفق بودند!")
            return True
            
        except Exception as e:
            print(f"❌ خطا در تست: {e}")
            return False

async def test_oauth_state_validation():
    """تست validation state"""
    print("\n🔒 تست OAuth State Validation")
    print("=" * 50)
    
    base_url = "http://localhost:3000"
    
    async with httpx.AsyncClient() as client:
        try:
            # Test invalid state
            print("1️⃣ تست state نامعتبر...")
            response = await client.get(f"{base_url}/auth/google/callback?code=test&state=invalid_state", follow_redirects=False)
            
            if response.status_code in [302, 307]:
                redirect_url = response.headers.get('location', '')
                if 'error=google_auth_failed' in redirect_url:
                    print("✅ Properly rejecting invalid state")
                else:
                    print(f"⚠️ Unexpected redirect: {redirect_url}")
            else:
                print(f"❌ Unexpected status code: {response.status_code}")
            
            # Test missing state
            print("\n2️⃣ تست state گمشده...")
            response = await client.get(f"{base_url}/auth/google/callback?code=test", follow_redirects=False)
            
            if response.status_code in [302, 307]:
                redirect_url = response.headers.get('location', '')
                if 'error=google_auth_failed' in redirect_url:
                    print("✅ Properly rejecting missing state")
                else:
                    print(f"⚠️ Unexpected redirect: {redirect_url}")
        else:
                print(f"❌ Unexpected status code: {response.status_code}")
            
            print("\n🎉 تمام تست‌های State Validation موفق بودند!")
            return True
            
        except Exception as e:
            print(f"❌ خطا در تست: {e}")
            return False

async def main():
    """تابع اصلی"""
    print("🚀 شروع تست Google OAuth Fix")
    print("=" * 60)
    
    # Wait a moment for server to be ready
    await asyncio.sleep(2)
    
    # Run tests
    oauth_success = await test_google_oauth_flow()
    state_success = await test_oauth_state_validation()
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 خلاصه نتایج تست")
    print("=" * 60)
    
    print(f"Google OAuth Flow: {'✅ PASS' if oauth_success else '❌ FAIL'}")
    print(f"State Validation: {'✅ PASS' if state_success else '❌ FAIL'}")
    
    if oauth_success and state_success:
        print("\n🎉 تمام تست‌ها موفق بودند!")
        print("✅ Google OAuth مشکل redirect loop حل شد!")
        return True
    else:
        print("\n⚠️ برخی تست‌ها ناموفق بودند")
        return False

if __name__ == "__main__":
    success = asyncio.run(main())
    exit(0 if success else 1)