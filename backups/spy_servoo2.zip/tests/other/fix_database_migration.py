#!/usr/bin/env python3
"""
Fix Database Migration Script
Ensures all required columns exist in user_settings table
"""

import asyncio
import aiosqlite
import sqlite3
from datetime import datetime

async def fix_database_migration():
    """Fix database migration issues"""
    print("🔧 Fixing Database Migration")
    print("=" * 50)
    
    try:
        # Connect to database
        conn = await aiosqlite.connect('smart_camera_system.db')
        
        # Check current table structure
        cursor = await conn.execute("PRAGMA table_info(user_settings)")
        columns = await cursor.fetchall()
        current_columns = [col[1] for col in columns]
        
        print(f"Current columns: {current_columns}")
        
        # Required columns
        required_columns = [
            ('id', 'INTEGER PRIMARY KEY AUTOINCREMENT'),
            ('username', 'TEXT NOT NULL'),
            ('ip', 'TEXT NOT NULL'),
            ('theme', 'TEXT'),
            ('language', 'TEXT'),
            ('flash_settings', 'TEXT'),
            ('servo1', 'INTEGER'),
            ('servo2', 'INTEGER'),
            ('device_mode', 'TEXT'),
            ('photo_quality', 'INTEGER'),
            ('smart_motion', 'BOOLEAN'),
            ('smart_tracking', 'BOOLEAN'),
            ('stream_enabled', 'BOOLEAN'),
            ('updated_at', 'TEXT')
        ]
        
        # Add missing columns
        for col_name, col_type in required_columns:
            if col_name not in current_columns:
                try:
                    print(f"Adding column: {col_name}")
                    await conn.execute(f"ALTER TABLE user_settings ADD COLUMN {col_name} {col_type}")
                    print(f"✅ Added column: {col_name}")
                except Exception as e:
                    if 'duplicate column name' not in str(e):
                        print(f"❌ Error adding column {col_name}: {e}")
                    else:
                        print(f"⚠️  Column {col_name} already exists")
        
        await conn.commit()
        
        # Verify final structure
        cursor = await conn.execute("PRAGMA table_info(user_settings)")
        columns = await conn.fetchall()
        final_columns = [col[1] for col in columns]
        
        print(f"\nFinal columns: {final_columns}")
        
        # Check if all required columns exist
        missing_columns = [col for col, _ in required_columns if col not in final_columns]
        
        if not missing_columns:
            print("✅ All required columns exist!")
        else:
            print(f"❌ Missing columns: {missing_columns}")
        
        await conn.close()
        
        # Test with a sample insert
        print("\n🧪 Testing database operations...")
        await test_database_operations()
        
    except Exception as e:
        print(f"❌ Error fixing migration: {e}")
        import traceback
        traceback.print_exc()

async def test_database_operations():
    """Test database operations after migration"""
    try:
        conn = await aiosqlite.connect('smart_camera_system.db')
        
        # Test insert
        test_data = {
            'username': 'test_migration_user',
            'ip': '127.0.0.1',
            'theme': 'dark',
            'language': 'fa',
            'servo1': 90,
            'servo2': 90,
            'device_mode': 'desktop',
            'photo_quality': 80,
            'smart_motion': True,
            'smart_tracking': False,
            'stream_enabled': True,
            'flash_settings': '{"intensity": 50, "enabled": false}',
            'updated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        await conn.execute('''
            INSERT OR REPLACE INTO user_settings 
            (username, ip, theme, language, servo1, servo2, device_mode, photo_quality, 
             smart_motion, smart_tracking, stream_enabled, flash_settings, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            test_data['username'], test_data['ip'], test_data['theme'],
            test_data['language'], test_data['servo1'], test_data['servo2'],
            test_data['device_mode'], test_data['photo_quality'],
            test_data['smart_motion'], test_data['smart_tracking'],
            test_data['stream_enabled'], test_data['flash_settings'],
            test_data['updated_at']
        ))
        await conn.commit()
        print("✅ Test insert successful")
        
        # Test select
        cursor = await conn.execute('''
            SELECT username, smart_motion, smart_tracking, stream_enabled
            FROM user_settings WHERE username = ?
        ''', ('test_migration_user',))
        result = await cursor.fetchone()
        
        if result:
            print(f"✅ Test select successful: {result}")
        else:
            print("❌ Test select failed")
        
        # Clean up test data
        await conn.execute('DELETE FROM user_settings WHERE username = ?', ('test_migration_user',))
        await conn.commit()
        
        await conn.close()
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()

def check_sqlite_version():
    """Check SQLite version and capabilities"""
    print("📋 SQLite Information:")
    print(f"SQLite version: {sqlite3.sqlite_version}")
    print(f"SQLite version info: {sqlite3.version}")
    
    # Test ALTER TABLE capabilities
    try:
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        cursor.execute('CREATE TABLE test (id INTEGER)')
        cursor.execute('ALTER TABLE test ADD COLUMN new_col TEXT')
        print("✅ ALTER TABLE ADD COLUMN supported")
        conn.close()
    except Exception as e:
        print(f"❌ ALTER TABLE ADD COLUMN not supported: {e}")

async def main():
    """Main function"""
    print("🚀 Starting Database Migration Fix")
    print("=" * 50)
    
    check_sqlite_version()
    print()
    
    await fix_database_migration()
    
    print("\n🎉 Database migration fix completed!")

if __name__ == "__main__":
    asyncio.run(main()) 