#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Deep Security Test Script
تست عمیق امنیت
"""

import asyncio
import aiohttp
import json
from datetime import datetime

class DeepSecurityTest:
    def __init__(self):
        self.base_url = "http://localhost:3000"
        self.results = {
            "success": [],
            "failed": [],
            "warnings": []
        }
    
    def log_result(self, category, test_name, status, details=""):
        """ثبت نتیجه تست"""
        result = {
            "test": test_name,
            "status": status,
            "details": details,
            "timestamp": datetime.now().isoformat()
        }
        self.results[category].append(result)
        
        status_icon = "✅" if status == "SUCCESS" else "❌" if status == "FAILED" else "⚠️"
        print(f"{status_icon} {test_name}: {status}")
        if details:
            print(f"   📝 {details}")
    
    async def test_csrf_protection(self):
        """تست محافظت CSRF"""
        try:
            async with aiohttp.ClientSession() as session:
                # تست بدون CSRF token
                headers = {'Content-Type': 'application/json'}
                data = {"username": "admin", "password": "admin123"}
                async with session.post(f"{self.base_url}/login", 
                                      json=data, headers=headers) as response:
                    if response.status == 200:
                        self.log_result("warnings", "CSRF Protection", "WARNING", 
                                      "CSRF protection may not be active")
                    else:
                        self.log_result("success", "CSRF Protection", "SUCCESS", 
                                      "CSRF protection is working")
        except Exception as e:
            self.log_result("failed", "CSRF Protection", "FAILED", str(e))
    
    async def test_sql_injection_protection(self):
        """تست محافظت SQL Injection"""
        sql_injection_payloads = [
            "'; DROP TABLE users; --",
            "' OR '1'='1",
            "admin'--",
            "'; INSERT INTO users VALUES ('hacker', 'hash', 'admin', 1); --"
        ]
        
        for payload in sql_injection_payloads:
            try:
                async with aiohttp.ClientSession() as session:
                    headers = {'Content-Type': 'application/json'}
                    data = {"username": payload, "password": "test"}
                    async with session.post(f"{self.base_url}/login", 
                                          json=data, headers=headers) as response:
                        if response.status == 401:  # Expected for invalid credentials
                            self.log_result("success", f"SQL Injection Protection ({payload[:20]}...)", "SUCCESS", 
                                          "SQL injection blocked")
                        else:
                            self.log_result("warnings", f"SQL Injection Protection ({payload[:20]}...)", "WARNING", 
                                          f"Unexpected status: {response.status}")
            except Exception as e:
                self.log_result("failed", f"SQL Injection Protection ({payload[:20]}...)", "FAILED", str(e))
    
    async def test_xss_protection(self):
        """تست محافظت XSS"""
        xss_payloads = [
            "<script>alert('XSS')</script>",
            "javascript:alert('XSS')",
            "<img src=x onerror=alert('XSS')>",
            "';alert('XSS');//"
        ]
        
        for payload in xss_payloads:
            try:
                async with aiohttp.ClientSession() as session:
                    headers = {'Content-Type': 'application/json'}
                    data = {"username": payload, "password": "test"}
                    async with session.post(f"{self.base_url}/login", 
                                          json=data, headers=headers) as response:
                        if response.status == 401:  # Expected for invalid credentials
                            self.log_result("success", f"XSS Protection ({payload[:20]}...)", "SUCCESS", 
                                          "XSS payload blocked")
                        else:
                            self.log_result("warnings", f"XSS Protection ({payload[:20]}...)", "WARNING", 
                                          f"Unexpected status: {response.status}")
            except Exception as e:
                self.log_result("failed", f"XSS Protection ({payload[:20]}...)", "FAILED", str(e))
    
    async def test_input_sanitization(self):
        """تست پاکسازی ورودی"""
        malicious_inputs = [
            "admin<script>",
            "user'; DROP TABLE users; --",
            "test<iframe src='javascript:alert(1)'>",
            "admin' OR '1'='1' --"
        ]
        
        for malicious_input in malicious_inputs:
            try:
                async with aiohttp.ClientSession() as session:
                    headers = {'Content-Type': 'application/json'}
                    data = {"username": malicious_input, "password": "test"}
                    async with session.post(f"{self.base_url}/login", 
                                          json=data, headers=headers) as response:
                        if response.status == 401:  # Expected for invalid credentials
                            self.log_result("success", f"Input Sanitization ({malicious_input[:20]}...)", "SUCCESS", 
                                          "Malicious input handled safely")
                        else:
                            self.log_result("warnings", f"Input Sanitization ({malicious_input[:20]}...)", "WARNING", 
                                          f"Unexpected status: {response.status}")
            except Exception as e:
                self.log_result("failed", f"Input Sanitization ({malicious_input[:20]}...)", "FAILED", str(e))
    
    async def test_authentication_bypass(self):
        """تست دور زدن احراز هویت"""
        bypass_attempts = [
            # تست بدون توکن
            {"headers": {}, "expected": 401},
            # تست با توکن نامعتبر
            {"headers": {"Authorization": "Bearer invalid_token"}, "expected": 401},
            # تست با توکن خالی
            {"headers": {"Authorization": "Bearer "}, "expected": 401}
        ]
        
        protected_endpoints = ["/", "/dashboard", "/get_status"]
        
        for endpoint in protected_endpoints:
            for attempt in bypass_attempts:
                try:
                    async with aiohttp.ClientSession() as session:
                        async with session.get(f"{self.base_url}{endpoint}", 
                                             headers=attempt["headers"]) as response:
                            if response.status == attempt["expected"]:
                                self.log_result("success", f"Auth Bypass Protection ({endpoint})", "SUCCESS", 
                                              "Authentication bypass prevented")
                            else:
                                self.log_result("warnings", f"Auth Bypass Protection ({endpoint})", "WARNING", 
                                              f"Expected {attempt['expected']}, got {response.status}")
                except Exception as e:
                    self.log_result("failed", f"Auth Bypass Protection ({endpoint})", "FAILED", str(e))
    
    async def test_session_management(self):
        """تست مدیریت نشست"""
        try:
            async with aiohttp.ClientSession() as session:
                # تست login موفق
                headers = {'Content-Type': 'application/json'}
                data = {"username": "admin", "password": "admin123"}
                async with session.post(f"{self.base_url}/login", 
                                      json=data, headers=headers) as response:
                    if response.status == 200:
                        cookies = response.cookies
                        if "access_token" in cookies:
                            self.log_result("success", "Session Management", "SUCCESS", 
                                          "Session token created successfully")
                        else:
                            self.log_result("warnings", "Session Management", "WARNING", 
                                          "No session token found")
                    else:
                        self.log_result("warnings", "Session Management", "WARNING", 
                                      f"Login failed with status: {response.status}")
        except Exception as e:
            self.log_result("failed", "Session Management", "FAILED", str(e))
    
    async def test_password_security(self):
        """تست امنیت رمز عبور"""
        weak_passwords = [
            "123456",
            "password",
            "admin",
            "qwerty",
            "123456789"
        ]
        
        for weak_password in weak_passwords:
            try:
                async with aiohttp.ClientSession() as session:
                    headers = {'Content-Type': 'application/json'}
                    data = {"username": "admin", "password": weak_password}
                    async with session.post(f"{self.base_url}/login", 
                                          json=data, headers=headers) as response:
                        if response.status == 401:  # Expected for weak password
                            self.log_result("success", f"Password Security ({weak_password})", "SUCCESS", 
                                          "Weak password rejected")
                        else:
                            self.log_result("warnings", f"Password Security ({weak_password})", "WARNING", 
                                          f"Unexpected status: {response.status}")
            except Exception as e:
                self.log_result("failed", f"Password Security ({weak_password})", "FAILED", str(e))
    
    async def test_rate_limiting_effectiveness(self):
        """تست اثربخشی محدودیت نرخ"""
        try:
            async with aiohttp.ClientSession() as session:
                headers = {'Content-Type': 'application/json'}
                data = {"username": "test", "password": "test123"}
                
                # ارسال درخواست‌های متعدد
                responses = []
                for i in range(10):
                    async with session.post(f"{self.base_url}/login", 
                                          json=data, headers=headers) as response:
                        responses.append(response.status)
                
                # بررسی اینکه آیا rate limiting اعمال شده
                if 429 in responses:
                    self.log_result("success", "Rate Limiting Effectiveness", "SUCCESS", 
                                  "Rate limiting effectively blocks excessive requests")
                else:
                    self.log_result("warnings", "Rate Limiting Effectiveness", "WARNING", 
                                  "Rate limiting may not be working effectively")
        except Exception as e:
            self.log_result("failed", "Rate Limiting Effectiveness", "FAILED", str(e))
    
    async def run_all_security_tests(self):
        """اجرای تمام تست‌های امنیتی"""
        print("🔒 شروع تست عمیق امنیت")
        print("=" * 60)
        print(f"⏰ زمان شروع: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print()
        
        # اجرای تمام تست‌های امنیتی
        await self.test_csrf_protection()
        await self.test_sql_injection_protection()
        await self.test_xss_protection()
        await self.test_input_sanitization()
        await self.test_authentication_bypass()
        await self.test_session_management()
        await self.test_password_security()
        await self.test_rate_limiting_effectiveness()
        
        # نمایش نتایج نهایی
        self.print_final_report()
    
    def print_final_report(self):
        """نمایش گزارش نهایی"""
        print("\n" + "=" * 60)
        print("🔒 گزارش نهایی تست عمیق امنیت")
        print("=" * 60)
        
        total_tests = len(self.results["success"]) + len(self.results["failed"]) + len(self.results["warnings"])
        security_score = (len(self.results["success"]) / total_tests * 100) if total_tests > 0 else 0
        
        print(f"📈 کل تست‌های امنیتی: {total_tests}")
        print(f"✅ موفق: {len(self.results['success'])}")
        print(f"❌ ناموفق: {len(self.results['failed'])}")
        print(f"⚠️ هشدار: {len(self.results['warnings'])}")
        print(f"🔒 امتیاز امنیت: {security_score:.1f}%")
        print()
        
        if self.results["failed"]:
            print("❌ تست‌های امنیتی ناموفق:")
            for result in self.results["failed"]:
                print(f"  • {result['test']}: {result['details']}")
            print()
        
        if self.results["warnings"]:
            print("⚠️ تست‌های امنیتی هشدار:")
            for result in self.results["warnings"]:
                print(f"  • {result['test']}: {result['details']}")
            print()
        
        print("✅ تست‌های امنیتی موفق:")
        for result in self.results["success"]:
            print(f"  • {result['test']}")
        
        print(f"\n🏁 تست امنیت کامل شد!")
        print(f"⏰ زمان پایان: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        if security_score >= 90:
            print("🛡️ امنیت سیستم عالی است!")
        elif security_score >= 70:
            print("🔒 امنیت سیستم خوب است")
        else:
            print("⚠️ امنیت سیستم نیاز به بهبود دارد")

async def main():
    """تابع اصلی"""
    tester = DeepSecurityTest()
    await tester.run_all_security_tests()

if __name__ == "__main__":
    asyncio.run(main()) 