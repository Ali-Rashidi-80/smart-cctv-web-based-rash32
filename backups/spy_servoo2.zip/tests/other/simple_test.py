#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Simple Test Script
تست ساده برای دیباگ
"""

import requests
import json

def test_endpoints():
    """تست ساده endpoint ها"""
    base_url = "http://localhost:3000"
    
    print("🧪 تست ساده endpoint ها")
    print("=" * 50)
    
    # تست health
    print("📊 تست /health...")
    try:
        response = requests.get(f"{base_url}/health")
        print(f"   وضعیت: {response.status_code}")
        print(f"   Content-Type: {response.headers.get('content-type')}")
        if response.status_code == 200:
            print(f"   پاسخ: {response.json()}")
    except Exception as e:
        print(f"   خطا: {e}")
    
    print()
    
    # تست register
    print("📝 تست /register...")
    try:
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        data = {
            "username": "testuser",
            "phone": "+989966902209",
            "password": "test123456"  # حداقل 8 کاراکتر
        }
        response = requests.post(f"{base_url}/register", 
                               json=data, 
                               headers=headers)
        print(f"   وضعیت: {response.status_code}")
        print(f"   Content-Type: {response.headers.get('content-type')}")
        if response.status_code == 200:
            print(f"   پاسخ: {response.json()}")
        else:
            print(f"   پاسخ: {response.text}")
    except Exception as e:
        print(f"   خطا: {e}")
    
    print()
    
    # تست login
    print("🔐 تست /login...")
    try:
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        data = {
            "username": "admin",
            "password": "admin123"
        }
        response = requests.post(f"{base_url}/login", 
                               json=data, 
                               headers=headers)
        print(f"   وضعیت: {response.status_code}")
        print(f"   Content-Type: {response.headers.get('content-type')}")
        if response.status_code == 200:
            print(f"   پاسخ: {response.json()}")
        else:
            print(f"   پاسخ: {response.text}")
    except Exception as e:
        print(f"   خطا: {e}")
    
    print()
    
    # تست recover-password
    print("📱 تست /recover-password...")
    try:
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        data = {
            "phone": "+989966902209"
        }
        response = requests.post(f"{base_url}/recover-password", 
                               json=data, 
                               headers=headers)
        print(f"   وضعیت: {response.status_code}")
        print(f"   Content-Type: {response.headers.get('content-type')}")
        if response.status_code == 200:
            print(f"   پاسخ: {response.json()}")
        else:
            print(f"   پاسخ: {response.text}")
    except Exception as e:
        print(f"   خطا: {e}")

if __name__ == "__main__":
    test_endpoints()