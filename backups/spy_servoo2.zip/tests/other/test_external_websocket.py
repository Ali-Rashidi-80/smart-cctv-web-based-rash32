#!/usr/bin/env python3
"""
Test script for external WebSocket connections
This script tests the WebSocket connection from an external IP address
"""

import asyncio
import websockets
import json
import requests
import sys
import socket

# Configuration - Updated to use HTTPS/WSS
SERVER_URL = "wss://smart-cctv-rash32.chbk.app/ws/pico"
HTTP_SERVER_URL = "https://smart-cctv-rash32.chbk.app"

def check_server_connectivity():
    """Check if the external server is reachable"""
    print("🔍 Checking server connectivity...")
    
    try:
        # Test HTTP connectivity
        print(f"📡 Testing HTTPS connection to {HTTP_SERVER_URL}...")
        response = requests.get(f"{HTTP_SERVER_URL}/health", timeout=10, verify=False)
        if response.status_code == 200:
            print("✅ HTTPS server is reachable")
            return True
        else:
            print(f"⚠️ HTTPS server responded with status: {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print("❌ HTTPS connection failed - server may be down or port blocked")
        return False
    except requests.exceptions.Timeout:
        print("❌ HTTPS connection timeout - server may be slow or unreachable")
        return False
    except Exception as e:
        print(f"❌ HTTPS connection error: {e}")
        return False

async def test_websocket_connection():
    """Test WebSocket connection with authentication"""
    
    print("🔍 Testing external WebSocket connection...")
    
    # First, get the current tokens
    try:
        print("📡 Getting authentication tokens...")
        response = requests.get(f"{HTTP_SERVER_URL}/public/tokens", timeout=10, verify=False)
        if response.status_code == 200:
            tokens_data = response.json()
            pico_tokens = tokens_data.get("pico_tokens", [])
            if pico_tokens:
                token = pico_tokens[0]  # Use the first token
                print(f"✅ Got token: {token[:10]}...")
            else:
                print("❌ No Pico tokens available")
                return False
        else:
            print(f"❌ Failed to get tokens: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Error getting tokens: {e}")
        return False
    
    # Test WebSocket connection with authentication
    try:
        print("🔌 Connecting to WebSocket with authentication...")
        headers = {
            "Authorization": f"Bearer {token}"
        }
        
        async with websockets.connect(
            SERVER_URL,
            extra_headers=headers,
            ping_interval=30,
            ping_timeout=10,
            ssl=True  # Enable SSL for WSS
        ) as websocket:
            print("✅ WebSocket connected successfully!")
            
            # Send a test message
            test_message = {
                "type": "connect",
                "device": "test_pico",
                "version": "1.0.0"
            }
            await websocket.send(json.dumps(test_message))
            print("📤 Sent connection message")
            
            # Wait for response
            try:
                response = await asyncio.wait_for(websocket.recv(), timeout=5.0)
                print(f"📥 Received response: {response}")
                
                # Send ping
                ping_message = {"type": "ping"}
                await websocket.send(json.dumps(ping_message))
                print("📤 Sent ping")
                
                # Wait for pong
                try:
                    pong_response = await asyncio.wait_for(websocket.recv(), timeout=5.0)
                    print(f"📥 Received pong: {pong_response}")
                except asyncio.TimeoutError:
                    print("⚠️ No pong response received")
                
                return True
                
            except asyncio.TimeoutError:
                print("⚠️ No response received within timeout")
                return False
                
    except Exception as e:
        print(f"❌ WebSocket connection failed: {e}")
        return False

async def test_websocket_without_auth():
    """Test WebSocket connection without authentication (should fail)"""
    
    print("\n🔍 Testing WebSocket connection without authentication...")
    
    try:
        async with websockets.connect(
            SERVER_URL,
            ping_interval=30,
            ping_timeout=10,
            ssl=True  # Enable SSL for WSS
        ) as websocket:
            print("❌ Connection succeeded without auth (this should not happen)")
            return False
    except Exception as e:
        print(f"✅ Connection properly rejected without auth: {e}")
        return True

def diagnose_network_issues():
    """Diagnose potential network issues"""
    print("\n🔍 Diagnosing network issues...")
    
    # Check DNS resolution
    try:
        hostname = "smart-cctv-rash32.chbk.app"
        ip = socket.gethostbyname(hostname)
        print(f"✅ DNS resolution: {hostname} -> {ip}")
    except socket.gaierror:
        print(f"❌ DNS resolution failed for {hostname}")
        return False
    
    # Check HTTPS connectivity
    try:
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        response = requests.get(f"{HTTP_SERVER_URL}/health", timeout=10, verify=False)
        if response.status_code == 200:
            print("✅ HTTPS connectivity working")
            return True
        else:
            print(f"⚠️ HTTPS connectivity returned status: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ HTTPS connectivity test failed: {e}")
        return False

async def main():
    """Main test function"""
    print("🚀 Starting external WebSocket connection tests...")
    print(f"📍 Server URL: {SERVER_URL}")
    
    # Step 1: Check basic connectivity
    if not check_server_connectivity():
        print("\n🔍 Running network diagnostics...")
        if not diagnose_network_issues():
            print("\n❌ Network connectivity issues detected.")
            print("💡 Possible solutions:")
            print("   1. Check if the external server is running")
            print("   2. Verify the domain name and port")
            print("   3. Check firewall settings")
            print("   4. Ensure the server is accessible from external networks")
            return False
    
    # Step 2: Test WebSocket connections
    success1 = await test_websocket_connection()
    success2 = await test_websocket_without_auth()
    
    print("\n📊 Test Results:")
    print(f"✅ Authenticated connection: {'PASS' if success1 else 'FAIL'}")
    print(f"✅ Unauthenticated rejection: {'PASS' if success2 else 'FAIL'}")
    
    if success1 and success2:
        print("\n🎉 All tests passed! External WebSocket connections are working properly.")
        return True
    else:
        print("\n❌ Some tests failed. Please check the server configuration.")
        print("\n💡 Troubleshooting tips:")
        print("   1. Ensure the server is configured to accept external connections")
        print("   2. Check if the server is bound to 0.0.0.0 instead of localhost")
        print("   3. Verify firewall rules allow incoming connections")
        print("   4. Check server logs for authentication errors")
        return False

if __name__ == "__main__":
    try:
        result = asyncio.run(main())
        sys.exit(0 if result else 1)
    except KeyboardInterrupt:
        print("\n⏹️ Test interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n💥 Unexpected error: {e}")
        sys.exit(1) 