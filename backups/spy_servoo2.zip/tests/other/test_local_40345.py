#!/usr/bin/env python3
"""
Test script for local server on port 6970
"""

import asyncio
import websockets
import json
import requests
import sys

# Configuration for local testing on port 6970
SERVER_URL = "ws://localhost:6970"
HTTP_SERVER_URL = "http://localhost:6970"

async def test_websocket_connection():
    """Test WebSocket connection with authentication"""
    
    print("🔍 Testing local WebSocket connection on port 6970...")
    
    # First, get the current tokens
    try:
        print("📡 Getting authentication tokens...")
        response = requests.get(f"{HTTP_SERVER_URL}/public/tokens", timeout=10)
        if response.status_code == 200:
            tokens_data = response.json()
            pico_tokens = tokens_data.get("pico_tokens", [])
            if pico_tokens:
                token = pico_tokens[0]  # Use the first token
                print(f"✅ Got token: {token[:10]}...")
            else:
                print("❌ No Pico tokens available")
                return False
        else:
            print(f"❌ Failed to get tokens: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Error getting tokens: {e}")
        return False
    
    # Test WebSocket connection with authentication
    try:
        print("🔌 Connecting to WebSocket with authentication...")
        headers = {
            "Authorization": f"Bearer {token}"
        }
        
        async with websockets.connect(
            f"{SERVER_URL}/ws/pico",
            extra_headers=headers,
            ping_interval=30,
            ping_timeout=10
        ) as websocket:
            print("✅ WebSocket connected successfully!")
            
            # Send a test message
            test_message = {
                "type": "connect",
                "device": "test_pico_6970",
                "version": "1.0.0"
            }
            await websocket.send(json.dumps(test_message))
            print("📤 Sent connection message")
            
            # Wait for response
            try:
                response = await asyncio.wait_for(websocket.recv(), timeout=5.0)
                print(f"📥 Received response: {response}")
                
                # Send ping
                ping_message = {"type": "ping"}
                await websocket.send(json.dumps(ping_message))
                print("📤 Sent ping")
                
                # Wait for pong
                try:
                    pong_response = await asyncio.wait_for(websocket.recv(), timeout=5.0)
                    print(f"📥 Received pong: {pong_response}")
                except asyncio.TimeoutError:
                    print("⚠️ No pong response received")
                
                return True
                
            except asyncio.TimeoutError:
                print("⚠️ No response received within timeout")
                return False
                
    except Exception as e:
        print(f"❌ WebSocket connection failed: {e}")
        return False

async def test_websocket_without_auth():
    """Test WebSocket connection without authentication (should work for localhost)"""
    
    print("\n🔍 Testing WebSocket connection without authentication (localhost)...")
    
    try:
        async with websockets.connect(
            f"{SERVER_URL}/ws/pico",
            ping_interval=30,
            ping_timeout=10
        ) as websocket:
            print("✅ Connection succeeded without auth (localhost allowed)")
            
            # Send a test message
            test_message = {
                "type": "connect",
                "device": "test_pico_local_6970",
                "version": "1.0.0"
            }
            await websocket.send(json.dumps(test_message))
            print("📤 Sent connection message")
            
            # Wait for response
            try:
                response = await asyncio.wait_for(websocket.recv(), timeout=5.0)
                print(f"📥 Received response: {response}")
                return True
            except asyncio.TimeoutError:
                print("⚠️ No response received within timeout")
                return False
                
    except Exception as e:
        print(f"❌ Connection failed: {e}")
        return False

async def test_public_tokens_endpoint():
    """Test the public tokens endpoint"""
    
    print("🔍 Testing public tokens endpoint on port 6970...")
    
    try:
        response = requests.get(f"{HTTP_SERVER_URL}/public/tokens", timeout=10)
        if response.status_code == 200:
            data = response.json()
            print("✅ Public tokens endpoint working")
            print(f"📋 Pico tokens: {len(data.get('pico_tokens', []))}")
            print(f"📋 ESP32CAM tokens: {len(data.get('esp32cam_tokens', []))}")
            return True
        else:
            print(f"❌ Public tokens endpoint failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Error testing public tokens endpoint: {e}")
        return False

async def main():
    """Main test function"""
    print("🚀 Starting local WebSocket connection tests on port 6970...")
    print(f"📍 Server URL: {SERVER_URL}")
    
    # Test 1: Public tokens endpoint
    success1 = await test_public_tokens_endpoint()
    
    # Test 2: Connection with authentication
    success2 = await test_websocket_connection()
    
    # Test 3: Connection without authentication (localhost should work)
    success3 = await test_websocket_without_auth()
    
    print("\n📊 Test Results:")
    print(f"✅ Public tokens endpoint: {'PASS' if success1 else 'FAIL'}")
    print(f"✅ Authenticated connection: {'PASS' if success2 else 'FAIL'}")
    print(f"✅ Localhost connection: {'PASS' if success3 else 'FAIL'}")
    
    if success1 and success2 and success3:
        print("\n🎉 All tests passed! Local server on port 6970 is working correctly.")
        print("💡 The server is ready for external connections.")
        print("🔧 External devices can connect using:")
        print("   - WebSocket: ws://services.gen6.chabokan.net:6970/ws/pico")
        print("   - HTTP: http://services.gen6.chabokan.net:6970")
        print("   - Get tokens: http://services.gen6.chabokan.net:6970/public/tokens")
        return True
    else:
        print("\n❌ Some tests failed. Please check the server configuration.")
        return False

if __name__ == "__main__":
    try:
        result = asyncio.run(main())
        sys.exit(0 if result else 1)
    except KeyboardInterrupt:
        print("\n⏹️ Test interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n💥 Unexpected error: {e}")
        sys.exit(1) 