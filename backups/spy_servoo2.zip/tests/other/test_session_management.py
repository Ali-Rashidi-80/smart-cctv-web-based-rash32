#!/usr/bin/env python3
"""
Session Management Test Script
Tests the session management functionality for admin and regular users
"""

import requests
import json
import time
from datetime import datetime

class SessionManagementTester:
    def __init__(self, base_url="http://localhost:3000"):
        self.base_url = base_url
        self.session = requests.Session()
        self.admin_token = None
        self.user_token = None
        
    def log_test(self, test_name, status, details=""):
        """Log test results"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        status_icon = "✅" if status == "PASS" else "❌" if status == "FAIL" else "⚠️"
        print(f"{status_icon} [{timestamp}] {test_name}: {status}")
        if details:
            print(f"   Details: {details}")
        print()

    def login_and_get_token(self, username, password):
        """Login and get token"""
        try:
            response = self.session.post(f"{self.base_url}/login", json={
                "username": username,
                "password": password
            })
            
            if response.status_code == 200:
                data = response.json()
                return data.get("access_token")
            else:
                return None
        except Exception as e:
            print(f"Login error: {e}")
            return None

    def test_admin_session_persistence(self):
        """Test admin session persistence after hard reload simulation"""
        self.log_test("Admin Session Persistence", "RUNNING")
        
        # Login as admin
        self.admin_token = self.login_and_get_token("admin", "admin123")
        if not self.admin_token:
            self.log_test("Admin Session Persistence", "FAIL", "Failed to login as admin")
            return False
        
        # Test admin can access protected endpoint
        headers = {"Authorization": f"Bearer {self.admin_token}"}
        response = self.session.get(f"{self.base_url}/get_user_settings", headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            if data.get("user_role") == "admin":
                self.log_test("Admin Session Persistence", "PASS", "Admin session working correctly")
                return True
            else:
                self.log_test("Admin Session Persistence", "FAIL", "User role not admin")
                return False
        else:
            self.log_test("Admin Session Persistence", "FAIL", f"HTTP {response.status_code}")
            return False

    def test_user_session_expiration(self):
        """Test regular user session expiration on hard reload"""
        self.log_test("User Session Expiration", "RUNNING")
        
        # Login as regular user
        self.user_token = self.login_and_get_token("user", "user123")
        if not self.user_token:
            self.log_test("User Session Expiration", "FAIL", "Failed to login as user")
            return False
        
        # Test user can access protected endpoint
        headers = {"Authorization": f"Bearer {self.user_token}"}
        response = self.session.get(f"{self.base_url}/get_user_settings", headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            if data.get("user_role") == "user":
                self.log_test("User Session Expiration", "PASS", "User session working correctly")
                return True
            else:
                self.log_test("User Session Expiration", "FAIL", "User role not user")
                return False
        else:
            self.log_test("User Session Expiration", "FAIL", f"HTTP {response.status_code}")
            return False

    def test_hard_reload_simulation(self):
        """Test hard reload simulation for both user types"""
        self.log_test("Hard Reload Simulation", "RUNNING")
        
        # Test admin hard reload simulation
        if self.admin_token:
            headers = {
                "Authorization": f"Bearer {self.admin_token}",
                "Accept": "text/html",  # Simulate browser request
                "X-Requested-With": ""  # Simulate hard reload
            }
            response = self.session.get(f"{self.base_url}/", headers=headers)
            
            if response.status_code == 200:
                self.log_test("Admin Hard Reload", "PASS", "Admin can access page after hard reload")
            else:
                self.log_test("Admin Hard Reload", "FAIL", f"Admin cannot access page: HTTP {response.status_code}")
        
        # Test user hard reload simulation
        if self.user_token:
            headers = {
                "Authorization": f"Bearer {self.user_token}",
                "Accept": "text/html",  # Simulate browser request
                "X-Requested-With": ""  # Simulate hard reload
            }
            response = self.session.get(f"{self.base_url}/", headers=headers)
            
            if response.status_code == 302 and "login" in response.headers.get("Location", ""):
                self.log_test("User Hard Reload", "PASS", "User redirected to login after hard reload")
            else:
                self.log_test("User Hard Reload", "FAIL", f"User not redirected: HTTP {response.status_code}")

    def test_session_cleanup(self):
        """Test session cleanup on logout"""
        self.log_test("Session Cleanup", "RUNNING")
        
        # Test admin logout
        if self.admin_token:
            response = self.session.post(f"{self.base_url}/logout")
            if response.status_code == 200:
                self.log_test("Admin Logout", "PASS", "Admin logout successful")
            else:
                self.log_test("Admin Logout", "FAIL", f"Admin logout failed: HTTP {response.status_code}")
        
        # Test user logout
        if self.user_token:
            response = self.session.post(f"{self.base_url}/logout")
            if response.status_code == 200:
                self.log_test("User Logout", "PASS", "User logout successful")
            else:
                self.log_test("User Logout", "FAIL", f"User logout failed: HTTP {response.status_code}")

    def test_unauthorized_access(self):
        """Test unauthorized access handling"""
        self.log_test("Unauthorized Access", "RUNNING")
        
        # Test access without token
        response = self.session.get(f"{self.base_url}/get_user_settings")
        if response.status_code == 401:
            self.log_test("Unauthorized Access", "PASS", "Properly blocked unauthorized access")
        else:
            self.log_test("Unauthorized Access", "FAIL", f"Unauthorized access not blocked: HTTP {response.status_code}")

    def test_token_expiration(self):
        """Test token expiration handling"""
        self.log_test("Token Expiration", "RUNNING")
        
        # Create an expired token (this is a simulation)
        expired_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhZG1pbiIsInJvbGUiOiJhZG1pbiIsImlwIjoiMTI3LjAuMC4xIiwiZXhwIjoxNjQwOTk5OTk5fQ.invalid_signature"
        
        headers = {"Authorization": f"Bearer {expired_token}"}
        response = self.session.get(f"{self.base_url}/get_user_settings", headers=headers)
        
        if response.status_code == 401:
            self.log_test("Token Expiration", "PASS", "Expired token properly rejected")
        else:
            self.log_test("Token Expiration", "FAIL", f"Expired token not rejected: HTTP {response.status_code}")

    def run_all_tests(self):
        """Run all session management tests"""
        print("🔐 Session Management Test Suite")
        print("=" * 50)
        
        tests = [
            self.test_admin_session_persistence,
            self.test_user_session_expiration,
            self.test_hard_reload_simulation,
            self.test_session_cleanup,
            self.test_unauthorized_access,
            self.test_token_expiration
        ]
        
        passed = 0
        failed = 0
        
        for test in tests:
            try:
                if test():
                    passed += 1
                else:
                    failed += 1
            except Exception as e:
                self.log_test(test.__name__, "FAIL", f"Exception: {e}")
                failed += 1
        
        print("=" * 50)
        print(f"📊 Test Results: {passed} PASSED, {failed} FAILED")
        
        if failed == 0:
            print("🎉 All session management tests passed!")
        else:
            print("⚠️ Some tests failed. Please check the implementation.")
        
        return failed == 0

def main():
    """Main function"""
    tester = SessionManagementTester()
    
    print("Starting Session Management Tests...")
    print("Make sure the server is running on http://localhost:3000")
    print("Ensure admin and user accounts exist in the database")
    print()
    
    success = tester.run_all_tests()
    
    if success:
        print("\n✅ Session management is working correctly!")
        print("   - Admin users can hard reload without issues")
        print("   - Regular users are forced to re-login on hard reload")
        print("   - Session cleanup works properly")
        print("   - Unauthorized access is properly blocked")
    else:
        print("\n❌ Session management has issues that need to be fixed")

if __name__ == "__main__":
    main() 