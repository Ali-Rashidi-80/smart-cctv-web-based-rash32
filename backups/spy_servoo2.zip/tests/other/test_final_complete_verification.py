#!/usr/bin/env python3
"""
Final Complete System Verification
Comprehensive test of all system components after migration fix
"""

import asyncio
import aiosqlite
import json
import sqlite3
from datetime import datetime

class FinalVerificationTest:
    def __init__(self):
        self.test_results = []
        
    def log_test(self, test_name: str, status: str, details: str = ""):
        """Log test results"""
        result = {
            "test": test_name,
            "status": status,
            "details": details,
            "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        self.test_results.append(result)
        
        emoji = "✅" if status == "PASS" else "❌" if status == "FAIL" else "⚠️"
        print(f"{emoji} {test_name}: {status}")
        if details:
            print(f"   Details: {details}")
        print()

    async def test_database_migration_fix(self):
        """Test 1: Verify database migration fix"""
        print("🧪 Test 1: Database Migration Fix")
        print("=" * 40)
        
        try:
            # Check table structure
            conn = await aiosqlite.connect('smart_camera_system.db')
            cursor = await conn.execute("PRAGMA table_info(user_settings)")
            columns = await cursor.fetchall()
            
            required_columns = [
                'id', 'username', 'ip', 'theme', 'language', 'flash_settings',
                'servo1', 'servo2', 'device_mode', 'photo_quality',
                'smart_motion', 'smart_tracking', 'stream_enabled', 'updated_at'
            ]
            
            found_columns = [col[1] for col in columns]
            missing_columns = [col for col in required_columns if col not in found_columns]
            
            if not missing_columns:
                self.log_test("Database Migration Fix", "PASS", f"All {len(required_columns)} columns exist")
            else:
                self.log_test("Database Migration Fix", "FAIL", f"Missing columns: {missing_columns}")
            
            await conn.close()
            
        except Exception as e:
            self.log_test("Database Migration Fix", "FAIL", f"Error: {str(e)}")

    async def test_smart_features_save(self):
        """Test 2: Test smart features save operation"""
        print("🧪 Test 2: Smart Features Save")
        print("=" * 40)
        
        try:
            conn = await aiosqlite.connect('smart_camera_system.db')
            
            # Test saving smart features
            test_username = 'test_smart_save_user'
            test_data = {
                'username': test_username,
                'ip': '127.0.0.1',
                'smart_motion': True,
                'smart_tracking': False,
                'updated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
            await conn.execute('''
                INSERT OR REPLACE INTO user_settings 
                (username, ip, smart_motion, smart_tracking, updated_at)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                test_data['username'], test_data['ip'], 
                test_data['smart_motion'], test_data['smart_tracking'],
                test_data['updated_at']
            ))
            await conn.commit()
            
            # Verify save
            cursor = await conn.execute('''
                SELECT username, smart_motion, smart_tracking 
                FROM user_settings WHERE username = ?
            ''', (test_username,))
            result = await cursor.fetchone()
            
            if result and result[0] == test_username:
                self.log_test("Smart Features Save", "PASS", "Smart features saved successfully")
            else:
                self.log_test("Smart Features Save", "FAIL", "Failed to save smart features")
            
            # Clean up
            await conn.execute('DELETE FROM user_settings WHERE username = ?', (test_username,))
            await conn.commit()
            await conn.close()
            
        except Exception as e:
            self.log_test("Smart Features Save", "FAIL", f"Error: {str(e)}")

    async def test_user_settings_complete(self):
        """Test 3: Complete user settings test"""
        print("🧪 Test 3: Complete User Settings")
        print("=" * 40)
        
        try:
            conn = await aiosqlite.connect('smart_camera_system.db')
            
            # Test complete user settings
            test_username = 'test_complete_user'
            test_settings = {
                'username': test_username,
                'ip': '127.0.0.1',
                'theme': 'dark',
                'language': 'fa',
                'servo1': 90,
                'servo2': 90,
                'device_mode': 'desktop',
                'photo_quality': 85,
                'smart_motion': True,
                'smart_tracking': False,
                'stream_enabled': True,
                'flash_settings': json.dumps({'intensity': 75, 'enabled': True}),
                'updated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
            await conn.execute('''
                INSERT OR REPLACE INTO user_settings 
                (username, ip, theme, language, servo1, servo2, device_mode, photo_quality, 
                 smart_motion, smart_tracking, stream_enabled, flash_settings, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                test_settings['username'], test_settings['ip'], test_settings['theme'],
                test_settings['language'], test_settings['servo1'], test_settings['servo2'],
                test_settings['device_mode'], test_settings['photo_quality'],
                test_settings['smart_motion'], test_settings['smart_tracking'],
                test_settings['stream_enabled'], test_settings['flash_settings'],
                test_settings['updated_at']
            ))
            await conn.commit()
            
            # Verify complete settings
            cursor = await conn.execute('''
                SELECT username, theme, language, servo1, servo2, device_mode, 
                       photo_quality, smart_motion, smart_tracking, stream_enabled, flash_settings
                FROM user_settings WHERE username = ?
            ''', (test_username,))
            result = await cursor.fetchone()
            
            if result and result[0] == test_username:
                self.log_test("Complete User Settings", "PASS", "All settings saved and retrieved")
            else:
                self.log_test("Complete User Settings", "FAIL", "Failed to save/retrieve settings")
            
            # Clean up
            await conn.execute('DELETE FROM user_settings WHERE username = ?', (test_username,))
            await conn.commit()
            await conn.close()
            
        except Exception as e:
            self.log_test("Complete User Settings", "FAIL", f"Error: {str(e)}")

    async def test_server_import_and_migration(self):
        """Test 4: Server import and migration"""
        print("🧪 Test 4: Server Import and Migration")
        print("=" * 40)
        
        try:
            import server_fastapi
            from server_fastapi import app, init_db, migrate_user_settings_table
            
            self.log_test("Server Import", "PASS", "Server imports successfully")
            
            # Test migration
            await migrate_user_settings_table()
            self.log_test("Migration Execution", "PASS", "Migration executed successfully")
            
            # Test database initialization
            await init_db()
            self.log_test("Database Initialization", "PASS", "Database initialized successfully")
            
        except Exception as e:
            self.log_test("Server Import and Migration", "FAIL", f"Error: {str(e)}")

    async def test_api_endpoints_availability(self):
        """Test 5: API endpoints availability"""
        print("🧪 Test 5: API Endpoints")
        print("=" * 40)
        
        try:
            import server_fastapi
            from server_fastapi import app
            
            routes = [route.path for route in app.routes]
            
            required_endpoints = [
                '/get_user_settings',
                '/save_user_settings',
                '/set_smart_features',
                '/get_smart_features',
                '/health',
                '/get_status'
            ]
            
            missing_endpoints = [ep for ep in required_endpoints if ep not in routes]
            
            if not missing_endpoints:
                self.log_test("API Endpoints", "PASS", f"All {len(required_endpoints)} endpoints available")
            else:
                self.log_test("API Endpoints", "FAIL", f"Missing: {missing_endpoints}")
                
        except Exception as e:
            self.log_test("API Endpoints", "FAIL", f"Error: {str(e)}")

    async def test_multiple_users_isolation(self):
        """Test 6: Multiple users isolation"""
        print("🧪 Test 6: Multiple Users Isolation")
        print("=" * 40)
        
        try:
            conn = await aiosqlite.connect('smart_camera_system.db')
            
            # Create multiple users with different settings
            users_data = [
                ('test_user_a', 'dark', 'fa', 90, 90, 'desktop', True, False, True),
                ('test_user_b', 'light', 'en', 45, 135, 'mobile', False, True, False),
                ('test_user_c', 'dark', 'en', 180, 0, 'desktop', True, True, True)
            ]
            
            for username, theme, lang, servo1, servo2, device_mode, motion, tracking, stream in users_data:
                await conn.execute('''
                    INSERT OR REPLACE INTO user_settings 
                    (username, ip, theme, language, servo1, servo2, device_mode, 
                     smart_motion, smart_tracking, stream_enabled, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (username, '127.0.0.1', theme, lang, servo1, servo2, device_mode, 
                     motion, tracking, stream, datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            
            await conn.commit()
            
            # Verify isolation
            cursor = await conn.execute('''
                SELECT username, theme, language, smart_motion, smart_tracking, stream_enabled
                FROM user_settings WHERE username IN ('test_user_a', 'test_user_b', 'test_user_c')
                ORDER BY username
            ''')
            results = await cursor.fetchall()
            
            if len(results) == 3:
                # Check that users have different settings
                themes = [r[1] for r in results]
                languages = [r[2] for r in results]
                motions = [r[3] for r in results]
                
                if len(set(themes)) > 1 and len(set(languages)) > 1:
                    self.log_test("Multiple Users Isolation", "PASS", "Users have different settings")
                else:
                    self.log_test("Multiple Users Isolation", "FAIL", "Users have identical settings")
            else:
                self.log_test("Multiple Users Isolation", "FAIL", f"Expected 3 users, got {len(results)}")
            
            # Clean up
            for username, _, _, _, _, _, _, _, _ in users_data:
                await conn.execute('DELETE FROM user_settings WHERE username = ?', (username,))
            await conn.commit()
            await conn.close()
            
        except Exception as e:
            self.log_test("Multiple Users Isolation", "FAIL", f"Error: {str(e)}")

    def generate_final_report(self):
        """Generate comprehensive final report"""
        print("\n" + "=" * 70)
        print("📊 FINAL COMPLETE VERIFICATION REPORT")
        print("=" * 70)
        
        total_tests = len(self.test_results)
        passed_tests = len([r for r in self.test_results if r['status'] == 'PASS'])
        failed_tests = len([r for r in self.test_results if r['status'] == 'FAIL'])
        
        print(f"Total Tests: {total_tests}")
        print(f"Passed: {passed_tests} ✅")
        print(f"Failed: {failed_tests} ❌")
        print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        
        if failed_tests > 0:
            print("\n❌ Failed Tests:")
            for result in self.test_results:
                if result['status'] == 'FAIL':
                    print(f"  - {result['test']}: {result['details']}")
        
        print("\n✅ All Tests Summary:")
        for result in self.test_results:
            emoji = "✅" if result['status'] == "PASS" else "❌"
            print(f"  {emoji} {result['test']}")
        
        if failed_tests == 0:
            print("\n🎉 ALL TESTS PASSED! System is fully operational!")
            print("✅ Database migration fixed")
            print("✅ Smart features working")
            print("✅ User settings isolated")
            print("✅ API endpoints available")
            print("✅ Server ready for production")
        else:
            print(f"\n⚠️  {failed_tests} test(s) failed. Please review and fix issues.")

async def main():
    """Run complete verification"""
    print("🚀 Starting Final Complete System Verification")
    print("=" * 70)
    
    tester = FinalVerificationTest()
    
    # Run all verification tests
    await tester.test_database_migration_fix()
    await tester.test_smart_features_save()
    await tester.test_user_settings_complete()
    await tester.test_server_import_and_migration()
    await tester.test_api_endpoints_availability()
    await tester.test_multiple_users_isolation()
    
    # Generate final report
    tester.generate_final_report()

if __name__ == "__main__":
    asyncio.run(main()) 