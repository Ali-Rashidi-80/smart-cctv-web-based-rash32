#!/usr/bin/env python3
"""
Simple test script to check server startup
"""

import asyncio
import aiosqlite
import os
import sys

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

async def test_database():
    """Test database connection and tables"""
    print("🔍 Testing database...")
    
    try:
        # Test database connection
        conn = await aiosqlite.connect("smart_camera_system.db")
        print("✅ Database connection successful")
        
        # Check tables
        cursor = await conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = await cursor.fetchall()
        table_names = [table[0] for table in tables]
        
        required_tables = ['users', 'camera_logs', 'password_recovery', 'servo_commands', 
                          'action_commands', 'device_mode_commands', 'manual_photos', 
                          'security_videos', 'user_settings']
        
        print("📊 Checking tables:")
        for table in required_tables:
            if table in table_names:
                print(f"   ✅ {table}")
            else:
                print(f"   ❌ {table} - missing")
        
        # Check admin user
        cursor = await conn.execute("SELECT COUNT(*) FROM users WHERE role = 'admin'")
        admin_count = await cursor.fetchone()
        if admin_count[0] > 0:
            print("   ✅ Admin user exists")
        else:
            print("   ❌ Admin user missing")
        
        await conn.close()
        print("✅ Database test completed")
        return True
        
    except Exception as e:
        print(f"❌ Database test failed: {e}")
        return False

async def test_environment():
    """Test environment variables"""
    print("🔍 Testing environment...")
    
    required_vars = ['SECRET_KEY', 'ADMIN_USERNAME', 'ADMIN_PASSWORD']
    optional_vars = ['GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET']
    
    print("📊 Checking required environment variables:")
    for var in required_vars:
        if os.getenv(var):
            print(f"   ✅ {var}")
        else:
            print(f"   ❌ {var} - missing")
    
    print("📊 Checking optional environment variables:")
    for var in optional_vars:
        if os.getenv(var):
            print(f"   ✅ {var}")
        else:
            print(f"   ⚠️ {var} - not set (optional)")
    
    print("✅ Environment test completed")
    return True

async def main():
    """Main test function"""
    print("🚀 Starting server startup test...")
    print("=" * 50)
    
    # Test environment
    env_ok = await test_environment()
    print()
    
    # Test database
    db_ok = await test_database()
    print()
    
    if env_ok and db_ok:
        print("🎉 All tests passed! Server should start correctly.")
        print("💡 To start the server, run: python server_fastapi.py")
    else:
        print("❌ Some tests failed. Please fix the issues before starting the server.")
        if not db_ok:
            print("💡 Try running: python reset_database.py")

if __name__ == "__main__":
    asyncio.run(main()) 