#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Comprehensive Database Reset and Verification Script
بازنشانی و راه‌اندازی مجدد کامل دیتابیس
"""

import asyncio
import os
import aiosqlite
import shutil
from datetime import datetime
import sys

# Add the current directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import necessary functions from server_fastapi
try:
    from server_fastapi import (
        DB_FILE, BACKUP_DIR, GALLERY_DIR, SECURITY_VIDEOS_DIR,
        hash_password, get_jalali_now_str, generate_secure_credentials
    )
except ImportError as e:
    print(f"❌ Error importing from server_fastapi: {e}")
    print("Make sure you're running this script from the project root directory")
    sys.exit(1)

async def reset_database():
    """بازنشانی و راه‌اندازی مجدد کامل دیتابیس"""
    print("🔄 بازنشانی کامل دیتابیس")
    print("=" * 60)
    
    # Create backup of existing database
    if os.path.exists(DB_FILE):
        backup_name = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
        backup_path = os.path.join(BACKUP_DIR, backup_name)
        
        try:
            os.makedirs(BACKUP_DIR, exist_ok=True)
            shutil.copy2(DB_FILE, backup_path)
            print(f"✅ فایل دیتابیس موجود در {backup_path} پشتیبان‌گیری شد")
        except Exception as e:
            print(f"⚠️ خطا در پشتیبان‌گیری: {e}")
    
    # Remove existing database file
    if os.path.exists(DB_FILE):
        try:
            os.remove(DB_FILE)
            print(f"✅ فایل دیتابیس {DB_FILE} حذف شد")
        except Exception as e:
            print(f"❌ خطا در حذف فایل دیتابیس: {e}")
            return False
    else:
        print(f"ℹ️ فایل دیتابیس {DB_FILE} وجود نداشت")
    
    # Create necessary directories
    directories = [BACKUP_DIR, GALLERY_DIR, SECURITY_VIDEOS_DIR, "logs"]
    for directory in directories:
        try:
            os.makedirs(directory, exist_ok=True)
            print(f"✅ دایرکتوری {directory} ایجاد شد")
        except Exception as e:
            print(f"⚠️ خطا در ایجاد دایرکتوری {directory}: {e}")
    
    # Generate admin credentials if needed
    credentials_file = "admin_credentials.txt"
    if not os.path.exists(credentials_file):
        try:
            SECRET_KEY, ADMIN_USERNAME, ADMIN_PASSWORD = generate_secure_credentials()
            
            with open(credentials_file, 'w', encoding='utf-8') as f:
                f.write(f"SECRET_KEY={SECRET_KEY}\n")
                f.write(f"ADMIN_USERNAME={ADMIN_USERNAME}\n")
                f.write(f"ADMIN_PASSWORD={ADMIN_PASSWORD}\n")
            
            print("🔐 اطلاعات امنیتی جدید ایجاد شد:")
            print(f"   Admin Username: {ADMIN_USERNAME}")
            print(f"   Admin Password: {ADMIN_PASSWORD}")
        except Exception as e:
            print(f"⚠️ خطا در ایجاد اطلاعات امنیتی: {e}")
            # Use default credentials
            ADMIN_USERNAME = "admin"
            ADMIN_PASSWORD = "admin123"
    else:
        # Read existing credentials
        try:
            with open(credentials_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()
                for line in lines:
                    if line.startswith("ADMIN_USERNAME="):
                        ADMIN_USERNAME = line.split("=", 1)[1].strip()
                    elif line.startswith("ADMIN_PASSWORD="):
                        ADMIN_PASSWORD = line.split("=", 1)[1].strip()
            print(f"✅ اطلاعات امنیتی موجود خوانده شد: {ADMIN_USERNAME}")
        except Exception as e:
            print(f"⚠️ خطا در خواندن اطلاعات امنیتی: {e}")
            ADMIN_USERNAME = "admin"
            ADMIN_PASSWORD = "admin123"
    
    # Create new database
    try:
        conn = await aiosqlite.connect(DB_FILE)
        print("✅ اتصال به دیتابیس جدید برقرار شد")
        
        # Enable WAL mode for better concurrency
        await conn.execute("PRAGMA journal_mode=WAL")
        await conn.execute("PRAGMA synchronous=NORMAL")
        await conn.execute("PRAGMA cache_size=10000")
        await conn.execute("PRAGMA temp_store=MEMORY")
        await conn.execute("PRAGMA foreign_keys=ON")
        await conn.execute("PRAGMA busy_timeout=30000")
        
        print("🗄️ ایجاد جداول دیتابیس...")
        
        # Create users table
        await conn.execute("""CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            phone TEXT UNIQUE,
            password_hash TEXT NOT NULL,
            role TEXT DEFAULT 'user',
            is_active BOOLEAN DEFAULT 1,
            two_fa_enabled BOOLEAN DEFAULT 0,
            two_fa_secret TEXT,
            created_at TEXT NOT NULL
        )""")
        print("✅ جدول users ایجاد شد")
        
        # Create password_recovery table
        await conn.execute("""CREATE TABLE IF NOT EXISTS password_recovery (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone TEXT NOT NULL,
            token TEXT UNIQUE NOT NULL,
            expires_at TEXT NOT NULL,
            used BOOLEAN DEFAULT 0,
            created_at TEXT NOT NULL
        )""")
        print("✅ جدول password_recovery ایجاد شد")
        
        # Create camera_logs table
        await conn.execute("""CREATE TABLE IF NOT EXISTS camera_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message TEXT NOT NULL,
            log_type TEXT NOT NULL,
            created_at TEXT DEFAULT '',
            source TEXT DEFAULT 'server',
            pico_timestamp TEXT DEFAULT NULL
        )""")
        print("✅ جدول camera_logs ایجاد شد")
        
        # Create servo_commands table
        await conn.execute("""CREATE TABLE IF NOT EXISTS servo_commands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            servo1 INTEGER NOT NULL,
            servo2 INTEGER NOT NULL,
            created_at TEXT DEFAULT '',
            processed INTEGER DEFAULT 0
        )""")
        print("✅ جدول servo_commands ایجاد شد")
        
        # Create action_commands table
        await conn.execute("""CREATE TABLE IF NOT EXISTS action_commands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT NOT NULL,
            intensity INTEGER DEFAULT 50,
            created_at TEXT DEFAULT '',
            processed INTEGER DEFAULT 0
        )""")
        print("✅ جدول action_commands ایجاد شد")
        
        # Create device_mode_commands table
        await conn.execute("""CREATE TABLE IF NOT EXISTS device_mode_commands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_mode TEXT NOT NULL,
            created_at TEXT DEFAULT '',
            processed INTEGER DEFAULT 0
        )""")
        print("✅ جدول device_mode_commands ایجاد شد")
        
        # Create manual_photos table
        await conn.execute("""CREATE TABLE IF NOT EXISTS manual_photos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            filepath TEXT NOT NULL,
            quality INTEGER DEFAULT 80,
            flash_used BOOLEAN DEFAULT FALSE,
            flash_intensity INTEGER DEFAULT 50,
            created_at TEXT DEFAULT ''
        )""")
        print("✅ جدول manual_photos ایجاد شد")
        
        # Create security_videos table
        await conn.execute("""CREATE TABLE IF NOT EXISTS security_videos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            filepath TEXT NOT NULL,
            hour_of_day INTEGER NOT NULL,
            duration INTEGER DEFAULT 3600,
            created_at TEXT DEFAULT ''
        )""")
        print("✅ جدول security_videos ایجاد شد")
        
        # Create user_settings table
        await conn.execute("""CREATE TABLE IF NOT EXISTS user_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ip TEXT NOT NULL,
            theme TEXT DEFAULT 'light',
            language TEXT DEFAULT 'fa',
            flash_settings TEXT DEFAULT '{}',
            servo1 INTEGER,
            servo2 INTEGER,
            device_mode TEXT DEFAULT 'desktop',
            updated_at TEXT DEFAULT ''
        )""")
        print("✅ جدول user_settings ایجاد شد")
        
        # Create admin user
        admin_password_hash = hash_password(ADMIN_PASSWORD)
        await conn.execute('''
            INSERT INTO users (username, phone, password_hash, role, is_active, created_at)
            VALUES (?, ?, ?, 'admin', 1, ?)
        ''', (ADMIN_USERNAME, "+989966902209", admin_password_hash, get_jalali_now_str()))
        print(f"✅ کاربر ادمین '{ADMIN_USERNAME}' ایجاد شد")
        
        # Insert initial log entry
        await conn.execute('''
            INSERT INTO camera_logs (message, log_type, created_at, source)
            VALUES (?, ?, ?, ?)
        ''', ("Database reset and initialized successfully", "INFO", get_jalali_now_str(), "system"))
        print("✅ ورود اولیه لاگ ایجاد شد")
        
        # Commit all changes
        await conn.commit()
        await conn.close()
        
        print("🎉 دیتابیس با موفقیت بازنشانی شد!")
        print("=" * 60)
        print("📋 اطلاعات ورود:")
        print(f"   Username: {ADMIN_USERNAME}")
        print(f"   Password: {ADMIN_PASSWORD}")
        print("=" * 60)
        
        return True
        
    except Exception as e:
        print(f"❌ خطا در بازنشانی دیتابیس: {e}")
        return False

async def verify_database():
    """تأیید صحت دیتابیس و جداول"""
    print("\n🔍 تأیید صحت دیتابیس...")
    print("=" * 40)
    
    try:
        conn = await aiosqlite.connect(DB_FILE)
        
        # Check if database file exists
        if not os.path.exists(DB_FILE):
            print("❌ فایل دیتابیس وجود ندارد")
            return False
        
        # Get list of tables
        cursor = await conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = await cursor.fetchall()
        table_names = [table[0] for table in tables]
        
        required_tables = [
            'users', 'password_recovery', 'camera_logs', 'servo_commands',
            'action_commands', 'device_mode_commands', 'manual_photos',
            'security_videos', 'user_settings'
        ]
        
        print("📊 بررسی جداول:")
        all_tables_exist = True
        for table in required_tables:
            if table in table_names:
                print(f"   ✅ {table}")
            else:
                print(f"   ❌ {table} - وجود ندارد")
                all_tables_exist = False
        
        # Check admin user
        cursor = await conn.execute("SELECT COUNT(*) FROM users WHERE role = 'admin'")
        admin_count = await cursor.fetchone()
        if admin_count[0] > 0:
            print("   ✅ کاربر ادمین وجود دارد")
        else:
            print("   ❌ کاربر ادمین وجود ندارد")
            all_tables_exist = False
        
        # Check initial log
        cursor = await conn.execute("SELECT COUNT(*) FROM camera_logs")
        log_count = await cursor.fetchone()
        if log_count[0] > 0:
            print("   ✅ لاگ‌های اولیه وجود دارد")
        else:
            print("   ⚠️ لاگ‌های اولیه وجود ندارد")
        
        await conn.close()
        
        if all_tables_exist:
            print("\n🎉 دیتابیس به درستی تأیید شد!")
            return True
        else:
            print("\n❌ مشکلاتی در دیتابیس یافت شد")
            return False
            
    except Exception as e:
        print(f"❌ خطا در تأیید دیتابیس: {e}")
        return False

async def main():
    """تابع اصلی"""
    print("🚀 شروع بازنشانی کامل دیتابیس")
    print("=" * 60)
    
    # Reset database
    success = await reset_database()
    
    if success:
        # Verify database
        verification_success = await verify_database()
        
        if verification_success:
            print("\n🎉 عملیات با موفقیت کامل شد!")
            print("✅ دیتابیس بازنشانی و تأیید شد")
            print("🚀 آماده برای راه‌اندازی سرور")
        else:
            print("\n⚠️ دیتابیس بازنشانی شد اما تأیید نشد")
            print("🔧 لطفاً سرور را مجدداً راه‌اندازی کنید")
    else:
        print("\n❌ عملیات بازنشانی ناموفق بود")
        print("🔧 لطفاً خطاها را بررسی کنید")

if __name__ == "__main__":
    asyncio.run(main()) 