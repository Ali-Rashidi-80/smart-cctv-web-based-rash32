#!/usr/bin/env python3
"""
Comprehensive Test Suite for Smart Camera System
Tests servo operations, manual photo capture, frame streaming, and all commands
under continuous load with detailed logging and error tracking.
"""

import asyncio
import aiohttp
import json
import time
import logging
import os
import sys
from datetime import datetime
from typing import Dict, List, Any
import websockets
import threading
import queue
import random
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
import traceback

# Configure comprehensive logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(f'comprehensive_test_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)

@dataclass
class TestResult:
    test_name: str
    success: bool
    duration: float
    error: str = None
    details: Dict = None

class ComprehensiveTestSuite:
    def __init__(self, base_url: str = "http://localhost:3000"):
        self.base_url = base_url
        self.ws_url = f"ws://localhost:3000/ws"
        self.pico_ws_url = f"ws://localhost:3000/ws/pico"
        self.esp32cam_ws_url = f"ws://localhost:3000/ws/esp32cam"
        self.session = None
        self.websocket = None
        self.pico_websocket = None
        self.esp32cam_websocket = None
        self.test_results: List[TestResult] = []
        self.frame_queue = queue.Queue()
        self.is_streaming = False
        self.streaming_thread = None
        self.auth_token = None
        self.test_start_time = None
        
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
        if self.websocket:
            await self.websocket.close()
        if self.pico_websocket:
            await self.pico_websocket.close()
        if self.esp32cam_websocket:
            await self.esp32cam_websocket.close()

    async def login(self) -> bool:
        """Login to get authentication token"""
        try:
            login_data = {
                "username": "rof642fr",
                "password": "5qEKU@A@Tv"
            }
            
            async with self.session.post(f"{self.base_url}/login", json=login_data) as response:
                if response.status == 200:
                    data = await response.json()
                    self.auth_token = data.get("access_token")
                    logger.info(f"Login successful, token: {self.auth_token[:20]}...")
                    return True
                else:
                    logger.error(f"Login failed: {response.status}")
                    return False
        except Exception as e:
            logger.error(f"Login error: {e}")
            return False

    async def test_server_health(self) -> TestResult:
        """Test server health and basic connectivity"""
        start_time = time.time()
        try:
            async with self.session.get(f"{self.base_url}/health") as response:
                if response.status == 200:
                    data = await response.json()
                    logger.info(f"Server health: {data}")
                    return TestResult(
                        test_name="Server Health Check",
                        success=True,
                        duration=time.time() - start_time,
                        details=data
                    )
                else:
                    return TestResult(
                        test_name="Server Health Check",
                        success=False,
                        duration=time.time() - start_time,
                        error=f"Status: {response.status}"
                    )
        except Exception as e:
            return TestResult(
                test_name="Server Health Check",
                success=False,
                duration=time.time() - start_time,
                error=str(e)
            )

    async def test_websocket_connection(self) -> TestResult:
        """Test WebSocket connection"""
        start_time = time.time()
        try:
            self.websocket = await websockets.connect(self.ws_url)
            await self.websocket.ping()
            logger.info("WebSocket connection established")
            return TestResult(
                test_name="WebSocket Connection",
                success=True,
                duration=time.time() - start_time
            )
        except Exception as e:
            return TestResult(
                test_name="WebSocket Connection",
                success=False,
                duration=time.time() - start_time,
                error=str(e)
            )

    async def test_pico_websocket_connection(self) -> TestResult:
        """Test Pico WebSocket connection"""
        start_time = time.time()
        try:
            self.pico_websocket = await websockets.connect(self.pico_ws_url)
            await self.pico_websocket.ping()
            logger.info("Pico WebSocket connection established")
            return TestResult(
                test_name="Pico WebSocket Connection",
                success=True,
                duration=time.time() - start_time
            )
        except Exception as e:
            return TestResult(
                test_name="Pico WebSocket Connection",
                success=False,
                duration=time.time() - start_time,
                error=str(e)
            )

    async def test_esp32cam_websocket_connection(self) -> TestResult:
        """Test ESP32CAM WebSocket connection"""
        start_time = time.time()
        try:
            self.esp32cam_websocket = await websockets.connect(self.esp32cam_ws_url)
            await self.esp32cam_websocket.ping()
            logger.info("ESP32CAM WebSocket connection established")
            return TestResult(
                test_name="ESP32CAM WebSocket Connection",
                success=True,
                duration=time.time() - start_time
            )
        except Exception as e:
            return TestResult(
                test_name="ESP32CAM WebSocket Connection",
                success=False,
                duration=time.time() - start_time,
                error=str(e)
            )

    async def test_servo_commands(self) -> List[TestResult]:
        """Test all servo commands"""
        results = []
        
        # Test servo positions
        servo_positions = [
            (90, 90), (0, 0), (180, 180), (45, 135), (135, 45),
            (30, 150), (150, 30), (60, 120), (120, 60)
        ]
        
        for i, (servo1, servo2) in enumerate(servo_positions):
            start_time = time.time()
            try:
                command = {"servo1": servo1, "servo2": servo2}
                headers = {"Authorization": f"Bearer {self.auth_token}"} if self.auth_token else {}
                
                async with self.session.post(f"{self.base_url}/set_servo", json=command, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        logger.info(f"Servo command {i+1}: {servo1}, {servo2} - Success")
                        results.append(TestResult(
                            test_name=f"Servo Command {i+1} ({servo1}, {servo2})",
                            success=True,
                            duration=time.time() - start_time,
                            details=data
                        ))
                    else:
                        logger.error(f"Servo command {i+1} failed: {response.status}")
                        results.append(TestResult(
                            test_name=f"Servo Command {i+1} ({servo1}, {servo2})",
                            success=False,
                            duration=time.time() - start_time,
                            error=f"Status: {response.status}"
                        ))
                        
                # Wait between commands
                await asyncio.sleep(0.5)
                
            except Exception as e:
                logger.error(f"Servo command {i+1} error: {e}")
                results.append(TestResult(
                    test_name=f"Servo Command {i+1} ({servo1}, {servo2})",
                    success=False,
                    duration=time.time() - start_time,
                    error=str(e)
                ))
        
        return results

    async def test_action_commands(self) -> List[TestResult]:
        """Test all action commands"""
        results = []
        
        actions = ["buzzer", "led", "motor", "relay", "custom"]
        intensities = [0, 25, 50, 75, 100]
        
        for action in actions:
            for intensity in intensities:
                start_time = time.time()
                try:
                    command = {"action": action, "intensity": intensity}
                    headers = {"Authorization": f"Bearer {self.auth_token}"} if self.auth_token else {}
                    
                    async with self.session.post(f"{self.base_url}/set_action", json=command, headers=headers) as response:
                        if response.status == 200:
                            data = await response.json()
                            logger.info(f"Action command: {action} intensity {intensity} - Success")
                            results.append(TestResult(
                                test_name=f"Action Command ({action}, {intensity})",
                                success=True,
                                duration=time.time() - start_time,
                                details=data
                            ))
                        else:
                            logger.error(f"Action command failed: {response.status}")
                            results.append(TestResult(
                                test_name=f"Action Command ({action}, {intensity})",
                                success=False,
                                duration=time.time() - start_time,
                                error=f"Status: {response.status}"
                            ))
                            
                    await asyncio.sleep(0.3)
                    
                except Exception as e:
                    logger.error(f"Action command error: {e}")
                    results.append(TestResult(
                        test_name=f"Action Command ({action}, {intensity})",
                        success=False,
                        duration=time.time() - start_time,
                        error=str(e)
                    ))
        
        return results

    async def test_manual_photo_capture(self) -> List[TestResult]:
        """Test manual photo capture with different parameters"""
        results = []
        
        photo_configs = [
            {"quality": 50, "flash": False, "intensity": 0},
            {"quality": 80, "flash": True, "intensity": 50},
            {"quality": 100, "flash": True, "intensity": 100},
            {"quality": 60, "flash": False, "intensity": 0},
            {"quality": 90, "flash": True, "intensity": 75}
        ]
        
        for i, config in enumerate(photo_configs):
            start_time = time.time()
            try:
                headers = {"Authorization": f"Bearer {self.auth_token}"} if self.auth_token else {}
                
                async with self.session.post(f"{self.base_url}/manual_photo", json=config, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        logger.info(f"Manual photo {i+1}: {config} - Success")
                        results.append(TestResult(
                            test_name=f"Manual Photo {i+1} ({config})",
                            success=True,
                            duration=time.time() - start_time,
                            details=data
                        ))
                    else:
                        logger.error(f"Manual photo {i+1} failed: {response.status}")
                        results.append(TestResult(
                            test_name=f"Manual Photo {i+1} ({config})",
                            success=False,
                            duration=time.time() - start_time,
                            error=f"Status: {response.status}"
                        ))
                        
                await asyncio.sleep(1.0)  # Wait longer for photo processing
                
            except Exception as e:
                logger.error(f"Manual photo {i+1} error: {e}")
                results.append(TestResult(
                    test_name=f"Manual Photo {i+1} ({config})",
                    success=False,
                    duration=time.time() - start_time,
                    error=str(e)
                ))
        
        return results

    async def test_device_mode_commands(self) -> List[TestResult]:
        """Test device mode commands"""
        results = []
        
        modes = ["desktop", "mobile"]
        
        for mode in modes:
            start_time = time.time()
            try:
                command = {"device_mode": mode}
                headers = {"Authorization": f"Bearer {self.auth_token}"} if self.auth_token else {}
                
                async with self.session.post(f"{self.base_url}/set_device_mode", json=command, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        logger.info(f"Device mode: {mode} - Success")
                        results.append(TestResult(
                            test_name=f"Device Mode ({mode})",
                            success=True,
                            duration=time.time() - start_time,
                            details=data
                        ))
                    else:
                        logger.error(f"Device mode failed: {response.status}")
                        results.append(TestResult(
                            test_name=f"Device Mode ({mode})",
                            success=False,
                            duration=time.time() - start_time,
                            error=f"Status: {response.status}"
                        ))
                        
                await asyncio.sleep(0.5)
                
            except Exception as e:
                logger.error(f"Device mode error: {e}")
                results.append(TestResult(
                    test_name=f"Device Mode ({mode})",
                    success=False,
                    duration=time.time() - start_time,
                    error=str(e)
                ))
        
        return results

    async def test_smart_features(self) -> List[TestResult]:
        """Test smart features commands"""
        results = []
        
        feature_configs = [
            {"motion": True, "tracking": False},
            {"motion": False, "tracking": True},
            {"motion": True, "tracking": True},
            {"motion": False, "tracking": False}
        ]
        
        for i, config in enumerate(feature_configs):
            start_time = time.time()
            try:
                headers = {"Authorization": f"Bearer {self.auth_token}"} if self.auth_token else {}
                
                async with self.session.post(f"{self.base_url}/set_smart_features", json=config, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        logger.info(f"Smart features {i+1}: {config} - Success")
                        results.append(TestResult(
                            test_name=f"Smart Features {i+1} ({config})",
                            success=True,
                            duration=time.time() - start_time,
                            details=data
                        ))
                    else:
                        logger.error(f"Smart features {i+1} failed: {response.status}")
                        results.append(TestResult(
                            test_name=f"Smart Features {i+1} ({config})",
                            success=False,
                            duration=time.time() - start_time,
                            error=f"Status: {response.status}"
                        ))
                        
                await asyncio.sleep(0.5)
                
            except Exception as e:
                logger.error(f"Smart features {i+1} error: {e}")
                results.append(TestResult(
                    test_name=f"Smart Features {i+1} ({config})",
                    success=False,
                    duration=time.time() - start_time,
                    error=str(e)
                ))
        
        return results

    async def test_gallery_operations(self) -> List[TestResult]:
        """Test gallery operations"""
        results = []
        
        # Test get gallery
        start_time = time.time()
        try:
            headers = {"Authorization": f"Bearer {self.auth_token}"} if self.auth_token else {}
            async with self.session.get(f"{self.base_url}/get_gallery?page=0&limit=10", headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    logger.info(f"Gallery fetch - Success, {len(data.get('photos', []))} photos")
                    results.append(TestResult(
                        test_name="Get Gallery",
                        success=True,
                        duration=time.time() - start_time,
                        details={"photo_count": len(data.get('photos', []))}
                    ))
                else:
                    results.append(TestResult(
                        test_name="Get Gallery",
                        success=False,
                        duration=time.time() - start_time,
                        error=f"Status: {response.status}"
                    ))
        except Exception as e:
            results.append(TestResult(
                test_name="Get Gallery",
                success=False,
                duration=time.time() - start_time,
                error=str(e)
            ))

        # Test get videos
        start_time = time.time()
        try:
            async with self.session.get(f"{self.base_url}/get_videos?page=0&limit=5", headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    logger.info(f"Videos fetch - Success, {len(data.get('videos', []))} videos")
                    results.append(TestResult(
                        test_name="Get Videos",
                        success=True,
                        duration=time.time() - start_time,
                        details={"video_count": len(data.get('videos', []))}
                    ))
                else:
                    results.append(TestResult(
                        test_name="Get Videos",
                        success=False,
                        duration=time.time() - start_time,
                        error=f"Status: {response.status}"
                    ))
        except Exception as e:
            results.append(TestResult(
                test_name="Get Videos",
                success=False,
                duration=time.time() - start_time,
                error=str(e)
            ))

        return results

    async def test_logs_operations(self) -> List[TestResult]:
        """Test logs operations"""
        results = []
        
        # Test get logs
        start_time = time.time()
        try:
            headers = {"Authorization": f"Bearer {self.auth_token}"} if self.auth_token else {}
            async with self.session.get(f"{self.base_url}/get_logs?limit=50", headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    logger.info(f"Logs fetch - Success, {len(data.get('logs', []))} logs")
                    results.append(TestResult(
                        test_name="Get Logs",
                        success=True,
                        duration=time.time() - start_time,
                        details={"log_count": len(data.get('logs', []))}
                    ))
                else:
                    results.append(TestResult(
                        test_name="Get Logs",
                        success=False,
                        duration=time.time() - start_time,
                        error=f"Status: {response.status}"
                    ))
        except Exception as e:
            results.append(TestResult(
                test_name="Get Logs",
                success=False,
                duration=time.time() - start_time,
                error=str(e)
            ))

        return results

    async def test_user_settings(self) -> List[TestResult]:
        """Test user settings operations"""
        results = []
        
        # Test get settings
        start_time = time.time()
        try:
            headers = {"Authorization": f"Bearer {self.auth_token}"} if self.auth_token else {}
            async with self.session.get(f"{self.base_url}/get_user_settings", headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    logger.info(f"Get settings - Success")
                    results.append(TestResult(
                        test_name="Get User Settings",
                        success=True,
                        duration=time.time() - start_time,
                        details=data
                    ))
                else:
                    results.append(TestResult(
                        test_name="Get User Settings",
                        success=False,
                        duration=time.time() - start_time,
                        error=f"Status: {response.status}"
                    ))
        except Exception as e:
            results.append(TestResult(
                test_name="Get User Settings",
                success=False,
                duration=time.time() - start_time,
                error=str(e)
            ))

        # Test save settings
        start_time = time.time()
        try:
            settings = {
                "device_mode": "desktop",
                "theme": "light",
                "language": "fa",
                "servo1": 90,
                "servo2": 90,
                "photoQuality": 80,
                "smart_motion": True,
                "smart_tracking": False,
                "stream_enabled": True
            }
            
            async with self.session.post(f"{self.base_url}/save_user_settings", json=settings, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    logger.info(f"Save settings - Success")
                    results.append(TestResult(
                        test_name="Save User Settings",
                        success=True,
                        duration=time.time() - start_time,
                        details=data
                    ))
                else:
                    results.append(TestResult(
                        test_name="Save User Settings",
                        success=False,
                        duration=time.time() - start_time,
                        error=f"Status: {response.status}"
                    ))
        except Exception as e:
            results.append(TestResult(
                test_name="Save User Settings",
                success=False,
                duration=time.time() - start_time,
                error=str(e)
            ))

        return results

    async def test_system_status(self) -> List[TestResult]:
        """Test system status endpoints"""
        results = []
        
        status_endpoints = [
            "/get_status",
            "/get_photo_count",
            "/devices/status",
            "/system/performance",
            "/performance_metrics"
        ]
        
        for endpoint in status_endpoints:
            start_time = time.time()
            try:
                headers = {"Authorization": f"Bearer {self.auth_token}"} if self.auth_token else {}
                async with self.session.get(f"{self.base_url}{endpoint}", headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        logger.info(f"Status {endpoint} - Success")
                        results.append(TestResult(
                            test_name=f"System Status {endpoint}",
                            success=True,
                            duration=time.time() - start_time,
                            details=data
                        ))
                    else:
                        results.append(TestResult(
                            test_name=f"System Status {endpoint}",
                            success=False,
                            duration=time.time() - start_time,
                            error=f"Status: {response.status}"
                        ))
            except Exception as e:
                results.append(TestResult(
                    test_name=f"System Status {endpoint}",
                    success=False,
                    duration=time.time() - start_time,
                    error=str(e)
                ))

        return results

    async def simulate_frame_streaming(self, duration: int = 30):
        """Simulate continuous frame streaming"""
        logger.info(f"Starting frame streaming simulation for {duration} seconds")
        self.is_streaming = True
        
        async def stream_frames():
            frame_count = 0
            start_time = time.time()
            
            while self.is_streaming and (time.time() - start_time) < duration:
                try:
                    # Simulate frame data
                    frame_data = b"simulated_frame_data_" + str(frame_count).encode()
                    
                    # Send frame via WebSocket if connected
                    if self.websocket:
                        await self.websocket.send(json.dumps({
                            "type": "frame",
                            "data": frame_data.hex(),
                            "timestamp": time.time()
                        }))
                    
                    frame_count += 1
                    await asyncio.sleep(0.1)  # 10 FPS
                    
                except Exception as e:
                    logger.error(f"Frame streaming error: {e}")
                    break
            
            logger.info(f"Frame streaming completed: {frame_count} frames sent")
        
        # Start streaming in background
        asyncio.create_task(stream_frames())

    async def run_comprehensive_test(self):
        """Run the complete comprehensive test suite"""
        self.test_start_time = time.time()
        logger.info("Starting comprehensive test suite...")
        
        # Initial setup tests
        logger.info("=== Initial Setup Tests ===")
        self.test_results.append(await self.test_server_health())
        
        if not await self.login():
            logger.error("Login failed, cannot continue with authenticated tests")
            return
        
        # Connection tests
        logger.info("=== Connection Tests ===")
        self.test_results.append(await self.test_websocket_connection())
        self.test_results.append(await self.test_pico_websocket_connection())
        self.test_results.append(await self.test_esp32cam_websocket_connection())
        
        # Start frame streaming simulation
        logger.info("=== Starting Frame Streaming Simulation ===")
        await self.simulate_frame_streaming(60)  # 60 seconds of streaming
        
        # Wait a moment for streaming to establish
        await asyncio.sleep(2)
        
        # Run all command tests while streaming
        logger.info("=== Running Command Tests Under Load ===")
        
        # Servo commands
        logger.info("--- Testing Servo Commands ---")
        self.test_results.extend(await self.test_servo_commands())
        
        # Action commands
        logger.info("--- Testing Action Commands ---")
        self.test_results.extend(await self.test_action_commands())
        
        # Manual photo capture
        logger.info("--- Testing Manual Photo Capture ---")
        self.test_results.extend(await self.test_manual_photo_capture())
        
        # Device mode commands
        logger.info("--- Testing Device Mode Commands ---")
        self.test_results.extend(await self.test_device_mode_commands())
        
        # Smart features
        logger.info("--- Testing Smart Features ---")
        self.test_results.extend(await self.test_smart_features())
        
        # Gallery operations
        logger.info("--- Testing Gallery Operations ---")
        self.test_results.extend(await self.test_gallery_operations())
        
        # Logs operations
        logger.info("--- Testing Logs Operations ---")
        self.test_results.extend(await self.test_logs_operations())
        
        # User settings
        logger.info("--- Testing User Settings ---")
        self.test_results.extend(await self.test_user_settings())
        
        # System status
        logger.info("--- Testing System Status ---")
        self.test_results.extend(await self.test_system_status())
        
        # Stop streaming
        self.is_streaming = False
        await asyncio.sleep(2)
        
        # Final tests after streaming
        logger.info("=== Final Tests After Streaming ===")
        self.test_results.append(await self.test_server_health())
        
        # Generate comprehensive report
        self.generate_test_report()

    def generate_test_report(self):
        """Generate comprehensive test report"""
        total_tests = len(self.test_results)
        successful_tests = sum(1 for result in self.test_results if result.success)
        failed_tests = total_tests - successful_tests
        total_duration = time.time() - self.test_start_time
        
        logger.info("=" * 80)
        logger.info("COMPREHENSIVE TEST REPORT")
        logger.info("=" * 80)
        logger.info(f"Total Tests: {total_tests}")
        logger.info(f"Successful: {successful_tests}")
        logger.info(f"Failed: {failed_tests}")
        logger.info(f"Success Rate: {(successful_tests/total_tests)*100:.2f}%")
        logger.info(f"Total Duration: {total_duration:.2f} seconds")
        logger.info("=" * 80)
        
        # Detailed results
        logger.info("\nDETAILED TEST RESULTS:")
        logger.info("-" * 80)
        
        for result in self.test_results:
            status = "✓ PASS" if result.success else "✗ FAIL"
            logger.info(f"{status} {result.test_name} ({result.duration:.3f}s)")
            if result.error:
                logger.info(f"    Error: {result.error}")
            if result.details:
                logger.info(f"    Details: {result.details}")
        
        # Failed tests summary
        if failed_tests > 0:
            logger.info("\nFAILED TESTS SUMMARY:")
            logger.info("-" * 80)
            for result in self.test_results:
                if not result.success:
                    logger.info(f"✗ {result.test_name}: {result.error}")
        
        # Performance analysis
        logger.info("\nPERFORMANCE ANALYSIS:")
        logger.info("-" * 80)
        durations = [r.duration for r in self.test_results]
        avg_duration = sum(durations) / len(durations)
        max_duration = max(durations)
        min_duration = min(durations)
        
        logger.info(f"Average Test Duration: {avg_duration:.3f}s")
        logger.info(f"Fastest Test: {min_duration:.3f}s")
        logger.info(f"Slowest Test: {max_duration:.3f}s")
        
        # Save detailed report to file
        report_filename = f"comprehensive_test_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        report_data = {
            "test_summary": {
                "total_tests": total_tests,
                "successful_tests": successful_tests,
                "failed_tests": failed_tests,
                "success_rate": (successful_tests/total_tests)*100,
                "total_duration": total_duration,
                "average_duration": avg_duration,
                "max_duration": max_duration,
                "min_duration": min_duration
            },
            "test_results": [
                {
                    "test_name": r.test_name,
                    "success": r.success,
                    "duration": r.duration,
                    "error": r.error,
                    "details": r.details
                }
                for r in self.test_results
            ],
            "timestamp": datetime.now().isoformat()
        }
        
        with open(report_filename, 'w', encoding='utf-8') as f:
            json.dump(report_data, f, indent=2, ensure_ascii=False)
        
        logger.info(f"\nDetailed report saved to: {report_filename}")

async def main():
    """Main function to run the comprehensive test suite"""
    logger.info("Starting Comprehensive Smart Camera System Test Suite")
    logger.info("=" * 80)
    
    async with ComprehensiveTestSuite() as test_suite:
        try:
            await test_suite.run_comprehensive_test()
        except KeyboardInterrupt:
            logger.info("Test interrupted by user")
        except Exception as e:
            logger.error(f"Test suite error: {e}")
            logger.error(traceback.format_exc())
    
    logger.info("Comprehensive test suite completed")

if __name__ == "__main__":
    asyncio.run(main()) 