#!/usr/bin/env python3
"""
Final Fixes Verification Test
Tests all the database fixes and improvements made to the server
"""

import asyncio
import aiosqlite
import json
import aiohttp
import time
from datetime import datetime

class FinalFixesTest:
    def __init__(self):
        self.base_url = "http://localhost:3000"
        self.auth_token = None
        self.test_results = []
        
    def log_test(self, test_name, status, message):
        """Log test result"""
        result = {
            "test": test_name,
            "status": status,
            "message": message,
            "timestamp": datetime.now().isoformat()
        }
        self.test_results.append(result)
        print(f"{'✅' if status == 'PASS' else '❌'} {test_name}: {message}")
        
    async def login(self):
        """Login to get authentication token"""
        try:
            async with aiohttp.ClientSession() as session:
                login_data = {
                    "username": "rof642fr",
                    "password": "5qEKU@A@Tv"
                }
                
                async with session.post(f"{self.base_url}/login", json=login_data) as response:
                    if response.status == 200:
                        data = await response.json()
                        self.auth_token = data.get("access_token")
                        self.log_test("Login", "PASS", "Login successful")
                        return True
                    else:
                        self.log_test("Login", "FAIL", f"Login failed: {response.status}")
                        return False
        except Exception as e:
            self.log_test("Login", "FAIL", f"Login error: {str(e)}")
            return False
    
    async def test_database_migration(self):
        """Test 1: Database migration fixes"""
        print("\n🧪 Test 1: Database Migration Fixes")
        print("=" * 50)
        
        try:
            conn = await aiosqlite.connect('smart_camera_system.db')
            
            # Check current table structure
            cursor = await conn.execute("PRAGMA table_info(user_settings)")
            columns = await cursor.fetchall()
            current_columns = [col[1] for col in columns]
            
            print(f"Current columns: {current_columns}")
            
            # Check if all required columns exist
            required_columns = [
                'id', 'username', 'ip', 'theme', 'language', 'flash_settings',
                'servo1', 'servo2', 'device_mode', 'photo_quality',
                'smart_motion', 'smart_tracking', 'stream_enabled', 'updated_at'
            ]
            
            missing_columns = [col for col in required_columns if col not in current_columns]
            
            if not missing_columns:
                self.log_test("Database Migration", "PASS", "All required columns exist")
            else:
                self.log_test("Database Migration", "FAIL", f"Missing columns: {missing_columns}")
            
            await conn.close()
            
        except Exception as e:
            self.log_test("Database Migration", "FAIL", f"Error: {str(e)}")
    
    async def test_user_settings_operations(self):
        """Test 2: User settings operations"""
        print("\n🧪 Test 2: User Settings Operations")
        print("=" * 50)
        
        try:
            async with aiohttp.ClientSession() as session:
                headers = {"Authorization": f"Bearer {self.auth_token}"} if self.auth_token else {}
                
                # Test get user settings
                async with session.get(f"{self.base_url}/get_user_settings", headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        self.log_test("Get User Settings", "PASS", "Settings retrieved successfully")
                    else:
                        self.log_test("Get User Settings", "FAIL", f"Status: {response.status}")
                
                # Test save user settings
                settings = {
                    "device_mode": "desktop",
                    "theme": "light",
                    "language": "fa",
                    "servo1": 90,
                    "servo2": 90,
                    "photoQuality": 80,
                    "smart_motion": True,
                    "smart_tracking": False,
                    "stream_enabled": True
                }
                
                async with session.post(f"{self.base_url}/save_user_settings", json=settings, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        self.log_test("Save User Settings", "PASS", "Settings saved successfully")
                    else:
                        self.log_test("Save User Settings", "FAIL", f"Status: {response.status}")
                        
        except Exception as e:
            self.log_test("User Settings Operations", "FAIL", f"Error: {str(e)}")
    
    async def test_smart_features_operations(self):
        """Test 3: Smart features operations"""
        print("\n🧪 Test 3: Smart Features Operations")
        print("=" * 50)
        
        try:
            async with aiohttp.ClientSession() as session:
                headers = {"Authorization": f"Bearer {self.auth_token}"} if self.auth_token else {}
                
                # Test get smart features
                async with session.get(f"{self.base_url}/get_smart_features", headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        self.log_test("Get Smart Features", "PASS", "Smart features retrieved successfully")
                    else:
                        self.log_test("Get Smart Features", "FAIL", f"Status: {response.status}")
                
                # Test set smart features
                smart_features = {
                    "motion": True,
                    "tracking": False
                }
                
                async with session.post(f"{self.base_url}/set_smart_features", json=smart_features, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        self.log_test("Set Smart Features", "PASS", "Smart features set successfully")
                    else:
                        self.log_test("Set Smart Features", "FAIL", f"Status: {response.status}")
                        
        except Exception as e:
            self.log_test("Smart Features Operations", "FAIL", f"Error: {str(e)}")
    
    async def test_servo_operations(self):
        """Test 4: Servo operations"""
        print("\n🧪 Test 4: Servo Operations")
        print("=" * 50)
        
        try:
            async with aiohttp.ClientSession() as session:
                headers = {"Authorization": f"Bearer {self.auth_token}"} if self.auth_token else {}
                
                # Test servo commands
                servo_commands = [
                    {"servo1": 90, "servo2": 90},
                    {"servo1": 0, "servo2": 180},
                    {"servo1": 180, "servo2": 0},
                    {"servo1": 45, "servo2": 135}
                ]
                
                for i, command in enumerate(servo_commands):
                    async with session.post(f"{self.base_url}/set_servo", json=command, headers=headers) as response:
                        if response.status == 200:
                            data = await response.json()
                            self.log_test(f"Servo Command {i+1}", "PASS", f"Servo {command} set successfully")
                        else:
                            self.log_test(f"Servo Command {i+1}", "FAIL", f"Status: {response.status}")
                    
                    await asyncio.sleep(0.5)  # Wait between commands
                        
        except Exception as e:
            self.log_test("Servo Operations", "FAIL", f"Error: {str(e)}")
    
    async def test_manual_photo_capture(self):
        """Test 5: Manual photo capture"""
        print("\n🧪 Test 5: Manual Photo Capture")
        print("=" * 50)
        
        try:
            async with aiohttp.ClientSession() as session:
                headers = {"Authorization": f"Bearer {self.auth_token}"} if self.auth_token else {}
                
                # Test manual photo capture
                photo_configs = [
                    {"quality": 80, "flash": False, "intensity": 0},
                    {"quality": 90, "flash": True, "intensity": 50}
                ]
                
                for i, config in enumerate(photo_configs):
                    async with session.post(f"{self.base_url}/manual_photo", json=config, headers=headers) as response:
                        if response.status == 200:
                            data = await response.json()
                            self.log_test(f"Manual Photo {i+1}", "PASS", f"Photo captured with {config}")
                        else:
                            self.log_test(f"Manual Photo {i+1}", "FAIL", f"Status: {response.status}")
                    
                    await asyncio.sleep(1.0)  # Wait between photos
                        
        except Exception as e:
            self.log_test("Manual Photo Capture", "FAIL", f"Error: {str(e)}")
    
    async def test_system_status(self):
        """Test 6: System status endpoints"""
        print("\n🧪 Test 6: System Status Endpoints")
        print("=" * 50)
        
        try:
            async with aiohttp.ClientSession() as session:
                headers = {"Authorization": f"Bearer {self.auth_token}"} if self.auth_token else {}
                
                # Test various status endpoints
                status_endpoints = [
                    "/get_status",
                    "/get_photo_count",
                    "/devices/status",
                    "/system/performance"
                ]
                
                for endpoint in status_endpoints:
                    async with session.get(f"{self.base_url}{endpoint}", headers=headers) as response:
                        if response.status == 200:
                            data = await response.json()
                            self.log_test(f"Status {endpoint}", "PASS", "Status retrieved successfully")
                        else:
                            self.log_test(f"Status {endpoint}", "FAIL", f"Status: {response.status}")
                        
        except Exception as e:
            self.log_test("System Status", "FAIL", f"Error: {str(e)}")
    
    async def run_all_tests(self):
        """Run all tests"""
        print("🚀 Starting Final Fixes Verification Test")
        print("=" * 60)
        
        # Test 1: Database migration
        await self.test_database_migration()
        
        # Test 2: Login
        if not await self.login():
            print("❌ Login failed, cannot continue with authenticated tests")
            return
        
        # Test 3: User settings operations
        await self.test_user_settings_operations()
        
        # Test 4: Smart features operations
        await self.test_smart_features_operations()
        
        # Test 5: Servo operations
        await self.test_servo_operations()
        
        # Test 6: Manual photo capture
        await self.test_manual_photo_capture()
        
        # Test 7: System status
        await self.test_system_status()
        
        # Generate summary
        self.generate_summary()
    
    def generate_summary(self):
        """Generate test summary"""
        print("\n" + "=" * 60)
        print("📊 FINAL FIXES VERIFICATION SUMMARY")
        print("=" * 60)
        
        total_tests = len(self.test_results)
        passed_tests = sum(1 for result in self.test_results if result["status"] == "PASS")
        failed_tests = total_tests - passed_tests
        
        print(f"Total Tests: {total_tests}")
        print(f"Passed: {passed_tests}")
        print(f"Failed: {failed_tests}")
        print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        
        if failed_tests > 0:
            print("\n❌ Failed Tests:")
            for result in self.test_results:
                if result["status"] == "FAIL":
                    print(f"  - {result['test']}: {result['message']}")
        
        # Save detailed results
        report_filename = f"final_fixes_verification_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_filename, 'w', encoding='utf-8') as f:
            json.dump({
                "summary": {
                    "total_tests": total_tests,
                    "passed_tests": passed_tests,
                    "failed_tests": failed_tests,
                    "success_rate": (passed_tests/total_tests)*100
                },
                "results": self.test_results,
                "timestamp": datetime.now().isoformat()
            }, f, indent=2, ensure_ascii=False)
        
        print(f"\n📄 Detailed report saved to: {report_filename}")

async def main():
    """Main function"""
    test_suite = FinalFixesTest()
    await test_suite.run_all_tests()

if __name__ == "__main__":
    asyncio.run(main()) 