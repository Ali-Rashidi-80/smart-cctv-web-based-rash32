#!/usr/bin/env python3
"""
Simple script to start the server on port 6970 for external access
"""

import os
import sys
import uvicorn
import socket

def check_port(port):
    """Check if port is available"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex(('localhost', port))
        sock.close()
        return result != 0
    except:
        return False

def main():
    """Start server on port 6970"""
    
    print("🌐 Starting External Server")
    print("=" * 40)
    
    # Check if port 6970 is available
    if not check_port(6970):
        print("❌ Port 6970 is already in use")
        print("💡 Please stop any existing server on port 6970")
        return False
    
    print("✅ Port 6970 is available")
    print("🚀 Starting server...")
    print("   - Host: 0.0.0.0 (all interfaces)")
    print("   - Port: 6970")
    print("   - External access: enabled")
    
    # Set environment variables
    os.environ['HOST'] = '0.0.0.0'
    os.environ['PORT'] = '6970'
    os.environ['EXTERNAL_ACCESS'] = 'true'
    
    try:
        # Import and run the server
        from server_fastapi import app
        
        print("\n📡 Server Information:")
        print("   - Local URL: http://localhost:6970")
        print("   - External URL: http://services.gen6.chabokan.net:6970")
        print("   - WebSocket: ws://services.gen6.chabokan.net:6970/ws/pico")
        print("   - Health check: http://services.gen6.chabokan.net:6970/health")
        print("   - Public tokens: http://services.gen6.chabokan.net:6970/public/tokens")
        
        print("\n🔧 External devices can connect using:")
        print("   1. Get tokens: curl http://services.gen6.chabokan.net:6970/public/tokens")
        print("   2. Connect WebSocket: ws://services.gen6.chabokan.net:6970/ws/pico")
        print("   3. Use Authorization header: Bearer <token>")
        
        print("\n⏹️ Press Ctrl+C to stop the server")
        print("=" * 40)
        
        # Start the server
        uvicorn.run(
            app,
            host="0.0.0.0",
            port=6970,
            log_level="info",
            access_log=True
        )
        
    except KeyboardInterrupt:
        print("\n🛑 Server stopped by user")
        return True
    except Exception as e:
        print(f"\n❌ Error starting server: {e}")
        return False

if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"\n💥 Unexpected error: {e}")
        sys.exit(1) 