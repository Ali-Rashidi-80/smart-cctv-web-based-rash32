#!/usr/bin/env python3
"""
Script to start the server for external connections
This script configures the server to accept connections from external IP addresses
"""

import os
import sys
import subprocess
import time
import requests
import socket

def check_port_availability(port):
    """Check if a port is available"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex(('localhost', port))
        sock.close()
        return result != 0  # True if port is available
    except:
        return False

def wait_for_server(port, max_wait=30):
    """Wait for server to be ready"""
    print(f"⏳ Waiting for server to start on port {port}...")
    
    for i in range(max_wait):
        try:
            response = requests.get(f"http://localhost:{port}/health", timeout=2)
            if response.status_code == 200:
                print(f"✅ Server is ready on port {port}")
                return True
        except:
            pass
        
        time.sleep(1)
        if (i + 1) % 5 == 0:
            print(f"   Still waiting... ({i + 1}/{max_wait})")
    
    print(f"❌ Server failed to start within {max_wait} seconds")
    return False

def start_server_for_external():
    """Start the server configured for external connections"""
    
    print("🚀 Starting server for external connections...")
    
    # Set environment variables for external access
    env = os.environ.copy()
    env['HOST'] = '0.0.0.0'  # Bind to all interfaces
    env['PORT'] = '6970'    # Use the external port
    env['EXTERNAL_ACCESS'] = 'true'
    
    # Check if port is available
    if not check_port_availability(6970):
        print("❌ Port 6970 is already in use")
        print("💡 Please stop any existing server or use a different port")
        return False
    
    try:
        print("📡 Starting server with external access configuration...")
        print("   - Host: 0.0.0.0 (all interfaces)")
        print("   - Port: 6970")
        print("   - External access: enabled")
        
        # Start the server
        process = subprocess.Popen([
            sys.executable, 'server_fastapi.py'
        ], env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        
        # Wait for server to start
        if wait_for_server(6970):
            print("\n🎉 Server started successfully!")
            print("📋 Server Information:")
            print("   - Local URL: http://localhost:6970")
            print("   - External URL: http://services.gen6.chabokan.net:6970")
            print("   - WebSocket: ws://services.gen6.chabokan.net:6970/ws/pico")
            print("   - Health check: http://services.gen6.chabokan.net:6970/health")
            print("   - Public tokens: http://services.gen6.chabokan.net:6970/public/tokens")
            
            print("\n🔧 Configuration for external devices:")
            print("   1. Get tokens: curl http://services.gen6.chabokan.net:6970/public/tokens")
            print("   2. Connect WebSocket: ws://services.gen6.chabokan.net:6970/ws/pico")
            print("   3. Use Authorization header: Bearer <token>")
            
            print("\n⏹️ Press Ctrl+C to stop the server")
            
            try:
                # Keep the server running
                process.wait()
            except KeyboardInterrupt:
                print("\n🛑 Stopping server...")
                process.terminate()
                process.wait()
                print("✅ Server stopped")
            
            return True
        else:
            print("❌ Failed to start server")
            process.terminate()
            return False
            
    except Exception as e:
        print(f"❌ Error starting server: {e}")
        return False

def test_external_access():
    """Test if the server is accessible externally"""
    print("\n🔍 Testing external access...")
    
    try:
        # Test health endpoint
        response = requests.get("http://services.gen6.chabokan.net:6970/health", timeout=10)
        if response.status_code == 200:
            print("✅ External HTTP access working")
        else:
            print(f"⚠️ External HTTP access returned status: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ External HTTP access failed: {e}")
        return False
    
    try:
        # Test public tokens endpoint
        response = requests.get("http://services.gen6.chabokan.net:6970/public/tokens", timeout=10)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Public tokens endpoint working - {len(data.get('pico_tokens', []))} Pico tokens available")
        else:
            print(f"⚠️ Public tokens endpoint returned status: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Public tokens endpoint failed: {e}")
        return False
    
    return True

def main():
    """Main function"""
    print("🌐 External Server Configuration")
    print("=" * 50)
    
    # Check if we're running on the external server
    if os.path.exists('/etc/hostname'):
        try:
            with open('/etc/hostname', 'r') as f:
                hostname = f.read().strip()
                if 'services.gen6.chabokan.net' in hostname:
                    print("✅ Running on external server")
                else:
                    print(f"⚠️ Running on: {hostname}")
        except:
            pass
    
    # Start server
    if start_server_for_external():
        # Test external access
        if test_external_access():
            print("\n🎉 External server is fully operational!")
            print("💡 External devices can now connect using:")
            print("   - WebSocket: ws://services.gen6.chabokan.net:6970/ws/pico")
            print("   - HTTP: http://services.gen6.chabokan.net:6970")
        else:
            print("\n⚠️ Server started but external access may have issues")
            print("💡 Check firewall and network configuration")
    else:
        print("\n❌ Failed to start external server")
        return False
    
    return True

if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n⏹️ Operation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n💥 Unexpected error: {e}")
        sys.exit(1) 