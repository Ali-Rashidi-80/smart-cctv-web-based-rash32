import logging
from datetime import datetime
from colorama import Fore, Style, Back, init as colorama_init
import re
import sys
import json

try:
    from persiantools.jdatetime import JalaliDateTime
    PERSIANTOOLS_AVAILABLE = True
except ImportError:
    PERSIANTOOLS_AVAILABLE = False

colorama_init(autoreset=True)

# رنگ‌بندی سطح لاگ
LEVEL_COLORS = {
    'DEBUG': Fore.CYAN + Style.BRIGHT,
    'INFO': Fore.GREEN + Style.BRIGHT,
    'WARNING': Fore.YELLOW + Style.BRIGHT,
    'ERROR': Fore.RED + Style.BRIGHT,
    'CRITICAL': Fore.WHITE + Back.RED + Style.BRIGHT,
}
# رنگ‌بندی متدهای HTTP
METHOD_COLORS = {
    'GET': Fore.BLUE + Style.BRIGHT,
    'POST': Fore.MAGENTA + Style.BRIGHT,
    'PUT': Fore.CYAN + Style.BRIGHT,
    'DELETE': Fore.RED + Style.BRIGHT,
    'PATCH': Fore.YELLOW + Style.BRIGHT,
}
# کلیدواژه‌های مهم (انگلیسی و فارسی)
KEYWORDS = {
    'SUCCESS': Fore.GREEN + Style.BRIGHT,
    'FAILED': Fore.RED + Style.BRIGHT,
    'ERROR': Fore.RED + Style.BRIGHT,
    'WARNING': Fore.YELLOW + Style.BRIGHT,
    'CRITICAL': Fore.WHITE + Back.RED + Style.BRIGHT,
    'STARTED': Fore.CYAN + Style.BRIGHT,
    'STOPPED': Fore.MAGENTA + Style.BRIGHT,
    'موفق': Fore.GREEN + Style.BRIGHT,
    'خطا': Fore.RED + Style.BRIGHT,
    'هشدار': Fore.YELLOW + Style.BRIGHT,
    'بحرانی': Fore.WHITE + Back.RED + Style.BRIGHT,
    'شروع': Fore.CYAN + Style.BRIGHT,
    'پایان': Fore.MAGENTA + Style.BRIGHT,
}
# Regexها
RE_NUMBER = re.compile(r'(\d+)', re.UNICODE)
RE_IP = re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b')
RE_URL = re.compile(r'(https?://[\w\./\-\?&=%]+|/\S+)', re.UNICODE)
RE_FILE = re.compile(r'\b\w+\.(?:py|jpg|png|db|log|json|mp4|avi)\b', re.UNICODE)
RE_QUOTE = re.compile(r'("[^"]*"|\'[^\']*\')', re.UNICODE)
RE_STATUS_2XX_3XX = re.compile(r'\b(2\d\d|3\d\d)\b')
RE_STATUS_4XX = re.compile(r'\b4\d\d\b')
RE_STATUS_5XX = re.compile(r'\b5\d\d\b')

class JalaliFormatter(logging.Formatter):
    """
    فرمت‌کننده لاگ حرفه‌ای با تاریخ شمسی، رنگ‌بندی، جداکننده و جذابیت بصری ویژه برای ترمینال و فایل.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.enable_color = sys.stdout.isatty()

    def formatTime(self, record, datefmt=None):
        dt = datetime.fromtimestamp(record.created)
        if PERSIANTOOLS_AVAILABLE:
            try:
                jdt = JalaliDateTime.to_jalali(dt)
                weekday_fingilish = {
                    'saturday': 'shanbe',
                    'sunday': 'yekshanbe',
                    'monday': 'doshanbe',
                    'tuesday': 'seshanbe',
                    'wednesday': 'chaharshanbe',
                    'thursday': 'panjshanbe',
                    'friday': 'jome',
                }
                day_en = jdt.strftime('%A').lower()
                day_fing = weekday_fingilish.get(day_en, day_en)
                jalali_str = jdt.strftime('%Y-%m-%d %H:%M:%S') + f' {day_fing}'
                return jalali_str
            except Exception:
                pass
        # Fallback: Gregorian date, English weekday
        weekday_fingilish = {
            'saturday': 'shanbe',
            'sunday': 'yekshanbe',
            'monday': 'doshanbe',
            'tuesday': 'seshanbe',
            'wednesday': 'chaharshanbe',
            'thursday': 'panjshanbe',
            'friday': 'jome',
        }
        day_en = dt.strftime('%A').lower()
        day_fing = weekday_fingilish.get(day_en, day_en)
        gregorian_str = dt.strftime('%Y-%m-%d %H:%M:%S') + f' {day_fing}'
        return gregorian_str

    def colorize_message(self, msg):
        # اگر خروجی رنگی نیست، هیچ رنگی اعمال نکن
        if not self.enable_color:
            return msg
        # اعداد
        msg = RE_NUMBER.sub(lambda m: Fore.YELLOW + m.group(1) + Style.RESET_ALL, msg)
        # متدهای HTTP
        for method, color in METHOD_COLORS.items():
            msg = re.sub(rf'\b{method}\b', color + method + Style.RESET_ALL, msg)
        # رشته‌های کوتیشن‌دار
        msg = RE_QUOTE.sub(Fore.CYAN + r'\1' + Style.RESET_ALL, msg)
        # آی‌پی
        msg = RE_IP.sub(Fore.LIGHTBLUE_EX + r'\g<0>' + Style.RESET_ALL, msg)
        # URL
        msg = RE_URL.sub(Fore.LIGHTMAGENTA_EX + r'\g<0>' + Style.RESET_ALL, msg)
        # فایل
        msg = RE_FILE.sub(Fore.LIGHTCYAN_EX + r'\g<0>' + Style.RESET_ALL, msg)
        # کلیدواژه‌های مهم
        for word, color in KEYWORDS.items():
            msg = re.sub(rf'\b{word}\b', color + word + Style.RESET_ALL, msg, flags=re.IGNORECASE)
        return msg

    def pretty_json(self, obj):
        # نمایش زیبا و رنگی دیکشنری/JSON
        if not self.enable_color:
            return json.dumps(obj, indent=2, ensure_ascii=False)
        txt = json.dumps(obj, indent=2, ensure_ascii=False)
        txt = RE_QUOTE.sub(Fore.CYAN + r'\1' + Style.RESET_ALL, txt)
        txt = RE_NUMBER.sub(lambda m: Fore.YELLOW + m.group(1) + Style.RESET_ALL, txt)
        txt = RE_FILE.sub(Fore.LIGHTCYAN_EX + r'\g<0>' + Style.RESET_ALL, txt)
        return txt

    def format(self, record):
        # سطح لاگ
        level = record.levelname.upper()
        level_color = LEVEL_COLORS.get(level, '') if self.enable_color else ''
        record.levelname = level_color + level + (Style.RESET_ALL if self.enable_color else '')
        # پیام
        msg = record.getMessage()
        # اگر پیام دیکشنری یا JSON باشد، زیبا نمایش بده
        if isinstance(record.msg, (dict, list)):
            msg = self.pretty_json(record.msg)
        else:
            msg = self.colorize_message(str(msg))
        # وضعیت HTTP
        msg = RE_STATUS_2XX_3XX.sub(Fore.GREEN + r'\1' + Style.RESET_ALL if self.enable_color else r'\1', msg)
        msg = RE_STATUS_4XX.sub(Fore.YELLOW + r'\g<0>' + Style.RESET_ALL if self.enable_color else r'\g<0>', msg)
        msg = RE_STATUS_5XX.sub(Fore.RED + r'\g<0>' + Style.RESET_ALL if self.enable_color else r'\g<0>', msg)
        # جداکننده و فاصله
        formatted = f"{self.formatTime(record)}  {record.levelname}  {msg}"
        separator = '\n' + (Fore.LIGHTBLACK_EX + '-'*80 + Style.RESET_ALL if self.enable_color else '-'*80) + '\n'
        return f"{formatted}{separator}" 