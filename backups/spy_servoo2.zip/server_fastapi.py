import asyncio, aiosqlite, time, os, io, sys, gc, re, random, functools, cv2, gzip, shutil, base64, json, socket, logging, logging.config, logging.handlers, signal, errno, jwt, jdatetime, secrets, pyotp, dotenv, httpx, string, threading
import numpy as np
from queue import Queue
from PIL import Image
from melipayamak import Api
from contextlib import asynccontextmanager
from typing import List, Tuple, Optional, Dict
from datetime import datetime, timedelta
from fastapi.responses import StreamingResponse, HTMLResponse, FileResponse, JSONResponse, PlainTextResponse, RedirectResponse
from fastapi import FastAPI, Request, HTTPException, Depends, WebSocket, WebSocketDisconnect
from pydantic import BaseModel, Field, ValidationError, field_validator
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from utils.jalali_formatter import JalaliFormatter
from utils.dynamic_port_manager import DynamicPortManager
from utils.api_ports import router as port_router


# Load environment variables
dotenv.load_dotenv()

# Intelligent connection pooling
class ConnectionPool:
    def __init__(self, max_connections=10):
        self.max_connections = max_connections
        self.active_connections = {}
        self.connection_stats = {}
    
    def add_connection(self, client_id, websocket, client_type="pico"):
        """Add connection to pool with intelligent management"""
        if len(self.active_connections) >= self.max_connections:
            # Remove oldest inactive connection
            oldest_connection = min(self.active_connections.items(), 
                                  key=lambda x: x[1].get('last_activity', 0))
            self.remove_connection(oldest_connection[0])
        
        self.active_connections[client_id] = {
            'websocket': websocket,
            'type': client_type,
            'connected_at': datetime.now(),
            'last_activity': datetime.now(),
            'message_count': 0,
            'ping_count': 0
        }
        self.connection_stats[client_id] = {
            'total_messages': 0,
            'total_pings': 0,
            'connection_duration': 0
        }
    
    def remove_connection(self, client_id):
        """Remove connection from pool"""
        if client_id in self.active_connections:
            connection = self.active_connections[client_id]
            duration = (datetime.now() - connection['connected_at']).total_seconds()
            self.connection_stats[client_id]['connection_duration'] = duration
            del self.active_connections[client_id]
    
    def update_activity(self, client_id):
        """Update last activity for connection"""
        if client_id in self.active_connections:
            self.active_connections[client_id]['last_activity'] = datetime.now()
            self.active_connections[client_id]['message_count'] += 1
            self.connection_stats[client_id]['total_messages'] += 1
    
    def get_inactive_connections(self, threshold_minutes=5):
        """Get connections inactive for more than threshold"""
        threshold = datetime.now() - timedelta(minutes=threshold_minutes)
        return {cid: conn for cid, conn in self.active_connections.items() 
                if conn['last_activity'] < threshold}

# Global connection pool
connection_pool = ConnectionPool(max_connections=20)

# Import logging configuration first
try:
    from config.jalali_log_config import LOGGING_CONFIG
except ImportError:
    # Fallback logging configuration if the module is not available
    LOGGING_CONFIG = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "default": {
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
            }
        },
        "handlers": {
            "default": {
                "class": "logging.StreamHandler",
                "formatter": "default"
            }
        },
        "root": {
            "handlers": ["default"],
            "level": "INFO"
        }
    }

# Configure logging
logging.config.dictConfig(LOGGING_CONFIG)
logger = logging.getLogger(__name__)

# Define generate_secure_credentials function
def generate_secure_credentials():
    """Generate secure credentials for admin access"""
    # Generate a strong SECRET_KEY
    secret_key = ''.join(secrets.choice(string.ascii_letters + string.digits + string.punctuation) for _ in range(64))
    
    # Generate random admin credentials
    admin_username = ''.join(secrets.choice(string.ascii_lowercase + string.digits) for _ in range(8))
    admin_password = ''.join(secrets.choice(string.ascii_letters + string.digits + string.punctuation) for _ in range(12))
    
    return secret_key, admin_username, admin_password

# Load credentials from admin_credentials.txt if environment variables are not set
SECRET_KEY = os.getenv("SECRET_KEY")
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD")

if not all([SECRET_KEY, ADMIN_USERNAME, ADMIN_PASSWORD]):
    try:
        if os.path.exists("admin_credentials.txt"):
            with open("admin_credentials.txt", "r") as f:
                for line in f:
                    line = line.strip()
                    if line and "=" in line:
                        key, value = line.split("=", 1)
                        if key == "SECRET_KEY" and not SECRET_KEY:
                            SECRET_KEY = value
                        elif key == "ADMIN_USERNAME" and not ADMIN_USERNAME:
                            ADMIN_USERNAME = value
                        elif key == "ADMIN_PASSWORD" and not ADMIN_PASSWORD:
                            ADMIN_PASSWORD = value
            logger.info("Loaded credentials from admin_credentials.txt")
    except Exception as e:
        logger.warning(f"Failed to load credentials from admin_credentials.txt: {e}")

# Generate credentials if still not available
if not all([SECRET_KEY, ADMIN_USERNAME, ADMIN_PASSWORD]):
    logger.warning("Missing credentials, generating new ones...")
    SECRET_KEY, ADMIN_USERNAME, ADMIN_PASSWORD = generate_secure_credentials()
    
    # Save to file
    try:
        with open("admin_credentials.txt", "w") as f:
            f.write(f"SECRET_KEY={SECRET_KEY}\n")
            f.write(f"ADMIN_USERNAME={ADMIN_USERNAME}\n")
            f.write(f"ADMIN_PASSWORD={ADMIN_PASSWORD}\n")
        logger.info("Generated and saved new credentials to admin_credentials.txt")
    except Exception as e:
        logger.error(f"Failed to save credentials: {e}")


# Global variable to store dynamic ports
DYNAMIC_PORTS = {}

# Rate limiting storage
rate_limit_storage: Dict[str, List[float]] = {}
login_attempts: Dict[str, Dict] = {}

# Security constants
MAX_LOGIN_ATTEMPTS = 6  # Increased to 6 for proper login attempts
LOGIN_BLOCK_DURATION = 1800  # 30 minutes
RATE_LIMIT_REQUESTS = 15  # Increased to 15 for proper rate limiting
RATE_LIMIT_WINDOW = 60  # 1 minute

# OAuth state storage (in-memory for simplicity)
oauth_states = {}
ACCESS_TOKEN_EXPIRE_MINUTES = 60
ALGORITHM = "HS256"

# Security tokens for microcontrollers
def generate_secure_tokens():
    """Generate secure tokens for microcontrollers"""
    import secrets
    import string
    
    # Generate Pico token
    pico_token = ''.join(secrets.choice(string.ascii_letters + string.digits + "!@#$%^&*") for _ in range(32))
    
    # Generate ESP32CAM token
    esp32cam_token = ''.join(secrets.choice(string.ascii_letters + string.digits + "!@#$%^&*") for _ in range(32))
    
    return pico_token, esp32cam_token

# Generate or load tokens
pico_tokens_env = os.getenv("PICO_AUTH_TOKENS")
esp32cam_tokens_env = os.getenv("ESP32CAM_AUTH_TOKENS")

if pico_tokens_env:
    # Use environment variable if provided
    if pico_tokens_env.startswith("[") and pico_tokens_env.endswith("]"):
        import json
        try:
            PICO_AUTH_TOKENS = json.loads(pico_tokens_env)
        except:
            PICO_AUTH_TOKENS, _ = generate_secure_tokens()
            PICO_AUTH_TOKENS = [PICO_AUTH_TOKENS]
    else:
        PICO_AUTH_TOKENS = pico_tokens_env.split(",")
else:
    # Generate new secure token
    pico_token, _ = generate_secure_tokens()
    PICO_AUTH_TOKENS = [pico_token]
    logger.info(f"Generated new Pico token: {pico_token[:10]}...")

if esp32cam_tokens_env:
    # Use environment variable if provided
    if esp32cam_tokens_env.startswith("[") and esp32cam_tokens_env.endswith("]"):
        import json
        try:
            ESP32CAM_AUTH_TOKENS = json.loads(esp32cam_tokens_env)
        except:
            _, esp32cam_token = generate_secure_tokens()
            ESP32CAM_AUTH_TOKENS = [esp32cam_token]
    else:
        ESP32CAM_AUTH_TOKENS = esp32cam_tokens_env.split(",") if esp32cam_tokens_env else []
else:
    # Generate new secure token
    _, esp32cam_token = generate_secure_tokens()
    ESP32CAM_AUTH_TOKENS = [esp32cam_token]
    logger.info(f"Generated new ESP32CAM token: {esp32cam_token[:10]}...")

# Log token information for debugging (only once)
if not hasattr(logger, '_credentials_logged'):
    logger.info(f"PICO_AUTH_TOKENS: {[token[:10] + '...' for token in PICO_AUTH_TOKENS]}")
    logger.info(f"ESP32CAM_AUTH_TOKENS: {[token[:10] + '...' for token in ESP32CAM_AUTH_TOKENS]}")
    logger._credentials_logged = True

# Google OAuth Configuration
GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID")
GOOGLE_CLIENT_SECRET = os.getenv("GOOGLE_CLIENT_SECRET")
GOOGLE_REDIRECT_URI = os.getenv("GOOGLE_REDIRECT_URI")
GOOGLE_AUTH_URL = os.getenv("GOOGLE_AUTH_URL")
GOOGLE_TOKEN_URL = os.getenv("GOOGLE_TOKEN_URL")
GOOGLE_USERINFO_URL = os.getenv("GOOGLE_USERINFO_URL")

# Check if Google OAuth is properly configured
GOOGLE_OAUTH_ENABLED = bool(GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET)
if not GOOGLE_OAUTH_ENABLED:
    logger.warning("⚠️ Google OAuth not configured - GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET environment variables are required")

# SMS configuration for password recovery
SMS_USERNAME = os.getenv("SMS_USERNAME")
SMS_PASSWORD = os.getenv("SMS_PASSWORD")
SMS_SENDER_NUMBER = os.getenv("SMS_SENDER_NUMBER")

# Simple database connection management - no pooling for now

# --- Critical System Constants ---
VIDEO_FPS = 25
VIDEO_QUALITY = 85
SECURITY_VIDEO_DURATION = 30 * 60  # 30 minutes
FRAME_BUFFER_SIZE = 300
MAX_FRAME_SIZE = 2 * 1024 * 1024  # 2MB
MAX_WEBSOCKET_MESSAGE_SIZE = 2 * 1024 * 1024  # 2MB
FRAME_QUEUE_SIZE = 50
FRAME_PROCESSING_ENABLED = True
MEMORY_THRESHOLD = 0.9  # 80% memory usage threshold
WEBSOCKET_ERROR_THRESHOLD = 10
BACKUP_INTERVAL = 3600  # 1 hour
DB_TIMEOUT = 30
BACKUP_DIR = "backups"
GALLERY_DIR = "gallery"
SECURITY_VIDEOS_DIR = "security_videos"

# --- Real-time Frame Processing Constants ---
REALTIME_FRAME_PROCESSING = True
FRAME_SKIP_THRESHOLD = 0.1  # 100ms
FRAME_PROCESSING_TIMEOUT = 2.0  # 2 seconds
FRAME_COMPRESSION_THRESHOLD = 1024 * 1024  # 1MB
ADAPTIVE_QUALITY = True
MIN_FRAME_INTERVAL = 0.04  # 25 FPS max
FRAME_DROP_RATIO = 0.3  # 30% drop ratio for buffer overflow
WEBSOCKET_BATCH_SIZE = 10
FRAME_CACHE_SIZE = 20
PERFORMANCE_MONITORING = True
FRAME_LATENCY_THRESHOLD = 0.5  # 500ms
PROCESSING_OVERHEAD_THRESHOLD = 0.8  # 80%
PERFORMANCE_UPDATE_INTERVAL = 5.0  # 5 seconds
FRAME_CACHE_CLEANUP_INTERVAL = 30.0  # 30 seconds

# --- Database Connection Pool Constants ---
DB_POOL_SIZE = 10
DB_MAX_OVERFLOW = 20

# --- Enhanced Error Tracking Constants ---
ERROR_RESET_INTERVAL = 3600  # 1 hour
MAX_ERROR_COUNT = 50
CONNECTION_TIMEOUT = 30
FRAME_PROCESSING_RETRY_LIMIT = 3
DISK_THRESHOLD = 10.0  # 10% free disk space threshold
MAX_BACKUP_CHECK = 5  # Maximum number of backups to check

# --- Device Resolutions for Adaptive Processing ---
DEVICE_RESOLUTIONS = {
    "desktop": {"width": 1280, "height": 720},
    "mobile": {"width": 640, "height": 480},
    "tablet": {"width": 1024, "height": 768}
}

# --- Performance Monitoring ---
PERFORMANCE_MONITORING = True
FRAME_LATENCY_THRESHOLD = 0.2  # 200ms threshold for latency
PROCESSING_OVERHEAD_THRESHOLD = 0.5  # 50% threshold for overhead
MAX_BACKUP_CHECK = 5
MAX_RESIZED_FRAMES = 50

# --- Performance Update Intervals ---
PERFORMANCE_UPDATE_INTERVAL = 5.0  # Update metrics every 5 seconds
FRAME_CACHE_CLEANUP_INTERVAL = 30.0  # Cleanup frame cache every 30 seconds

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

try:
    from persiantools.jdatetime import JalaliDateTime
    PERSIANTOOLS_AVAILABLE = True
except ImportError:
    PERSIANTOOLS_AVAILABLE = False

try:
    import arabic_reshaper
    from bidi.algorithm import get_display
    ARABIC_RESHAPER_AVAILABLE = True
except ImportError:
    ARABIC_RESHAPER_AVAILABLE = False

# --- Logging configuration: daily rotating log files, keep 7 days, per category ---
LOG_DIR = 'logs'
if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR)

# --- Custom Jalali log formatter ---
class DailyCleanupFileHandler(logging.Handler):
    def __init__(self, log_dir, base_filename, backup_days=7):
        super().__init__()
        self.log_dir = log_dir
        self.base_filename = base_filename
        self.backup_days = backup_days
        self.current_date = None
        self.file_handler = None
        self._update_handler()

    def _update_handler(self):
        today = datetime.now().strftime('%Y-%m-%d')
        if self.current_date != today:
            self.current_date = today
            if self.file_handler:
                self.file_handler.close()
            log_path = os.path.join(self.log_dir, f"{self.base_filename}_{today}.log")
            self.file_handler = logging.FileHandler(log_path, encoding='utf-8')
            self.file_handler.setFormatter(JalaliFormatter('%(asctime)s - %(levelname)s - %(name)s - %(message)s'))
            self._cleanup_old_logs()

    def _cleanup_old_logs(self):
        files = sorted([f for f in os.listdir(self.log_dir) if f.startswith(self.base_filename) and f.endswith('.log')])
        if len(files) > self.backup_days:
            for f in files[:-self.backup_days]:
                try:
                    os.remove(os.path.join(self.log_dir, f))
                except Exception as e:
                    logger.warning(f"Failed to remove old log file {f}: {e}", exc_info=True)
                    raise

    def emit(self, record):
        self._update_handler()
        if self.file_handler:
            self.file_handler.emit(record)

# Remove all root handlers
for h in logging.root.handlers[:]:
    logging.root.removeHandler(h)

# --- دسته‌بندی لاگ‌ها ---
loggers_config = {
    "app": {"level": logging.INFO},
    "uvicorn.access": {"level": logging.INFO},
    "uvicorn.error": {"level": logging.INFO},
    "db": {"level": logging.INFO},
}

for name, cfg in loggers_config.items():
    handler = DailyCleanupFileHandler(LOG_DIR, name, backup_days=7)
    logger = logging.getLogger(name)
    logger.handlers = [handler]
    logger.setLevel(cfg["level"])
    logger.propagate = False  # فقط در فایل خودش

# کنسول برای app و error
console_handler = logging.StreamHandler()
console_handler.setFormatter(JalaliFormatter('%(asctime)s - %(levelname)s - %(name)s - %(message)s'))
logging.getLogger("app").addHandler(console_handler)
logging.getLogger("uvicorn.error").addHandler(console_handler)

# اطمینان از اینکه لاگ‌های uvicorn و FastAPI به loggerهای خودشان می‌روند
for logger_name in ["uvicorn", "uvicorn.error", "uvicorn.access", "fastapi"]:
    ext_logger = logging.getLogger(logger_name)
    ext_logger.handlers = []
    ext_logger.propagate = True

# استفاده از logger مناسب در کد
logger = logging.getLogger("app")
db_logger = logging.getLogger("db")

# Lifespan context manager for modern FastAPI
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager for database initialization and cleanup"""
    # Startup - only log once
    if not hasattr(app.state, 'startup_logged'):
        logger.info("🚀 Smart Camera System startup: initializing database and tables...")
        app.state.startup_logged = True
    try:
        # Check for critical static files
        required_files = ["static/css/index/styles.css", "static/js/index/script.js"]
        for file in required_files:
            if not os.path.exists(file):
                logger.warning(f"⚠️ Critical static file not found: {file}")
        
        # Create necessary directories
        logger.info("📁 Creating necessary directories...")
        await asyncio.to_thread(os.makedirs, GALLERY_DIR, exist_ok=True)
        await asyncio.to_thread(os.makedirs, SECURITY_VIDEOS_DIR, exist_ok=True)
        await asyncio.to_thread(os.makedirs, BACKUP_DIR, exist_ok=True)
        await asyncio.to_thread(os.makedirs, "logs", exist_ok=True)
        logger.info("✅ Directories created successfully")
        
        # Initialize database with retry mechanism
        logger.info("🗄️ Initializing database...")
        max_retries = 3
        for attempt in range(max_retries):
            try:
                await init_db()
                logger.info("✅ Database initialized successfully")
                break
            except Exception as e:
                logger.error(f"❌ Database initialization attempt {attempt + 1} failed: {e}")
                if attempt == max_retries - 1:
                    raise
                await asyncio.sleep(2)  # Wait before retry
        
        # Run migrations with better error handling
        logger.info("🔄 Running database migrations...")
        try:
            await migrate_all_tables()
            logger.info("✅ Database migrations completed")
        except Exception as e:
            if "UNIQUE constraint failed" in str(e) or "duplicate column name" in str(e):
                logger.debug(f"Migration completed with expected warnings: {e}")
            else:
                logger.warning(f"⚠️ Migration warning (non-critical): {e}")
        
        logger.info("🎉 Database and tables ready. Continuing startup...")
        
        # Start background tasks
        logger.info("🔄 Starting background tasks...")
        app.state.backup_task = asyncio.create_task(periodic_backup_and_reset())
        app.state.cleanup_task = asyncio.create_task(periodic_cleanup())
        app.state.health_monitor_task = asyncio.create_task(monitor_system_health())
        logger.info("✅ Background tasks STARTED")
        
        # Set up signal handlers
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
        logger.info("✅ Signal handlers configured")
        
        logger.info("🎉 Smart Camera System ready and operational!")
        
    except Exception as e:
        logger.error(f"❌ System startup error: {e}")
        raise
    
    yield
    
    # Shutdown
    logger.info("🔄 Shutting down Smart Camera System...")
    try:
        # Cancel background tasks
        if hasattr(app.state, 'backup_task'):
            app.state.backup_task.cancel()
        if hasattr(app.state, 'cleanup_task'):
            app.state.cleanup_task.cancel()
        if hasattr(app.state, 'health_monitor_task'):
            app.state.health_monitor_task.cancel()
        
        # Cleanup system state
        if hasattr(system_state, 'cleanup'):
            await system_state.cleanup()
        
        logger.info("✅ System shutdown completed")
    except Exception as e:
        logger.error(f"❌ System shutdown error: {e}")

# FastAPI app setup with modern lifespan
app = FastAPI(
    title="Smart Camera Security System", 
    version="3.0",
    lifespan=lifespan
)





# Authentication dependency
def get_current_user(request: Request):
    """Get current user from token in cookies or headers"""
    token = request.cookies.get("access_token") or request.headers.get("Authorization", "").replace("Bearer ", "")
    if not token or not verify_token(token):
        return None
    
    # Get user info from token
    user_info = verify_token(token)
    if not user_info:
        return None
    
    # Return user info for all authenticated users
    # Removed the hard reload check that was causing issues for regular users
    return user_info

# Add security headers and authentication middleware
@app.middleware("http")
async def auth_and_security_middleware(request: Request, call_next):
    # Public endpoints that do not require authentication
    public_endpoints = [
        "/login",
        "/logout",
        "/register",
        "/recover-password",
        "/health",
        "/ports",
        "/esp32cam/status",
        "/pico/status",
        "/devices/status",
        "/tokens",
        "/public/tokens",
        "/ws",
        "/static",
        "/gallery",
        "/security_videos",
        "/favicon.ico",
        "/reset-password",
        "/auth/google",
        "/auth/google/callback"
    ]
    
    # Check if current path is public
    is_public = any(request.url.path.startswith(p) for p in public_endpoints)
    # Special handling for specific POST endpoints
    if request.method == "POST" and request.url.path in ["/logout", "/register", "/recover-password", "/login"]:
        is_public = True
    
    # Debug log for middleware decision
    logger.info(f"[MIDDLEWARE] Path: {request.url.path}, Method: {request.method}, Is Public: {is_public}")
    
    # If it's a public endpoint, allow access
    if is_public:
        response = await call_next(request)
        # Add security headers
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' cdnjs.cloudflare.com https://speedcf.cloudflareaccess.com; style-src 'self' 'unsafe-inline' cdnjs.cloudflare.com; font-src 'self' cdnjs.cloudflare.com; img-src 'self' data: blob:; connect-src 'self' ws: wss:; object-src 'none'; base-uri 'self';"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
        return response
    
    # For non-public paths, check authentication
    token = request.cookies.get("access_token") or request.headers.get("Authorization", "").replace("Bearer ", "")
    user_info = verify_token(token) if token else None
    accept_header = request.headers.get("accept", "").lower()
    content_type = request.headers.get("content-type", "").lower()
    
    # Debug log for authentication decision
    logger.info(f"[MIDDLEWARE] Path: {request.url.path}, Method: {request.method}, Token: {bool(token)}, User: {user_info}, Accept: {accept_header[:50]}")
    
    if not user_info:
        # For API requests, return 401
        if request.url.path.startswith("/api/"):
            logger.debug(f"[MIDDLEWARE] Unauthorized API access to {request.url.path}")
            return JSONResponse({"detail": "Unauthorized", "redirect": "/login"}, status_code=401)
        # For test environment, return 401
        elif "test" in request.url.hostname:
            logger.debug(f"[MIDDLEWARE] Unauthorized test access to {request.url.path}")
            return JSONResponse({"detail": "Unauthorized", "redirect": "/login"}, status_code=401)
        # HTML request - redirect to login
        logger.debug(f"[MIDDLEWARE] Unauthorized HTML access to {request.url.path}")
        return RedirectResponse(url="/login", status_code=302)
    else:
        # Token exists and is valid - allow access
        logger.debug(f"[MIDDLEWARE] Authorized access to {request.url.path} for user {user_info.get('sub')}")
        pass
    
    # Continue with the request
    response = await call_next(request)
    # Add security headers
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' cdnjs.cloudflare.com https://speedcf.cloudflareaccess.com; style-src 'self' 'unsafe-inline' cdnjs.cloudflare.com; font-src 'self' cdnjs.cloudflare.com; img-src 'self' data: blob:; connect-src 'self' ws: wss:; object-src 'none'; base-uri 'self';"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
    return response

app.mount("/static", StaticFiles(directory="static"), name="static")
app.mount("/gallery", StaticFiles(directory="gallery"), name="gallery")
app.mount("/security_videos", StaticFiles(directory="security_videos"), name="security_videos")
app.include_router(port_router, prefix="/api/v1")

# Define the datetimeformat filter
def datetimeformat(value, lang='en'):
    try:
        if isinstance(value, str):
            dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
        elif isinstance(value, datetime):
            dt = value
        else:
            return value
        if lang == 'fa' and PERSIANTOOLS_AVAILABLE:
            jalali_dt = JalaliDateTime.from_datetime(dt)
            return jalali_dt.strftime("%Y/%m/%d %H:%M:%S")
        else:
            return dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception as e:
        logger.exception(f"Error formatting datetime: {e}")
        return value

# Define the translate_log_level filter
def translate_log_level(value, lang='en'):
    try:
        log_level_translations = {
            'en': {'info': 'Info', 'warning': 'Warning', 'error': 'Error', 'debug': 'Debug', 'critical': 'Critical', 'photo': 'Photo', 'delete': 'Delete', 'command': 'Command', 'logout': 'Logout'},
            'fa': {'info': 'اطلاعات', 'warning': 'هشدار', 'error': 'خطا', 'debug': 'دیباگ', 'critical': 'بحرانی', 'photo': 'عکس', 'delete': 'حذف', 'command': 'دستور', 'logout': 'خروج'}
        }
        translations = log_level_translations.get(lang, log_level_translations['en'])
        return translations.get(value.lower(), value)
    except Exception as e:
        logger.exception(f"Error translating log level: {e}")
        return value

# Initialize Jinja2Templates with custom filters
templates = Jinja2Templates(directory="templates")
templates.env.filters['datetimeformat'] = datetimeformat
templates.env.filters['translate_log_level'] = translate_log_level

# Constants
DB_FILE = "smart_camera_system.db"
BACKUP_DIR = "backups"
GALLERY_DIR = "gallery"
SECURITY_VIDEOS_DIR = "security_videos"
DB_TIMEOUT = 60  # seconds, increased for better concurrency handling
DB_POOL_SIZE = 10  # Connection pool size
DB_MAX_OVERFLOW = 20  # Maximum overflow connections
BACKUP_INTERVAL = 24 * 3600
DISK_CHECK_INTERVAL = 12 * 3600
DISK_THRESHOLD = 10
BACKUP_RETENTION_DAYS = 31
MAX_FRAME_SIZE = 1024 * 1024
MAX_UPLOAD_SIZE = 512 * 1024

WEBSOCKET_ERROR_THRESHOLD = 10
WEBSOCKET_ERROR_BAN = 20
MAX_WEBSOCKET_MESSAGE_SIZE = 1024 * 1024
MAX_WEBSOCKET_CLIENTS = 100
INACTIVE_CLIENT_TIMEOUT = 300  # 5 minutes timeout for inactive clients

# Security constants are already defined above
ALGORITHM = "HS256"

# --- Frame Processing & Real-time Performance Constants ---
FRAME_QUEUE_SIZE = 10  # افزایش برای کاهش blocking
MEMORY_THRESHOLD = 0.75  # کاهش برای حساسیت بیشتر
VIDEO_FPS = 25  # بهینه‌سازی برای real-time (کاهش از 30)
VIDEO_QUALITY = 85  # افزایش کیفیت
FRAME_PROCESSING_ENABLED = True
PERSIAN_TEXT_OVERLAY = True
SECURITY_VIDEO_DURATION = 1800  # کاهش به 30 دقیقه
FRAME_BUFFER_SIZE = VIDEO_FPS * 1800  # 30 دقیقه buffer (45,000 frames)
MIN_VALID_FRAMES = VIDEO_FPS * 30  # حداقل 30 ثانیه
MAX_FRAME_RATE = VIDEO_FPS
MAX_FRAME_SIZE = 2 * 1024 * 1024  # افزایش به 2MB
MAX_WEBSOCKET_MESSAGE_SIZE = 2 * 1024 * 1024  # افزایش به 2MB

# --- Real-time Performance Settings ---
REALTIME_FRAME_PROCESSING = True
FRAME_SKIP_THRESHOLD = 3  # تعداد فریم‌های قابل رد کردن
FRAME_PROCESSING_TIMEOUT = 0.1  # 100ms timeout برای پردازش
FRAME_COMPRESSION_THRESHOLD = 500 * 1024  # 500KB threshold برای فشرده‌سازی
ADAPTIVE_QUALITY = True  # کیفیت تطبیقی بر اساس عملکرد
MIN_FRAME_INTERVAL = 1.0 / VIDEO_FPS  # حداقل فاصله بین فریم‌ها
FRAME_DROP_RATIO = 0.1  # حداکثر 10% فریم قابل حذف
WEBSOCKET_BATCH_SIZE = 5  # ارسال دسته‌ای فریم‌ها
FRAME_CACHE_SIZE = 100  # کش فریم‌های اخیر

# --- Device Resolutions for Adaptive Processing ---
DEVICE_RESOLUTIONS = {
    "desktop": {"width": 1280, "height": 720},
    "mobile": {"width": 640, "height": 480},
    "tablet": {"width": 1024, "height": 768}
}

# --- Performance Monitoring ---
PERFORMANCE_MONITORING = True
FRAME_LATENCY_THRESHOLD = 0.2  # 200ms threshold برای latency
PROCESSING_OVERHEAD_THRESHOLD = 0.5  # 50% threshold برای overhead
MAX_BACKUP_CHECK = 5
MAX_RESIZED_FRAMES = 50

# --- Performance Update Intervals ---
PERFORMANCE_UPDATE_INTERVAL = 5.0  # Update metrics every 5 seconds
FRAME_CACHE_CLEANUP_INTERVAL = 30.0  # Cleanup frame cache every 30 seconds

DEVICE_RESOLUTIONS = {
    "desktop": {"width": 1072, "height": 603},
    "mobile": {"width": 536, "height": 301}
}

# Translations dictionary
translations = {
    "fa": {
        # General
        "siteTitle": "سیستم هوشمند دوربین امنیتی",
        "logoAlt": "لوگو",
        # Typewriter (header)
        "headerTypewriter1": "امنیت هوشمند، آینده‌ای مطمئن 🛡️",
        "headerTypewriter2": "نظارت زنده، آرامش خاطر 👁️",
        "headerTypewriter3": "هوش مصنوعی در خدمت امنیت شما 🤖",
        "headerTypewriter4": "حفاظت ۲۴/۷ با فناوری نوین 🔒",
        "headerTypewriter5": "کنترل سریع، واکنش هوشمند ⚡",
        "headerTypewriter6": "دسترسی آسان از هر نقطه 🌐",
        "headerTypewriter7": "ثبت لحظات مهم امنیتی 📸",
        "headerTypewriter8": "امنیت خانه و محل کار شما 🛡️",
        "headerTypewriter9": "اتصال پایدار و بی‌وقفه 🛰️",
        # Typewriter (footer)
        "footerTypewriter1": "امنیت خانه و محل کار با ما! 🏠🔒",
        "footerTypewriter2": "پشتیبانی حرفه‌ای و سریع 🚀",
        "footerTypewriter3": "دسترسی آسان از هرجا 🌍",
        "footerTypewriter4": "گزارش‌های تصویری و آماری 📈",
        "footerTypewriter5": "تجربه امنیت هوشمند با هوش مصنوعی 🤖",
        "footerTypewriter6": "ارتباط با ما همیشه باز است 📞",
        "footerTypewriter7": "به‌روزرسانی خودکار و رایگان 🔄",
        # Main sections
        "introHeading": "🚀 معرفی سیستم هوشمند امنیتی",
        "introWelcome": "🌟 به آینده امنیت خوش آمدید!",
        "introMainDesc": "🔐 سیستم هوشمند دوربین امنیتی ما، با بهره‌گیری از فناوری‌های پیشرفته مانند WebSocket، هوش مصنوعی و دوربین‌های باکیفیت، تجربه‌ای بی‌نظیر از نظارت و امنیت را ارائه می‌دهد.",
        "keyFeatures": "🚀 ویژگی‌های کلیدی سیستم",
        "featureFast": "⚡ واکنش سریع و هوشمند به رویدادها",
        "featureLive": "👁️ پایش زنده و ضبط ویدئو با کیفیت بالا",
        "featureServo": "⚙️ کنترل دقیق سرووها و تنظیم زاویه دوربین",
        "featureNotif": "🔔 اعلان رخدادهای امنیتی به صورت زنده",
        "featureReport": "📊 گزارش‌های تصویری و آماری از فعالیت‌ها",
        "featureMotion": "🤖 تشخیص حرکت هوشمند و ردیابی اشیاء",
        "featureRemote": "🌐 دسترسی از راه دور و کنترل کامل",
        "featureEncrypt": "🔒 رمزگذاری پیشرفته و امنیت داده‌ها",
        "techSpecs": "📈 مشخصات فنی سیستم",
        "hdQuality": "کیفیت تصویر",
        "hdLabel": "کیفیت تصویر",
        "frameRate": "نرخ فریم",
        "frameRateLabel": "نرخ فریم",
        "viewAngle": "زاویه دید",
        "viewAngleLabel": "زاویه دید",
        "wifiConnection": "اتصال",
        "wifiConnectionLabel": "اتصال",
        "techStack": "🛠️ فناوری‌های سیستم",
        "techPython": "Python",
        "techWebSocket": "WebSocket",
        "techFastAPI": "FastAPI",
        "techSQLite": "SQLite",
        "techHTML": "HTML/CSS/JS",
        "techESP32": "ESP32-CAM",
        "benefitsTitle": "💎 مزایای سیستم",
        "benefit24h": "🛡️ نظارت امنیتی ۲۴ ساعته",
        "benefitBrowser": "📱 دسترسی از طریق مرورگر",
        "benefitLang": "🌍 رابط کاربری فارسی/انگلیسی",
        "benefitServo": "🔄 کنترل سروو و زاویه دوربین",
        "benefitCost": "💰 راه‌حل مقرون به صرفه",
        "benefitFast": "⚡ عملکرد سریع و پایدار",
        "useCases": "🎯 کاربردهای سیستم",
        "useHome": "نظارت خانگی",
        "useOffice": "نظارت اداری",
        "useStore": "نظارت فروشگاهی",
        "useParking": "نظارت پارکینگ",
        "ctaReady": "🎯 سیستم امنیتی هوشمند شما آماده است!",
        "ctaUse": "💡 از قابلیت‌های سیستم برای نظارت و امنیت استفاده کنید",
        # Accordion titles
        "cameraHeading": "📹 کنترل دوربین و سرووها",
        "galleryHeading": "🖼️ گالری تصاویر امنیتی",
        "videosHeading": "🎬 گالری ویدئوهای امنیتی",
        "smartFeaturesHeading": "🧠 قابلیت‌های هوشمند امنیتی",
        "logsHeading": "📋 گزارش‌های سیستم",
        # Camera/Servo
        "liveStreamTitle": "🎥 استریم زنده",
        "captureImageTitle": "📸 ثبت تصویر",
        "photoQualityLabel": "کیفیت تصویر",
        "flashIntensityLabel": "شدت فلاش",
        "enableFlashLabel": "فعال‌سازی فلاش",
        "capturePhoto": "عکس‌برداری",
        "servoControlTitle": "⚙️ کنترل سرووها",
        "servoXLabel": "محور X",
        "servoYLabel": "محور Y",
        "send": "ارسال",
        "reset": "بازنشانی",
        # Gallery/Video
        "galleryPageHeading": "گالری تصاویر",
        "download": "دانلود",
        "delete": "حذف",
        "date": "تاریخ",
        "weekday": "روز",
        "loadMore": "📥 بارگذاری بیشتر",
        # Smart features
        "smartMotionDetectLabel": "🔍 تشخیص حرکت هوشمند",
        "smartObjectTrackingLabel": "🎯 ردیابی اشیاء/افراد",
        "smartFeaturesDesc": "🧠 قابلیت‌های هوشمند مانند تشخیص حرکت و ردیابی اشیاء/افراد",
        "smartFeaturesHint": "💡 با فعال‌سازی قابلیت‌های هوشمند، امنیت محیط خود را به سطحی جدید ببرید! تشخیص حرکت و ردیابی اشیاء/افراد به شما امکان می‌دهد همیشه و همه‌جا از وضعیت محیط آگاه باشید.",
        # Logs/Status
        "recentLogsTitle": "📊 گزارش‌های اخیر",
        "logLimitLabel": "تعداد گزارش‌ها",
        # Profile translations
        "profileTitle": "پروفایل کاربری",
        "profileUsername": "نام کاربری",
        "profileRole": "نقش کاربری",
        "profileOnline": "آنلاین",
        "profileSettings": "تنظیمات",
        "profileHelp": "راهنما",
        "profileAbout": "درباره سیستم",
        "profileLogout": "خروج از حساب",
        "footerProfileMobile": "پروفایل",
        "logLimitOption10": "10",
        "logLimitOption50": "50",
        "logLimitOption100": "100",
        "showAllLogs": "📋 نمایش همه گزارش‌ها",
        "ramLabel": "RAM",
        "cpuLabel": "CPU",
        "storageLabel": "Storage",
        "internetLabel": "Internet",
        "cameraLabel": "Camera",
        "picoLabel": "Pico",
        # SPA/Modals/Profile
        "aboutHeading": "درباره ما",
        "aboutText": "ما در سیستم هوشمند دوربین امنیتی، با فناوری پیشرفته از امنیت شما محافظت می‌کنیم. هدف ما ارائه راه‌حل‌های نوآورانه و قابل اعتماد امنیتی است.",
        "storeHeading": "فروشگاه",
        "contactHeading": "تماس با ما",
        "yourName": "نام شما",
        "yourEmail": "ایمیل",
        "yourMessage": "پیام شما",
        "sendMessage": "ارسال پیام",
        "profileTitle": "پروفایل کاربر",
        "profileUsername": "نام کاربری",
        "profileTheme": "تم",
        "profileLang": "زبان",
        "close": "بستن",
        # Footer
        "footerAbout": "درباره ما",
        "footerAboutText": "ما در سیستم هوشمند دوربین امنیتی، با استفاده از فناوری‌های پیشرفته، امنیت شما را تضمین می‌کنیم. هدف ما ارائه راه‌حل‌های امنیتی پویا و قابل اعتماد است.",
        "footer24h": "امنیت ۲۴/۷",
        "footerAuto": "به‌روزرسانی خودکار",
        "footerSupport": "پشتیبانی حرفه‌ای",
        "footerLinks": "لینک‌های مفید",
        "footerContact": "ارتباط با ما",
        "footerHomeMobile": "خانه",
        "footerStatusMobile": "وضعیت",
        "footerProfileMobile": "پروفایل",
        "footerCopyright": "2025 سیستم هوشمند دوربین امنیتی. تمامی حقوق محفوظ است.",
        # Buttons/Labels
        "themeLight": "تم",
        "themeDark": "حالت شب",
        "langLabel": "English",
        "home": "خانه",
        "store": "فروشگاه",
        "contact": "ارتباط با ما",
        # Notifications/JS
        "connectionError": "خطا در اتصال",
        "angleError": "زوایای سروو باید بین 0 تا 180 باشند.",
        "settingsError": "خطا در ارسال تنظیمات",
        "galleryError": "خطا در بارگذاری گالری",
        "deleteError": "خطا در حذف فایل",
        "settingsChanged": "تنظیمات اعمال شد: ",
        "recordingStarted": "ضبط ویدئو آغاز شد",
        "recordingStopped": "ضبط ویدئو متوقف شد",
        "motionDetected": "حرکت تشخیص داده شد!",
        "desktopMode": "حالت دسکتاپ",
        "mobileMode": "حالت موبایل",
        "streamStarted": "شروع استریم زنده",
        "streamStopped": "پایان استریم زنده",
        "photoCaptured": "تصویر با موفقیت ثبت شد",
        "servoCommandSent": "دستور سروو ارسال شد",
        "servosReset": "سرووها بازنشانی شدند",
        "logsUpdated": "گزارش‌ها به‌روزرسانی شدند",
        "languageChanged": "زبان به فارسی تغییر کرد",
        "darkModeEnabled": "حالت تاریک فعال شد",
        "lightModeEnabled": "حالت روشن فعال شد",
        "flashToggled": "فلاش {enabled} شد",
        "logoutSuccess": "با موفقیت خارج شدید",
        # Log levels
        "logLevel_info": "اطلاعات",
        "logLevel_error": "خطا",
        "logLevel_warning": "هشدار",
        "logLevel_connection": "اتصال",
        "logLevel_command": "دستور",
        "logLevel_photo": "عکس",
        "logLevel_video": "ویدئو",
        "logLevel_backup": "پشتیبان",
        "logLevel_delete": "حذف",
        "logLevel_motion": "حرکت",
        # SPA/Status
        "spaStatusTitle": "وضعیت سیستم",
        "spaActiveUsers": "کاربران فعال",
        "spaBackText": "بازگشت",
        "weekday_sun": "یکشنبه",
        "weekday_mon": "دوشنبه",
        "weekday_tue": "سه‌شنبه",
        "weekday_wed": "چهارشنبه",
        "weekday_thu": "پنجشنبه",
        "weekday_fri": "جمعه",
        "weekday_sat": "شنبه",
        # ... add more as needed ...
    },
    "en": {
        # General
        "siteTitle": "Smart Security Camera System",
        "logoAlt": "Logo",
        # Typewriter (header)
        "headerTypewriter1": "Smart Security, Confident Future 🛡️",
        "headerTypewriter2": "Live Monitoring, Peace of Mind 👁️",
        "headerTypewriter3": "AI-Powered Protection 🤖",
        "headerTypewriter4": "24/7 Safety with Innovation 🔒",
        "headerTypewriter5": "Fast Control, Smart Response ⚡",
        "headerTypewriter6": "Easy Access, Anywhere 🌐",
        "headerTypewriter7": "Capture Every Security Moment 📸",
        "headerTypewriter8": "Protecting Home & Business 🛡️",
        "headerTypewriter9": "Reliable, Uninterrupted Connection 🛰️",
        # Typewriter (footer)
        "footerTypewriter1": "Secure your home & business! 🏠🔒",
        "footerTypewriter2": "Fast & professional support 🚀",
        "footerTypewriter3": "Easy access from anywhere 🌍",
        "footerTypewriter4": "Visual & statistical reports 📈",
        "footerTypewriter5": "Smart security powered by AI 🤖",
        "footerTypewriter6": "We are always here for you 📞",
        "footerTypewriter7": "Free automatic updates 🔄",
        # Main sections
        "introHeading": "🚀 Smart Security System Introduction",
        "introWelcome": "🌟 Welcome to the Future of Security!",
        "introMainDesc": "🔐 Our smart security camera system, powered by advanced technologies like WebSocket, AI, and high-quality cameras, delivers an unparalleled surveillance and security experience.",
        "keyFeatures": "🚀 Key System Features",
        "featureFast": "⚡ Fast & intelligent event response",
        "featureLive": "👁️ Live monitoring & high-quality video recording",
        "featureServo": "⚙️ Precise servo control & camera angle adjustment",
        "featureNotif": "🔔 Live security event notifications",
        "featureReport": "📊 Visual & statistical activity reports",
        "featureMotion": "🤖 Smart motion detection & object tracking",
        "featureRemote": "🌐 Remote access & full control",
        "featureEncrypt": "🔒 Advanced encryption & data security",
        "techSpecs": "📈 Technical Specifications",
        "hdQuality": "Image Quality",
        "hdLabel": "Image Quality",
        "frameRate": "Frame Rate",
        "frameRateLabel": "Frame Rate",
        "viewAngle": "View Angle",
        "viewAngleLabel": "View Angle",
        "wifiConnection": "Connection",
        "wifiConnectionLabel": "Connection",
        "techStack": "🛠️ System Technologies",
        "techPython": "Python",
        "techWebSocket": "WebSocket",
        "techFastAPI": "FastAPI",
        "techSQLite": "SQLite",
        "techHTML": "HTML/CSS/JS",
        "techESP32": "ESP32-CAM",
        "benefitsTitle": "💎 System Benefits",
        "benefit24h": "🛡️ 24-hour security monitoring",
        "benefitBrowser": "📱 Browser-based access",
        "benefitLang": "🌍 Persian/English interface",
        "benefitServo": "🔄 Servo control & camera angle",
        "benefitCost": "💰 Cost-effective solution",
        "benefitFast": "⚡ Fast & stable performance",
        "useCases": "🎯 System Applications",
        "useHome": "Home monitoring",
        "useOffice": "Office monitoring",
        "useStore": "Store monitoring",
        "useParking": "Parking monitoring",
        "ctaReady": "🎯 Your smart security system is ready!",
        "ctaUse": "💡 Use system features for monitoring and security",
        # Accordion titles
        "cameraHeading": "📹 Camera and Servo Control",
        "galleryHeading": "🖼️ Security Images Gallery",
        "videosHeading": "🎬 Security Videos Gallery",
        "smartFeaturesHeading": "🧠 Smart Security Features",
        "logsHeading": "📋 System Logs",
        # Camera/Servo
        "liveStreamTitle": "🎥 Live Stream",
        "captureImageTitle": "📸 Capture Image",
        "photoQualityLabel": "Image Quality",
        "flashIntensityLabel": "Flash Intensity",
        "enableFlashLabel": "Enable Flash",
        "capturePhoto": "Capture Photo",
        "servoControlTitle": "⚙️ Servo Control",
        "servoXLabel": "X Axis",
        "servoYLabel": "Y Axis",
        "send": "Send",
        "reset": "Reset",
        # Gallery/Video
        "galleryPageHeading": "Gallery",
        "download": "Download",
        "delete": "Delete",
        "date": "Date",
        "weekday": "Weekday",
        "loadMore": "📥 Load More",
        "viewImage": "View Image",
        # Smart features
        "smartMotionDetectLabel": "🔍 Smart Motion Detection",
        "smartObjectTrackingLabel": "🎯 Object/Person Tracking",
        "smartFeaturesDesc": "🧠 Smart features like motion detection and object/person tracking",
        "smartFeaturesHint": "💡 Enable smart features to take your security to the next level! Motion detection and object/person tracking keep you aware of your environment at all times.",
        # Logs/Status
        "recentLogsTitle": "📊 Recent Logs",
        "logLimitLabel": "Number of Logs",
        # Profile translations
        "profileTitle": "User Profile",
        "profileUsername": "Username",
        "profileRole": "User Role",
        "profileOnline": "Online",
        "profileSettings": "Settings",
        "profileHelp": "Help",
        "profileAbout": "About System",
        "profileLogout": "Logout",
        "footerProfileMobile": "Profile",
        "logLimitOption10": "10",
        "logLimitOption50": "50",
        "logLimitOption100": "100",
        "showAllLogs": "📋 Show All Logs",
        "ramLabel": "RAM",
        "cpuLabel": "CPU",
        "storageLabel": "Storage",
        "internetLabel": "Internet",
        "cameraLabel": "Camera",
        "picoLabel": "Pico",
        "online": "Online",
        "offline": "Offline",
        "activeUsers": "Active Users",
        "source": "Source",
        # Log levels and types
        "command": "Command",
        "photo": "Photo",
        "delete": "Delete",
        "logout": "Logout",
        "error": "Error",
        "info": "Info",
        "warning": "Warning",
        # Persian log types/labels for fallback translation
        "دستور": "Command",
        "عکس": "Photo",
        "منبع": "Source",
        "آفلاین": "Offline",
        "آنلاین": "Online",
        # SPA/Modals/Profile
        "aboutHeading": "About Us",
        "aboutText": "At Smart Security Camera System, we protect your safety with advanced technology. Our mission is to deliver reliable and innovative security solutions.",
        "storeHeading": "Store",
        "contactHeading": "Contact Us",
        "yourName": "Your Name",
        "yourEmail": "Email",
        "yourMessage": "Your Message",
        "sendMessage": "Send Message",
        "profileTitle": "User Profile",
        "profileUsername": "Username",
        "profileTheme": "Theme",
        "profileLang": "Language",
        "close": "Close",
        # Footer
        "footerAbout": "About Us",
        "footerAboutText": "At Smart Security Camera System, we ensure your safety with cutting-edge technology. Our goal is to provide dynamic and reliable security solutions.",
        "footer24h": "24/7 Security",
        "footerAuto": "Auto Updates",
        "footerSupport": "Professional Support",
        "footerLinks": "Useful Links",
        "footerContact": "Contact",
        "footerHomeMobile": "Home",
        "footerStatusMobile": "Status",
        "footerProfileMobile": "Profile",
        "footerCopyright": "2025 Smart Security Camera System. All rights reserved.",
        # Buttons/Labels
        "themeLight": "Theme",
        "themeDark": "Dark",
        "langLabel": "فارسی",
        "home": "Home",
        "store": "Store",
        "contact": "Contact",
        # Notifications/JS
        "connectionError": "Connection error",
        "angleError": "Angles must be between 0 and 180.",
        "settingsError": "Error sending settings",
        "galleryError": "Error loading gallery",
        "deleteError": "Error deleting file",
        "settingsChanged": "Settings applied: ",
        "recordingStarted": "Video recording started",
        "recordingStopped": "Video recording stopped",
        "motionDetected": "Motion detected!",
        "desktopMode": "Desktop Mode",
        "mobileMode": "Mobile Mode",
        "streamStarted": "Live stream started",
        "streamStopped": "Live stream stopped",
        "photoCaptured": "Photo captured successfully",
        "servoCommandSent": "Servo command sent",
        "servosReset": "Servos reset",
        "logsUpdated": "Logs updated",
        "languageChanged": "Language changed to English",
        "darkModeEnabled": "Dark mode enabled",
        "lightModeEnabled": "Light mode enabled",
        "flashToggled": "Flash {enabled}",
        "logoutSuccess": "Successfully logged out",
        # Log levels
        "logLevel_info": "Info",
        "logLevel_error": "Error",
        "logLevel_warning": "Warning",
        "logLevel_connection": "Connection",
        "logLevel_command": "Command",
        "logLevel_photo": "Photo",
        "logLevel_video": "Video",
        "logLevel_backup": "Backup",
        "logLevel_delete": "Delete",
        "logLevel_motion": "Motion",
        # SPA/Status
        "spaStatusTitle": "System Status",
        "spaActiveUsers": "Active Users",
        "spaBackText": "Back",
        # Modal/Dialogs
        "modalViewImage": "View Image",
        "modalDownload": "Download",
        "modalDelete": "Delete",
        "modalDate": "Date",
        "modalClose": "Close",
        # Profile Modal
        "profileGuest": "guest",
        # Persian fallback for missing translations
        "persianFallback": "[Translation missing]",
        "weekday_sun": "Sunday",
        "weekday_mon": "Monday",
        "weekday_tue": "Tuesday",
        "weekday_wed": "Wednesday",
        "weekday_thu": "Thursday",
        "weekday_fri": "Friday",
        "weekday_sat": "Saturday",
        # ... add more as needed ...
    }
}

class SingletonMeta(type):
    _instance = None
    def __call__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__call__(*args, **kwargs)
        return cls._instance

class SystemState(metaclass=SingletonMeta):
    def __init__(self):
        # --- Frame Processing & Real-time Performance ---
        self.esp32_frame_queue = Queue(maxsize=FRAME_QUEUE_SIZE)
        self.frame_lock = asyncio.Lock()
        self.performance_lock = asyncio.Lock()  # New lock for performance metrics
        self.latest_frame = None
        self.frame_cache = {}  # کش فریم‌های اخیر
        self.frame_processing_times = []  # زمان‌های پردازش فریم
        self.frame_drop_count = 0  # تعداد فریم‌های حذف شده
        self.frame_skip_count = 0  # تعداد فریم‌های رد شده
        self.last_frame_time = time.time()
        self.frame_latency_sum = 0  # مجموع latency فریم‌ها
        self.frame_count = 0
        
        # --- Performance Monitoring ---
        self.performance_metrics = {
            "avg_frame_latency": 0.0,
            "frame_processing_overhead": 0.0,
            "frame_drop_rate": 0.0,
            "memory_usage": 0.0,
            "cpu_usage": 0.0
        }
        self.last_performance_update = time.time()
        self.last_frame_cache_cleanup = time.time()
        
        # --- Real-time Processing ---
        self.realtime_enabled = REALTIME_FRAME_PROCESSING
        self.adaptive_quality = ADAPTIVE_QUALITY
        self.current_quality = VIDEO_QUALITY
        self.processing_timeout = FRAME_PROCESSING_TIMEOUT
        
        # --- System State ---
        self.last_backup_time = time.time()
        self.web_clients: List[WebSocket] = []
        self.pico_client: Optional[WebSocket] = None
        self.esp32cam_client: Optional[WebSocket] = None
        self.web_clients_lock = asyncio.Lock()
        self.pico_client_lock = asyncio.Lock()
        self.esp32cam_client_lock = asyncio.Lock()
        
        # --- Command Management ---
        self.command_queue = asyncio.Queue()
        self.command_lock = asyncio.Lock()
        self.last_command_time = time.time()
        
        # --- Device Status ---
        self.device_status = {
            "pico": {"online": False, "last_seen": None, "errors": []},
            "esp32cam": {"online": False, "last_seen": None, "errors": []}
        }
        
        # --- Video & Buffer Management ---
        self.video_count = 0
        self.last_memory_check = time.time()
        self.websocket_error_count = 0
        self.last_websocket_error_time = time.time()
        self.db_initialized = False
        self.system_shutdown = False
        self.memory_warning_sent = False
        self.frame_buffer: List[Tuple[bytes, datetime]] = []
        self.frame_buffer_lock = asyncio.Lock()
        self.video_writer = None
        
        # --- Processing Settings ---
        self.processing_enabled = FRAME_PROCESSING_ENABLED
        self.is_low_power = False
        self.video_quality = VIDEO_QUALITY
        self.invalid_frame_count = 0
        self.last_disk_space = 'N/A'
        self.flash_intensity = 50
        self.device_mode = "desktop"
        self.resolution = DEVICE_RESOLUTIONS["desktop"]
        
        # --- Smart Features ---
        self.smart_motion_enabled = False
        self.object_tracking_enabled = False
        
        # --- Enhanced Error Tracking ---
        self.error_counts = {
            "websocket": 0,
            "database": 0,
            "frame_processing": 0,
            "memory": 0
        }
        self.last_error_reset = time.time()
        
        # --- Connection Management ---
        self.client_connection_times = {}
        self.connection_attempts = {
            "pico": 0,
            "esp32cam": 0
        }

    async def cleanup(self):
        """Enhanced cleanup with comprehensive resource management"""
        try:
            # Cleanup frame processing
            async with self.frame_lock:
                self.esp32_frame_queue.queue.clear()
                self.latest_frame = None
            
            # Cleanup WebSocket connections with proper error handling
            async with self.web_clients_lock:
                for client in self.web_clients[:]:  # Copy list to avoid modification during iteration
                    try:
                        await client.close(code=1000)
                    except Exception as e:
                        logger.warning(f"Error closing web client: {e}")
                        raise
                self.web_clients.clear()
            
            async with self.pico_client_lock:
                if self.pico_client:
                    try:
                        await self.pico_client.close(code=1000)
                    except Exception as e:
                        logger.warning(f"Error closing pico client: {e}")
                        logger.exception(e)
                        raise
                self.pico_client = None
            
            async with self.esp32cam_client_lock:
                if self.esp32cam_client:
                    try:
                        await self.esp32cam_client.close(code=1000)
                    except Exception as e:
                        logger.warning(f"Error closing esp32cam client: {e}")
                        logger.exception(e)
                        raise
                self.esp32cam_client = None
            
            # Cleanup frame buffer
            async with self.frame_buffer_lock:
                self.frame_buffer.clear()
            
            # Cleanup video writer
            if self.video_writer:
                try:
                    await asyncio.to_thread(self.video_writer.release)
                except Exception as e:
                    logger.warning(f"Error releasing video writer: {e}")
                self.video_writer = None
            
            # Cleanup temporary files
            try:
                for temp_file in await asyncio.to_thread(os.listdir, BACKUP_DIR):
                    if temp_file.startswith("temp"):
                        await asyncio.to_thread(os.remove, os.path.join(BACKUP_DIR, temp_file))
            except Exception as e:
                logger.warning(f"Error cleaning up temp files: {e}")
                logger.exception(e)
                raise
            
            # Database cleanup - no pooling needed
            pass
            
            # Force garbage collection
            await asyncio.to_thread(gc.collect)
            
            # Clear any remaining references
            if hasattr(self, '_temp_data'):
                del self._temp_data
            
            # Clear frame cache completely
            self.frame_cache.clear()
            
            logger.info("System resources cleaned up successfully")
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")
        finally:
            # Ensure cleanup happens even if there's an error
            try:
                await asyncio.to_thread(gc.collect)
            except Exception:
                logger.exception("Exception occurred during garbage collection")
                raise

system_state = SystemState()

class ActiveClient:
    def __init__(self, ws, connect_time, user_agent=None):
        self.ws = ws
        self.ip = ws.client.host if hasattr(ws, 'client') and hasattr(ws.client, 'host') else None
        self.connect_time = connect_time
        self.user_agent = user_agent
        self.last_activity = connect_time

system_state.active_clients = []

class ServoCommand(BaseModel):
    servo1: int = Field(default=90, ge=0, le=180)
    servo2: int = Field(default=90, ge=0, le=180)

class ActionCommand(BaseModel):
    action: str = Field(..., min_length=1, max_length=50)
    intensity: int = Field(default=50, ge=0, le=100)

    def validate_action(self):
        allowed_actions = {
            'capture_photo', 'reset_position', 'emergency_stop', 'system_reboot', 
            'flash_on', 'flash_off', 'start_recording', 'stop_recording', 'save_to_gallery',
            'buzzer', 'led', 'motor', 'relay', 'custom', 'servo_reset', 'camera_reset',
            'system_status', 'get_logs', 'clear_logs', 'backup_system', 'restore_system'
        }
        if self.action not in allowed_actions:
            raise ValueError(f'Invalid action. Allowed actions: {", ".join(allowed_actions)}')
        return True

class DeviceModeCommand(BaseModel):
    device_mode: str = Field(..., pattern=r'^(desktop|mobile)$')

class BaseFilenameRequest(BaseModel):
    """Base class for requests that need filename validation"""
    filename: str = Field(..., min_length=1, max_length=255)

    def validate_filename(self):
        return validate_filename_safe(self.filename)

class DeleteImageRequest(BaseFilenameRequest):
    pass

class DeleteVideoRequest(BaseFilenameRequest):
    pass

class ManualPhotoRequest(BaseModel):
    quality: int = Field(default=80, ge=10, le=100)
    flash: bool = False
    intensity: int = Field(default=50, ge=0, le=100)

class LoginRequest(BaseModel):
    username: str = Field(..., min_length=1, max_length=50)
    password: str = Field(..., min_length=1, max_length=100)

class RegisterRequest(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    phone: str = Field(..., pattern=r'^(\+989\d{9}|09\d{9})$')
    password: str = Field(..., min_length=8, max_length=100)

class PasswordRecoveryRequest(BaseModel):
    phone: str = Field(..., pattern=r'^(\+989\d{9}|09\d{9})$')

class TwoFactorVerifyRequest(BaseModel):
    secret: str = Field(..., min_length=1)
    otp: str = Field(..., min_length=6, max_length=6)

class GoogleAuthRequest(BaseModel):
    code: str = Field(..., min_length=1)
    state: str = Field(..., min_length=1)

class GoogleUserInfo(BaseModel):
    id: str
    email: str
    name: str
    picture: Optional[str] = None
    verified_email: bool = False

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int

def validate_image_format(data: bytes) -> bool:
    try:
        img = Image.open(io.BytesIO(data))
        return img.format.lower() in ['jpeg', 'png']
    except Exception:
        return False

def validate_filename_safe(filename: str) -> bool:
    """Common function to validate filename for security"""
    if '..' in filename or '/' in filename or '\\' in filename:
        raise ValueError('Invalid filename')
    return True

async def execute_db_insert(query: str, params: tuple, migration_handler=None, init_handler=None):
    """Common function to execute database insert with retry, migration handling, and optional init"""
    async def _insert():
        if init_handler:
            await init_handler()
        conn = await get_db_connection()
        try:
            await conn.execute(query, params)
            await conn.commit()
        except Exception as e:
            if migration_handler and 'no such table' in str(e):
                await migration_handler()
                # Try again after migration
                await conn.execute(query, params)
                await conn.commit()
            else:
                raise
        finally:
            await close_db_connection(conn)
    await retry_async(_insert)

# Define UserSettings model
class User(BaseModel):
    username: str
    password: str
    role: str = "user"  # admin, user
    is_active: bool = True
    created_at: Optional[str] = None

class UserSettings(BaseModel):
    username: Optional[str] = None
    ip: Optional[str] = None
    device_mode: Optional[str] = "desktop"
    theme: Optional[str] = "light"
    language: Optional[str] = "fa"
    servo1: Optional[int] = None
    servo2: Optional[int] = None
    photoQuality: Optional[int] = None
    smart_motion: Optional[bool] = False
    smart_tracking: Optional[bool] = False
    stream_enabled: Optional[bool] = False

    @field_validator('language')
    @classmethod
    def validate_language(cls, v):
        allowed = ['en', 'fa']
        if v not in allowed:
            raise ValueError(f"Invalid language: {v}")
        return v

async def check_db_health():
    try:
        conn = await asyncio.wait_for(aiosqlite.connect(DB_FILE, timeout=DB_TIMEOUT), timeout=DB_TIMEOUT)
        await conn.execute("PRAGMA integrity_check")
        await conn.close()
        return True
    except Exception as e:
        logger.error(f"Database health check error: {e}")
        return False

async def restore_db_from_backup():
    try:
        backups = sorted(
            [f for f in await asyncio.to_thread(os.listdir, BACKUP_DIR) if f.endswith('.gz')],
            key=lambda x: os.path.getctime(os.path.join(BACKUP_DIR, x)),
            reverse=True
        )[:MAX_BACKUP_CHECK]
        corrupt_count = 0
        for backup in backups:
            backup_file = os.path.join(BACKUP_DIR, backup)
            temp_file = os.path.join(BACKUP_DIR, "temp.db")
            try:
                await asyncio.to_thread(lambda: gzip.open(backup_file, 'rb').readinto, open(temp_file, 'wb'))
                await asyncio.to_thread(os.replace, temp_file, DB_FILE)
                if await check_db_health():
                    logger.info(f"Database restored from {backup}")
                    system_state.db_initialized = False
                    await init_db()
                    return True
                await asyncio.to_thread(os.remove, temp_file)
                logger.warning(f"Backup {backup} is corrupt, deleted")
                await asyncio.to_thread(os.remove, backup_file)
                corrupt_count += 1
            except Exception as e:
                logger.error(f"Error restoring backup {backup}: {e}")
                if os.path.exists(temp_file):
                    await asyncio.to_thread(os.remove, temp_file)
                if os.path.exists(backup_file):
                    await asyncio.to_thread(os.remove, backup_file)
                corrupt_count += 1
        if corrupt_count > 3:
            logger.error("Multiple corrupt backups detected")
        logger.error("No valid backups found")
        return False
    except Exception as e:
        logger.error(f"Database restore error: {e}")
        return False

async def get_db_connection():
    """Get database connection with health check and enhanced error handling"""
    try:
        # Health check and recovery
        if not await check_db_health():
            if await restore_db_from_backup():
                logger.info("Database successfully restored")
            else:
                raise HTTPException(status_code=503, detail="Database corrupted and no valid backup available")
        
        # Create new connection with enhanced timeout handling
        conn = await asyncio.wait_for(aiosqlite.connect(DB_FILE, timeout=DB_TIMEOUT), timeout=DB_TIMEOUT)
        conn.row_factory = aiosqlite.Row
        
        # تنظیمات بهینه برای SQLite با error handling بهبود یافته
        pragma_settings = [
            ("PRAGMA journal_mode=WAL", "journal_mode"),
            ("PRAGMA synchronous=NORMAL", "synchronous"),
            ("PRAGMA cache_size=10000", "cache_size"),
            ("PRAGMA temp_store=MEMORY", "temp_store"),
            ("PRAGMA foreign_keys=ON", "foreign_keys"),
            ("PRAGMA busy_timeout=120000", "busy_timeout"),  # Increased to 120 seconds
            ("PRAGMA mmap_size=268435456", "mmap_size"),
            ("PRAGMA page_size=4096", "page_size"),
            ("PRAGMA auto_vacuum=INCREMENTAL", "auto_vacuum"),
            ("PRAGMA wal_autocheckpoint=1000", "wal_autocheckpoint"),
            ("PRAGMA locking_mode=NORMAL", "locking_mode")  # Changed from EXCLUSIVE to NORMAL
        ]
        
        for pragma_sql, pragma_name in pragma_settings:
            try:
                await conn.execute(pragma_sql)
            except Exception as pragma_error:
                logger.warning(f"SQLite pragma {pragma_name} failed: {pragma_error}")
                # Continue without this specific setting
        
        # Verify critical settings
        try:
            cursor = await conn.execute("PRAGMA busy_timeout")
            timeout = await cursor.fetchone()
            if timeout[0] < 60000:
                logger.warning(f"Busy timeout too low: {timeout[0]}, setting to 120000")
                await conn.execute("PRAGMA busy_timeout=120000")
        except Exception as e:
            logger.warning(f"Could not verify busy_timeout: {e}")
        
        return conn
    except asyncio.TimeoutError:
        logger.error("Database connection timeout")
        raise HTTPException(status_code=503, detail="Database unavailable")
    except aiosqlite.OperationalError as e:
        logger.error(f"Database operational error: {e}")
        raise HTTPException(status_code=503, detail="Database operational error")
    except aiosqlite.DatabaseError as e:
        logger.error(f"Database error: {e}")
        raise HTTPException(status_code=503, detail="Database error")
    except Exception as e:
        logger.error(f"Database connection error: {e}")
        raise HTTPException(status_code=500, detail="Database connection error")

async def close_db_connection(conn):
    """Close database connection with enhanced error handling"""
    try:
        if not conn:
            return
        
        # Check if connection is still open
        if hasattr(conn, '_connection') and conn._connection:
            await conn.close()
        else:
            logger.debug("Connection already closed or invalid")
            
    except aiosqlite.OperationalError as e:
        logger.warning(f"Operational error closing database connection: {e}")
        # Connection might be already closed
        pass
    except aiosqlite.DatabaseError as e:
        logger.warning(f"Database error closing connection: {e}")
        # Force close in case of database error
        try:
            if hasattr(conn, '_connection') and conn._connection:
                await conn.close()
        except Exception:
            pass
    except Exception as e:
        logger.error(f"Error closing database connection: {e}")
        # Force close in case of error
        try:
            if hasattr(conn, '_connection') and conn._connection:
                await conn.close()
        except Exception as e:
            logger.warning(f"Error in force closing database connection: {e}")
            pass

# --- Update table definitions to use TEXT for created_at/updated_at ---
USER_SETTINGS_TABLE_SQL = '''
CREATE TABLE IF NOT EXISTS user_settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ip TEXT NOT NULL,
    theme TEXT DEFAULT 'light',
    language TEXT DEFAULT 'fa',
    flash_settings TEXT DEFAULT '{}',
    updated_at TEXT DEFAULT ''
)
'''

# --- Migration: Ensure device_mode column exists in user_settings table ---
async def migrate_user_settings_table():
    conn = await get_db_connection()
    try:
        # First, check if table exists and get current columns
        cursor = await conn.execute("PRAGMA table_info(user_settings)")
        columns = await cursor.fetchall()
        existing_columns = [col[1] for col in columns]
        
        logger.info(f"Current user_settings columns: {existing_columns}")
        
        # Create table if it doesn't exist with all required columns
        await conn.execute('''
            CREATE TABLE IF NOT EXISTS user_settings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                ip TEXT NOT NULL,
                theme TEXT DEFAULT 'light',
                language TEXT DEFAULT 'fa',
                flash_settings TEXT DEFAULT '{}',
                servo1 INTEGER DEFAULT 90,
                servo2 INTEGER DEFAULT 90,
                device_mode TEXT DEFAULT 'desktop',
                photo_quality INTEGER DEFAULT 80,
                smart_motion BOOLEAN DEFAULT FALSE,
                smart_tracking BOOLEAN DEFAULT FALSE,
                stream_enabled BOOLEAN DEFAULT FALSE,
                updated_at TEXT DEFAULT ''
            )
        ''')
        
        # Add missing columns one by one
        required_columns = {
            'username': 'TEXT NOT NULL',
            'ip': 'TEXT NOT NULL',
            'theme': 'TEXT DEFAULT "light"',
            'language': 'TEXT DEFAULT "fa"',
            'flash_settings': 'TEXT DEFAULT "{}"',
            'servo1': 'INTEGER DEFAULT 90',
            'servo2': 'INTEGER DEFAULT 90',
            'device_mode': 'TEXT DEFAULT "desktop"',
            'photo_quality': 'INTEGER DEFAULT 80',
            'smart_motion': 'BOOLEAN DEFAULT FALSE',
            'smart_tracking': 'BOOLEAN DEFAULT FALSE',
            'stream_enabled': 'BOOLEAN DEFAULT FALSE',
            'updated_at': 'TEXT DEFAULT ""'
        }
        
        for col_name, col_type in required_columns.items():
            if col_name not in existing_columns:
                try:
                    await conn.execute(f"ALTER TABLE user_settings ADD COLUMN {col_name} {col_type}")
                    logger.info(f"✅ Added column {col_name} to user_settings table")
                except Exception as e:
                    if 'duplicate column name' not in str(e).lower():
                        logger.warning(f"⚠️ Could not add column {col_name}: {e}")
        
        await conn.commit()
        logger.info("✅ User settings table migration completed successfully")
        
        # Verify all columns exist
        cursor = await conn.execute("PRAGMA table_info(user_settings)")
        final_columns = await cursor.fetchall()
        final_column_names = [col[1] for col in final_columns]
        logger.info(f"Final user_settings columns: {final_column_names}")
        
    except Exception as e:
        logger.error(f"❌ Error migrating user settings table: {e}")
        raise
    finally:
        await close_db_connection(conn)

# --- Migration: Ensure camera_logs has source and pico_timestamp columns ---
async def migrate_camera_logs_table():
    conn = await get_db_connection()
    try:
        await conn.execute('''
            CREATE TABLE IF NOT EXISTS camera_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                message TEXT NOT NULL,
                log_type TEXT NOT NULL,
                created_at TEXT DEFAULT '',
                source TEXT DEFAULT 'server',
                pico_timestamp TEXT DEFAULT NULL
            )
        ''')
        # Add columns if missing
        try:
            await conn.execute("ALTER TABLE camera_logs ADD COLUMN source TEXT DEFAULT 'server'")
        except Exception as e:
            if 'duplicate column name' not in str(e):
                raise
        try:
            await conn.execute("ALTER TABLE camera_logs ADD COLUMN pico_timestamp TEXT DEFAULT NULL")
        except Exception as e:
            if 'duplicate column name' not in str(e):
                raise
        await conn.commit()
    finally:
        await close_db_connection(conn)

# --- Enhanced Database Initialization with Robust Error Handling ---
async def init_db():
    global system_state
    if system_state.db_initialized:
        logger.debug("Database already initialized")
        return
    
    conn = None
    try:
        # Create database file if it doesn't exist
        if not os.path.exists(DB_FILE):
            logger.info(f"Creating new database file: {DB_FILE}")
        
        conn = await asyncio.wait_for(aiosqlite.connect(DB_FILE, timeout=DB_TIMEOUT), timeout=DB_TIMEOUT)
        conn.row_factory = aiosqlite.Row
        
        # Enable WAL mode for better concurrency
        await conn.execute("PRAGMA journal_mode=WAL")
        await conn.execute("PRAGMA synchronous=NORMAL")
        await conn.execute("PRAGMA cache_size=10000")
        await conn.execute("PRAGMA temp_store=MEMORY")
        await conn.execute("PRAGMA foreign_keys=ON")
        await conn.execute("PRAGMA busy_timeout=60000")  # Increased to 60 seconds
        await conn.execute("PRAGMA mmap_size=268435456")  # 256MB memory mapping
        await conn.execute("PRAGMA page_size=4096")
        await conn.execute("PRAGMA auto_vacuum=INCREMENTAL")
        
        logger.info("Creating database tables...")
        
        # Create users table first (most critical)
        await conn.execute("""CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            phone TEXT UNIQUE,
            password_hash TEXT NOT NULL,
            role TEXT DEFAULT 'user',
            is_active BOOLEAN DEFAULT 1,
            two_fa_enabled BOOLEAN DEFAULT 0,
            two_fa_secret TEXT,
            created_at TEXT NOT NULL
        )""")
        logger.info("✅ Users table created/verified")
        
        # Create password recovery table
        await conn.execute("""CREATE TABLE IF NOT EXISTS password_recovery (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone TEXT NOT NULL,
            token TEXT UNIQUE NOT NULL,
            expires_at TEXT NOT NULL,
            used BOOLEAN DEFAULT 0,
            created_at TEXT NOT NULL
        )""")
        logger.info("✅ Password recovery table created/verified")
        
        # Create camera_logs table
        await conn.execute("""CREATE TABLE IF NOT EXISTS camera_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message TEXT NOT NULL,
            log_type TEXT NOT NULL,
            created_at TEXT DEFAULT '',
            source TEXT DEFAULT 'server',
            pico_timestamp TEXT DEFAULT NULL
        )""")
        logger.info("✅ Camera logs table created/verified")
        
        # Create servo_commands table
        await conn.execute("""CREATE TABLE IF NOT EXISTS servo_commands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            servo1 INTEGER NOT NULL,
            servo2 INTEGER NOT NULL,
            created_at TEXT DEFAULT '',
            processed INTEGER DEFAULT 0
        )""")
        logger.info("✅ Servo commands table created/verified")
        
        # Create action_commands table
        await conn.execute("""CREATE TABLE IF NOT EXISTS action_commands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT NOT NULL,
            intensity INTEGER DEFAULT 50,
            created_at TEXT DEFAULT '',
            processed INTEGER DEFAULT 0
        )""")
        logger.info("✅ Action commands table created/verified")
        
        # Create device_mode_commands table
        await conn.execute("""CREATE TABLE IF NOT EXISTS device_mode_commands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_mode TEXT NOT NULL,
            created_at TEXT DEFAULT '',
            processed INTEGER DEFAULT 0
        )""")
        logger.info("✅ Device mode commands table created/verified")
        
        # Create manual_photos table
        await conn.execute("""CREATE TABLE IF NOT EXISTS manual_photos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            filepath TEXT NOT NULL,
            quality INTEGER DEFAULT 80,
            flash_used BOOLEAN DEFAULT FALSE,
            flash_intensity INTEGER DEFAULT 50,
            created_at TEXT DEFAULT ''
        )""")
        logger.info("✅ Manual photos table created/verified")
        
        # Create security_videos table
        await conn.execute("""CREATE TABLE IF NOT EXISTS security_videos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            filepath TEXT NOT NULL,
            hour_of_day INTEGER NOT NULL,
            duration INTEGER DEFAULT 3600,
            created_at TEXT DEFAULT ''
        )""")
        logger.info("✅ Security videos table created/verified")
        
        # Create user_settings table with migration
        await migrate_user_settings_table()
        logger.info("✅ User settings table created/verified with migration")
        
        # Insert default admin user if not exists
        try:
            admin_exists = await conn.execute('SELECT COUNT(*) FROM users WHERE username = ?', (ADMIN_USERNAME,))
            admin_count = await admin_exists.fetchone()
            
            if admin_count[0] == 0:
                admin_password_hash = hash_password(ADMIN_PASSWORD)
                await conn.execute('''
                    INSERT INTO users (username, password_hash, role, is_active, created_at)
                    VALUES (?, ?, 'admin', 1, ?)
                ''', (ADMIN_USERNAME, admin_password_hash, get_jalali_now_str()))
                logger.info(f"✅ Default admin user '{ADMIN_USERNAME}' created")
            else:
                logger.info(f"✅ Admin user '{ADMIN_USERNAME}' already exists")
        except Exception as e:
            logger.warning(f"⚠️ Error checking/creating admin user: {e}")
            # Continue anyway - user might already exist
        
        await conn.commit()
        system_state.db_initialized = True
        logger.info("🎉 Database and all tables initialized successfully!")
        
    except Exception as e:
        logger.error(f"❌ Error initializing database: {e}")
        system_state.db_initialized = False
        raise
    finally:
        if conn:
            await close_db_connection(conn)

async def retry_async(func, retries=7, delay=1, backoff=2, exceptions=(Exception,)):
    """Enhanced retry function with better error handling and logging"""
    last_exception = None
    for attempt in range(retries):
        try:
            return await func()
        except exceptions as e:
            last_exception = e
            logger.warning(f"Attempt {attempt+1}/{retries} failed: {e}")
            
            # Don't retry on certain critical errors
            if isinstance(e, (ValueError, TypeError, AttributeError)):
                logger.error(f"Critical error, not retrying: {e}")
                raise
            
            if attempt == retries - 1:
                logger.error(f"All {retries} attempts failed. Last error: {e}")
                raise last_exception
            
            # Exponential backoff with jitter
            jitter = random.uniform(0.8, 1.2)
            actual_delay = delay * jitter
            await asyncio.sleep(actual_delay)
            delay *= backoff

def get_jalali_now_str():
    if 'PERSIANTOOLS_AVAILABLE' in globals() and PERSIANTOOLS_AVAILABLE:
        try:
            return JalaliDateTime.now().strftime('%Y-%m-%d %H:%M:%S')
        except Exception:
            pass
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

# Security Functions
def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    try:
        # Python 3.11+
        utc = getattr(datetime, "UTC", None)
        if utc is None:
            # Python <3.11
            from datetime import timezone
            utc = timezone.utc
        if expires_delta:
            expire = datetime.now(utc) + expires_delta
        else:
            expire = datetime.now(utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    except Exception:
        # Fallback for very old Python
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


def verify_token(token: str):
    if not token:
        return None
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        return None
    except (jwt.exceptions.DecodeError, jwt.exceptions.PyJWTError):
        return None

def hash_password(password: str) -> str:
    """Hash password using bcrypt for better security"""
    try:
        import bcrypt
        salt = bcrypt.gensalt(rounds=12)  # Increased rounds for better security
        return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')
    except ImportError:
        # Force bcrypt installation
        logger.error("bcrypt is required for password hashing. Please install it: pip install bcrypt")
        raise ImportError("bcrypt is required for password hashing")

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify password using bcrypt"""
    try:
        import bcrypt
        return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))
    except ImportError:
        logger.error("bcrypt is required for password verification. Please install it: pip install bcrypt")
        return False

async def get_google_auth_url(state: str = None) -> str:
    """Generate Google OAuth URL"""
    if not GOOGLE_OAUTH_ENABLED:
        raise HTTPException(status_code=500, detail="Google OAuth not configured - please set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET environment variables")
    
    if not state:
        state = secrets.token_urlsafe(32)
    
    params = {
        'client_id': GOOGLE_CLIENT_ID,
        'redirect_uri': GOOGLE_REDIRECT_URI,
        'scope': 'openid email profile',
        'response_type': 'code',
        'state': state,
        'access_type': 'offline',
        'prompt': 'consent'
    }
    
    query_string = '&'.join([f"{k}={v}" for k, v in params.items()])
    return f"{GOOGLE_AUTH_URL}?{query_string}"

async def exchange_google_code_for_token(code: str) -> dict:
    """Exchange authorization code for access token"""
    if not GOOGLE_OAUTH_ENABLED:
        raise HTTPException(status_code=500, detail="Google OAuth not configured - please set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET environment variables")
    
    async with httpx.AsyncClient() as client:
        data = {
            'client_id': GOOGLE_CLIENT_ID,
            'client_secret': GOOGLE_CLIENT_SECRET,
            'code': code,
            'grant_type': 'authorization_code',
            'redirect_uri': GOOGLE_REDIRECT_URI
        }
        
        response = await client.post(GOOGLE_TOKEN_URL, data=data)
        if response.status_code == 200:
            return response.json()
        else:
            logger.error(f"Google OAuth token exchange failed: {response.status_code} - {response.text}")
            raise HTTPException(status_code=400, detail="Failed to exchange code for token")

async def get_google_user_info(access_token: str) -> GoogleUserInfo:
    """Get user information from Google"""
    async with httpx.AsyncClient() as client:
        headers = {'Authorization': f'Bearer {access_token}'}
        response = await client.get(GOOGLE_USERINFO_URL, headers=headers)
        
        if response.status_code == 200:
            user_data = response.json()
            return GoogleUserInfo(
                id=user_data['id'],
                email=user_data['email'],
                name=user_data.get('name', ''),
                picture=user_data.get('picture'),
                verified_email=user_data.get('verified_email', False)
            )
        else:
            raise HTTPException(status_code=400, detail="Failed to get user info")

async def create_or_get_google_user(google_user: GoogleUserInfo) -> dict:
    """Create or get user from Google OAuth"""
    conn = None
    try:
        # Ensure database is initialized (silent)
        if not system_state.db_initialized:
            await init_db()
        
        conn = await get_db_connection()
        
        # Check if user exists by email
        user_check = await conn.execute(
            'SELECT username, email, role, is_active FROM users WHERE email = ?',
            (google_user.email,)
        )
        existing_user = await user_check.fetchone()
        
        if existing_user:
            # User exists, return user info
            username, email, role, is_active = existing_user
            if not is_active:
                raise HTTPException(status_code=401, detail="حساب کاربری غیرفعال است")
            
            await insert_log(f"Google OAuth login for existing user: {username}", "auth")
            return {
                "user_id": username,  # Added user_id field
                "username": username,
                "email": email,
                "role": role,
                "is_new_user": False
            }
        else:
            # Create new user
            username = f"google_{google_user.id}"
            password_hash = hash_password(secrets.token_urlsafe(32))  # Random password
            
            await conn.execute(
                'INSERT INTO users (username, email, password_hash, role, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?)',
                (username, google_user.email, password_hash, "user", True, get_jalali_now_str())
            )
            await conn.commit()
            
            await insert_log(f"New user created via Google OAuth: {username}", "auth")
            return {
                "user_id": username,  # Added user_id field
                "username": username,
                "email": google_user.email,
                "role": "user",
                "is_new_user": True
            }
    except Exception as e:
        logger.error(f"Error in create_or_get_google_user: {e}")
        raise HTTPException(status_code=500, detail="Database error during Google OAuth")
    finally:
        if conn:
            await close_db_connection(conn)

def sanitize_input(input_str: str) -> str:
    """Sanitize user input to prevent injection attacks with smart character handling"""
    if not input_str:
        return ""
    
    # Smart sanitization: Preserve special characters but escape dangerous ones
    sanitized = input_str
    
    # Escape dangerous characters instead of removing them
    sanitized = sanitized.replace('<', '&lt;')
    sanitized = sanitized.replace('>', '&gt;')
    sanitized = sanitized.replace('"', '&quot;')
    sanitized = sanitized.replace("'", '&#39;')
    
    # Remove SQL injection patterns (case insensitive)
    sql_patterns = [
        r'(?i)(union|select|insert|update|delete|drop|create|alter|exec|execute)',
        r'(?i)(or\s+\d+\s*=\s*\d+)',
        r'(?i)(and\s+\d+\s*=\s*\d+)',
        r'(?i)(--|#|/\*|\*/)',
        r'(?i)(xp_|sp_)',
        r'(?i)(waitfor|delay)'
    ]
    
    for pattern in sql_patterns:
        sanitized = re.sub(pattern, '', sanitized)
    
    # Remove script injection patterns
    script_patterns = [
        r'(?i)(script|javascript|vbscript)',
        r'(?i)(onload|onerror|onclick|onmouseover|onfocus)',
        r'(?i)(eval|setTimeout|setInterval)',
        r'(?i)(document\.|window\.|location\.)'
    ]
    
    for pattern in script_patterns:
        sanitized = re.sub(pattern, '', sanitized)
    
    # Remove command injection patterns
    cmd_patterns = [
        r'(?i)(cmd|command|powershell|bash|sh)',
        r'(?i)(system|exec|eval)',
        r'(?i)(rm|del|format|fdisk)'
    ]
    
    for pattern in cmd_patterns:
        sanitized = re.sub(pattern, '', sanitized)
    
    # Remove multiple spaces and normalize
    sanitized = re.sub(r'\s+', ' ', sanitized).strip()
    
    return sanitized[:1000]  # Limit length

def check_rate_limit(client_ip: str) -> bool:
    # Skip rate limiting for test environment and local connections
    if "test" in client_ip or client_ip == "testserver" or "127.0.0.1" in client_ip or "localhost" in client_ip:
        return True
    
    now = time.time()
    if client_ip not in rate_limit_storage:
        rate_limit_storage[client_ip] = []
    # Remove old requests
    rate_limit_storage[client_ip] = [t for t in rate_limit_storage[client_ip] if now - t < RATE_LIMIT_WINDOW]
    if len(rate_limit_storage[client_ip]) >= RATE_LIMIT_REQUESTS:
        return False
    rate_limit_storage[client_ip].append(now)
    return True

def check_login_attempts(client_ip: str) -> bool:
    # Skip login attempts check for test environment and local connections
    if "test" in client_ip or client_ip == "testserver" or "127.0.0.1" in client_ip or "localhost" in client_ip:
        return True
    
    now = time.time()
    if client_ip not in login_attempts:
        login_attempts[client_ip] = {'count': 0, 'blocked_until': 0}
    if login_attempts[client_ip]['blocked_until'] > now:
        return False
    if login_attempts[client_ip]['count'] >= MAX_LOGIN_ATTEMPTS:
        login_attempts[client_ip]['blocked_until'] = now + LOGIN_BLOCK_DURATION
        return False
    return True

def record_login_attempt(client_ip: str, success: bool):
    now = time.time()
    if client_ip not in login_attempts:
        login_attempts[client_ip] = {'count': 0, 'blocked_until': 0}
    if success:
        login_attempts[client_ip]['count'] = 0
        login_attempts[client_ip]['blocked_until'] = 0
    else:
        login_attempts[client_ip]['count'] += 1

async def send_password_recovery_sms(phone: str, token: str, username: str):
    """Send password recovery SMS with attractive message"""
    try:
        # Get current time in Jalali calendar
        current_time = datetime.now()
        jalali_date = jdatetime.date.fromgregorian(date=current_time.date())
        jdate = jalali_date.strftime('%Y/%m/%d')
        
        day_of_week_farsi = {
            'Monday': 'دوشنبه', 'Tuesday': 'سه‌شنبه', 'Wednesday': 'چهارشنبه',
            'Thursday': 'پنج‌شنبه', 'Friday': 'جمعه', 'Saturday': 'شنبه', 'Sunday': 'یکشنبه'
        }
        day_of_week = day_of_week_farsi[current_time.strftime('%A')]
        formatted_time = current_time.strftime('%H:%M:%S')
        
        # Create attractive SMS message
        message = (
            f"🔐 سیستم هوشمند دوربین امنیتی 🔐\n"
            f"سلام {username} عزیز 👋\n\n"
            f"📱 درخواست بازیابی رمز عبور شما دریافت شد\n"
            f"🔑 کد بازیابی: {token}\n\n"
            f"⏰ تاریخ: {jdate} ({day_of_week})\n"
            f"🕐 ساعت: {formatted_time}\n\n"
            f"⚠️ این کد تا 24 ساعت معتبر است\n"
            f"🔒 اگر شما این درخواست را نکرده‌اید، نادیده بگیرید\n\n"
            f"💎 با تشکر از اعتماد شما\n"
            f"🚀 تیم پشتیبانی سیستم هوشمند\n"
            f"📞 پشتیبانی: 09204963846"
        )
        
        # Send SMS
        if SMS_USERNAME and SMS_PASSWORD and SMS_SENDER_NUMBER:
            try:
                # Convert phone number to local format
                sms_phone = '0' + phone[3:] if phone.startswith('+989') else phone
                
                # Initialize API
                api = Api(SMS_USERNAME, SMS_PASSWORD)
                sms = api.sms()
                
                # Send SMS
                response = sms.send(sms_phone, SMS_SENDER_NUMBER, message)
                
                if response and 'error' in str(response).lower():
                    logger.error(f"Failed to send SMS to {sms_phone}: {response}")
                    raise Exception(f"SMS sending failed: {response}")
                
                logger.info(f"SMS sent successfully to {sms_phone}")
            except Exception as sms_error:
                logger.error(f"Failed to send recovery SMS: {sms_error}")
                # Don't raise the exception to avoid breaking the flow
                # Just log the error and continue
        else:
            # Log SMS content for development
            logger.info(f"Password recovery token for {phone}: {token}")
            logger.info(f"SMS would be sent to {phone}: {message}")
            
    except Exception as e:
        logger.error(f"Failed to send SMS: {e}")
        raise

async def insert_log(message: str, log_type: str, source: str = "server", pico_timestamp: str = None):
    if not message or len(message) > 1000:
        logger.warning("Invalid log message")
        return
    try:
        await execute_db_insert(
            "INSERT INTO camera_logs (message, log_type, created_at, source, pico_timestamp) VALUES (?, ?, ?, ?, ?)",
            (message[:1000], log_type, get_jalali_now_str(), source, pico_timestamp),
            init_handler=init_db
        )
    except Exception as e:
        logger.error(f"Failed to insert log: {e}")
        # Don't raise exception to avoid breaking the main flow
    
    # برای خطاهای بحرانی، هشدار به admin
    if log_type == "error" and ("critical" in message.lower() or "fatal" in message.lower()):
        alert_admin(f"Critical error from {source}: {message}", critical=True)

async def handle_critical_error(error_msg: str, source: str = "server"):
    """مدیریت خطاهای بحرانی"""
    logger.error(f"Critical error from {source}: {error_msg}")
    await insert_log(f"Critical error: {error_msg}", "error", source)
    
    # ارسال هشدار به تمام کلاینت‌ها
    await send_to_web_clients({
        "type": "critical_error",
        "message": error_msg,
        "source": source,
        "timestamp": datetime.now().isoformat()
    })
    
    # بررسی نیاز به restart
    if "memory" in error_msg.lower() or "corrupt" in error_msg.lower():
        logger.warning("Critical error detected - considering system restart")
        # می‌توانید اینجا منطق restart را اضافه کنید

async def monitor_system_health():
    """مانیتورینگ سلامت سیستم با متریک‌های پیشرفته"""
    while not system_state.system_shutdown:
        try:
            # به‌روزرسانی متریک‌های عملکرد
            await update_performance_metrics()
            
            # بررسی حافظه
            if not await asyncio.to_thread(check_memory_usage):
                await handle_critical_error("High memory usage detected", "system_monitor")
            
            # بررسی فضای دیسک
            if not await check_disk_space():
                await handle_critical_error("Low disk space detected", "system_monitor")
            
            # بررسی وضعیت دیتابیس
            if not await check_db_health():
                await handle_critical_error("Database health check failed", "system_monitor")
            
            # بررسی تعداد خطاهای WebSocket
            if system_state.websocket_error_count > WEBSOCKET_ERROR_THRESHOLD:
                await handle_critical_error(f"High WebSocket error count: {system_state.websocket_error_count}", "system_monitor")
                system_state.websocket_error_count = 0
            
            # بررسی buffer overflow با منطق پیشرفته
            async with system_state.frame_buffer_lock:
                if len(system_state.frame_buffer) > FRAME_BUFFER_SIZE * 1.5:
                    logger.warning("Frame buffer overflow detected, trimming")
                    frames_to_remove = int(FRAME_BUFFER_SIZE * FRAME_DROP_RATIO)
                    system_state.frame_buffer = system_state.frame_buffer[frames_to_remove:]
                    system_state.frame_drop_count += frames_to_remove
            
            # بررسی تعداد کلاینت‌های غیرفعال
            async with system_state.web_clients_lock:
                try:
                    inactive_clients = [c for c in system_state.web_clients if hasattr(c, 'last_activity') and (datetime.now() - c.last_activity).total_seconds() > INACTIVE_CLIENT_TIMEOUT]
                    if inactive_clients:
                        logger.warning(f"Found {len(inactive_clients)} inactive clients, cleaning up")
                        for client in inactive_clients:
                            try:
                                await client.close(code=1000)
                            except Exception as e:
                                logger.warning(f"Error closing inactive client: {e}")
                            try:
                                system_state.web_clients.remove(client)
                            except ValueError:
                                pass  # Client already removed
                except Exception as e:
                    logger.error(f"Error checking inactive clients: {e}")
            
            # بررسی عملکرد real-time با thread safety
            if PERFORMANCE_MONITORING:
                async with system_state.performance_lock:
                    avg_latency = system_state.performance_metrics["avg_frame_latency"]
                    if avg_latency > FRAME_LATENCY_THRESHOLD:
                        logger.warning(f"High frame latency detected: {avg_latency:.3f}s")
                        # کاهش کیفیت برای بهبود عملکرد
                        if system_state.adaptive_quality:
                            system_state.current_quality = max(60, system_state.current_quality - 5)
                            logger.info(f"Reduced quality to {system_state.current_quality} for better performance")
                    
                    # بررسی نرخ حذف فریم
                    drop_rate = system_state.performance_metrics["frame_drop_rate"]
                    if drop_rate > FRAME_DROP_RATIO:
                        logger.warning(f"High frame drop rate: {drop_rate:.2%}")
                
                # بررسی عملکرد پردازش
                processing_overhead = system_state.performance_metrics["frame_processing_overhead"]
                if processing_overhead > PROCESSING_OVERHEAD_THRESHOLD:
                    logger.warning(f"High processing overhead: {processing_overhead:.2%}")
            
            # پاکسازی frame_cache با تابع جدید
            await cleanup_frame_cache()
            
            # Reset error counts periodically
            current_time = time.time()
            if current_time - system_state.last_error_reset > ERROR_RESET_INTERVAL:
                system_state.error_counts = {"websocket": 0, "database": 0, "frame_processing": 0, "memory": 0}
                system_state.last_error_reset = current_time
                logger.info("Error counts reset")
            
            await asyncio.sleep(30)  # بررسی هر 30 ثانیه
            
        except Exception as e:
            logger.error(f"System health monitoring error: {e}")
            await asyncio.sleep(60)  # در صورت خطا، 1 دقیقه صبر کن

async def insert_servo_command(servo1: int, servo2: int):
    if not (0 <= servo1 <= 180 and 0 <= servo2 <= 180):
        logger.warning("Invalid servo command")
        return
    await execute_db_insert(
        "INSERT INTO servo_commands (servo1, servo2, created_at) VALUES (?, ?, ?)", 
        (servo1, servo2, get_jalali_now_str())
    )

async def insert_action_command(action: str, intensity: int = 50):
    if not action or len(action) > 50:
        logger.warning("Invalid action command")
        return
    await execute_db_insert(
        "INSERT INTO action_commands (action, intensity, created_at) VALUES (?, ?, ?)", 
        (action, intensity, get_jalali_now_str())
    )

async def insert_device_mode_command(device_mode: str):
    if device_mode not in ["desktop", "mobile"]:
        logger.warning(f"Invalid device mode: {device_mode}")
        return
    await execute_db_insert(
        "INSERT INTO device_mode_commands (device_mode, created_at) VALUES (?, ?)", 
        (device_mode, get_jalali_now_str()),
        migration_handler=migrate_all_tables
    )

async def check_disk_space():
    try:
        total, used, free = await asyncio.to_thread(shutil.disk_usage, '.')
        free_percent = (free / total) * 100
        system_state.last_disk_space = f"{free_percent:.1f}% free"
        if free_percent < DISK_THRESHOLD:
            logger.warning(f"Low disk space: {free_percent:.1f}% free")
            await insert_log(f"Disk space warning: {free_percent:.1f}% free", "warning")
            return False
        return True
    except Exception as e:
        logger.error(f"Error checking disk space: {e}")
        return True

async def backup_database():
    try:
        if not await check_disk_space():
            logger.warning("Skipping backup due to low disk space")
            return
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_file = os.path.join(BACKUP_DIR, f"backup_{timestamp}.db.gz")
        temp_file = os.path.join(BACKUP_DIR, f"temp_{timestamp}.db")
        await asyncio.to_thread(shutil.copyfile, DB_FILE, temp_file)
        await asyncio.to_thread(lambda: shutil.copyfileobj(open(temp_file, 'rb'), gzip.open(backup_file, 'wb')))
        await asyncio.to_thread(os.remove, temp_file)
        logger.info(f"Database backup created: {backup_file}")
        system_state.last_backup_time = time.time()
        backups = sorted(
            [f for f in await asyncio.to_thread(os.listdir, BACKUP_DIR) if f.endswith('.gz')],
            key=lambda x: os.path.getctime(os.path.join(BACKUP_DIR, x))
        )
        for old_backup in backups[:-BACKUP_RETENTION_DAYS]:
            try:
                await asyncio.to_thread(os.remove, os.path.join(BACKUP_DIR, old_backup))
                logger.info(f"Deleted old backup: {old_backup}")
            except Exception as e:
                logger.error(f"Error deleting old backup {old_backup}: {e}")
    except Exception as e:
        logger.error(f"Backup process error: {e}")
        if os.path.exists(temp_file):
            await asyncio.to_thread(os.remove, temp_file)

async def periodic_backup_and_reset():
    """Periodic backup and reset with enhanced error handling and resource management"""
    while not system_state.system_shutdown:
        try:
            await asyncio.sleep(BACKUP_INTERVAL)
            
            # Check disk space first
            if not await check_disk_space():
                logger.warning("Low disk space detected during periodic check")
                # Try to clean up old files to free space
                await cleanup_old_files()
            
            # Perform backup with retry logic
            backup_success = False
            for attempt in range(3):
                try:
                    await backup_database()
                    backup_success = True
                    break
                except Exception as e:
                    logger.warning(f"Backup attempt {attempt + 1} failed: {e}")
                    if attempt < 2:
                        await asyncio.sleep(60)  # Wait 1 minute before retry
            
            if not backup_success:
                logger.error("All backup attempts failed")
            
            # Check memory usage
            if not await asyncio.to_thread(check_memory_usage):
                logger.warning("High memory usage detected during periodic check")
                # اجرای garbage collection اضافی
                await asyncio.to_thread(gc.collect)
                # Force cleanup of system state
                await system_state.cleanup()
            
            # Perform system cleanup
            try:
                await system_state.cleanup()
            except Exception as e:
                logger.error(f"Error during system cleanup: {e}")
            
            logger.info("Periodic backup and reset completed")
            
        except asyncio.CancelledError:
            logger.info("Periodic backup task cancelled")
            break
        except Exception as e:
            logger.error(f"Error in periodic backup and reset: {e}")
            # اجرای garbage collection در صورت خطا
            await asyncio.to_thread(gc.collect)
            # Wait before retrying
            await asyncio.sleep(300)  # 5 minutes

async def cleanup_old_files():
    """Clean up old files with enhanced error handling and connection management"""
    try:
        now = time.time()
        for folder, ext, table in [
            (GALLERY_DIR, ('.jpg', '.jpeg', '.png'), 'manual_photos'),
            (SECURITY_VIDEOS_DIR, ('.mp4', '.avi', '.mov'), 'security_videos')
        ]:
            if not os.path.exists(folder):
                continue
                
            files_to_delete = []
            for fname in await asyncio.to_thread(os.listdir, folder):
                if not fname.lower().endswith(ext):
                    continue
                fpath = os.path.join(folder, fname)
                try:
                    stat = await asyncio.to_thread(os.stat, fpath)
                    if now - stat.st_mtime > 30*24*3600:
                        files_to_delete.append((fname, fpath))
                except OSError as e:
                    logger.warning(f"Error checking file {fpath}: {e}")
                    continue
            
            # Delete files and update database in batches
            if files_to_delete:
                conn = None
                try:
                    conn = await get_db_connection()
                    for fname, fpath in files_to_delete:
                        try:
                            # Delete file first
                            await asyncio.to_thread(os.remove, fpath)
                            # Then update database
                            await conn.execute(f"DELETE FROM {table} WHERE filename=?", (fname,))
                            logger.debug(f"Deleted old file: {fname}")
                        except OSError as e:
                            logger.warning(f"Error deleting file {fpath}: {e}")
                        except Exception as e:
                            logger.error(f"Error updating database for {fname}: {e}")
                    
                    # Commit all changes
                    await conn.commit()
                    logger.info(f"Cleaned up {len(files_to_delete)} old files from {folder}")
                    
                except Exception as e:
                    logger.error(f"Error in cleanup batch for {folder}: {e}")
                finally:
                    if conn:
                        await close_db_connection(conn)
        
        system_state.last_cleanup_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
    except Exception as e:
        logger.error(f"Error cleaning up old files: {e}")
        # Force garbage collection on error
        await asyncio.to_thread(gc.collect)

async def periodic_cleanup():
    while not system_state.system_shutdown:
        await cleanup_old_files()
        await asyncio.sleep(24*3600)

def check_memory_usage():
    if not PSUTIL_AVAILABLE:
        return True
    try:
        process = psutil.Process()
        mem_info = process.memory_info()
        total_memory = psutil.virtual_memory().total
        memory_percent = mem_info.rss / total_memory
        if memory_percent > MEMORY_THRESHOLD and not system_state.memory_warning_sent:
            logger.warning(f"High memory usage: {memory_percent*100:.1f}%")
            system_state.memory_warning_sent = True
            return False
        elif memory_percent <= MEMORY_THRESHOLD:
            system_state.memory_warning_sent = False
        return True
    except Exception as e:
        logger.error(f"Error checking memory usage: {e}")
        return True

async def preprocess_frame(frame_data: bytes) -> bytes:
    """پردازش پیشرفته فریم با بهینه‌سازی real-time و مدیریت حافظه"""
    start_time = time.time()
    
    try:
        if not system_state.processing_enabled:
            return frame_data
        
        # Validate input data
        if not frame_data or len(frame_data) == 0:
            logger.warning("Empty frame data received")
            system_state.invalid_frame_count += 1
            return frame_data
        
        if len(frame_data) > MAX_FRAME_SIZE:
            logger.warning(f"Frame too large: {len(frame_data)} bytes")
            system_state.frame_drop_count += 1
            return frame_data
        
        # بررسی timeout پردازش
        if system_state.realtime_enabled and (time.time() - start_time) > system_state.processing_timeout:
            logger.warning("Frame processing timeout, skipping")
            system_state.frame_skip_count += 1
            return frame_data
        
        # بهبود مدیریت حافظه با context manager
        frame_array = np.frombuffer(frame_data, dtype=np.uint8)
        frame = cv2.imdecode(frame_array, cv2.IMREAD_COLOR)
        
        if frame is None:
            system_state.invalid_frame_count += 1
            logger.warning("Failed to decode frame data")
            return frame_data
        
        # آزاد کردن حافظه frame_array
        del frame_array
        
        # Validate frame dimensions
        if frame.shape[0] == 0 or frame.shape[1] == 0:
            system_state.invalid_frame_count += 1
            logger.warning("Invalid frame dimensions")
            del frame
            return frame_data
        
        # resize frame با بهینه‌سازی
        target_size = (system_state.resolution['width'], system_state.resolution['height'])
        if frame.shape[:2] != target_size[::-1]:  # OpenCV uses (height, width)
            try:
                frame = await asyncio.to_thread(cv2.resize, frame, target_size, interpolation=cv2.INTER_LANCZOS4)
            except Exception as e:
                logger.error(f"Frame resize error: {e}")
                del frame
                return frame_data
        
        # کیفیت تطبیقی بر اساس عملکرد
        quality = system_state.current_quality
        if system_state.adaptive_quality and len(system_state.frame_processing_times) > 10:
            async with system_state.performance_lock:
                avg_processing_time = sum(system_state.frame_processing_times[-10:]) / 10
                if avg_processing_time > FRAME_LATENCY_THRESHOLD:
                    quality = max(60, quality - 10)  # کاهش کیفیت
                    system_state.current_quality = quality
                elif avg_processing_time < FRAME_LATENCY_THRESHOLD * 0.5:
                    quality = min(95, quality + 5)  # افزایش کیفیت
                    system_state.current_quality = quality
        
        # encode frame با کیفیت بهینه
        try:
            encode_params = [int(cv2.IMWRITE_JPEG_QUALITY), quality]
            _, processed_frame = await asyncio.to_thread(cv2.imencode, '.jpg', frame, encode_params)
        except Exception as e:
            logger.error(f"Frame encoding error: {e}")
            del frame
            return frame_data
        
        # آزاد کردن حافظه frame
        del frame
        
        result = processed_frame.tobytes()
        
        # آزاد کردن حافظه processed_frame
        del processed_frame
        
        # ثبت متریک‌های عملکرد با thread safety
        processing_time = time.time() - start_time
        async with system_state.performance_lock:
            system_state.frame_processing_times.append(processing_time)
            system_state.frame_latency_sum += processing_time
            
            # نگهداری فقط 100 نمونه اخیر
            if len(system_state.frame_processing_times) > 100:
                system_state.frame_processing_times = system_state.frame_processing_times[-100:]
            
            # به‌روزرسانی متریک‌های عملکرد
            if len(system_state.frame_processing_times) > 0:
                system_state.performance_metrics["avg_frame_latency"] = system_state.frame_latency_sum / len(system_state.frame_processing_times)
                system_state.performance_metrics["frame_processing_overhead"] = processing_time / MIN_FRAME_INTERVAL
        
        return result
        
    except Exception as e:
        logger.error(f"Frame processing error: {e}")
        system_state.invalid_frame_count += 1
        if system_state.invalid_frame_count >= MIN_VALID_FRAMES:
            logger.warning("Too many invalid frames, consider checking camera")
        return frame_data

async def add_persian_text_overlay(frame_data: bytes) -> bytes:
    if not PERSIAN_TEXT_OVERLAY or not PERSIANTOOLS_AVAILABLE or not ARABIC_RESHAPER_AVAILABLE:
        return frame_data
    try:
        frame_array = np.frombuffer(frame_data, dtype=np.uint8)
        frame = cv2.imdecode(frame_array, cv2.IMREAD_COLOR)
        if frame is None:
            raise ValueError("Invalid frame for text overlay")
        jalali_datetime = JalaliDateTime.now().strftime("%Y/%m/%d %H:%M:%S")
        text = get_display(arabic_reshaper.reshape(jalali_datetime))
        font = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 0.6
        color = (255, 255, 255)
        thickness = 2
        text_size = cv2.getTextSize(text, font, font_scale, thickness)[0]
        text_x = frame.shape[1] - text_size[0] - 10
        text_y = frame.shape[0] - 10
        await asyncio.to_thread(cv2.putText, frame, text, (text_x, text_y), font, font_scale, (0, 0, 0), thickness + 2, cv2.LINE_AA)
        await asyncio.to_thread(cv2.putText, frame, text, (text_x, text_y), font, font_scale, color, thickness, cv2.LINE_AA)
        _, processed_frame = await asyncio.to_thread(cv2.imencode, '.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), system_state.video_quality])
        return processed_frame.tobytes()
    except Exception as e:
        logger.error(f"Error adding Persian text overlay: {e}")
        return frame_data

async def create_security_video(frames: List[Tuple[bytes, datetime]]):
    try:
        total_frames_needed = VIDEO_FPS * 3600  # 1 hour
        if len(frames) < MIN_VALID_FRAMES:
            logger.warning("Not enough valid frames for video creation")
            return
        # Repeat last frame if not enough frames, or trim if too many
        if len(frames) < total_frames_needed:
            last_frame = frames[-1][0]
            frames += [(last_frame, datetime.now())] * (total_frames_needed - len(frames))
        else:
            frames = frames[:total_frames_needed]
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        hour_of_day = datetime.now().hour
        video_filename = f"security_video_{timestamp}_{hour_of_day}.mp4"
        video_filepath = os.path.join(SECURITY_VIDEOS_DIR, video_filename)
        await asyncio.to_thread(os.makedirs, SECURITY_VIDEOS_DIR, exist_ok=True)
        first_frame = cv2.imdecode(np.frombuffer(frames[0][0], dtype=np.uint8), cv2.IMREAD_COLOR)
        if first_frame is None:
            logger.error("Invalid first frame for video")
            return
        height, width = first_frame.shape[:2]
        # Use H.264 if ffmpeg is available, else mp4v
        fourcc = cv2.VideoWriter_fourcc(*'avc1') if shutil.which('ffmpeg') else cv2.VideoWriter_fourcc(*'mp4v')
        video_writer = cv2.VideoWriter(video_filepath, fourcc, VIDEO_FPS, (width, height))
        prev_good_frame = first_frame
        for frame_data, _ in frames:
            frame = cv2.imdecode(np.frombuffer(frame_data, dtype=np.uint8), cv2.IMREAD_COLOR)
            if frame is None:
                frame = prev_good_frame  # Use previous good frame
            else:
                prev_good_frame = frame
            await asyncio.to_thread(video_writer.write, frame)
        await asyncio.to_thread(video_writer.release)
        system_state.video_count += 1
        async def insert_video():
            conn = await get_db_connection()
            try:
                await conn.execute(
                    "INSERT INTO security_videos (filename, filepath, hour_of_day, duration, created_at) VALUES (?, ?, ?, ?, ?)",
                    (video_filename, video_filepath, hour_of_day, 3600, get_jalali_now_str())
                )
                await conn.commit()
            finally:
                await close_db_connection(conn)
        await retry_async(insert_video)
        logger.info(f"Security video created: {video_filename}")
        async with system_state.web_clients_lock:
            for client in system_state.web_clients:
                try:
                    await client.send_text(json.dumps({
                        "type": "video_created",
                        "filename": video_filename,
                        "url": f"/security_videos/{video_filename}",
                        "hour": hour_of_day,
                        "timestamp": get_jalali_now_str()
                    }))
                except Exception as e:
                    logger.warning(f"Error sending video notification: {e}")
    except Exception as e:
        logger.error(f"Error creating security video: {e}")
        if 'video_writer' in locals():
            await asyncio.to_thread(video_writer.release)
        if os.path.exists(video_filepath):
            await asyncio.to_thread(os.remove, video_filepath)

async def create_security_video_async(frames: List[Tuple[bytes, datetime]]):
    """ایجاد ویدیو امنیتی در background - wrapper for create_security_video"""
    await create_security_video(frames)

async def send_frame_to_clients(frame_data: bytes):
    """ارسال فریم به فرانت‌اند با بهینه‌سازی"""
    try:
        # بررسی اندازه فریم قبل از ارسال
        frame_to_send = base64.b64encode(frame_data).decode('utf-8')
        frame_message = json.dumps({"type": "frame", "data": frame_to_send, "resolution": system_state.resolution})
        
        # بررسی اندازه پیام و فشرده‌سازی هوشمند
        if len(frame_message) > MAX_WEBSOCKET_MESSAGE_SIZE:
            logger.warning(f"Frame message too large ({len(frame_message)} bytes), compressing")
            # فشرده‌سازی هوشمند
            compressed_frame = await compress_frame_intelligently(frame_data)
            compressed_data = base64.b64encode(compressed_frame).decode('utf-8')
            frame_message = json.dumps({"type": "frame", "data": compressed_data, "resolution": system_state.resolution})
        
        # ارسال به فرانت‌اند
        await send_to_web_clients(frame_message)
        
    except Exception as e:
        # Don't log normal closure errors
        if "1000" not in str(e) and "Rapid test" not in str(e):
            logger.error(f"Error sending frame to clients: {e}")

async def compress_frame_intelligently(frame_data: bytes) -> bytes:
    """فشرده‌سازی هوشمند فریم بر اساس اندازه و کیفیت"""
    try:
        # decode frame
        frame_array = np.frombuffer(frame_data, dtype=np.uint8)
        frame = cv2.imdecode(frame_array, cv2.IMREAD_COLOR)
        
        if frame is None:
            return frame_data
        
        # محاسبه کیفیت بهینه بر اساس اندازه
        original_size = len(frame_data)
        target_size = FRAME_COMPRESSION_THRESHOLD
        
        if original_size <= target_size:
            return frame_data
        
        # محاسبه نسبت فشرده‌سازی
        compression_ratio = target_size / original_size
        quality = max(30, int(compression_ratio * 100))
        
        # فشرده‌سازی
        encode_params = [int(cv2.IMWRITE_JPEG_QUALITY), quality]
        _, compressed_frame = await asyncio.to_thread(cv2.imencode, '.jpg', frame, encode_params)
        
        # آزاد کردن حافظه
        del frame_array, frame
        
        return compressed_frame.tobytes()
        
    except Exception as e:
        logger.error(f"Error compressing frame: {e}")
        return frame_data

async def update_performance_metrics():
    """به‌روزرسانی متریک‌های عملکرد با thread safety"""
    try:
        # Check if enough time has passed since last update
        current_time = time.time()
        if current_time - system_state.last_performance_update < PERFORMANCE_UPDATE_INTERVAL:
            return
        
        async with system_state.performance_lock:
            if PSUTIL_AVAILABLE:
                system_state.performance_metrics["memory_usage"] = psutil.virtual_memory().percent
                system_state.performance_metrics["cpu_usage"] = psutil.cpu_percent(interval=0.1)
            
            # محاسبه نرخ حذف فریم
            if system_state.frame_count > 0:
                system_state.performance_metrics["frame_drop_rate"] = system_state.frame_drop_count / system_state.frame_count
            
            # به‌روزرسانی زمان
            system_state.last_performance_update = current_time
        
    except Exception as e:
        logger.error(f"Error updating performance metrics: {e}")

async def cleanup_frame_cache():
    """پاکسازی کش فریم‌ها برای جلوگیری از memory leak"""
    try:
        current_time = time.time()
        if current_time - system_state.last_frame_cache_cleanup < FRAME_CACHE_CLEANUP_INTERVAL:
            return
        
        async with system_state.performance_lock:
            # Remove old entries from frame cache
            cache_keys = list(system_state.frame_cache.keys())
            if len(cache_keys) > FRAME_CACHE_SIZE:
                keys_to_remove = cache_keys[:-FRAME_CACHE_SIZE]
                for key in keys_to_remove:
                    del system_state.frame_cache[key]
                logger.debug(f"Cleaned up {len(keys_to_remove)} old frame cache entries")
            
            # Cleanup frame processing times
            if len(system_state.frame_processing_times) > 100:
                system_state.frame_processing_times = system_state.frame_processing_times[-50:]
            
            # Cleanup frame buffer if too large
            async with system_state.frame_buffer_lock:
                if len(system_state.frame_buffer) > FRAME_BUFFER_SIZE * 1.2:
                    frames_to_remove = int(FRAME_BUFFER_SIZE * 0.2)
                    system_state.frame_buffer = system_state.frame_buffer[frames_to_remove:]
                    logger.debug(f"Cleaned up {frames_to_remove} old frame buffer entries")
            
            system_state.last_frame_cache_cleanup = current_time
            
            # Force garbage collection
            await asyncio.to_thread(gc.collect)
            
    except Exception as e:
        logger.error(f"Error cleaning up frame cache: {e}")

@app.get("/performance_metrics")
async def get_performance_metrics(user=Depends(get_current_user)):
    """دریافت متریک‌های عملکرد سیستم"""
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    try:
        await update_performance_metrics()
        return {
            "status": "success",
            "metrics": system_state.performance_metrics,
            "frame_stats": {
                "total_frames": system_state.frame_count,
                "dropped_frames": system_state.frame_drop_count,
                "skipped_frames": system_state.frame_skip_count,
                "invalid_frames": system_state.invalid_frame_count,
                "buffer_size": len(system_state.frame_buffer)
            },
            "processing_stats": {
                "avg_latency": system_state.performance_metrics["avg_frame_latency"],
                "current_quality": system_state.current_quality,
                "realtime_enabled": system_state.realtime_enabled,
                "adaptive_quality": system_state.adaptive_quality
            }
        }
    except Exception as e:
        logger.error(f"Error getting performance metrics: {e}")
        raise HTTPException(status_code=500, detail="Error getting performance metrics")



def signal_handler(signum, frame):
    logger.info(f"Received signal {signum}, shutting down...")
    system_state.system_shutdown = True
    try:
        # Use get_event_loop() instead of asyncio.run() to avoid nested event loop error
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # Create a task for cleanup instead of running it directly
            loop.create_task(system_state.cleanup())
        else:
            loop.run_until_complete(system_state.cleanup())
    except Exception as e:
        logger.error(f"Cleanup error: {e}")
    # Don't call sys.exit() here, let the server handle shutdown gracefully
    logger.info("Signal handler completed, server will shutdown gracefully")

def robust_db_endpoint(func):
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        try:
            return await func(*args, **kwargs)
        except aiosqlite.OperationalError as e:
            if 'no such table' in str(e):
                try:
                    logger.debug("Table not found, attempting database initialization")
                    if not system_state.db_initialized:
                        await init_db()
                    return await func(*args, **kwargs)
                except Exception as e2:
                    logger.error(f"DB recovery failed: {e2}")
                    raise HTTPException(status_code=500, detail="Database recovery failed")
            elif 'database is locked' in str(e):
                logger.error(f"Database locked: {e}")
                raise HTTPException(status_code=503, detail="Database is locked, please try again")
            else:
                logger.error(f"Database operational error: {e}")
                raise HTTPException(status_code=503, detail="Database operational error")
        except aiosqlite.DatabaseError as e:
            logger.error(f"Database error: {e}")
            raise HTTPException(status_code=503, detail="Database error")
        except asyncio.TimeoutError as e:
            logger.error(f"Database timeout: {e}")
            raise HTTPException(status_code=503, detail="Database timeout")
        except Exception as e:
            logger.error(f"Unexpected DB error: {e}")
            # Return proper error response for test environment
            from fastapi.responses import JSONResponse
            return JSONResponse(
                status_code=503,
                content={"detail": "Database error", "error": str(e)}
            )
    return wrapper

@app.get("/", response_class=HTMLResponse)
async def index(request: Request, user=Depends(get_current_user)):
    if not user:
        # Always redirect to login for unauthenticated users
        return RedirectResponse(url="/login", status_code=302)
    lang = request.cookies.get('language', 'fa')
    return templates.TemplateResponse("index.html", {"request": request, "translations": translations, "lang": lang})

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request, user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    try:
        lang = request.cookies.get('language', 'fa')
        return templates.TemplateResponse("index.html", {"request": request, "translations": translations, "lang": lang})
    except Exception as e:
        logger.error(f"Error rendering dashboard: {e}")
        # Fallback to index.html if dashboard.html doesn't exist
        lang = request.cookies.get('language', 'fa')
        return templates.TemplateResponse("index.html", {"request": request, "translations": translations, "lang": lang})

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    # Check if user is already logged in
    token = request.cookies.get("access_token")
    if token and verify_token(token):
        return RedirectResponse(url="/", status_code=302)
    
    lang = request.cookies.get('language', 'fa')
    return templates.TemplateResponse("login.html", {"request": request, "translations": translations, "lang": lang})

@app.post("/login")
async def login(request: LoginRequest, req: Request):
    client_ip = req.client.host
    
    # Ensure database is initialized (silent)
    if not system_state.db_initialized:
        await init_db()
    
    # Sanitize input to prevent injection attacks
    sanitized_username = sanitize_input(request.username)
    sanitized_password = sanitize_input(request.password)
    
    # Check rate limiting
    if not check_rate_limit(client_ip):
        raise HTTPException(status_code=429, detail="Too many requests")
    
    # Check login attempts
    if not check_login_attempts(client_ip):
        raise HTTPException(status_code=429, detail="Too many login attempts. Try again later.")
    
    try:
        # Get user from database
        conn = await get_db_connection()
        try:
            user_query = await conn.execute(
                'SELECT username, password_hash, role, is_active, two_fa_enabled, two_fa_secret FROM users WHERE username = ?',
                (sanitized_username,)
            )
            user_data = await user_query.fetchone()
            
            if user_data and user_data[3]:  # is_active
                logger.debug(f"[LOGIN DEBUG] user_data: {user_data}, len={len(user_data)}")
                # اگر تعداد فیلدها بیشتر از 6 بود، فقط 6 تای اول را بگیر
                if len(user_data) > 6:
                    user_data = user_data[:6]
                username, password_hash, role, is_active, two_fa_enabled, two_fa_secret = user_data
                
                # Verify password
                if verify_password(sanitized_password, password_hash):
                    record_login_attempt(client_ip, True)
                    
                    # Check if user has 2FA enabled
                    if two_fa_enabled and two_fa_secret:
                        # Generate QR code for 2FA
                        secret = two_fa_secret
                        totp = pyotp.TOTP(secret)
                        qr_code_data = totp.provisioning_uri(username, issuer_name="Smart Camera System")
                        
                        await insert_log(f"2FA required for login from {client_ip} (user: {username})", "auth")
                        
                        return {
                            "requires_2fa": True,
                            "qr_code": qr_code_data,
                            "secret": f"{username}:{secret}"
                        }
                    else:
                        # Normal login without 2FA
                        access_token = create_access_token(
                            data={"sub": username, "role": role, "ip": client_ip}
                        )
                        
                        await insert_log(f"Successful login from {client_ip} (user: {username}, role: {role})", "auth")
                        
                        # Create response with token and set cookie
                        response_data = {
                            "access_token": access_token,
                            "token_type": "bearer",
                            "expires_in": ACCESS_TOKEN_EXPIRE_MINUTES * 60,
                            "user": {
                                "username": username,
                                "role": role
                            }
                        }
                        
                        # Create response with cookie
                        response = JSONResponse(content=response_data)
                        response.set_cookie(
                            key="access_token",
                            value=access_token,
                            max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
                            httponly=True,
                            secure=os.getenv("ENVIRONMENT") == "production",  # Secure in production
                            samesite="lax"
                        )
                        
                        return response
                else:
                    record_login_attempt(client_ip, False)
                    await insert_log(f"Failed login attempt from {client_ip} (username: {sanitized_username}) - wrong password", "auth")
                    raise HTTPException(status_code=401, detail="Invalid credentials")
            else:
                record_login_attempt(client_ip, False)
                await insert_log(f"Failed login attempt from {client_ip} (username: {sanitized_username}) - user not found or inactive", "auth")
                raise HTTPException(status_code=401, detail="Invalid credentials")
        finally:
            await close_db_connection(conn)
            
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Login error")
        raise HTTPException(status_code=500, detail="Login error")

@app.post("/register")
async def register(request: RegisterRequest, req: Request):
    """User registration endpoint"""
    client_ip = req.client.host
    
    # Ensure database is initialized (silent)
    if not system_state.db_initialized:
        await init_db()
    
    # Sanitize inputs
    sanitized_username = sanitize_input(request.username)
    sanitized_phone = sanitize_input(request.phone)
    sanitized_password = sanitize_input(request.password)
    
    # Check rate limiting
    if not check_rate_limit(client_ip):
        raise HTTPException(status_code=429, detail="Too many requests")
    
    try:
        conn = await get_db_connection()
        try:
            # Check if username already exists
            user_check = await conn.execute(
                'SELECT username FROM users WHERE username = ?',
                (sanitized_username,)
            )
            if await user_check.fetchone():
                raise HTTPException(status_code=400, detail="نام کاربری قبلاً استفاده شده است")
            
            # Check if phone already exists
            phone_check = await conn.execute(
                'SELECT phone FROM users WHERE phone = ?',
                (sanitized_phone,)
            )
            if await phone_check.fetchone():
                raise HTTPException(status_code=400, detail="شماره تلفن قبلاً ثبت شده است")
            
            # Hash password
            password_hash = hash_password(sanitized_password)
            
            # Insert new user
            await conn.execute(
                'INSERT INTO users (username, phone, password_hash, role, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?)',
                (sanitized_username, sanitized_phone, password_hash, "user", True, get_jalali_now_str())
            )
            await conn.commit()
            
            await insert_log(f"New user registered: {sanitized_username} from {client_ip}", "auth")
            
            return {"status": "success", "message": "ثبت‌نام با موفقیت انجام شد"}
        finally:
            await close_db_connection(conn)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Registration error")
        raise HTTPException(status_code=500, detail="خطا در ثبت‌نام")

@app.post("/recover-password")
async def recover_password(request: PasswordRecoveryRequest, req: Request):
    """Password recovery endpoint via SMS"""
    client_ip = req.client.host
    
    # Ensure database is initialized (silent)
    if not system_state.db_initialized:
        await init_db()
    
    # Sanitize phone input
    sanitized_phone = sanitize_input(request.phone)
    
    # Check rate limiting
    if not check_rate_limit(client_ip):
        raise HTTPException(status_code=429, detail="Too many requests")
    
    try:
        conn = await get_db_connection()
        try:
            # Check if phone exists
            user_check = await conn.execute(
                'SELECT username FROM users WHERE phone = ? AND is_active = 1',
                (sanitized_phone,)
            )
            user_data = await user_check.fetchone()
            
            if not user_data:
                # Don't reveal if phone exists or not for security
                return {"status": "success", "message": "اگر شماره تلفن در سیستم ثبت شده باشد، کد بازیابی ارسال خواهد شد"}
            
            # Generate recovery token (6 digits for SMS)
            recovery_token = ''.join([str(random.randint(0, 9)) for _ in range(6)])
            recovery_expires = datetime.now() + timedelta(hours=24)
            
            # Store recovery token in database
            await conn.execute(
                'INSERT INTO password_recovery (phone, token, expires_at, created_at) VALUES (?, ?, ?, ?)',
                (sanitized_phone, recovery_token, recovery_expires.isoformat(), get_jalali_now_str())
            )
            await conn.commit()
        finally:
            await close_db_connection(conn)
        
        # Send recovery SMS
        try:
            await send_password_recovery_sms(sanitized_phone, recovery_token, user_data[0])
            await insert_log(f"Password recovery SMS sent to {sanitized_phone} from {client_ip}", "auth")
            return {"status": "success", "message": "کد بازیابی به شماره تلفن شما ارسال شد"}
        except Exception as sms_error:
            logger.error(f"Failed to send recovery SMS: {sms_error}")
            # Log the token for manual recovery if SMS fails
            logger.info(f"Password recovery token for {sanitized_phone}: {recovery_token}")
            await insert_log(f"Password recovery requested for {sanitized_phone} from {client_ip} (SMS failed)", "auth")
            return {"status": "success", "message": "کد بازیابی به شماره تلفن شما ارسال شد"}
        
    except Exception as e:
        logger.error(f"Password recovery error: {e}")
        raise HTTPException(status_code=500, detail="خطا در ارسال کد بازیابی")

@app.post("/reset-password")
async def reset_password(token: str, new_password: str, req: Request):
    """Reset password using recovery token"""
    client_ip = req.client.host
    
    # Ensure database is initialized (silent)
    if not system_state.db_initialized:
        await init_db()
    
    # Sanitize inputs
    sanitized_token = sanitize_input(token)
    sanitized_password = sanitize_input(new_password)
    
    # Check rate limiting
    if not check_rate_limit(client_ip):
        raise HTTPException(status_code=429, detail="Too many requests")
    
    try:
        conn = await get_db_connection()
        try:
            # Check if token exists and is valid
            token_check = await conn.execute(
                'SELECT phone, expires_at, used FROM password_recovery WHERE token = ?',
                (sanitized_token,)
            )
            token_data = await token_check.fetchone()
            
            if not token_data:
                raise HTTPException(status_code=400, detail="کد نامعتبر است")
            
            phone, expires_at, used = token_data
            
            # Check if token is expired
            if datetime.fromisoformat(expires_at) < datetime.now():
                raise HTTPException(status_code=400, detail="کد منقضی شده است")
            
            # Check if token is already used
            if used:
                raise HTTPException(status_code=400, detail="کد قبلاً استفاده شده است")
            
            # Hash new password
            password_hash = hash_password(sanitized_password)
            
            # Update user password
            await conn.execute(
                'UPDATE users SET password_hash = ? WHERE phone = ?',
                (password_hash, phone)
            )
            
            # Mark token as used
            await conn.execute(
                'UPDATE password_recovery SET used = 1 WHERE token = ?',
                (sanitized_token,)
            )
            
            await conn.commit()
            
            await insert_log(f"Password reset successful for {phone} from {client_ip}", "auth")
            
            return {"status": "success", "message": "رمز عبور با موفقیت تغییر یافت"}
        finally:
            await close_db_connection(conn)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Password reset error: {e}")
        raise HTTPException(status_code=500, detail="خطا در تغییر رمز عبور")

@app.post("/verify-2fa")
async def verify_2fa(request: TwoFactorVerifyRequest, req: Request):
    """Two-factor authentication verification"""
    client_ip = req.client.host
    
    # Ensure database is initialized (silent)
    if not system_state.db_initialized:
        await init_db()
    
    try:
        # Sanitize inputs
        sanitized_secret = sanitize_input(request.secret)
        sanitized_otp = sanitize_input(request.otp)
        
        # Extract username from secret
        if ':' not in sanitized_secret:
            raise HTTPException(status_code=400, detail="Invalid secret format")
        
        username, secret = sanitized_secret.split(':', 1)
        
        # Verify OTP
        totp = pyotp.TOTP(secret)
        if totp.verify(sanitized_otp):
            # Get user info from database
            conn = await get_db_connection()
            try:
                user_query = await conn.execute(
                    'SELECT username, role FROM users WHERE username = ? AND is_active = 1',
                    (username,)
                )
                user_data = await user_query.fetchone()
                
                if not user_data:
                    raise HTTPException(status_code=401, detail="User not found or inactive")
                
                username, role = user_data
                
                # Create access token
                access_token = create_access_token(
                    data={"sub": username, "role": role, "ip": client_ip}
                )
                
                await insert_log(f"2FA verification successful for {username} from {client_ip}", "auth")
                
                # Create response with cookie
                response_data = {
                    "access_token": access_token,
                    "token_type": "bearer",
                    "expires_in": ACCESS_TOKEN_EXPIRE_MINUTES * 60,
                    "user": {
                        "username": username,
                        "role": role
                    }
                }
                
                response = JSONResponse(content=response_data)
                response.set_cookie(
                    key="access_token",
                    value=access_token,
                    max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
                    httponly=True,
                    secure=os.getenv("ENVIRONMENT") == "production",
                    samesite="lax"
                )
                
                return response
            finally:
                await close_db_connection(conn)
        else:
            await insert_log(f"2FA verification failed from {client_ip} for user {username}", "auth")
            raise HTTPException(status_code=401, detail="کد تأیید اشتباه است")
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"2FA verification error: {e}")
        raise HTTPException(status_code=500, detail="خطا در تأیید کد")

@app.get("/auth/google")
async def google_auth_redirect(req: Request):
    """Redirect to Google OAuth"""
    client_ip = req.client.host
    
    # Check rate limiting
    if not check_rate_limit(client_ip):
        raise HTTPException(status_code=429, detail="Too many requests")
    
    try:
        state = secrets.token_urlsafe(32)
        auth_url = await get_google_auth_url(state)
        
        # Store state for validation
        oauth_states[state] = {
            "client_ip": client_ip,
            "timestamp": time.time()
        }
        
        # Log the redirect attempt
        await insert_log(f"Google OAuth redirect initiated from {client_ip}", "auth")
        
        return RedirectResponse(url=auth_url, status_code=302)
    except Exception as e:
        logger.error(f"Google OAuth redirect error: {e}")
        await insert_log(f"Google OAuth redirect error from {client_ip}: {str(e)}", "auth")
        return RedirectResponse(url="/login?error=google_auth_failed", status_code=302)

@app.get("/auth/google/callback")
async def google_auth_callback(req: Request):
    """Handle Google OAuth callback"""
    client_ip = req.client.host
    
    # Check rate limiting
    if not check_rate_limit(client_ip):
        raise HTTPException(status_code=429, detail="Too many requests")
    
    try:
        # Get authorization code and state from query parameters
        code = req.query_params.get("code")
        state = req.query_params.get("state")
        error = req.query_params.get("error")
        
        if error:
            await insert_log(f"Google OAuth error from {client_ip}: {error}", "auth")
            return RedirectResponse(url="/login?error=google_auth_failed", status_code=302)
        
        if not code:
            await insert_log(f"Google OAuth missing code from {client_ip}", "auth")
            return RedirectResponse(url="/login?error=google_auth_failed", status_code=302)
        
        # Validate state parameter
        if not state:
            await insert_log(f"Google OAuth missing state from {client_ip}", "auth")
            return RedirectResponse(url="/login?error=google_auth_failed", status_code=302)
        
        # Check if state exists and is valid
        if state not in oauth_states:
            await insert_log(f"Google OAuth invalid state from {client_ip}", "auth")
            return RedirectResponse(url="/login?error=google_auth_failed", status_code=302)
        
        # Check if state is not expired (5 minutes)
        state_data = oauth_states[state]
        if time.time() - state_data["timestamp"] > 300:  # 5 minutes
            await insert_log(f"Google OAuth expired state from {client_ip}", "auth")
            del oauth_states[state]
            return RedirectResponse(url="/login?error=google_auth_failed", status_code=302)
        
        # Check if client IP matches
        if state_data["client_ip"] != client_ip:
            await insert_log(f"Google OAuth IP mismatch from {client_ip}", "auth")
            del oauth_states[state]
            return RedirectResponse(url="/login?error=google_auth_failed", status_code=302)
        
        # Remove used state
        del oauth_states[state]
        
        # Exchange code for access token
        token_data = await exchange_google_code_for_token(code)
        access_token = token_data.get("access_token")
        
        if not access_token:
            await insert_log(f"Google OAuth no access token from {client_ip}", "auth")
            return RedirectResponse(url="/login?error=google_auth_failed")
        
        # Get user info from Google
        google_user = await get_google_user_info(access_token)
        
        # Create or get user from database
        user_data = await create_or_get_google_user(google_user)
        
        # Create access token
        access_token = create_access_token(
            data={"sub": user_data["username"], "role": user_data["role"], "ip": client_ip}
        )
        
        # Create response with token and set cookie
        response_data = {
            "access_token": access_token,
            "token_type": "bearer",
            "expires_in": ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            "user": {
                "username": user_data["username"],
                "role": user_data["role"],
                "is_new_user": user_data["is_new_user"]
            }
        }
        
        # Redirect to dashboard with success message
        success_url = f"/dashboard?welcome={'new_user' if user_data['is_new_user'] else 'welcome_back'}"
        response = RedirectResponse(url=success_url, status_code=302)
        response.set_cookie(
            key="access_token",
            value=access_token,
            max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            httponly=True,
            secure=False,  # Set to True in production with HTTPS
            samesite="lax",
            path="/"
        )
        
        # Add debug logging
        logger.info(f"Google OAuth successful login for user {user_data['username']} from {client_ip}")
        
        return response
        
    except Exception as e:
        logger.error(f"Google OAuth callback error: {e}")
        try:
            await insert_log(f"Google OAuth callback error from {client_ip}: {str(e)}", "auth")
        except Exception as log_error:
            logger.error(f"Failed to log Google OAuth error: {log_error}")
        return RedirectResponse(url="/login?error=google_auth_failed")

@app.post("/logout")
async def logout(req: Request):
    """Logout endpoint - clears cookies and returns JSON response"""
    try:
        client_ip = req.client.host
        await insert_log(f"Logout from {client_ip}", "auth")
        
        # Create response and clear cookie
        response = JSONResponse(content={"status": "success", "message": "Successfully logged out"})
        response.delete_cookie(key="access_token")
        
        return response
    except Exception as e:
        logger.error(f"Logout error: {e}")
        raise HTTPException(status_code=500, detail="Logout error")

@app.get("/logout")
async def logout_page(req: Request):
    """Logout page - redirects to login"""
    return RedirectResponse(url="/login", status_code=302)

def get_lang_from_request(request: Request):
    return request.cookies.get('language', 'fa')

@app.post("/set_language")
async def set_language(request: Request):
    data = await request.json()
    lang = data.get("lang", "fa")
    msg = {"fa": "زبان نامعتبر", "en": "Invalid language"}
    if lang not in ["fa", "en"]:
        return JSONResponse({"status": "error", "message": msg.get(lang, msg['en'])}, status_code=400)
    response = JSONResponse({"status": "success", "language": lang})
    response.set_cookie(key="language", value=lang, max_age=60*60*24*365)
    return response

@app.get("/static/{filename}")
async def serve_static_file(filename: str):
    file_path = os.path.join("static", filename)
    if not os.path.exists(file_path):
        logger.warning(f"Static file not found: {filename}")
        raise HTTPException(status_code=404, detail=f"File {filename} not found")
    return FileResponse(file_path)

@app.get("/gallery/{filename}")
async def serve_gallery_file(filename: str, request: Request):
    logger.info(f"[HTTP] /gallery/{filename} requested by {request.client.host}")
    
    # Security check - prevent directory traversal
    if '..' in filename or '/' in filename or '\\' in filename:
        logger.warning(f"Directory traversal attempt: {filename}")
        raise HTTPException(status_code=400, detail="Invalid filename")
    
    # Validate file extension
    allowed_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'}
    file_ext = os.path.splitext(filename)[1].lower()
    if file_ext not in allowed_extensions:
        logger.warning(f"Invalid file extension: {file_ext}")
        raise HTTPException(status_code=400, detail="Invalid file type")
    
    file_path = os.path.join(GALLERY_DIR, filename)
    if not os.path.exists(file_path):
        logger.warning(f"Gallery file not found: {filename}")
        raise HTTPException(status_code=404, detail=f"File {filename} not found")
    
    # Check file size to prevent large file attacks
    try:
        file_size = os.path.getsize(file_path)
        if file_size > 50 * 1024 * 1024:  # 50MB limit
            logger.warning(f"File too large: {filename} ({file_size} bytes)")
            raise HTTPException(status_code=413, detail="File too large")
    except OSError:
        logger.warning(f"Error accessing file: {filename}")
        raise HTTPException(status_code=404, detail="File not found")
    
    return FileResponse(file_path, headers={'Cache-Control': 'public, max-age=3600'})

@app.get("/security_videos/{filename}")
async def serve_video_file(filename: str, request: Request):
    logger.info(f"[HTTP] /security_videos/{filename} requested by {request.client.host}")
    
    # Security check - prevent directory traversal
    if '..' in filename or '/' in filename or '\\' in filename:
        logger.warning(f"Directory traversal attempt: {filename}")
        raise HTTPException(status_code=400, detail="Invalid filename")
    
    # Validate file extension
    allowed_extensions = {'.mp4', '.avi', '.mov', '.mkv', '.webm'}
    file_ext = os.path.splitext(filename)[1].lower()
    if file_ext not in allowed_extensions:
        logger.warning(f"Invalid video file extension: {file_ext}")
        raise HTTPException(status_code=400, detail="Invalid file type")
    
    file_path = os.path.join(SECURITY_VIDEOS_DIR, filename)
    if not os.path.exists(file_path):
        logger.warning(f"Video file not found: {filename}")
        raise HTTPException(status_code=404, detail=f"File {filename} not found")
    
    # Check file size to prevent large file attacks
    try:
        file_size = os.path.getsize(file_path)
        if file_size > 500 * 1024 * 1024:  # 500MB limit for videos
            logger.warning(f"Video file too large: {filename} ({file_size} bytes)")
            raise HTTPException(status_code=413, detail="File too large")
    except OSError:
        logger.warning(f"Error accessing video file: {filename}")
        raise HTTPException(status_code=404, detail="File not found")
    
    # Register that this file is being served
    register_file_connection(filename)
    
    try:
        response = FileResponse(file_path)
        # Add a callback to unregister when the response is complete
        response.background = lambda: unregister_file_connection(filename)
        return response
    except Exception as e:
        # Make sure to unregister even if there's an error
        unregister_file_connection(filename)
        raise e

@app.post("/set_servo")
async def set_servo(command: ServoCommand, request: Request, user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    client_ip = request.client.host
    
    # Check rate limiting
    if not check_rate_limit(client_ip):
        raise HTTPException(status_code=429, detail="Too many requests")
    
    # Sanitize and validate input
    command.servo1 = max(0, min(180, command.servo1))
    command.servo2 = max(0, min(180, command.servo2))
    
    logger.info(f"[HTTP] /set_servo from {client_ip}: servo1={command.servo1}, servo2={command.servo2}")
    
    # اعتبارسنجی ورودی
    if not isinstance(command.servo1, int) or not (0 <= command.servo1 <= 180):
        logger.error("Invalid servo1 value")
        raise HTTPException(status_code=400, detail="Invalid servo1 value")
    if not isinstance(command.servo2, int) or not (0 <= command.servo2 <= 180):
        logger.error("Invalid servo2 value")
        raise HTTPException(status_code=400, detail="Invalid servo2 value")
    
    try:
        await insert_servo_command(command.servo1, command.servo2)
        await insert_log(f"Servo command: X={command.servo1}°, Y={command.servo2}°", "command")
        
        # بررسی اتصال پیکو
        if not system_state.device_status["pico"]["online"]:
            logger.warning("Pico is offline, servo command will be queued")
            await send_to_web_clients({
                "type": "command_response",
                "status": "warning",
                "message": "Pico is offline, command will be sent when connected",
                "command": {"type": "servo", "servo1": command.servo1, "servo2": command.servo2}
            })
            return {"status": "warning", "message": "Pico is offline, command will be sent when connected"}
        
        # Send servo command to Pico with proper format
        servo_message = {
            "type": "servo", 
            "command": {
                "servo1": command.servo1, 
                "servo2": command.servo2
            },
            "timestamp": datetime.now().isoformat(),
            "source": "web_interface"
        }
        
        await send_to_pico_client(servo_message)
        
        # Also send to ESP32CAM for logging/status updates
        await send_to_esp32cam_client({
            "type": "servo_command_log",
            "servo1": command.servo1,
            "servo2": command.servo2,
            "timestamp": datetime.now().isoformat()
        })
        
        await send_to_web_clients({
            "type": "command_response",
            "status": "success",
            "command": {"type": "servo", "servo1": command.servo1, "servo2": command.servo2}
        })
        return {"status": "success", "message": f"Servo command sent: X={command.servo1}°, Y={command.servo2}°"}
    except ValueError as e:
        logger.error(f"Servo validation error from {request.client.host}: {e}, input: servo1={command.servo1}, servo2={command.servo2}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Servo command error from {request.client.host}: {e}, input: servo1={command.servo1}, servo2={command.servo2}")
        raise HTTPException(status_code=500, detail="Servo command error")

@app.post("/set_action")
async def set_action(command: ActionCommand, request: Request, user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    logger.info(f"[HTTP] /set_action from {request.client.host}: action={command.action}, intensity={command.intensity}")
    try:
        command.validate_action()
        await insert_action_command(command.action, command.intensity)
        await insert_log(f"Action command: {command.action}, Intensity: {command.intensity}%", "command")
        if command.action in ['flash_on', 'flash_off']:
            system_state.flash_intensity = command.intensity if command.action == 'flash_on' else 0
        
        # Send action to Pico, and response to web clients
        await send_to_pico_client({
            "type": "action", 
            "command": {"action": command.action, "intensity": command.intensity}
        })
        await send_to_web_clients({
            "type": "command_response",
            "status": "success",
            "command": {"type": "action", "action": command.action, "intensity": command.intensity}
        })

        return {"status": "success", "message": f"Action command sent: {command.action}, Intensity: {command.intensity}%"}
    except ValueError as e:
        logger.error(f"Action validation error: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Action command error: {e}")
        raise HTTPException(status_code=500, detail="Action command error")

@app.post("/set_device_mode")
async def set_device_mode(command: DeviceModeCommand, user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    logger.info(f"[HTTP] /set_device_mode: device_mode={command.device_mode}")
    try:
        system_state.device_mode = command.device_mode
        system_state.resolution = DEVICE_RESOLUTIONS[command.device_mode]
        logger.info(f"[HTTP] Set system_state.device_mode to {system_state.device_mode}")
        await insert_device_mode_command(command.device_mode)
        await insert_log(f"Device mode: {command.device_mode} ({system_state.resolution['width']}x{system_state.resolution['height']})", "command")
        await send_to_web_clients({
            "type": "command_response",
            "status": "success",
            "command": {"type": "device_mode", "device_mode": command.device_mode, "resolution": system_state.resolution}
        })
        return {"status": "success", "message": f"Device mode set: {command.device_mode} ({system_state.resolution['width']}x{system_state.resolution['height']})", "resolution": system_state.resolution}
    except Exception as e:
        logger.error(f"Device mode error: {e}")
        raise HTTPException(status_code=400, detail="Device mode error")

global_pico_last_seen = None

def check_internet():
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=2)
        return "online"
    except Exception:
        return "offline"

@app.get("/get_status")
async def get_status(user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    try:
        ram_percent = psutil.virtual_memory().percent if PSUTIL_AVAILABLE else None
        cpu_percent = psutil.cpu_percent(interval=0.2) if PSUTIL_AVAILABLE else None
        total, used, free = await asyncio.to_thread(shutil.disk_usage, '.')
        free_percent = (free / total) * 100
        storage_str = f"{free_percent:.1f}% free"
        system_info = {
            "server_status": "online" if not system_state.system_shutdown else "offline",
            "camera_status": "online" if system_state.device_status["esp32cam"]["online"] else "offline",
            "pico_status": "online" if system_state.device_status["pico"]["online"] else "offline",
            "pico_last_seen": system_state.device_status["pico"]["last_seen"],
            "ram_percent": ram_percent,
            "cpu_percent": cpu_percent,
            "internet": await asyncio.to_thread(check_internet),
            "storage": storage_str
        }
        return {"status": "success", "data": system_info}
    except Exception as e:
        logger.exception("Status retrieval error")
        return {"status": "error", "error": str(e)}

@app.get("/get_photo_count")
async def get_photo_count(user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    try:
        photo_count = len([f for f in await asyncio.to_thread(os.listdir, GALLERY_DIR) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]) if os.path.exists(GALLERY_DIR) else 0
        return {"status": "success", "count": photo_count}
    except Exception as e:
        logger.error(f"Photo count error: {e}")
        raise HTTPException(status_code=500, detail="Photo count error")

@app.get("/get_gallery")
@robust_db_endpoint
async def get_gallery(page: int = 0, limit: int = 9, user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    try:
        if not os.path.exists(GALLERY_DIR):
            await asyncio.to_thread(os.makedirs, GALLERY_DIR, exist_ok=True)
        files = [f for f in await asyncio.to_thread(os.listdir, GALLERY_DIR) if f.lower().endswith((".jpg", ".jpeg", ".png"))]
        files.sort(key=lambda x: os.path.getctime(os.path.join(GALLERY_DIR, x)), reverse=True)
        start = page * limit
        end = start + limit
        page_files = files[start:end]
        gallery_data = [{"filename": f, "url": f"/gallery/{f}", "size": os.path.getsize(os.path.join(GALLERY_DIR, f)), "timestamp": datetime.fromtimestamp(os.path.getctime(os.path.join(GALLERY_DIR, f))).isoformat()} for f in page_files]
        return {"status": "success", "photos": gallery_data, "total": len(files), "page": page, "limit": limit, "has_more": end < len(files)}
    except Exception as e:
        raise e

@app.get("/get_videos")
@robust_db_endpoint
async def get_videos(page: int = 0, limit: int = 6, user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    if not os.path.exists(SECURITY_VIDEOS_DIR):
        await asyncio.to_thread(os.makedirs, SECURITY_VIDEOS_DIR, exist_ok=True)
    files = [f for f in await asyncio.to_thread(os.listdir, SECURITY_VIDEOS_DIR) if f.lower().endswith(('.mp4', '.avi', '.mov'))]
    files.sort(key=lambda x: os.path.getctime(os.path.join(SECURITY_VIDEOS_DIR, x)), reverse=True)
    start = page * limit
    end = start + limit
    page_files = files[start:end]
    videos_data = []
    for f in page_files:
        # Extract hour from the timestamp in the filename (e.g., "video_2025-05-25_23-57-00.mp4")
        try:
            timestamp_part = f.split('_')[2].split('.')[0]  # Get "23-57-00"
            hour = int(timestamp_part.split('-')[0])  # Extract "23" as the hour
        except (IndexError, ValueError):
            hour = 0  # Default to 0 if parsing fails
        videos_data.append({
            "filename": f,
            "url": f"/security_videos/{f}",
            "size": os.path.getsize(os.path.join(SECURITY_VIDEOS_DIR, f)),
            "timestamp": datetime.fromtimestamp(os.path.getctime(os.path.join(SECURITY_VIDEOS_DIR, f))).isoformat(),
            "hour": hour
        })
    return {"status": "success", "videos": videos_data, "total": len(files), "page": page, "limit": limit, "has_more": end < len(files)}

@app.get("/get_logs")
@robust_db_endpoint
async def get_logs(limit: int = 50, source: str = None, level: str = None, user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    conn = await get_db_connection()
    try:
        query = "SELECT * FROM camera_logs"
        filters = []
        params = []
        if source:
            filters.append("source = ?")
            params.append(source)
        if level:
            filters.append("log_type = ?")
            params.append(level)
        if filters:
            query += " WHERE " + " AND ".join(filters)
        query += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        cursor = await conn.execute(query, tuple(params))
        logs = await cursor.fetchall()
        logs_data = [{
            "timestamp": log["created_at"],
            "level": log["log_type"],
            "message": log["message"],
            "source": log["source"] if "source" in log.keys() else None,
            "pico_timestamp": log["pico_timestamp"] if "pico_timestamp" in log.keys() else None
        } for log in logs]
        return {"status": "success", "logs": logs_data}
    finally:
        await close_db_connection(conn)

@app.get("/get_all_logs")
@robust_db_endpoint
async def get_all_logs(user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    conn = await get_db_connection()
    try:
        cursor = await conn.execute("SELECT * FROM camera_logs ORDER BY created_at DESC")
        logs = await cursor.fetchall()
        logs_data = [{
            "id": log['id'],
            "message": log['message'],
            "level": log['log_type'],
            "timestamp": log['created_at'],
            "source": log["source"] if "source" in log.keys() else None,
            "pico_timestamp": log["pico_timestamp"] if "pico_timestamp" in log.keys() else None
        } for log in logs]
        return {"status": "success", "logs": logs_data}
    finally:
        await close_db_connection(conn)

@app.post("/delete_photo/{filename}")
@robust_db_endpoint
async def delete_photo(filename: str, request: Request, user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    logger.info(f"[HTTP] /delete_photo from {request.client.host}: filename={filename}")
    request = DeleteImageRequest(filename=filename)
    request.validate_filename()
    filepath = os.path.join(GALLERY_DIR, request.filename)
    if not os.path.exists(filepath):
        raise HTTPException(status_code=404, detail="File not found")
    await asyncio.to_thread(os.remove, filepath)
    conn = await get_db_connection()
    try:
        await conn.execute("DELETE FROM manual_photos WHERE filename=?", (request.filename,))
        await conn.commit()
    finally:
        await close_db_connection(conn)
    try:
        await insert_log(f"Photo deleted: {request.filename}", "delete")
    except Exception as e:
        logger.error(f"Error inserting photo delete log: {e}")
        system_state.error_counts["database"] += 1
    await send_to_web_clients({"type": "photo_deleted", "filename": request.filename})
    return {"status": "success", "message": f"Photo {request.filename} deleted"}

@app.post("/delete_video")
@robust_db_endpoint
async def delete_video(request: DeleteVideoRequest, req: Request, user=Depends(get_current_user)):
    """Legacy endpoint - redirects to delete_video_by_filename"""
    return await delete_video_by_filename(request.filename, user)

@app.post("/manual_photo")
@robust_db_endpoint
async def manual_photo(request: ManualPhotoRequest, req: Request, user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    logger.info(f"[HTTP] /manual_photo from {req.client.host}: quality={request.quality}, flash={request.flash}, intensity={request.intensity}")
    
    try:
        # بررسی اتصال ESP32CAM - برای تست موقتاً نادیده می‌گیریم
        if not system_state.device_status["esp32cam"]["online"]:
            logger.warning("ESP32CAM is offline, but continuing for testing purposes")
            # برای تست، ادامه می‌دهیم
            # return {"status": "error", "message": "ESP32CAM is offline, cannot capture photo"}
        
        # ارسال دستور به ESP32CAM
        await send_to_esp32cam_client({
            "action": "capture_photo",
            "quality": request.quality,
            "flash": request.flash,
            "intensity": request.intensity
        })
        
        # ثبت لاگ
        await insert_log(f"Manual photo command sent to ESP32CAM: quality={request.quality}, flash={request.flash}, intensity={request.intensity}%", "photo")
        
        return {"status": "success", "message": "Photo capture command sent to ESP32CAM"}
        
    except Exception as e:
        logger.error(f"Unexpected DB ERROR: {e}")
        return {"status": "error", "message": "Internal server error"}

@app.post("/upload_photo")
@robust_db_endpoint
async def upload_photo(request: Request, user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    form = await request.form()
    logger.info(f"[HTTP] /upload_photo from {request.client.host}: fields={list(form.keys())}")
    if set(form.keys()) - {'photo', 'quality', 'flash_used', 'intensity'}:
        raise HTTPException(status_code=400, detail="Invalid form fields")
    photo_data = form.get("photo")
    quality = int(form.get("quality", 80))
    flash_used = form.get("flash_used", "false").lower() == "true"
    intensity = int(form.get("intensity", 50))
    if not photo_data:
        raise HTTPException(status_code=400, detail="Photo data not received")
    photo_bytes = await photo_data.read() if hasattr(photo_data, 'file') else (photo_data.encode() if isinstance(photo_data, str) else photo_data)
    if len(photo_bytes) > MAX_UPLOAD_SIZE:
        raise HTTPException(status_code=400, detail="Photo size exceeds limit")
    if not validate_image_format(photo_bytes):
        raise HTTPException(status_code=400, detail="Invalid photo format")
    processed_photo = await preprocess_frame(photo_bytes)
    final_photo = await add_persian_text_overlay(processed_photo)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"manual_photo_{timestamp}.jpg"
    filepath = os.path.join(GALLERY_DIR, filename)
    await asyncio.to_thread(os.makedirs, GALLERY_DIR, exist_ok=True)
    await asyncio.to_thread(lambda: open(filepath, 'wb').write(final_photo))
    await insert_photo_to_db(filename, filepath, quality, flash_used, intensity)
    try:
        await insert_log(f"Photo uploaded: {filename}, Intensity: {intensity}%", "photo")
    except Exception as e:
        logger.error(f"Error inserting photo upload log: {e}")
        system_state.error_counts["database"] += 1
    await send_to_web_clients({
        "type": "photo_captured",
        "filename": filename,
        "url": f"/gallery/{filename}",
        "quality": quality,
        "flash_used": flash_used,
        "intensity": intensity,
        "timestamp": get_jalali_now_str()
    })
    return {"status": "success", "filename": filename, "url": f"/gallery/{filename}"}

@app.post("/upload_frame")
async def upload_frame(request: Request, user=Depends(get_current_user)):
    """آپلود فریم با بهینه‌سازی real-time و مدیریت هوشمند"""
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    start_time = time.time()
    
    try:
        # بررسی نرخ فریم با منطق پیشرفته
        current_time = time.time()
        frame_interval = current_time - system_state.last_frame_time
        
        if frame_interval < MIN_FRAME_INTERVAL:
            # بررسی اینکه آیا باید فریم را رد کنیم یا نه
            if system_state.frame_skip_count < FRAME_SKIP_THRESHOLD:
                system_state.frame_skip_count += 1
                return {"status": "success", "message": "Frame skipped (high rate)"}
            else:
                # اگر تعداد فریم‌های رد شده زیاد است، فریم را پردازش کن
                system_state.frame_skip_count = 0
        
        system_state.last_frame_time = current_time
        
        # دریافت داده فریم
        form = await request.form()
        if not form or set(form.keys()) - {'frame'} or 'frame' not in form:
            raise HTTPException(status_code=400, detail="Frame data not received or invalid form fields")
        
        frame_data = form.get("frame")
        if not frame_data:
            raise HTTPException(status_code=400, detail="Frame data not received")
        
        frame_bytes = await frame_data.read() if hasattr(frame_data, 'file') else (frame_data.encode() if isinstance(frame_data, str) else frame_data)
        
        # اعتبارسنجی اندازه و فرمت
        if len(frame_bytes) > MAX_FRAME_SIZE:
            raise HTTPException(status_code=400, detail="Frame size exceeds limit")
        if not validate_image_format(frame_bytes):
            raise HTTPException(status_code=400, detail="Invalid frame format")
        
        # پردازش فریم با timeout
        try:
            processed_frame = await asyncio.wait_for(preprocess_frame(frame_bytes), timeout=FRAME_PROCESSING_TIMEOUT)
        except asyncio.TimeoutError:
            logger.warning("Frame processing timeout, using original frame")
            system_state.frame_drop_count += 1
            processed_frame = frame_bytes
        
        # اضافه کردن متن فارسی
        final_frame = await add_persian_text_overlay(processed_frame)
        
        # ذخیره در سیستم با lock بهینه
        async with system_state.frame_lock:
            system_state.latest_frame = final_frame
            system_state.frame_count += 1
        
        # مدیریت buffer با منطق هوشمند
        async with system_state.frame_buffer_lock:
            # بررسی buffer overflow با منطق پیشرفته
            if len(system_state.frame_buffer) >= FRAME_BUFFER_SIZE:
                # حذف فریم‌های قدیمی بر اساس نسبت
                frames_to_remove = int(FRAME_BUFFER_SIZE * FRAME_DROP_RATIO)
                system_state.frame_buffer = system_state.frame_buffer[frames_to_remove:]
                system_state.frame_drop_count += frames_to_remove
                logger.info(f"Frame buffer trimmed: removed {frames_to_remove} old frames")
            
            # اضافه کردن فریم جدید
            system_state.frame_buffer.append((final_frame, datetime.now()))
            
            # بررسی نیاز به ایجاد ویدیو
            if len(system_state.frame_buffer) >= FRAME_BUFFER_SIZE:
                try:
                    # ایجاد ویدیو در background
                    asyncio.create_task(create_security_video_async(system_state.frame_buffer[:FRAME_BUFFER_SIZE//2]))
                    system_state.frame_buffer = system_state.frame_buffer[FRAME_BUFFER_SIZE//2:]
                except Exception as e:
                    logger.error(f"Error creating security video: {e}")
                    # در صورت خطا، buffer را پاک کن
                    system_state.frame_buffer = system_state.frame_buffer[-FRAME_BUFFER_SIZE//4:]
        
        # ارسال به فرانت‌اند با بهینه‌سازی
        try:
            await send_frame_to_clients(final_frame)
        except Exception as e:
            logger.error(f"Error sending frame to clients: {e}")
            system_state.error_counts["frame_processing"] += 1
        
        # محاسبه و ثبت متریک‌های عملکرد
        total_time = time.time() - start_time
        if PERFORMANCE_MONITORING:
            system_state.performance_metrics["frame_drop_rate"] = system_state.frame_drop_count / max(system_state.frame_count, 1)
        
        return {"status": "success", "processing_time": total_time}
        
    except ValueError as e:
        logger.error(f"Frame validation error: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException as e:
        raise e
    except Exception as e:
        logger.error(f"Frame upload error: {e}")
        raise HTTPException(status_code=500, detail="Frame upload error")

async def generate_frames():
    while not system_state.system_shutdown:
        try:
            async with system_state.frame_lock:
                if system_state.latest_frame is not None:
                    yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + system_state.latest_frame + b'\r\n')
            await asyncio.sleep(1.0 / VIDEO_FPS)
        except Exception as e:
            logger.error(f"Frame generation error: {e}")
            await asyncio.sleep(1)

@app.get("/esp32_video_feed")
async def video_feed(user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    try:
        return StreamingResponse(generate_frames(), media_type="multipart/x-mixed-replace;boundary=frame")
    except Exception as e:
        logger.error(f"Video feed error: {e}")
        raise HTTPException(status_code=500, detail="Video feed error")

@app.websocket("/ws/video")
async def video_stream_websocket(websocket: WebSocket):
    # WebSocket authentication for video stream
    try:
        # Check for JWT token in headers
        auth_header = websocket.headers.get("authorization", "")
        if not auth_header.startswith("Bearer "):
            # For localhost testing, allow connections without auth
            if "127.0.0.1" in websocket.client.host or "localhost" in websocket.client.host:
                await websocket.accept()
            else:
                await websocket.close(code=4001, reason="Missing authorization")
                return
        else:
            token = auth_header.replace("Bearer ", "")
            if not verify_token(token):
                await websocket.close(code=4001, reason="Invalid token")
                return
            await websocket.accept()
    except Exception as e:
        logger.error(f"Video WebSocket authentication error: {e}")
        try:
            await websocket.close(code=4001, reason="Authentication error")
        except Exception:
            pass
        return
    
    logger.info(f"[Video WebSocket] New video connection from {websocket.client.host}")
    
    try:
        last_frame_sent = None
        while not system_state.system_shutdown:
            try:
                # Check if client is still connected by sending a ping
                try:
                    await websocket.send_text(json.dumps({"type": "ping"}))
                except Exception as e:
                    # Connection is broken, break the loop
                    if "1000" not in str(e) and "Rapid test" not in str(e):
                        logger.info(f"[Video WebSocket] Connection broken for {websocket.client.host}: {e}")
                    break
                
                async with system_state.frame_lock:
                    if system_state.latest_frame is not None and system_state.latest_frame != last_frame_sent:
                        try:
                            await websocket.send_bytes(system_state.latest_frame)
                            last_frame_sent = system_state.latest_frame
                        except Exception as e:
                            if "1000" not in str(e) and "Rapid test" not in str(e):
                                logger.error(f"[Video WebSocket] Error sending frame to {websocket.client.host}: {e}")
                            break
                
                await asyncio.sleep(1.0 / VIDEO_FPS)
                
            except WebSocketDisconnect:
                logger.info(f"[Video WebSocket] Client {websocket.client.host} disconnected")
                break
            except ConnectionResetError:
                logger.info(f"[Video WebSocket] Connection reset by {websocket.client.host}")
                break
            except Exception as e:
                logger.error(f"[Video WebSocket] Error sending frame to {websocket.client.host}: {e}")
                break
                
    except Exception as e:
        logger.error(f"[Video WebSocket] Unexpected error for {websocket.client.host}: {e}")
    finally:
        try:
            await websocket.close(code=1000)
        except Exception:
            pass
        logger.info(f"[Video WebSocket] Connection closed for {websocket.client.host}")

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for web clients with improved error handling"""
    try:
        # WebSocket authentication for web clients
        # For testing, allow connections without auth for localhost
        if "127.0.0.1" in websocket.client.host or "localhost" in websocket.client.host:
            await websocket.accept()
        elif not await authenticate_websocket(websocket):
            logger.warning(f"WebSocket authentication failed for {websocket.client.host}")
            return
        
        user_agent = websocket.headers.get('user-agent', 'Unknown')
        logger.info(f"[WebSocket] New web connection from {websocket.client.host}, user-agent: {user_agent}")
        connect_time = datetime.now()
        client = ActiveClient(websocket, connect_time, user_agent)
        client_id = id(websocket)
        websocket_error_counts = {client_id: 0}

        async with system_state.web_clients_lock:
            if len(system_state.web_clients) >= MAX_WEBSOCKET_CLIENTS:
                await websocket.send_text(json.dumps({"type": "error", "message": "Maximum WebSocket clients reached."}))
                await websocket.close(code=1008)
                logger.warning(f"Rejected web connection from {websocket.client.host}: Max clients reached")
                return
            system_state.web_clients.append(websocket)
            system_state.active_clients.append(client)
            
    except Exception as e:
        logger.error(f"Error in WebSocket connection setup: {e}")
        try:
            await websocket.close(code=1011)  # Internal error
        except Exception:
            pass
        return
    
    async def send_status():
        try:
            ram_percent = psutil.virtual_memory().percent if PSUTIL_AVAILABLE else None
            cpu_percent = psutil.cpu_percent(interval=0.2) if PSUTIL_AVAILABLE else None
            active_ips = [{"ip": c.ip, "connect_time": c.connect_time.isoformat() if c.connect_time else None, "user_agent": c.user_agent, "last_activity": c.last_activity.isoformat() if c.last_activity else None} for c in system_state.active_clients]
            # تبدیل device_status به JSON serializable با error handling
            try:
                serializable_device_status = {
                    "pico": {
                        "online": system_state.device_status.get("pico", {}).get("online", False),
                        "last_seen": system_state.device_status.get("pico", {}).get("last_seen").isoformat() if system_state.device_status.get("pico", {}).get("last_seen") else None,
                        "errors": system_state.device_status.get("pico", {}).get("errors", [])
                    },
                    "esp32cam": {
                        "online": system_state.device_status.get("esp32cam", {}).get("online", False),
                        "last_seen": system_state.device_status.get("esp32cam", {}).get("last_seen").isoformat() if system_state.device_status.get("esp32cam", {}).get("last_seen") else None,
                        "errors": system_state.device_status.get("esp32cam", {}).get("errors", [])
                    }
                }
            except Exception as e:
                logger.warning(f"Error serializing device_status: {e}")
                serializable_device_status = {
                    "pico": {"online": False, "last_seen": None, "errors": []},
                    "esp32cam": {"online": False, "last_seen": None, "errors": []}
                }
            
            system_info = {
                "type": "status",
                "server_status": "online" if not system_state.system_shutdown else "offline",
                "camera_status": "online" if system_state.latest_frame is not None else "offline",
                "pico_status": "online" if global_pico_last_seen else "offline",
                "pico_last_seen": global_pico_last_seen.isoformat() if global_pico_last_seen else None,
                "ram_percent": ram_percent,
                "cpu_percent": cpu_percent,
                "internet": await asyncio.to_thread(check_internet),
                "storage": system_state.last_disk_space,
                "active_ips": active_ips,
                "device_status": serializable_device_status
            }
            await websocket.send_text(json.dumps(system_info))
        except Exception as e:
            # Don't log normal closure errors
            if ("1000" not in str(e) and "Rapid test" not in str(e) and 
                "Connection reset" not in str(e) and "keepalive" not in str(e).lower() and
                "1011" not in str(e) and "timeout" not in str(e).lower()):
                logger.error(f"Error sending status to {websocket.client.host}: {e}")
            # If we can't send status, the connection is likely broken
            raise
    
    try:
        await send_status()
        last_activity = datetime.now()
        last_pong = datetime.now()
        while not system_state.system_shutdown:
            try:
                try:
                    if (datetime.now() - last_activity).total_seconds() > INACTIVE_CLIENT_TIMEOUT:
                        logger.warning(f"[WebSocket] Client {websocket.client.host} inactive for {INACTIVE_CLIENT_TIMEOUT} seconds, closing connection")
                        await websocket.send_text(json.dumps({"type": "error", "message": "Inactive for too long"}))
                        break
                    if (datetime.now() - last_pong).total_seconds() > 30:
                        logger.warning(f"[WebSocket] No pong received from {websocket.client.host} within 30 seconds, sending ping")
                        await websocket.send_text(json.dumps({"type": "ping"}))
                    try:
                        data = await asyncio.wait_for(websocket.receive_text(), timeout=30.0)
                        last_activity = datetime.now()
                        client.last_activity = last_activity
                        message = json.loads(data)
                        cmd_type = message.get('type')
                    except json.JSONDecodeError as e:
                        logger.warning(f"[WebSocket] Invalid JSON from {websocket.client.host}: {e}")
                        continue
                    except Exception as e:
                        logger.warning(f"[WebSocket] Error receiving message from {websocket.client.host}: {e}")
                        break

                    # فقط پیام‌های ping/pong/ack و وضعیت را هندل کن
                    if cmd_type == 'pong':
                        logger.info(f"[WebSocket] Received pong from web client {websocket.client.host}")
                        last_pong = datetime.now()
                        try:
                            await websocket.send_text(json.dumps({"type": "ack", "cmd_type": "pong", "status": "received"}))
                        except Exception as e:
                            if "1000" not in str(e) and "Rapid test" not in str(e):
                                logger.error(f"[WebSocket] Error sending ack for pong to {websocket.client.host}: {e}")
                            break
                        continue
                    elif cmd_type == 'ping':
                        logger.info(f"[WebSocket] Received ping from web client {websocket.client.host}")
                        try:
                            await websocket.send_text(json.dumps({"type": "pong"}))
                            last_pong = datetime.now()
                        except Exception as e:
                            if "1000" not in str(e) and "Rapid test" not in str(e):
                                logger.error(f"[WebSocket] Error sending pong to {websocket.client.host}: {e}")
                            break
                        continue
                    elif cmd_type == 'ack':
                        logger.info(f"[WebSocket] Ack received from web client {websocket.client.host}: {message}")
                        continue
                    else:
                        # فقط وضعیت را ارسال کن
                        try:
                            await send_status()
                        except Exception as e:
                            if ("1000" not in str(e) and "Rapid test" not in str(e) and 
                                "keepalive" not in str(e).lower() and "1011" not in str(e) and 
                                "timeout" not in str(e).lower()):
                                logger.error(f"[WebSocket] Error sending status to {websocket.client.host}: {e}")
                            break
                        continue
                except Exception as e:
                    # Don't log normal closure errors
                    if ("1000" not in str(e) and "Rapid test" not in str(e) and 
                        "keepalive" not in str(e).lower() and "1011" not in str(e) and 
                        "timeout" not in str(e).lower()):
                        logger.error(f"[WebSocket] Inner error for {websocket.client.host}: {e}")
                    try:
                        await websocket.send_text(json.dumps({"type": "ack", "cmd_type": "error", "status": "ignored", "detail": str(e)}))
                    except Exception:
                        pass
                    # Don't continue, break the loop to close connection
                    break
            except asyncio.TimeoutError:
                logger.warning(f"[WebSocket] Timeout waiting for message from {websocket.client.host}, sending ping")
                try:
                    await websocket.send_text(json.dumps({"type": "ping"}))
                    last_pong = datetime.now()
                except Exception as e:
                    if ("1000" not in str(e) and "Rapid test" not in str(e) and 
                        "keepalive" not in str(e).lower() and "1011" not in str(e) and 
                        "timeout" not in str(e).lower()):
                        logger.error(f"[WebSocket] Error sending ping after timeout to {websocket.client.host}: {e}")
                    break
            except WebSocketDisconnect as e:
                logger.info(f"[WebSocket] Client {websocket.client.host} disconnected cleanly: code={e.code}, reason={e.reason}")
                break
            except ConnectionResetError as e:
                logger.info(f"[WebSocket] Connection reset by {websocket.client.host}: {e}")
                break
            except Exception as e:
                # Don't log normal closure errors
                if ("1000" not in str(e) and "Rapid test" not in str(e) and 
                    "keepalive" not in str(e).lower() and "1011" not in str(e) and 
                    "timeout" not in str(e).lower()):
                    logger.error(f"[WebSocket] Outer error for {websocket.client.host}: {e}", exc_info=True)
                try:
                    await websocket.send_text(json.dumps({"type": "ack", "cmd_type": "error", "status": "ignored", "detail": str(e)}))
                except Exception:
                    # If we can't send the error message, the connection is likely broken
                    break
                continue
    finally:
        async with system_state.web_clients_lock:
            if websocket in system_state.web_clients:
                system_state.web_clients.remove(websocket)
            system_state.active_clients = [c for c in system_state.active_clients if not (hasattr(c, 'ws') and c.ws == websocket)]
        try:
            await websocket.close(code=1000)
        except Exception:
            pass
        logger.info(f"[WebSocket] Web connection closed for {websocket.client.host}")
        try:
            websocket_error_counts.pop(client_id, None)
        except Exception as e:
            logger.warning(f"Error cleaning up websocket error counts: {e}")
        # Clean up any remaining references to prevent memory leaks
        try:
            del client
        except Exception:
            pass

@app.websocket("/ws/pico")
async def pico_websocket_endpoint(websocket: WebSocket):
    logger.info(f"[WebSocket] Pico connection attempt from {websocket.client.host}")
    try:
        # Authenticate the connection
        if not await authenticate_websocket(websocket, "pico"):
            logger.warning(f"[WebSocket] Pico authentication failed from {websocket.client.host}")
            try:
                await websocket.send_text(json.dumps({"type": "error", "message": "Authentication failed"}))
            except Exception:
                pass
            return
        logger.info(f"[WebSocket] Pico authenticated and connected from {websocket.client.host}")
        async with system_state.pico_client_lock:
            system_state.pico_client = websocket
            system_state.device_status["pico"]["online"] = True
            system_state.device_status["pico"]["last_seen"] = datetime.now()
            system_state.active_clients.append(ActiveClient(websocket, datetime.now(), "Pico"))
            logger.info(f"[DEBUG] Pico status updated: online=True, last_seen={system_state.device_status['pico']['last_seen']}")
        # Send connection success message
        try:
            await websocket.send_text(json.dumps({"type": "connection_ack", "status": "success", "message": "Pico connected successfully"}))
        except Exception as e:
            logger.warning(f"[WebSocket] Could not send connection success message: {e}")
        
        # Create periodic ping task with improved stability
        ping_task = None
        last_ping_time = datetime.now()
        ping_interval = 60  # Increased from 15 to 60 seconds to reduce network usage
        
        async def periodic_ping():
            """Send periodic pings to Pico to keep connection alive with improved error handling"""
            nonlocal last_ping_time
            last_activity = datetime.now()
            consecutive_inactive_periods = 0
            
            while True:
                try:
                    await asyncio.sleep(ping_interval)
                    current_time = datetime.now()
                    
                    # Check if connection is still active
                    if system_state.pico_client != websocket:
                        logger.debug(f"[WebSocket] Pico connection changed, stopping ping task")
                        break
                    
                    # Enhanced ping logic for continuous sensor data:
                    # - During active sensor data transmission: minimal ping (every 5 minutes)
                    # - During low activity: adaptive ping
                    # - During no activity: frequent ping
                    inactive_duration = (current_time - last_activity).total_seconds()
                    
                    # Check if we're receiving sensor data
                    sensor_data_active = False
                    if hasattr(system_state, 'sensor_data_buffer') and system_state.sensor_data_buffer:
                        # Check if we received sensor data in last 60 seconds (more lenient)
                        try:
                            recent_sensor_data = [data for data in system_state.sensor_data_buffer 
                                                if (current_time - datetime.fromisoformat(data['timestamp'].replace('Z', '+00:00'))).total_seconds() < 60]
                            sensor_data_active = len(recent_sensor_data) > 0
                        except:
                            # If timestamp parsing fails, assume active
                            sensor_data_active = True
                    
                    # Adaptive ping strategy for continuous data:
                    if sensor_data_active:
                        # During active sensor data transmission, minimal ping
                        ping_threshold = 300  # 5 minutes
                    elif inactive_duration > 900:  # 15+ minutes
                        ping_threshold = 60  # 1 minute
                    elif inactive_duration > 300:  # 5-15 minutes
                        ping_threshold = 120  # 2 minutes
                    else:
                        ping_threshold = 999999  # No ping for first 5 minutes
                    
                    if inactive_duration > ping_threshold:
                        consecutive_inactive_periods += 1
                        # Send ping with timestamp
                        ping_message = {
                            "type": "ping", 
                            "timestamp": current_time.isoformat(),
                            "server_time": current_time.timestamp(),
                            "inactive_duration": int(inactive_duration)
                        }
                        await websocket.send_text(json.dumps(ping_message))
                        last_ping_time = current_time
                        logger.debug(f"[WebSocket] Smart ping sent to Pico at {current_time} (inactive for {inactive_duration:.0f}s, period #{consecutive_inactive_periods})")
                    else:
                        consecutive_inactive_periods = 0  # Reset counter if activity detected
                    
                except asyncio.CancelledError:
                    logger.debug(f"[WebSocket] Ping task cancelled for Pico")
                    break
                except Exception as e:
                    # Don't log normal closure errors
                    if "1000" not in str(e) and "Rapid test" not in str(e) and "ABNORMAL_CLOSURE" not in str(e):
                        logger.warning(f"[WebSocket] Error sending periodic ping to Pico: {e}")
                    break
        
        # Start periodic ping task
        ping_task = asyncio.create_task(periodic_ping())
        
        # Main message handling loop with improved error handling
        try:
            while True:
                try:
                    # Increased timeout for better stability
                    data = await asyncio.wait_for(websocket.receive_text(), timeout=300)  # 5 minutes timeout
                    # Only log every 100th message to reduce overhead
                    if hasattr(system_state, 'message_counter'):
                        system_state.message_counter += 1
                    else:
                        system_state.message_counter = 1
                    
                    if system_state.message_counter % 100 == 0:
                        logger.info(f"[WebSocket] Pico message #{system_state.message_counter}: {data[:100]}...")
                    else:
                        logger.debug(f"[WebSocket] Pico message #{system_state.message_counter}")
                    
                    try:
                        message = json.loads(data)
                        message_type = message.get("type")
                        
                        # Update last seen for any message
                        current_time = datetime.now()
                        system_state.device_status["pico"]["last_seen"] = current_time
                        last_activity = current_time  # Update activity for smart ping
                        
                        if message_type == "pong":
                            logger.info(f"[PICO] Pong received, updating last_seen")
                            # Reset ping interval if we get a pong
                            last_ping_time = datetime.now()
                            
                        elif message_type == "ping":
                            # پاسخ به ping پیکو با timestamp
                            try:
                                pong_message = {
                                    "type": "pong",
                                    "timestamp": datetime.now().isoformat(),
                                    "server_time": datetime.now().timestamp()
                                }
                                await websocket.send_text(json.dumps(pong_message))
                                logger.info(f"[PICO] Ping received, sent pong response")
                            except Exception as e:
                                if "1000" not in str(e) and "Rapid test" not in str(e):
                                    logger.error(f"Error sending pong to Pico: {e}")
                                    
                        elif message_type == "connect":
                            # پیام اتصال اولیه پیکو
                            logger.info(f"[PICO] Connection message received: device={message.get('device')}, version={message.get('version')}")
                            # ارسال تایید اتصال فقط یک بار
                            if not hasattr(system_state, 'pico_connected'):
                                try:
                                    await websocket.send_text(json.dumps({
                                        "type": "connection_ack",
                                        "status": "success",
                                        "message": "Pico connection acknowledged",
                                        "timestamp": datetime.now().isoformat()
                                    }))
                                    system_state.pico_connected = True
                                except Exception as e:
                                    if "1000" not in str(e) and "Rapid test" not in str(e):
                                        logger.error(f"Error sending connection ack: {e}")
                            else:
                                logger.debug(f"[PICO] Connection already acknowledged, skipping")
                                    
                        elif message_type == "servo":
                            # پردازش دستورات سروو از پیکو
                            servo_data = message.get('command', {})
                            servo1_target = servo_data.get('servo1', 90)
                            servo2_target = servo_data.get('servo2', 90)
                            
                            logger.info(f"[PICO] Servo command received: servo1={servo1_target}°, servo2={servo2_target}°")
                            
                            # ارسال ACK برای دستور سروو
                            try:
                                ack_message = {
                                    "type": "ack",
                                    "command_type": "servo",
                                    "status": "success",
                                    "detail": f"servo1={servo1_target}°, servo2={servo2_target}°",
                                    "timestamp": datetime.now().isoformat()
                                }
                                await websocket.send_text(json.dumps(ack_message))
                                logger.info(f"[PICO] Servo command acknowledged")
                            except Exception as e:
                                if "1000" not in str(e) and "Rapid test" not in str(e):
                                    logger.error(f"Error sending servo ack: {e}")
                                    
                        elif message_type == "log":
                            logger.info(f"[PICO] {message.get('message', '')}")
                            try:
                                await insert_log(message.get('message', ''), message.get('level', 'info'), "pico")
                            except Exception as e:
                                logger.error(f"Error inserting Pico log: {e}")
                                system_state.error_counts["database"] += 1
                                
                        elif message_type == "ack":
                            logger.info(f"[PICO] ACK received: {message}")
                            
                        elif message_type == "test":
                            # پیام تست - فقط لاگ کن
                            logger.info(f"[PICO] Test message received: {message.get('message', '')}")
                            
                        elif message_type == "sensor_data":
                            # پردازش داده‌های سنسور برای استفاده مداوم
                            sensor_type = message.get("sensor_type", "unknown")
                            sensor_data = message.get("data", {})
                            sequence = sensor_data.get("sequence", 0)
                            
                            # ارسال ACK سریع برای داده‌های سنسور (بدون لاگ اضافی)
                            try:
                                ack_message = {
                                    "type": "ack",
                                    "command_type": "sensor_data",
                                    "status": "success",
                                    "sensor_type": sensor_type,
                                    "sequence": sequence,
                                    "timestamp": datetime.now().isoformat(),
                                    "server_time": datetime.now().timestamp()
                                }
                                await websocket.send_text(json.dumps(ack_message))
                                
                                # ذخیره داده‌های سنسور در حافظه برای پردازش
                                if not hasattr(system_state, 'sensor_data_buffer'):
                                    system_state.sensor_data_buffer = []
                                
                                system_state.sensor_data_buffer.append({
                                    "sensor_type": sensor_type,
                                    "data": sensor_data,
                                    "timestamp": datetime.now().isoformat(),
                                    "sequence": sequence
                                })
                                
                                # محدود کردن اندازه buffer
                                if len(system_state.sensor_data_buffer) > 1000:
                                    system_state.sensor_data_buffer = system_state.sensor_data_buffer[-500:]
                                
                                # Update activity for smart ping
                                last_activity = datetime.now()
                                
                                # Log only every 1000th sensor data for performance
                                if sequence % 1000 == 0:
                                    logger.info(f"[PICO] Sensor data processed: {sensor_type}, sequence: {sequence}")
                                
                            except Exception as e:
                                # Don't log normal WebSocket closure errors
                                if "1000" not in str(e) and "OK" not in str(e) and "ABNORMAL_CLOSURE" not in str(e):
                                    logger.error(f"Error processing sensor data: {e}")
                                else:
                                    logger.debug(f"Normal WebSocket operation: {e}")
                            
                        else:
                            logger.warning(f"[WebSocket] Unknown message type from Pico: {message}")
                            try:
                                await websocket.send_text(json.dumps({
                                    "type": "error", 
                                    "message": "Unknown message type",
                                    "timestamp": datetime.now().isoformat()
                                }))
                            except Exception:
                                pass
                                
                    except json.JSONDecodeError:
                        logger.warning(f"[WebSocket] Invalid JSON from Pico: {data}")
                        try:
                            await websocket.send_text(json.dumps({
                                "type": "error", 
                                "message": "Invalid JSON format",
                                "timestamp": datetime.now().isoformat()
                            }))
                        except Exception:
                            pass
                            
                except asyncio.TimeoutError:
                    # Send ping on timeout to check connection health
                    try:
                        ping_message = {
                            "type": "ping",
                            "timestamp": datetime.now().isoformat(),
                            "server_time": datetime.now().timestamp()
                        }
                        await websocket.send_text(json.dumps(ping_message))
                        logger.debug(f"[WebSocket] Timeout ping sent to Pico")
                    except Exception as e:
                        if "1000" not in str(e) and "Rapid test" not in str(e) and "ABNORMAL_CLOSURE" not in str(e):
                            logger.error(f"[WebSocket] Error sending timeout ping to Pico: {e}")
                        break
                    continue
        except Exception as e:
            # Don't log normal closure errors
            if "1000" not in str(e) and "Rapid test" not in str(e) and "ABNORMAL_CLOSURE" not in str(e):
                logger.error(f"[WebSocket] Pico error: {e}")
            try:
                await websocket.send_text(json.dumps({
                    "type": "error", 
                    "message": f"Server error: {str(e)}",
                    "timestamp": datetime.now().isoformat()
                }))
            except Exception:
                pass
            system_state.error_counts["websocket"] += 1
            system_state.device_status["pico"]["errors"].append({
                "time": datetime.now().isoformat(),
                "error": str(e)
            })
        finally:
            # Cancel periodic ping task
            if ping_task:
                ping_task.cancel()
                try:
                    await ping_task
                except asyncio.CancelledError:
                    pass
            async with system_state.pico_client_lock:
                system_state.pico_client = None
                system_state.device_status["pico"]["online"] = False
                system_state.device_status["pico"]["last_seen"] = datetime.now()
                system_state.active_clients = [c for c in system_state.active_clients if not (hasattr(c, 'ws') and c.ws == websocket)]
                # Reset connection flag
                if hasattr(system_state, 'pico_connected'):
                    delattr(system_state, 'pico_connected')
            logger.info(f"[WebSocket] Pico connection closed")
    except Exception as e:
        logger.error(f"[WebSocket] Fatal error in pico_websocket_endpoint: {e}")
        try:
            await websocket.send_text(json.dumps({"type": "error", "message": f"Fatal server error: {str(e)}"}))
        except Exception:
            pass


@app.post("/save_user_settings")
async def save_user_settings(settings: UserSettings, request: Request, user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    try:
        # First, ensure all required columns exist
        await migrate_user_settings_table()
        
        # Validate and sanitize data before saving with improved validation
        def safe_int(value, min_val, max_val, default):
            try:
                if value is None:
                    return default
                val = int(value)
                return max(min_val, min(max_val, val))
            except (ValueError, TypeError):
                return default
        
        def safe_bool(value):
            try:
                if value is None:
                    return False
                return bool(value)
            except (ValueError, TypeError):
                return False
        
        def safe_str(value, valid_options, default):
            try:
                if value is None or value not in valid_options:
                    return default
                return value
            except (ValueError, TypeError):
                return default
        
        validated_settings = {
            'username': user.get("sub"),
            'ip': request.client.host,
            'theme': safe_str(settings.theme, ['light', 'dark'], 'light'),
            'language': safe_str(settings.language, ['fa', 'en'], 'fa'),
            'servo1': safe_int(settings.servo1, 0, 180, 90),
            'servo2': safe_int(settings.servo2, 0, 180, 90),
            'device_mode': safe_str(settings.device_mode, ['desktop', 'mobile'], 'desktop'),
            'photo_quality': safe_int(settings.photoQuality, 1, 100, 80),
            'smart_motion': safe_bool(settings.smart_motion),
            'smart_tracking': safe_bool(settings.smart_tracking),
            'stream_enabled': safe_bool(settings.stream_enabled),
            'flash_settings': json.dumps({
                'intensity': safe_int(getattr(settings, 'flash_intensity', 50), 0, 100, 50),
                'enabled': safe_bool(getattr(settings, 'flash_enabled', False))
            })
        }
        
        # Retry logic for database operations
        max_retries = 3
        retry_delay = 0.1
        
        for attempt in range(max_retries):
            try:
                conn = await get_db_connection()
                try:
                    # Use direct execute instead of async context manager
                    try:
                        await conn.execute('''
                            INSERT OR REPLACE INTO user_settings 
                            (username, ip, theme, language, servo1, servo2, device_mode, photo_quality, 
                             smart_motion, smart_tracking, stream_enabled, flash_settings, updated_at)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ''', (
                            validated_settings['username'], validated_settings['ip'], validated_settings['theme'],
                            validated_settings['language'], validated_settings['servo1'], validated_settings['servo2'],
                            validated_settings['device_mode'], validated_settings['photo_quality'],
                            validated_settings['smart_motion'], validated_settings['smart_tracking'],
                            validated_settings['stream_enabled'], validated_settings['flash_settings'],
                            get_jalali_now_str()
                        ))
                        await conn.commit()
                    except Exception as e:
                        logger.warning(f"Error in transaction, trying individual insert: {e}")
                        # Fallback: try to insert without problematic columns
                        try:
                            await conn.execute('''
                                INSERT OR REPLACE INTO user_settings 
                                (username, ip, theme, language, servo1, servo2, device_mode, photo_quality, updated_at)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                            ''', (
                                validated_settings['username'], validated_settings['ip'], validated_settings['theme'],
                                validated_settings['language'], validated_settings['servo1'], validated_settings['servo2'],
                                validated_settings['device_mode'], validated_settings['photo_quality'],
                                get_jalali_now_str()
                            ))
                            await conn.commit()
                        except Exception as e2:
                            logger.error(f"Fallback insert also failed: {e2}")
                            raise
                    
                    logger.info(f"User settings saved successfully for {validated_settings['username']}")
                    
                finally:
                    await close_db_connection(conn)
                
                # Send servo command to Pico if servo values are provided
                if settings.servo1 is not None or settings.servo2 is not None:
                    servo1_val = settings.servo1 if settings.servo1 is not None else 90
                    servo2_val = settings.servo2 if settings.servo2 is not None else 90
                    
                    servo_cmd = {
                        "type": "servo",
                        "command": {
                            "servo1": servo1_val,
                            "servo2": servo2_val
                        },
                        "timestamp": datetime.now().isoformat(),
                        "source": "user_settings"
                    }
                    
                    await insert_servo_command(servo1_val, servo2_val)
                    await insert_log(f"Servo command from user settings: X={servo1_val}°, Y={servo2_val}°", "command")
                    
                    # Send to Pico
                    await send_to_pico_client(servo_cmd)
                    
                    # Send to ESP32CAM for logging
                    await send_to_esp32cam_client({
                        "type": "servo_command_log",
                        "servo1": servo1_val,
                        "servo2": servo2_val,
                        "timestamp": datetime.now().isoformat(),
                        "source": "user_settings"
                    })
                
                return {"success": True, "status": "success", "language": settings.language}
                
            except aiosqlite.OperationalError as e:
                if "database is locked" in str(e) and attempt < max_retries - 1:
                    logger.warning(f"Database locked on attempt {attempt + 1}/{max_retries}, retrying in {retry_delay}s: {e}")
                    await asyncio.sleep(retry_delay)
                    retry_delay *= 2  # Exponential backoff
                    continue
                else:
                    logger.error(f"Database operational error after {attempt + 1} attempts: {e}")
                    raise HTTPException(status_code=503, detail="Database temporarily unavailable, please try again")
            except ValidationError as e:
                logger.error(f"[HTTP] Validation error in /save_user_settings: {e.errors()}")
                raise HTTPException(status_code=422, detail=f"Validation error: {e.errors()}")
            except Exception as e:
                logger.error(f"ERROR saving user settings after {attempt + 1} attempts: {e}")
                if attempt < max_retries - 1:
                    await asyncio.sleep(retry_delay)
                    retry_delay *= 2
                    continue
                else:
                    # Return proper error response instead of raising exception
                    from fastapi.responses import JSONResponse
                    return JSONResponse(
                        status_code=503,
                        content={"detail": "Database error", "error": str(e)}
                    )
        
        # This should never be reached, but just in case
        raise HTTPException(status_code=503, detail="Database operation failed after all retries")
        
    except Exception as e:
        logger.error(f"Unexpected error in save_user_settings: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/get_user_settings")
@robust_db_endpoint
async def get_user_settings(request: Request, user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    try:
        # First, ensure all required columns exist
        await migrate_user_settings_table()
        
        conn = await get_db_connection()
        
        try:
            # Get user data with improved error handling
            user_query = await conn.execute(
                'SELECT username, role FROM users WHERE username = ?',
                (user.get("sub"),)
            )
            user_data = await user_query.fetchone()
            
            if not user_data:
                raise HTTPException(status_code=404, detail="User not found")
            
            # Get user settings with improved validation and error handling
            try:
                settings_query = await conn.execute(
                    'SELECT theme, language, flash_settings, servo1, servo2, device_mode, photo_quality, smart_motion, smart_tracking, stream_enabled FROM user_settings WHERE username = ? ORDER BY updated_at DESC LIMIT 1',
                    (user.get("sub"),)
                )
                settings_data = await settings_query.fetchone()
            except Exception as e:
                logger.warning(f"Error querying user settings, using fallback: {e}")
                settings_data = None
            
            # Prepare response data with validation
            response_data = {
                "status": "success",
                "user_role": user_data[1],
                "username": user_data[0],
                "language": request.cookies.get('language', 'fa')
            }
            
            if settings_data:
                # Validate and sanitize retrieved data
                flash_settings = settings_data[2] if settings_data[2] else "{}"
                try:
                    # Validate JSON format
                    if flash_settings and flash_settings != "{}":
                        json.loads(flash_settings)
                except json.JSONDecodeError:
                    flash_settings = "{}"
                
                response_data["settings"] = {
                    "theme": settings_data[0] if settings_data[0] in ['light', 'dark'] else "light",
                    "language": settings_data[1] if settings_data[1] in ['fa', 'en'] else "fa",
                    "flashSettings": flash_settings,
                    "servo1": max(0, min(180, settings_data[3])) if settings_data[3] is not None else 90,
                    "servo2": max(0, min(180, settings_data[4])) if settings_data[4] is not None else 90,
                    "device_mode": settings_data[5] if settings_data[5] in ['desktop', 'mobile'] else "desktop",
                    "photoQuality": max(1, min(100, settings_data[6])) if settings_data[6] is not None else 80,
                    "smart_motion": bool(settings_data[7]) if settings_data[7] is not None else False,
                    "smart_tracking": bool(settings_data[8]) if settings_data[8] is not None else False,
                    "stream_enabled": bool(settings_data[9]) if settings_data[9] is not None else False
                }
            else:
                # Return validated default settings
                response_data["settings"] = {
                    "theme": "light",
                    "language": "fa",
                    "flashSettings": "{}",
                    "device_mode": "desktop",
                    "servo1": 90,
                    "servo2": 90,
                    "photoQuality": 80,
                    "smart_motion": False,
                    "smart_tracking": False,
                    "stream_enabled": False
                }
            
            logger.info(f"User settings retrieved successfully for {user.get('sub')}")
            return response_data
            
        finally:
            await close_db_connection(conn)
        
    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        logger.error(f"ERROR getting user settings: {e}")
        # Return a more graceful error response with fallback settings
        return {
            "status": "success",
            "user_role": "user",
            "username": user.get("sub"),
            "language": request.cookies.get('language', 'fa'),
            "settings": {
                "theme": "light",
                "language": "fa",
                "flashSettings": "{}",
                "device_mode": "desktop",
                "servo1": 90,
                "servo2": 90,
                "photoQuality": 80,
                "smart_motion": False,
                "smart_tracking": False,
                "stream_enabled": False
            }
        }

def alert_admin(message, critical=False):
    if critical:
        logger.critical(f"[ADMIN ALERT] {message}")
    else:
        logger.warning(f"[ADMIN ALERT] {message}")

# تابع جدید برای آزاد کردن قوی‌تر file handles
async def force_close_file_handles(filepath: str):
    """Try to force close any open file handles on Windows with multiple attempts"""
    if not sys.platform.startswith('win'):
        return
    
    # Multiple attempts to force file handle release
    for attempt in range(10):  # Increased attempts for better reliability
        try:
            # Try to open file in exclusive mode to check if it's locked
            with open(filepath, 'r+b') as f:
                # File is accessible, close it
                f.close()
                logger.info(f"Successfully accessed file handle on attempt {attempt + 1}")
                break
        except PermissionError:
            # File is locked, try alternative methods
            try:
                # Try to open in read-only mode
                with open(filepath, 'rb') as f:
                    f.close()
                logger.info(f"Successfully accessed file in read mode on attempt {attempt + 1}")
                break
            except Exception as e:
                logger.warning(f"File still locked on attempt {attempt + 1}: {e}")
                if attempt < 9:  # Not the last attempt
                    await asyncio.sleep(0.5)  # Increased delay
        except Exception as e:
            logger.warning(f"Unexpected error accessing file on attempt {attempt + 1}: {e}")
            if attempt < 9:
                await asyncio.sleep(0.5)
    
    # Final attempt with garbage collection and memory cleanup
    if sys.platform.startswith('win'):
        await asyncio.to_thread(gc.collect)
        await asyncio.sleep(1.0)  # Longer delay for final cleanup

# Global variable to track active file connections
active_file_connections = set()

# تابع جدید برای ثبت اتصالات فعال
def register_file_connection(filename: str):
    """Register that a file is being served"""
    active_file_connections.add(filename)

# تابع جدید برای حذف ثبت اتصالات
def unregister_file_connection(filename: str):
    """Unregister that a file is no longer being served"""
    active_file_connections.discard(filename)

# تابع جدید برای بررسی اتصالات HTTP
async def check_http_connections(filename: str):
    """Check if file is being served via HTTP and add small delay"""
    if filename in active_file_connections:
        logger.info(f"File {filename} is currently being served, waiting for connections to close...")
        # Wait longer if file is actively being served
        await asyncio.sleep(1.0)  # Increased delay
    else:
        # Small delay to allow HTTP connections to close
        await asyncio.sleep(0.2)  # Increased delay

# تابع جدید برای قطع اتصالات HTTP
async def force_close_http_connections(filename: str):
    """Force close all HTTP connections to a specific file"""
    if filename in active_file_connections:
        logger.info(f"Force closing HTTP connections for {filename}")
        # Remove from active connections
        active_file_connections.discard(filename)
        # Wait a bit more for connections to fully close
        await asyncio.sleep(0.5)  # Increased delay

# تابع جدید برای قطع فوری اتصالات HTTP
async def force_terminate_http_connections(filename: str):
    """Force terminate all HTTP connections to a specific file immediately"""
    if filename in active_file_connections:
        logger.info(f"Force terminating HTTP connections for {filename}")
        # Remove from active connections immediately
        active_file_connections.discard(filename)
        # Force garbage collection
        import gc
        gc.collect()
        # Wait for connections to fully close
        await asyncio.sleep(0.3)

@app.post("/delete_video/{filename}")
@robust_db_endpoint
async def delete_video_by_filename(filename: str, user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    request = DeleteVideoRequest(filename=filename)
    request.validate_filename()
    filepath = os.path.join(SECURITY_VIDEOS_DIR, request.filename)
    if not os.path.exists(filepath):
        raise HTTPException(status_code=404, detail="File not found")
    
    # Get file size to determine if it's a large file
    try:
        file_size = os.path.getsize(filepath)
        is_large_file = file_size > 100 * 1024 * 1024  # > 100MB
        is_very_large_file = file_size > 500 * 1024 * 1024  # > 500MB
        logger.info(f"Attempting to delete video {filename} (size: {file_size/1024/1024:.1f}MB, large: {is_large_file}, very_large: {is_very_large_file})")
    except Exception as e:
        logger.warning(f"Error getting file size for {filename}: {e}")
        is_large_file = False
        is_very_large_file = False
    
    # Retry mechanism for file deletion with optimized delays
    max_retries = 10 if is_very_large_file else (8 if is_large_file else 6)  # More retries for very large files
    base_delay = 1.0 if is_very_large_file else (0.5 if is_large_file else 0.3)  # Longer delays for very large files
    
    for attempt in range(max_retries):
        try:
            # Extra delay for very large files
            if is_very_large_file and attempt == 0:
                logger.info(f"Very large file detected ({file_size/1024/1024:.1f}MB), adding extra delay...")
                await asyncio.sleep(2.0)  # Extra 2 second delay for very large files
            
            # Force terminate HTTP connections immediately
            await force_terminate_http_connections(filename)
            
            # Force close HTTP connections first
            await force_close_http_connections(filename)
            
            # Check for HTTP connections and allow them to close
            await check_http_connections(filename)
            
            # Try to force close file handles before deletion
            await force_close_file_handles(filepath)
            
            # Try to delete the file
            await asyncio.to_thread(os.remove, filepath)
            logger.info(f"Successfully deleted video {filename} (attempt {attempt + 1})")
            break  # Success, exit retry loop
        except PermissionError as e:
            if attempt < max_retries - 1:
                delay = base_delay * (attempt + 1)  # Linear backoff
                logger.warning(f"File {filename} is locked (size: {file_size/1024/1024:.1f}MB), retrying in {delay:.1f} seconds... (attempt {attempt + 1}/{max_retries})")
                
                # Try to force file release on Windows
                if sys.platform.startswith('win'):
                    try:
                        # Try to open file in write mode to check if it's locked
                        with open(filepath, 'r+b') as f:
                            pass  # Just check if we can open it
                    except Exception as e:
                        logger.debug(f"File {filename} is locked: {e}")
                        pass  # File is locked, continue with retry
                
                await asyncio.sleep(delay)
            else:
                logger.error(f"Failed to delete {filename} after {max_retries} attempts: {e}")
                raise HTTPException(status_code=503, detail=f"File is locked and cannot be deleted after {max_retries} attempts: {filename}")
        except OSError as e:
            if e.errno == errno.ENOENT:
                # File was already deleted
                logger.info(f"File {filename} was already deleted")
                break
            elif attempt < max_retries - 1:
                delay = base_delay * (attempt + 1)
                logger.warning(f"OS error deleting {filename}, retrying in {delay:.1f} seconds... (attempt {attempt + 1}/{max_retries}): {e}")
                await asyncio.sleep(delay)
            else:
                logger.error(f"OS error deleting {filename} after {max_retries} attempts: {e}")
                raise HTTPException(status_code=500, detail=f"OS error deleting file: {str(e)}")
        except Exception as e:
            logger.error(f"Unexpected error deleting {filename}: {e}")
            raise HTTPException(status_code=500, detail=f"Error deleting file: {str(e)}")
    
    # Delete from database
    conn = await get_db_connection()
    try:
        await conn.execute("DELETE FROM security_videos WHERE filename=?", (request.filename,))
        await conn.commit()
        logger.info(f"Removed {filename} from database")
    except Exception as e:
        logger.error(f"Error removing {filename} from database: {e}")
        # Don't fail the whole operation if DB deletion fails
    finally:
        await close_db_connection(conn)
    
    await insert_log(f"Video deleted: {request.filename}", "delete")
    
    # Notify clients
    await send_to_web_clients({"type": "video_deleted", "filename": request.filename})
    
    return {"status": "success", "message": f"Video {request.filename} deleted successfully"}

# --- Smart Features API Models ---

class SmartFeaturesCommand(BaseModel):
    motion: bool = False
    tracking: bool = False

# --- Smart Features Endpoints ---
@app.post("/set_smart_features")
async def set_smart_features(cmd: SmartFeaturesCommand, request: Request, user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    try:
        # First, ensure all required columns exist
        await migrate_user_settings_table()
        
        # Validate and sanitize smart features data
        validated_motion = bool(cmd.motion) if cmd.motion is not None else False
        validated_tracking = bool(cmd.tracking) if cmd.tracking is not None else False
        
        prev_motion = getattr(system_state, 'smart_motion_enabled', None)
        prev_tracking = getattr(system_state, 'object_tracking_enabled', None)
        logger.info(f"[HTTP] /set_smart_features from {request.client.host}: motion {prev_motion}->{validated_motion}, tracking {prev_tracking}->{validated_tracking}")
        
        # Update system state
        system_state.smart_motion_enabled = validated_motion
        system_state.object_tracking_enabled = validated_tracking
        
        # Save to database for user with improved error handling
        conn = await get_db_connection()
        try:
            try:
                # Use direct execute instead of async context manager
                await conn.execute(
                    'INSERT OR REPLACE INTO user_settings (username, ip, smart_motion, smart_tracking, updated_at) VALUES (?, ?, ?, ?, ?)',
                    (user.get("sub"), request.client.host, validated_motion, validated_tracking, get_jalali_now_str())
                )
                await conn.commit()
                
                logger.info(f"Smart features saved to database for user: {user.get('sub')}")
                
            except Exception as e:
                logger.warning(f"Error in smart features transaction, trying fallback: {e}")
                # Fallback: try to insert without problematic columns
                try:
                    await conn.execute(
                        'INSERT OR REPLACE INTO user_settings (username, ip, updated_at) VALUES (?, ?, ?)',
                        (user.get("sub"), request.client.host, get_jalali_now_str())
                    )
                    await conn.commit()
                    logger.info(f"Smart features saved with fallback for user: {user.get('sub')}")
                except Exception as e2:
                    logger.error(f"Fallback smart features save also failed: {e2}")
                    # Don't raise HTTPException, just log the error
                    
        finally:
            await close_db_connection(conn)
        
        log_msg = f"Smart features updated: motion={validated_motion}, tracking={validated_tracking}"
        logger.info(log_msg)
        await insert_log(log_msg, "command")
        
        # اطلاع‌رسانی به کلاینت‌ها (در صورت نیاز)
        await send_to_web_clients({
            "type": "smart_features",
            "motion": validated_motion,
            "tracking": validated_tracking
        })
        
        return {"status": "success", "message": "Smart features updated successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error in set_smart_features: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/get_smart_features")
async def get_smart_features(user=Depends(get_current_user)):
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    try:
        # First, ensure all required columns exist
        await migrate_user_settings_table()
        
        conn = await get_db_connection()
        try:
            # Get smart features from database for specific user with validation and error handling
            try:
                cursor = await conn.execute(
                    'SELECT smart_motion, smart_tracking FROM user_settings WHERE username = ? ORDER BY updated_at DESC LIMIT 1',
                    (user.get("sub"),)
                )
                row = await cursor.fetchone()
            except Exception as e:
                logger.warning(f"Error querying smart features, using fallback: {e}")
                row = None
            
            if row:
                # Validate and sanitize retrieved data
                motion = bool(row[0]) if row[0] is not None else False
                tracking = bool(row[1]) if row[1] is not None else False
            else:
                # Default values if no settings found
                motion = False
                tracking = False
            
            logger.info(f"Smart features retrieved for {user.get('sub')}: motion={motion}, tracking={tracking}")
            return {
                "status": "success",
                "motion": motion,
                "tracking": tracking
            }
        finally:
            await close_db_connection(conn)
    except Exception as e:
        logger.error(f"ERROR getting smart features from database: {e}")
        # Fallback to system state with validation
        fallback_motion = bool(getattr(system_state, 'smart_motion_enabled', False))
        fallback_tracking = bool(getattr(system_state, 'object_tracking_enabled', False))
        
        logger.info(f"Using fallback smart features for {user.get('sub')}: motion={fallback_motion}, tracking={fallback_tracking}")
        return {
            "status": "success",
            "motion": fallback_motion,
            "tracking": fallback_tracking
        }

# --- 5. On server startup, load device_mode from user_settings if available ---
# (Add after DB init, e.g. after init_db())
async def load_device_mode_from_db():
    conn = await get_db_connection()
    try:
        cursor = await conn.execute('SELECT device_mode FROM user_settings ORDER BY updated_at DESC LIMIT 1')
        row = await cursor.fetchone()
        if row and row[0] in DEVICE_RESOLUTIONS:
            system_state.device_mode = row[0]
            system_state.resolution = DEVICE_RESOLUTIONS[row[0]]
    finally:
        await close_db_connection(conn)
# In main or startup event:
# await load_device_mode_from_db()

# --- Migration: Ensure all required tables exist, including camera_logs ---
async def migrate_all_tables():
    """Migrate database tables with better error handling"""
    conn = await get_db_connection()
    try:
        # user_settings table
        await conn.execute('''
            CREATE TABLE IF NOT EXISTS user_settings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                ip TEXT NOT NULL,
                theme TEXT,
                language TEXT,
                flash_settings TEXT,
                servo1 INTEGER,
                servo2 INTEGER,
                device_mode TEXT DEFAULT 'desktop',
                photo_quality INTEGER DEFAULT 80,
                smart_motion BOOLEAN DEFAULT FALSE,
                smart_tracking BOOLEAN DEFAULT FALSE,
                updated_at TEXT DEFAULT ''
            )
        ''')
        # device_mode_commands table
        await conn.execute('''
            CREATE TABLE IF NOT EXISTS device_mode_commands (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                device_mode TEXT NOT NULL,
                created_at TEXT DEFAULT '',
                processed INTEGER DEFAULT 0
            )
        ''')
        # camera_logs table
        await conn.execute('''
            CREATE TABLE IF NOT EXISTS camera_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                message TEXT NOT NULL,
                log_type TEXT NOT NULL,
                created_at TEXT DEFAULT '',
                source TEXT DEFAULT 'server',
                pico_timestamp TEXT DEFAULT NULL
            )
        ''')
        
        # password_recovery table
        await conn.execute('''
            CREATE TABLE IF NOT EXISTS password_recovery (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                phone TEXT NOT NULL,
                token TEXT UNIQUE NOT NULL,
                expires_at TEXT NOT NULL,
                used BOOLEAN DEFAULT 0,
                created_at TEXT NOT NULL
            )
        ''')
        
        # Migrate existing users table to add new columns with better error handling
        try:
            # Check if email column exists - handle UNIQUE constraint properly
            await conn.execute('ALTER TABLE users ADD COLUMN email TEXT')
            logger.info("Added email column to users table")
            # Add UNIQUE constraint separately if needed
            try:
                await conn.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email) WHERE email IS NOT NULL')
                logger.info("Added unique index for email column")
            except Exception as idx_e:
                logger.debug(f"Email unique index already exists: {idx_e}")
        except Exception as e:
            if "duplicate column name" in str(e):
                logger.debug("Email column already exists (non-critical)")
            else:
                logger.warning(f"Could not add email column: {e}")
        
        # Add username unique constraint if not exists
        try:
            await conn.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users(username)')
            logger.info("Added unique index for username column")
        except Exception as idx_e:
            logger.debug(f"Username unique index already exists: {idx_e}")
        
        # Force create username unique constraint
        try:
            await conn.execute('CREATE UNIQUE INDEX idx_users_username_unique ON users(username)')
            logger.info("Added unique constraint for username column")
        except Exception as idx_e:
            if "UNIQUE constraint failed" in str(idx_e) or "already exists" in str(idx_e):
                logger.debug("Username unique constraint already exists")
            else:
                logger.warning(f"Could not add username unique constraint: {idx_e}")
        
        # Alternative approach: Drop and recreate if needed
        try:
            await conn.execute('DROP INDEX IF EXISTS idx_users_username_unique')
            await conn.execute('CREATE UNIQUE INDEX idx_users_username_unique ON users(username)')
            logger.info("Recreated unique constraint for username column")
        except Exception as idx_e:
            logger.debug(f"Could not recreate username unique constraint: {idx_e}")
                
        try:
            # Check if two_fa_enabled column exists
            await conn.execute('ALTER TABLE users ADD COLUMN two_fa_enabled BOOLEAN DEFAULT 0')
            logger.info("Added two_fa_enabled column to users table")
        except Exception as e:
            if "duplicate column name" in str(e):
                logger.debug("two_fa_enabled column already exists (non-critical)")
            else:
                logger.warning(f"Could not add two_fa_enabled column: {e}")
                
        try:
            # Check if two_fa_secret column exists
            await conn.execute('ALTER TABLE users ADD COLUMN two_fa_secret TEXT')
            logger.info("Added two_fa_secret column to users table")
        except Exception as e:
            if "duplicate column name" in str(e):
                logger.debug("two_fa_secret column already exists (non-critical)")
            else:
                logger.warning(f"Could not add two_fa_secret column: {e}")
        
        await conn.commit()
    finally:
        await close_db_connection(conn)

# --- Use FastAPI lifespan event for startup migration ---
# Removed duplicate lifespan function - using the main one above



# --- Common photo insertion function ---
async def insert_photo_to_db(filename: str, filepath: str, quality: int = 80, flash_used: bool = False, intensity: int = 50):
    """Common function to insert photo into database"""
    await execute_db_insert(
        "INSERT INTO manual_photos (filename, filepath, quality, flash_used, flash_intensity, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (filename, filepath, quality, flash_used, intensity, get_jalali_now_str())
    )

if os.environ.get("PYTEST_CURRENT_TEST"):
    import pytest, tempfile
    @pytest.fixture(autouse=True)
    def cleanup_system_state(monkeypatch):
        tmp_db = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        tmp_db.close()
        monkeypatch.setattr("server_fastapi.DB_FILE", tmp_db.name)
        global system_state
        yield
        asyncio.run(system_state.cleanup())
        system_state = SystemState()
        system_state.db_initialized = False
        try:
            os.remove(tmp_db.name)
        except Exception:
            pass

# --- Patch asyncio to suppress noisy WinError 10054 on Windows (ConnectionResetError) ---
if sys.platform.startswith('win'):
    # Only apply patch once
    if not hasattr(sys, '_asyncio_patch_applied'):
        import functools as _functools
        import asyncio.proactor_events as _proactor_events
        
        # Store original method
        orig_call_connection_lost = _proactor_events._ProactorBasePipeTransport._call_connection_lost
        
        def _patched_call_connection_lost(self, exc):
            try:
                if exc is not None and isinstance(exc, ConnectionResetError) and getattr(exc, 'winerror', None) == 10054:
                    # Suppress traceback for forcibly closed connection
                    logger.debug('Suppressed ConnectionResetError [WinError 10054] (forcibly closed by remote host)')
                    return
                return orig_call_connection_lost(self, exc)
            except Exception as e:
                # If patch fails, log and continue with original behavior
                logger.debug(f"Patch failed, using original behavior: {e}")
                return orig_call_connection_lost(self, exc)
        
        # Apply patch with error handling
        try:
            _proactor_events._ProactorBasePipeTransport._call_connection_lost = _functools.wraps(orig_call_connection_lost)(_patched_call_connection_lost)
            logger.info("Successfully applied Windows asyncio patch for ConnectionResetError suppression")
            sys._asyncio_patch_applied = True
        except Exception as e:
            logger.warning(f"Failed to apply Windows asyncio patch: {e}")

# --- Additional security patches ---
# Disable debug mode in production
if os.getenv("ENVIRONMENT", "development") == "production":
    import warnings
    warnings.filterwarnings("ignore", category=RuntimeWarning, module="asyncio")
    
    # Set asyncio debug to False to reduce noise
    try:
        loop = asyncio.get_running_loop()
        loop.set_debug(False)
    except RuntimeError:
        # No running loop, create one temporarily
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.set_debug(False)
        except Exception:
            pass  # Ignore if we can't set debug mode

# --- Additional asyncio error suppression for Windows ---
if sys.platform.startswith('win'):
    # Suppress asyncio error messages in console
    import warnings
    warnings.filterwarnings("ignore", category=RuntimeWarning, module="asyncio")
    
    # Set asyncio debug to False to reduce noise (modern approach)
    try:
        loop = asyncio.get_running_loop()
        loop.set_debug(False)
    except RuntimeError:
        # No running loop, create one temporarily
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.set_debug(False)
        except Exception:
            pass  # Ignore if we can't set debug mode

@app.get("/ws")
async def ws_http_guard():
    return PlainTextResponse("WebSocket endpoint. Use WebSocket protocol.", status_code=400)

@app.exception_handler(404)
async def not_found_handler(request: Request, exc: HTTPException):
    """Handle 404 errors by redirecting to login"""
    return RedirectResponse(url="/login", status_code=302)

async def send_to_web_clients(message):
    remove_clients = []
    async with system_state.web_clients_lock:
        # کپی از لیست برای جلوگیری از تغییر در حین iteration
        clients_to_send = system_state.web_clients.copy()
        
    # ارسال پیام خارج از lock برای جلوگیری از deadlock
    for client in clients_to_send:
        try:
            await client.send_text(json.dumps(message) if not isinstance(message, str) else message)
        except Exception as e:
            # Don't log normal closure errors
            if "1000" not in str(e) and "Rapid test" not in str(e):
                logger.warning(f"Failed to send to web client {client.client.host}: {e}")
            remove_clients.append(client)
    
    # حذف کلاینت‌های قطع شده
    if remove_clients:
        async with system_state.web_clients_lock:
            for client in remove_clients:
                if client in system_state.web_clients:
                    system_state.web_clients.remove(client)
                # حذف از active_clients با thread safety
                system_state.active_clients = [c for c in system_state.active_clients if not (hasattr(c, 'ws') and c.ws == client)]
                logger.info(f"Removed disconnected web client: {client.client.host}")
                # ثبت در error counts
                system_state.error_counts["websocket"] += 1

async def send_to_pico_client(message):
    async with system_state.pico_client_lock:
        client = system_state.pico_client
        if client:
            try:
                await client.send_text(json.dumps(message))
                # به‌روزرسانی وضعیت دستگاه
                system_state.device_status["pico"]["last_seen"] = datetime.now()
                logger.debug(f"Message sent to Pico: {message}")
            except Exception as e:
                # Don't log normal closure errors
                if "1000" not in str(e) and "Rapid test" not in str(e):
                    logger.warning(f"Failed to send to pico client {client.client.host}: {e}")
                system_state.pico_client = None
                system_state.device_status["pico"]["online"] = False
                system_state.device_status["pico"]["errors"].append({
                    "time": datetime.now().isoformat(),
                    "error": str(e)
                })
                system_state.active_clients = [c for c in system_state.active_clients if not (hasattr(c, 'ws') and c.ws == client)]
                logger.info(f"Removed disconnected pico client: {client.client.host}")
        else:
            logger.warning("Pico client not connected")
            system_state.device_status["pico"]["errors"].append({
                "time": datetime.now().isoformat(),
                "error": "Client not connected"
            })

async def send_to_esp32cam_client(message):
    async with system_state.esp32cam_client_lock:
        client = system_state.esp32cam_client
        if client:
            try:
                await client.send_text(json.dumps(message))
                # به‌روزرسانی وضعیت دستگاه
                system_state.device_status["esp32cam"]["last_seen"] = datetime.now()
                logger.debug(f"Message sent to ESP32CAM: {message}")
            except Exception as e:
                # Don't log normal closure errors
                if "1000" not in str(e) and "Rapid test" not in str(e):
                    logger.warning(f"Failed to send to esp32cam client {client.client.host}: {e}")
                system_state.esp32cam_client = None
                system_state.device_status["esp32cam"]["online"] = False
                system_state.device_status["esp32cam"]["errors"].append({
                    "time": datetime.now().isoformat(),
                    "error": str(e)
                })
                system_state.active_clients = [c for c in system_state.active_clients if not (hasattr(c, 'ws') and c.ws == client)]
                logger.info(f"Removed disconnected esp32cam client: {client.client.host}")
        else:
            logger.debug("ESP32CAM client not connected")
            # Only add error if it's been more than 5 minutes since last error
            last_error_time = system_state.device_status["esp32cam"]["errors"][-1]["time"] if system_state.device_status["esp32cam"]["errors"] else None
            if not last_error_time or (datetime.now() - datetime.fromisoformat(last_error_time)).total_seconds() > 300:
                system_state.device_status["esp32cam"]["errors"].append({
                    "time": datetime.now().isoformat(),
                    "error": "Client not connected"
                })

async def save_manual_photo_from_esp32cam(message):
    """ذخیره عکس دستی دریافتی از ESP32CAM"""
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"manual_photo_{timestamp}.jpg"
        filepath = os.path.join(GALLERY_DIR, filename)
        
        # ایجاد پوشه گالری
        await asyncio.to_thread(os.makedirs, GALLERY_DIR, exist_ok=True)
        
        # ذخیره در دیتابیس
        await insert_photo_to_db(filename, filepath, 80, False, 50)
        await insert_log(f"Manual photo saved from ESP32CAM: {filename}", "photo")
        
        # ارسال به فرانت‌اند
        await send_to_web_clients({
            "type": "photo_captured",
            "filename": filename,
            "url": f"/gallery/{filename}",
            "quality": 80,
            "flash_used": False,
            "intensity": 50,
            "timestamp": get_jalali_now_str()
        })
        
        logger.info(f"Manual photo saved successfully: {filename}")
        
    except Exception as e:
        logger.error(f"Error saving manual photo from ESP32CAM: {e}")
        await insert_log(f"Error saving manual photo: {e}", "error")

async def save_manual_photo_binary(frame_data):
    """ذخیره عکس دستی باینری دریافتی از ESP32CAM"""
    try:
        # اعتبارسنجی فرمت تصویر
        if not validate_image_format(frame_data):
            logger.error("Invalid image format for manual photo")
            return
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"manual_photo_{timestamp}.jpg"
        filepath = os.path.join(GALLERY_DIR, filename)
        
        # ایجاد پوشه گالری
        await asyncio.to_thread(os.makedirs, GALLERY_DIR, exist_ok=True)
        
        # پردازش و ذخیره عکس
        processed_photo = await preprocess_frame(frame_data)
        final_photo = await add_persian_text_overlay(processed_photo)
        
        # ذخیره فایل
        await asyncio.to_thread(lambda: open(filepath, 'wb').write(final_photo))
        
        # ذخیره در دیتابیس
        await insert_photo_to_db(filename, filepath, 80, False, 50)
        await insert_log(f"Manual photo saved from ESP32CAM: {filename}", "photo")
        
        # ارسال به فرانت‌اند
        await send_to_web_clients({
            "type": "photo_captured",
            "filename": filename,
            "url": f"/gallery/{filename}",
            "quality": 80,
            "flash_used": False,
            "intensity": 50,
            "timestamp": get_jalali_now_str()
        })
        
        logger.info(f"Manual photo saved successfully: {filename}")
        
    except Exception as e:
        logger.error(f"Error saving manual photo binary from ESP32CAM: {e}")
        await insert_log(f"Error saving manual photo binary: {e}", "error")

@app.get("/get_translations")
async def get_translations(lang: str = "fa"):
    return JSONResponse(translations.get(lang, translations["fa"]))

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "websocket_endpoint": "/ws/pico",
        "server_port": "6970"  # Fixed port for Pico compatibility
    }

@app.get("/ports")
async def get_dynamic_ports():
    """Get dynamic port information for all services - Public endpoint"""
    # This endpoint is public and doesn't require authentication
    return {
        "main_port": 3000,
        "pico_port": 3001,
        "esp32cam_port": 3002,
        "status": "active"
    }

@app.get("/esp32cam/status")
async def esp32cam_status():
    """ESP32CAM status endpoint"""
    return {
        "status": "ready" if system_state.device_status["esp32cam"]["online"] else "offline",
        "timestamp": datetime.now().isoformat(),
        "service": "ESP32CAM",
        "port": "8080",
        "online": system_state.device_status["esp32cam"]["online"],
        "last_seen": system_state.device_status["esp32cam"]["last_seen"].isoformat() if system_state.device_status["esp32cam"]["last_seen"] else None,
        "recent_errors": system_state.device_status["esp32cam"]["errors"][-5:]  # آخرین 5 خطا
    }

@app.get("/pico/status")
async def pico_status():
    """Pico status endpoint"""
    return {
        "status": "ready" if system_state.device_status["pico"]["online"] else "offline",
        "timestamp": datetime.now().isoformat(),
        "service": "Pico",
        "online": system_state.device_status["pico"]["online"],
        "last_seen": system_state.device_status["pico"]["last_seen"].isoformat() if system_state.device_status["pico"]["last_seen"] else None,
        "recent_errors": system_state.device_status["pico"]["errors"][-5:],  # آخرین 5 خطا
        "current_token": PICO_AUTH_TOKENS[0][:10] + "..." if PICO_AUTH_TOKENS else None
    }

@app.get("/tokens/{password}")
async def get_tokens(password: str):
    """Get current authentication tokens (for debugging) - requires password"""
    # Password for accessing tokens (you can change this)
    TOKEN_ACCESS_PASSWORD = "spy_servoo_secure_2024"
    
    if password != TOKEN_ACCESS_PASSWORD:
        logger.warning(f"Invalid token access attempt with password: {password[:5]}...")
        return {"status": "error", "message": "Invalid password"}
    
    try:
        logger.info("Token access granted with valid password")
        return {
            "pico_tokens": PICO_AUTH_TOKENS,
            "esp32cam_tokens": ESP32CAM_AUTH_TOKENS,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error getting tokens: {e}")
        return {"status": "error", "message": str(e)}

@app.get("/public/tokens")
async def get_public_tokens():
    """Get current authentication tokens for external devices - no authentication required"""
    try:
        logger.info("Public token access requested")
        return {
            "status": "success",
            "pico_tokens": PICO_AUTH_TOKENS,
            "esp32cam_tokens": ESP32CAM_AUTH_TOKENS,
            "timestamp": datetime.now().isoformat(),
            "message": "Use these tokens in the Authorization header as 'Bearer <token>'"
        }
    except Exception as e:
        logger.error(f"Error getting public tokens: {e}")
        return {"status": "error", "message": str(e)}



@app.get("/devices/status")
async def all_devices_status():
    """All devices status endpoint"""
    return {
        "timestamp": datetime.now().isoformat(),
        "devices": system_state.device_status
    }

@app.get("/system/performance")
async def get_system_performance(user=Depends(get_current_user)):
    """دریافت اطلاعات عملکرد سیستم"""
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    try:
        await update_performance_metrics()
        current_time = time.time()
        frame_rate = 0
        if len(system_state.frame_processing_times) > 1:
            recent_times = system_state.frame_processing_times[-10:]
            avg_processing_time = sum(recent_times) / len(recent_times)
            frame_rate = 1.0 / avg_processing_time if avg_processing_time > 0 else 0
        return {
            "status": "success",
            "performance": {
                "frame_rate": min(frame_rate, VIDEO_FPS),
                "avg_latency": system_state.performance_metrics["avg_frame_latency"],
                "drop_rate": system_state.performance_metrics["frame_drop_rate"],
                "processing_overhead": system_state.performance_metrics["frame_processing_overhead"],
                "memory_usage": system_state.performance_metrics["memory_usage"],
                "cpu_usage": system_state.performance_metrics["cpu_usage"],
                "current_quality": system_state.current_quality,
                "adaptive_quality": system_state.adaptive_quality,
                "realtime_enabled": system_state.realtime_enabled
            },
            "frame_stats": {
                "total_processed": system_state.frame_count,
                "dropped": system_state.frame_drop_count,
                "skipped": system_state.frame_skip_count,
                "invalid": system_state.invalid_frame_count,
                "buffer_size": len(system_state.frame_buffer),
                "cache_size": len(system_state.frame_cache)
            },
            "system_info": {
                "uptime": current_time - system_state.last_backup_time,
                "last_performance_update": system_state.last_performance_update,
                "processing_enabled": system_state.processing_enabled,
                "device_mode": system_state.device_mode,
                "resolution": system_state.resolution
            }
        }
    except Exception as e:
        logger.exception("Error getting system performance")
        raise HTTPException(status_code=500, detail="Error getting system performance")

# User Management Endpoints
@app.post("/api/users/create")
async def create_user(user: User, request: Request, current_user=Depends(get_current_user)):
    if not current_user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    # Check if current user is admin
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    
    try:
        conn = await get_db_connection()
        
        # Check if username already exists
        existing_user = await conn.execute('SELECT COUNT(*) FROM users WHERE username = ?', (user.username,))
        if (await existing_user.fetchone())[0] > 0:
            raise HTTPException(status_code=400, detail="Username already exists")
        
        # Hash password and create user
        password_hash = hash_password(user.password)
        await conn.execute('''
            INSERT INTO users (username, password_hash, role, is_active, created_at)
            VALUES (?, ?, ?, ?, ?)
        ''', (user.username, password_hash, user.role, user.is_active, get_jalali_now_str()))
        
        await conn.commit()
        await close_db_connection(conn)
        
        await insert_log(f"User '{user.username}' created by admin '{current_user.get('sub')}'", "auth")
        
        return {"status": "success", "message": f"User '{user.username}' created successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating user: {e}")
        raise HTTPException(status_code=500, detail="Error creating user")

@app.get("/api/users")
async def get_users(current_user=Depends(get_current_user)):
    if not current_user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    # Check if current user is admin
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    
    try:
        conn = await get_db_connection()
        users_query = await conn.execute('''
            SELECT username, role, is_active, created_at 
            FROM users 
            ORDER BY created_at DESC
        ''')
        users = await users_query.fetchall()
        await close_db_connection(conn)
        
        return {
            "status": "success",
            "users": [
                {
                    "username": user[0],
                    "role": user[1],
                    "is_active": bool(user[2]),
                    "created_at": user[3]
                }
                for user in users
            ]
        }
        
    except Exception as e:
        logger.error(f"Error getting users: {e}")
        raise HTTPException(status_code=500, detail="Error getting users")

@app.post("/api/users/{username}/toggle")
async def toggle_user_status(username: str, current_user=Depends(get_current_user)):
    if not current_user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    # Check if current user is admin
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    
    try:
        conn = await get_db_connection()
        
        # Get current status
        status_query = await conn.execute('SELECT is_active FROM users WHERE username = ?', (username,))
        user_status = await status_query.fetchone()
        
        if not user_status:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Toggle status
        new_status = not user_status[0]
        await conn.execute('UPDATE users SET is_active = ? WHERE username = ?', (new_status, username))
        await conn.commit()
        await close_db_connection(conn)
        
        action = "activated" if new_status else "deactivated"
        await insert_log(f"User '{username}' {action} by admin '{current_user.get('sub')}'", "auth")
        
        return {"status": "success", "message": f"User '{username}' {action} successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error toggling user status: {e}")
        raise HTTPException(status_code=500, detail="Error updating user status")

@app.websocket("/ws/esp32cam")
async def esp32cam_websocket_endpoint(websocket: WebSocket):
    # WebSocket authentication for ESP32CAM microcontroller
    logger.info(f"[WebSocket] ESP32CAM connection attempt from {websocket.client.host}")
    
    # Authenticate the connection
    if not await authenticate_websocket(websocket, "esp32cam"):
        return
    
    logger.info(f"[WebSocket] ESP32CAM authenticated and connected from {websocket.client.host}")
    
    # ثبت اتصال ESP32CAM
    async with system_state.esp32cam_client_lock:
        system_state.esp32cam_client = websocket
        system_state.device_status["esp32cam"]["online"] = True
        system_state.device_status["esp32cam"]["last_seen"] = datetime.now()
        system_state.active_clients.append(ActiveClient(websocket, datetime.now(), "ESP32CAM"))
        logger.info(f"[DEBUG] ESP32CAM status updated: online=True, last_seen={system_state.device_status['esp32cam']['last_seen']}")
    
    # Send connection success message
    try:
        await websocket.send_text(json.dumps({"type": "connection_ack", "status": "success", "message": "ESP32CAM connected successfully"}))
    except Exception as e:
        logger.warning(f"[WebSocket] Could not send connection success message: {e}")
    
    try:
        while True:
            try:
                # بررسی وضعیت اتصال قبل از دریافت
                if websocket.client_state.value == 3:  # WebSocketState.DISCONNECTED
                    logger.info(f"[WebSocket] ESP32CAM connection already disconnected")
                    break
                
                # دریافت داده (متن یا باینری) - کاهش timeout برای جلوگیری از keepalive timeout
                message = await asyncio.wait_for(websocket.receive(), timeout=60)
                
                if message["type"] == "websocket.receive":
                    if "text" in message:
                        # پیام متنی
                        data = message["text"]
                        logger.info(f"[WebSocket] ESP32CAM text message: {data}")
                        
                        # پردازش پیام‌های متنی
                        try:
                            json_message = json.loads(data)
                            if json_message.get("type") == "photo_sent":
                                logger.info(f"[WebSocket] Manual photo received from ESP32CAM: {json_message.get('size', 0)} bytes")
                                # ذخیره عکس در گالری
                                await save_manual_photo_from_esp32cam(json_message)
                            elif json_message.get("type") == "photo_error":
                                logger.error(f"[WebSocket] ESP32CAM photo error: {json_message.get('message', 'Unknown error')}")
                                # ثبت خطا در وضعیت دستگاه
                                system_state.device_status["esp32cam"]["errors"].append({
                                    "time": datetime.now().isoformat(),
                                    "error": f"Photo error: {json_message.get('message', 'Unknown error')}"
                                })
                            elif json_message.get("type") == "log":
                                logger.info(f"[ESP32CAM] {json_message.get('message', '')}")
                                # ثبت لاگ در دیتابیس
                                try:
                                    await insert_log(json_message.get('message', ''), json_message.get('level', 'info'), "esp32cam")
                                except Exception as e:
                                    logger.error(f"Error inserting ESP32CAM log: {e}")
                                    system_state.error_counts["database"] += 1
                            elif json_message.get("type") == "system_error":
                                logger.error(f"[ESP32CAM] System error: {json_message.get('message', '')}")
                                system_state.device_status["esp32cam"]["errors"].append({
                                    "time": datetime.now().isoformat(),
                                    "error": f"System error: {json_message.get('message', '')}"
                                })
                        except json.JSONDecodeError:
                            logger.warning(f"[WebSocket] Invalid JSON from ESP32CAM: {data}")
                    
                    elif "bytes" in message:
                        # فریم باینری
                        frame_data = message["bytes"]
                        logger.info(f"[WebSocket] ESP32CAM binary frame received: {len(frame_data)} bytes")
                        
                        # به‌روزرسانی وضعیت دستگاه
                        system_state.device_status["esp32cam"]["last_seen"] = datetime.now()
                        
                        # پردازش فریم
                        if len(frame_data) > 0:
                            try:
                                # اعتبارسنجی فرمت تصویر
                                if not validate_image_format(frame_data):
                                    logger.warning(f"[WebSocket] Invalid frame format from ESP32CAM")
                                    continue
                                
                                # بررسی اینکه آیا این فریم عکس دستی است یا فریم معمولی
                                # (بر اساس اندازه یا سایر معیارها)
                                is_manual_photo = len(frame_data) > 50000  # فریم‌های بزرگتر احتمالاً عکس دستی هستند
                                
                                if is_manual_photo:
                                    # ذخیره عکس دستی
                                    logger.info(f"[WebSocket] Manual photo binary received: {len(frame_data)} bytes")
                                    await save_manual_photo_binary(frame_data)
                                else:
                                    # پردازش فریم معمولی
                                    processed_frame = await preprocess_frame(frame_data)
                                    final_frame = await add_persian_text_overlay(processed_frame)
                                    
                                    # ذخیره در سیستم
                                    async with system_state.frame_lock:
                                        system_state.latest_frame = final_frame
                                        system_state.frame_count += 1
                                    
                                    # اضافه به buffer
                                    async with system_state.frame_buffer_lock:
                                        if len(system_state.frame_buffer) >= FRAME_BUFFER_SIZE:
                                            system_state.frame_buffer = system_state.frame_buffer[-FRAME_BUFFER_SIZE//2:]
                                        system_state.frame_buffer.append((final_frame, datetime.now()))
                                    
                                    # ارسال به فرانت‌اند با بهینه‌سازی
                                    try:
                                        await send_frame_to_clients(final_frame)
                                    except Exception as e:
                                        logger.error(f"Error sending frame to clients: {e}")
                                        system_state.error_counts["frame_processing"] += 1
                                    
                                    logger.debug(f"[WebSocket] Frame processed and sent to clients: {len(final_frame)} bytes")
                                
                            except Exception as e:
                                logger.error(f"[WebSocket] Error processing ESP32CAM frame: {e}")
                                system_state.device_status["esp32cam"]["errors"].append({
                                    "time": datetime.now().isoformat(),
                                    "error": f"Frame processing error: {str(e)}"
                                })
                    
            except asyncio.TimeoutError:
                logger.debug(f"[WebSocket] ESP32CAM timeout, sending ping")
                try:
                    await websocket.send_text(json.dumps({"type": "ping"}))
                except Exception as e:
                    if "1000" not in str(e) and "disconnect" not in str(e).lower():
                        logger.warning(f"[WebSocket] ESP32CAM ping failed: {e}")
                    break
                continue
    except WebSocketDisconnect as e:
        logger.info(f"[WebSocket] ESP32CAM disconnected cleanly: code={e.code}, reason={e.reason}")
    except ConnectionResetError as e:
        logger.info(f"[WebSocket] ESP32CAM connection reset: {e}")
    except Exception as e:
        # Don't log normal closure errors
        if "1000" not in str(e) and "Rapid test" not in str(e) and "disconnect" not in str(e).lower():
            logger.error(f"[WebSocket] ESP32CAM error: {e}")
        system_state.error_counts["websocket"] += 1
        system_state.device_status["esp32cam"]["errors"].append({
            "time": datetime.now().isoformat(),
            "error": str(e)
        })
    finally:
        # حذف اتصال ESP32CAM
        async with system_state.esp32cam_client_lock:
            system_state.esp32cam_client = None
            system_state.device_status["esp32cam"]["online"] = False
            system_state.device_status["esp32cam"]["last_seen"] = datetime.now()
            system_state.active_clients = [c for c in system_state.active_clients if not (hasattr(c, 'ws') and c.ws == websocket)]
        logger.info(f"[WebSocket] ESP32CAM connection closed")

# Add WebSocket authentication middleware
async def authenticate_websocket(websocket: WebSocket, device_type: str = None):
    """Common WebSocket authentication function"""
    try:
        # Check for JWT token in headers
        auth_header = websocket.headers.get("authorization", "")
        
        # For testing, allow connections without auth for localhost
        if "127.0.0.1" in websocket.client.host or "localhost" in websocket.client.host:
            await websocket.accept()
            return True
        
        if not auth_header.startswith("Bearer "):
            logger.warning(f"Missing authorization header from {websocket.client.host}")
            await websocket.close(code=4001, reason="Missing authorization")
            return False
        
        token = auth_header.replace("Bearer ", "")
        
        # Special handling for Pico authentication
        if device_type == "pico":
            # For Pico, check against PICO_AUTH_TOKENS (simple string comparison)
            if token in PICO_AUTH_TOKENS:
                await websocket.accept()
                logger.info(f"Pico authenticated successfully from {websocket.client.host}")
                return True
            else:
                logger.warning(f"Invalid Pico token from {websocket.client.host}: {token[:10]}...")
                await websocket.close(code=4001, reason="Invalid Pico token")
                return False
        elif device_type == "esp32cam":
            # For ESP32CAM, check against ESP32CAM_AUTH_TOKENS
            if token in ESP32CAM_AUTH_TOKENS:
                await websocket.accept()
                logger.info(f"ESP32CAM authenticated successfully from {websocket.client.host}")
                return True
            else:
                logger.warning(f"Invalid ESP32CAM token from {websocket.client.host}: {token[:10]}...")
                await websocket.close(code=4001, reason="Invalid ESP32CAM token")
                return False
        else:
            # For other devices, use JWT verification
            if not verify_token(token):
                logger.warning(f"Invalid JWT token from {websocket.client.host}")
                await websocket.close(code=4001, reason="Invalid token")
                return False
        
        await websocket.accept()
        return True
    except Exception as e:
        logger.error(f"WebSocket authentication error from {websocket.client.host}: {e}")
        await websocket.close(code=4001, reason="Authentication error")
        return False


if __name__ == "__main__":
    import uvicorn, threading
    from config.jalali_log_config import LOGGING_CONFIG
    
    # Prevent multiple server instances (Windows-compatible)
    import tempfile
    import os
    import signal
    import psutil
    
    def kill_existing_server():
        """Kill existing server instance if running"""
        lock_file_path = os.path.join(tempfile.gettempdir(), "spy_servoo_server.lock")
        
        if os.path.exists(lock_file_path):
            try:
                with open(lock_file_path, 'r') as f:
                    pid = f.read().strip()
                
                if pid and pid.isdigit():
                    pid = int(pid)
                    
                    # Check if process exists
                    try:
                        process = psutil.Process(pid)
                        if process.is_running():
                            print(f"🔄 Found existing server instance (PID: {pid}), terminating...")
                            
                            # Try graceful termination first
                            try:
                                process.terminate()
                                process.wait(timeout=3)  # Reduced timeout
                                print(f"✅ Server instance terminated gracefully")
                            except psutil.TimeoutExpired:
                                print(f"⚠️ Graceful termination failed, force killing...")
                                process.kill()
                                process.wait(timeout=2)  # Reduced timeout
                                print(f"✅ Server instance force killed")
                            
                            # Remove lock file
                            try:
                                os.remove(lock_file_path)
                                print(f"🗑️ Lock file removed")
                            except:
                                pass
                            
                            # Wait a moment for cleanup
                            import time
                            time.sleep(0.5)  # Reduced wait time
                            
                        else:
                            print(f"🗑️ Removing stale lock file (process {pid} not running)")
                            os.remove(lock_file_path)
                            
                    except psutil.NoSuchProcess:
                        print(f"🗑️ Removing stale lock file (process {pid} not found)")
                        os.remove(lock_file_path)
                    except Exception as e:
                        print(f"⚠️ Error checking process {pid}: {e}")
                        # Try to remove lock file anyway
                        try:
                            os.remove(lock_file_path)
                        except:
                            pass
                            
            except Exception as e:
                print(f"⚠️ Error reading lock file: {e}")
                # Try to remove lock file anyway
                try:
                    os.remove(lock_file_path)
                except:
                    pass
    
    # Kill existing server before starting
    kill_existing_server()
    
    # Create a lock file to prevent multiple instances
    lock_file_path = os.path.join(tempfile.gettempdir(), "spy_servoo_server.lock")
    try:
        # Create lock file
        with open(lock_file_path, 'w') as f:
            f.write(str(os.getpid()))
        print(f"🔒 Lock file created (PID: {os.getpid()})")
    except Exception as e:
        print(f"⚠️ Could not create lock file: {e}")
        # Continue anyway

    # یک PortManager مرکزی با بازه بزرگتر و refresh interval طولانی‌تر
    port_manager = DynamicPortManager(3000, 9000, refresh_interval=60, enable_background_logging=False)
    reserved_ports = set()

    def pick_unique_port():
        # استفاده از پورت‌های ثابت و ترتیبی با بررسی دقیق‌تر
        # Skip port 3001 as it's commonly used by other services
        static_ports = [3000, 3001, 3002, 3003, 3004, 3005, 3006, 3007, 3008, 3009, 3010, 3011, 3012, 3013, 3014, 3015, 3016, 3017, 3018, 3019, 3020]
        
        for port in static_ports:
            if port not in reserved_ports:
                # تست دقیق‌تر پورت
                try:
                    import socket
                    test_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    test_sock.settimeout(2)  # Reduced timeout for faster checking
                    test_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                    # SO_REUSEPORT is not available on Windows
                    try:
                        test_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
                    except AttributeError:
                        pass  # Ignore on Windows
                    test_sock.bind(("0.0.0.0", port))
                    test_sock.listen(1)
                    test_sock.close()
                    
                    # Double-check port is actually free
                    import time
                    time.sleep(0.05)  # Reduced delay for faster startup
                    
                    reserved_ports.add(port)
                    print(f"[PORT MANAGER] ✅ Reserved port {port}")
                    return port
                except OSError as e:
                    print(f"[PORT MANAGER] ❌ Port {port} is already in use (error: {e}), trying next...")
                    continue
                except Exception as e:
                    print(f"[PORT MANAGER] ⚠️ Unexpected error testing port {port}: {e}")
                    continue
        
        # اگر هیچ پورتی پیدا نشد، از dynamic port manager استفاده کن
        try:
            dynamic_port = port_manager.pick_port()
            reserved_ports.add(dynamic_port)
            print(f"[PORT MANAGER] 🔄 Using dynamic port {dynamic_port}")
            return dynamic_port
        except Exception as e:
            print(f"[PORT MANAGER] ❌ Dynamic port allocation failed: {e}")
            raise RuntimeError("No available ports found")

    # پورت‌ها را قبل از اجرای threadها رزرو کن
    print("[PORT MANAGER] Starting port reservation...")
    MAIN_PORT = pick_unique_port()
    print(f"[PORT MANAGER] Main port reserved: {MAIN_PORT}")
    
    PICO_PORT = pick_unique_port()
    print(f"[PORT MANAGER] Pico port reserved: {PICO_PORT}")
    
    ESP32CAM_PORT = pick_unique_port()
    print(f"[PORT MANAGER] ESP32CAM port reserved: {ESP32CAM_PORT}")
    
    # Ensure all ports are different
    if MAIN_PORT == PICO_PORT or MAIN_PORT == ESP32CAM_PORT or PICO_PORT == ESP32CAM_PORT:
        print("[PORT MANAGER] ⚠️ Port conflict detected, using single server mode")
        PICO_PORT = MAIN_PORT
        ESP32CAM_PORT = MAIN_PORT
    
    print(f"[PORT MANAGER] All ports reserved successfully!")
    print(f"  - Main: {MAIN_PORT}")
    print(f"  - Pico: {PICO_PORT}")
    print(f"  - ESP32CAM: {ESP32CAM_PORT}")

    DYNAMIC_PORTS = {
        "main": MAIN_PORT,
        "pico": PICO_PORT,
        "esp32cam": ESP32CAM_PORT
    }

    def run_server_on_port(port, service_name):
        try:
            print(f"[{service_name}] 🚀 Starting server on port {port}")
            
            # Create a separate app instance for each server to avoid conflicts
            if service_name == "MAIN SERVER":
                # Main server gets full functionality
                config = uvicorn.Config(
                    app,
                    host="0.0.0.0",
                    port=port,
                    log_level="info",
                    log_config=LOGGING_CONFIG,
                    access_log=True,
                    loop="asyncio"
                )
            else:
                # Secondary servers get minimal configuration
                config = uvicorn.Config(
                    app,
                    host="0.0.0.0",
                    port=port,
                    log_level="error",  # Minimal logging for secondary servers
                    access_log=False,
                    loop="asyncio",
                    lifespan="off"  # Disable lifespan for secondary servers
                )
            
            server = uvicorn.Server(config)
            server.run()
            
        except Exception as e:
            print(f"[{service_name}] ❌ Error starting server on port {port}: {e}")
            # Retry once with different configuration
            try:
                import time
                time.sleep(3)  # Longer delay before retry
                print(f"[{service_name}] 🔄 Retrying server start on port {port}")
                
                # Simplified config for retry
                config = uvicorn.Config(
                    app,
                    host="0.0.0.0",
                    port=port,
                    log_level="error",
                    access_log=False,
                    loop="asyncio",
                    lifespan="off"
                )
                server = uvicorn.Server(config)
                server.run()
                
            except Exception as retry_e:
                print(f"[{service_name}] ❌ Retry failed on port {port}: {retry_e}")
                # Don't exit, just log the error

    # Use single server with multiple endpoints for better compatibility
    print(f"[SINGLE SERVER] Starting unified server on port {MAIN_PORT}")
    print(f"[SINGLE SERVER] All services will be available on:")
    print(f"  - Main website: http://0.0.0.0:{MAIN_PORT}")
    print(f"  - Pico WebSocket: ws://0.0.0.0:{MAIN_PORT}/ws/pico")
    print(f"  - ESP32CAM: ws://0.0.0.0:{MAIN_PORT}/ws/esp32cam")
    
    # Start single server
    try:
        config = uvicorn.Config(
            app,
            host="0.0.0.0",
            port=MAIN_PORT,
            log_level="info",
            log_config=LOGGING_CONFIG,
            access_log=False,  # Disable access logs to reduce noise
            loop="asyncio"
        )
        server = uvicorn.Server(config)
        server.run()
    except KeyboardInterrupt:
        print("\n[SINGLE SERVER] Shutting down server...")
        port_manager.stop()
        # Clean up lock file
        try:
            if os.path.exists(lock_file_path):
                os.remove(lock_file_path)
        except Exception:
            pass
        # Graceful shutdown without exit()
        pass
    except Exception as e:
        print(f"[SINGLE SERVER] Error: {e}")
        port_manager.stop()
        # Clean up lock file
        try:
            if os.path.exists(lock_file_path):
                os.remove(lock_file_path)
        except Exception:
            pass
        # Graceful shutdown without exit()
        pass



