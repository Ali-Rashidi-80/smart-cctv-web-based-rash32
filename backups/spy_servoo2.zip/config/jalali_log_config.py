# JalaliFormatter is defined in utils.jalali_formatter

LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "jalali": {
            "()": "utils.jalali_formatter.JalaliFormatter",
            "fmt": "%(asctime)s - %(levelname)s - %(message)s\n"
        }
    },
    "handlers": {
        "default": {
            "formatter": "jalali",
            "class": "logging.StreamHandler",
            "stream": "ext://sys.stdout",
        },
    },
    "loggers": {
        "": {"handlers": ["default"], "level": "INFO"},
        "uvicorn": {"handlers": ["default"], "level": "WARNING", "propagate": False},  # Reduce uvicorn noise
        "uvicorn.error": {"handlers": ["default"], "level": "WARNING", "propagate": False},  # Only show warnings and errors
        "uvicorn.access": {"handlers": ["default"], "level": "ERROR", "propagate": False},  # Only show errors
        "fastapi": {"handlers": ["default"], "level": "WARNING", "propagate": False},  # Reduce FastAPI noise
        "app": {"handlers": ["default"], "level": "INFO", "propagate": False},
        "db": {"handlers": ["default"], "level": "INFO", "propagate": False},
    }
} 