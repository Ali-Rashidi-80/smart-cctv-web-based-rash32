class SmartCameraSystem {
    constructor() {
        this.websocket = null;
        this.isStreaming = false;
        this.deviceMode = 'desktop';
        this.currentPage = 0;
        this.currentVideoPage = 0;
        this.isLoading = false;
        this.retryCount = 0;
        this.maxRetries = 5;
        this.retryDelay = 2000;
        this.language = localStorage.getItem('language') || 'fa';
        this.systemStatus = {
            websocket: 'disconnected',
            server: 'offline',
            camera: 'offline',
            pico: 'offline'
        };
        this.resolution = { desktop: { width: 1072, height: 603 }, mobile: { width: 536, height: 301 } };
        this.connectionErrorShown = false; // جلوگیری از ارور تکراری
        this.activeErrorNotification = null; // قفل نمایش خطای اتصال
        this.translations = window.translations || {};
        this.objectUrls = [];
        this.cleanupCallbacks = [];
    }

    // Main entry: load settings from server/localStorage and apply to UI before anything else
    async init() {
        try {
            // Setup session management first
            this.setupSessionManagement();
            
            // Check for hard reload scenario
            this.handleHardReload();
            
            await this.loadAndApplySettings();
            this.setupEventListeners();
            await this.loadInitialData();
            this.startStatusUpdates();
            // بستن همه آکاردئون‌ها به جز اولی
            document.querySelectorAll('.accordion-collapse').forEach((el) => {
                if (el.id !== 'introCollapse') {
                    el.classList.remove('show');
                }
            });
            document.querySelectorAll('.accordion-button').forEach((btn) => {
                if (btn.getAttribute('data-bs-target') !== '#introCollapse') {
                    btn.classList.add('collapsed');
                    btn.setAttribute('aria-expanded', 'false');
                }
            });
            console.log('✅ سیستم دوربین هوشمند راه‌اندازی شد');
        } catch (error) {
            console.error('❌ خطا در راه‌اندازی سیستم:', error);
            this.showNotification(this.getTranslation('connectionError'), 'error');
        }
    }

    // Handle hard reload scenarios
    handleHardReload() {
        // Check if this is a hard reload (page refresh)
        const isHardReload = !window.performance.getEntriesByType('navigation')[0]?.type || 
                            window.performance.getEntriesByType('navigation')[0]?.type === 'reload';
        
        if (isHardReload) {
            // Set a flag to indicate this is a hard reload
            sessionStorage.setItem('hard_reload', 'true');
            
            // Check if user is admin by making a request to server
            this.checkUserRole();
        }
    }

    // Check user role and handle session accordingly
    async checkUserRole() {
        try {
            const response = await fetch('/get_user_settings', {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest' // Prevent hard reload detection
                }
            });
            
            if (response.ok) {
                const data = await response.json();
                if (data.user_role === 'admin') {
                    // Admin user - restore session
                    console.log('Admin user detected - restoring session');
                    sessionStorage.removeItem('hard_reload');
                    
                    // Store admin session info
                    localStorage.setItem('user_role', 'admin');
                    localStorage.setItem('username', data.username);
                    
                    // Restore admin session
                    this.restoreAdminSession();
                } else {
                    // Regular user - force logout on hard reload
                    console.log('Regular user hard reload detected - forcing logout');
                    this.forceLogout();
                }
            } else if (response.status === 401) {
                // Unauthorized - redirect to login
                window.location.href = '/login';
            }
        } catch (error) {
            console.error('Error checking user role:', error);
            // On error, redirect to login for safety
            window.location.href = '/login';
        }
    }

    // Restore admin session after hard reload
    restoreAdminSession() {
        // Set admin-specific flags
        sessionStorage.setItem('admin_session', 'true');
        
        // Show admin notification
        this.showNotification('Admin session restored successfully', 'success');
        
        console.log('Admin session restored after hard reload');
    }

    // Force logout for regular users on hard reload
    forceLogout() {
        // Clear all storage
        localStorage.clear();
        sessionStorage.clear();
        
        // Show notification
        this.showNotification('Session expired. Please login again.', 'warning');
        
        // Redirect to login
        window.location.href = '/login';
    }

    // Enhanced session management
    setupSessionManagement() {
        // Listen for storage events (for multi-tab scenarios)
        window.addEventListener('storage', (e) => {
            if (e.key === 'access_token' && !e.newValue) {
                // Token was cleared in another tab
                this.handleSessionExpired();
            }
        });

        // Listen for beforeunload to save session state
        window.addEventListener('beforeunload', () => {
            if (localStorage.getItem('user_role') === 'admin') {
                sessionStorage.setItem('admin_session_active', 'true');
            }
        });

        // Check for session expiration
        setInterval(() => {
            const expires = localStorage.getItem('token_expires');
            if (expires && Date.now() > parseInt(expires)) {
                this.handleSessionExpired();
            }
        }, 60000); // Check every minute
    }

    // Handle session expiration
    handleSessionExpired() {
        if (localStorage.getItem('user_role') === 'admin') {
            // Admin session expired - show warning but don't force logout
            this.showNotification('Admin session expired. Please refresh the page.', 'warning');
        } else {
            // Regular user session expired - force logout
            this.forceLogout();
        }
    }

    // Load settings from server (preferred) or localStorage, then apply to UI
    async loadAndApplySettings() {
        let settings = null;
        try {
            const res = await fetch('/get_user_settings');
            if (res.ok) {
                const data = await res.json();
                if (data.status === 'success' && data.settings) settings = data.settings;
                if (data.language) this.language = data.language;
            }
        } catch (error) {
            console.warn('Error loading settings from server:', error);
        }
        if (!settings) {
            settings = {
                theme: 'dark',
                language: localStorage.getItem('language') || 'fa',
                flashSettings: localStorage.getItem('flashSettings') || '{"intensity":50,"enabled":false}',
                servo1: localStorage.getItem('servo1') || 90,
                servo2: localStorage.getItem('servo2') || 90,
                device_mode: localStorage.getItem('device_mode') || 'desktop'
            };
        }
        // Always sync language to localStorage
        if (settings.language !== localStorage.getItem('language')) {
            localStorage.setItem('language', settings.language);
        }
        this.language = settings.language || 'fa';
        localStorage.setItem('theme', settings.theme);
        localStorage.setItem('flashSettings', settings.flashSettings);
        localStorage.setItem('servo1', settings.servo1);
        localStorage.setItem('servo2', settings.servo2);
        localStorage.setItem('device_mode', settings.device_mode);
        await this.updateLanguage(this.language);
        this.applySettingsToUI(settings);
    }

    // Apply all settings to UI elements
    applySettingsToUI(settings) {
        // Theme
        if (settings.theme === 'dark') document.body.classList.add('dark-mode');
        else document.body.classList.remove('dark-mode');
        const themeIcon = document.getElementById('themeIcon');
        if (themeIcon) {
            themeIcon.classList.remove('fa-moon', 'fa-sun', 'fa-regular', 'fa-solid', 'theme-sun-glow', 'theme-moon-stars', 'theme-rotate');
            Array.from(themeIcon.querySelectorAll('.star')).forEach(e => e.remove());
            if (settings.theme === 'dark') {
                themeIcon.classList.add('fa-sun', 'fa-solid', 'theme-sun-glow', 'theme-rotate');
                themeIcon.style.color = '#fff';
                themeIcon.style.textShadow = '0 0 8px #fff8';
            } else {
                themeIcon.classList.add('fa-moon', 'fa-solid', 'theme-moon-stars', 'theme-rotate');
                themeIcon.style.color = '#fff';
                themeIcon.style.textShadow = '0 0 8px #fff8';
                for (let i = 1; i <= 3; i++) {
                    const star = document.createElement('span');
                    star.className = `star star${i}`;
                    themeIcon.appendChild(star);
                }
            }
        }

        // Flash
        try {
            const flash = JSON.parse(settings.flashSettings);
            const flashIntensity = document.getElementById('flashIntensity');
            const flashToggle = document.getElementById('flashToggle');
            const flashControls = document.getElementById('flashControls');
            if (flashIntensity) flashIntensity.value = flash.intensity;
            if (flashToggle) flashToggle.checked = flash.enabled;
            if (flashControls) flashControls.classList.toggle('active', flash.enabled);
            this.updateFlashIntensityValue(flash.intensity);
        } catch (error) {
            console.warn('Error parsing flash settings:', error);
        }
        // Servo
        const s1 = document.getElementById('servoX');
        const s1Num = document.getElementById('servoXNumber');
        if (s1) s1.value = settings.servo1;
        if (s1Num) s1Num.value = settings.servo1;
        if (document.getElementById('servoXValue')) document.getElementById('servoXValue').textContent = `${settings.servo1}°`;
        const s2 = document.getElementById('servoY');
        const s2Num = document.getElementById('servoYNumber');
        if (s2) s2.value = settings.servo2;
        if (s2Num) s2Num.value = settings.servo2;
        if (document.getElementById('servoYValue')) document.getElementById('servoYValue').textContent = `${settings.servo2}°`;
        // Language icon animation
        const langIcon = document.querySelector('#languageToggle i');
        if (langIcon) {
            langIcon.classList.remove('lang-rotate-rtl', 'lang-rotate-ltr');
            if (settings.language === 'fa') langIcon.classList.add('lang-rotate-rtl');
            else langIcon.classList.add('lang-rotate-ltr');
        }
        // Device mode button UI update
        const btn = document.getElementById('deviceModeToggle');
        if (btn) {
            const mode = settings.device_mode || localStorage.getItem('device_mode') || 'desktop';
            btn.innerHTML = `<i class="fas fa-${mode === 'mobile' ? 'mobile-alt' : 'desktop'} me-2"></i> ${this.getTranslation(mode === 'mobile' ? 'mobileMode' : 'desktopMode')}`;
            btn.classList.toggle('btn-outline-secondary', mode === 'desktop');
            btn.classList.toggle('btn-outline-primary', mode === 'mobile');
        }
    }

    // Save all settings to server (and localStorage is always up to date)
    async saveUserSettingsToServer() {
        const settings = {
            ...this.userSettings,
            language: this.language
        };
            await fetch('/save_user_settings', {
                method: 'POST',
            body: JSON.stringify(settings),
            headers: {'Content-Type': 'application/json'}
            });
    }

    async loadSettings() {
        try {
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') {
                document.body.classList.add('dark-mode');
            } else {
                document.body.classList.remove('dark-mode');
            }
            // Theme icon
            const themeIcon = document.getElementById('themeIcon');
            if (themeIcon) {
                themeIcon.classList.remove('fa-moon', 'fa-sun', 'fa-regular', 'fa-solid', 'theme-sun-glow', 'theme-moon-stars', 'theme-rotate');
                Array.from(themeIcon.querySelectorAll('.star')).forEach(e => e.remove());
                if (savedTheme === 'dark') {
                    themeIcon.classList.add('fa-sun', 'fa-solid', 'theme-sun-glow', 'theme-rotate');
                    themeIcon.style.color = '#fff';
                    themeIcon.style.textShadow = '0 0 8px #fff8';
                } else {
                    themeIcon.classList.add('fa-moon', 'fa-solid', 'theme-moon-stars', 'theme-rotate');
                    themeIcon.style.color = '#fff';
                    themeIcon.style.textShadow = '0 0 8px #fff8';
                    for (let i = 1; i <= 3; i++) {
                        const star = document.createElement('span');
                        star.className = `star star${i}`;
                        themeIcon.appendChild(star);
                    }
                }
            }
            // Language icon
            const langIcon = document.querySelector('#languageToggle i');
            if (langIcon) {
                langIcon.classList.remove('lang-rotate-rtl', 'lang-rotate-ltr');
                const savedLang = localStorage.getItem('language') || 'fa';
                if (savedLang === 'fa') langIcon.classList.add('lang-rotate-rtl');
                else langIcon.classList.add('lang-rotate-ltr');
            }
            const savedLanguage = localStorage.getItem('language') || 'fa';
            this.language = savedLanguage;
            await this.updateLanguage(savedLanguage);

            const flashSettings = localStorage.getItem('flashSettings');
            if (flashSettings) {
                const { intensity, enabled } = JSON.parse(flashSettings);
                const flashIntensity = document.getElementById('flashIntensity');
                const flashToggle = document.getElementById('flashToggle');
                const flashControls = document.getElementById('flashControls');
                if (flashIntensity) flashIntensity.value = intensity;
                if (flashToggle) flashToggle.checked = enabled;
                if (flashControls) flashControls.classList.toggle('active', enabled);
                this.updateFlashIntensityValue(intensity);
            }

            const servo1 = localStorage.getItem('servo1');
            const servo2 = localStorage.getItem('servo2');
            if (servo1 !== null) {
                const s1 = document.getElementById('servoX');
                const s1Num = document.getElementById('servoXNumber');
                if (s1) s1.value = servo1;
                if (s1Num) s1Num.value = servo1;
                if (document.getElementById('servoXValue')) document.getElementById('servoXValue').textContent = `${servo1}°`;
            }
            if (servo2 !== null) {
                const s2 = document.getElementById('servoY');
                const s2Num = document.getElementById('servoYNumber');
                if (s2) s2.value = servo2;
                if (s2Num) s2Num.value = servo2;
                if (document.getElementById('servoYValue')) document.getElementById('servoYValue').textContent = `${servo2}°`;
            }
        } catch (error) {
            console.error('خطا در بارگذاری تنظیمات:', error);
        }
    }

    getTranslation(key, fallback = '') {
        return (this.translations && this.translations[key]) || fallback || key;
    }

    setupEventListeners() {
        const elements = {
            toggleStreamBtn: document.getElementById('toggleStreamBtn'),
            deviceModeToggle: document.getElementById('deviceModeToggle'),
            capturePhotoBtn: document.getElementById('capturePhotoBtn'),
            photoQuality: document.getElementById('photoQuality'),
            flashIntensity: document.getElementById('flashIntensity'),
            flashToggle: document.getElementById('flashToggle'),
            sendServoBtn: document.getElementById('sendServoBtn'),
            resetServoBtn: document.getElementById('resetServoBtn'),
            loadMoreBtn: document.getElementById('loadMoreBtn'),
            loadMoreVideosBtn: document.getElementById('loadMoreVideosBtn'),
            refreshLogsBtn: document.getElementById('refreshLogsBtn'),
            showAllLogsBtn: document.getElementById('showAllLogsBtn'),
            themeToggle: document.getElementById('themeToggle'),
            languageToggle: document.getElementById('languageToggle'),
            logoutBtn: document.getElementById('logoutBtn'),
            menuToggle: document.querySelector('.menu-toggle'),
            footerThemeBtn: document.getElementById('footerThemeBtn'),
            footerLangBtn: document.getElementById('footerLangBtn'),
            profileHeaderBtn: document.getElementById('profileHeaderBtn')
        };

        // Helper to safely replace and rebind event listeners
        function replaceAndBind(btn, handler) {
            if (btn && btn.parentNode) {
                const newBtn = btn.cloneNode(true);
                btn.parentNode.replaceChild(newBtn, btn);
                newBtn.addEventListener('click', (e) => { e.preventDefault(); handler(); });
            }
        }
        replaceAndBind(elements.themeToggle, () => this.toggleTheme());
        replaceAndBind(elements.languageToggle, () => this.toggleLanguage());
        replaceAndBind(elements.footerThemeBtn, () => this.toggleTheme());
        replaceAndBind(elements.footerLangBtn, () => this.toggleLanguage());
        if (elements.toggleStreamBtn) elements.toggleStreamBtn.addEventListener('click', () => this.toggleStream());
        if (elements.deviceModeToggle) elements.deviceModeToggle.addEventListener('click', () => this.toggleDeviceMode());
        if (elements.capturePhotoBtn) elements.capturePhotoBtn.addEventListener('click', () => this.capturePhoto());
        if (elements.photoQuality) elements.photoQuality.addEventListener('input', (e) => {
            const val = e.target.value;
            document.getElementById('qualityValue').textContent = `${val}%`;
            localStorage.setItem('photoQuality', val);
        });
        if (elements.flashIntensity) elements.flashIntensity.addEventListener('input', (e) => {
            const val = e.target.value;
            document.getElementById('flashIntensityValue').textContent = `${val}%`;
            // Only update localStorage, not server
            let flashSettings = localStorage.getItem('flashSettings');
            try {
                flashSettings = JSON.parse(flashSettings || '{}');
            } catch { flashSettings = {}; }
            flashSettings.intensity = val;
            localStorage.setItem('flashSettings', JSON.stringify(flashSettings));
        });
        if (elements.flashToggle) elements.flashToggle.addEventListener('change', (e) => this.toggleFlash(e.target.checked));
        if (elements.sendServoBtn) elements.sendServoBtn.addEventListener('click', () => this.sendServoCommand());
        if (elements.resetServoBtn) elements.resetServoBtn.addEventListener('click', () => this.resetServo());
        if (elements.loadMoreBtn) elements.loadMoreBtn.addEventListener('click', () => this.loadMorePhotos());
        if (elements.loadMoreVideosBtn) elements.loadMoreVideosBtn.addEventListener('click', () => this.loadMoreVideos());
        if (elements.refreshLogsBtn) elements.refreshLogsBtn.addEventListener('click', () => this.loadLogs());
        if (elements.showAllLogsBtn) elements.showAllLogsBtn.addEventListener('click', () => this.showAllLogs());
        if (elements.logoutBtn) elements.logoutBtn.addEventListener('click', () => this.logout());
        if (elements.menuToggle) {
            elements.menuToggle.addEventListener('click', (e) => {
                e.stopPropagation();
                const nav = document.querySelector('.header-nav');
                nav.classList.toggle('active');
            });
            // بستن منو با کلیک بیرون
            document.addEventListener('click', (e) => {
                const nav = document.querySelector('.header-nav');
                if (nav.classList.contains('active') && !nav.contains(e.target) && !elements.menuToggle.contains(e.target)) {
                    nav.classList.remove('active');
                }
            });
            // بستن منو با کلیک روی آیتم منو
            document.querySelectorAll('.header-nav a').forEach(link => {
                link.addEventListener('click', () => {
                    const nav = document.querySelector('.header-nav');
                    nav.classList.remove('active');
                });
            });
        }

        document.querySelectorAll('.gallery-item').forEach(item => {
            item.addEventListener('click', () => {
                const url = item.dataset.url;
                const timestamp = item.dataset.timestamp;
                const isVideo = item.querySelector('video') !== null;
                const filename = item.dataset.filename;
                const weekday = item.dataset.weekday || '';
                this.showGalleryModal(url, timestamp, isVideo, filename, weekday);
            });
        });

        this.setupServoControls();
        this.setupAccordionEvents();
        if (elements.profileHeaderBtn) {
            elements.profileHeaderBtn.addEventListener('click', (e) => {
                e.preventDefault();
                // هیچ عملی انجام نشود (مودال حذف شده است)
            });
        }
    }

    setupServoControls() {
        const servoX = document.getElementById('servoX');
        const servoXNumber = document.getElementById('servoXNumber');
        const servoY = document.getElementById('servoY');
        const servoYNumber = document.getElementById('servoYNumber');

        // Helper to send only on release
        const sendFinalServo = () => {
            this.saveUserSettingsToServer();
            this.sendServoCommand();
        };

        if (servoX && servoXNumber) {
            servoX.addEventListener('input', () => {
                const val = servoX.value;
                servoXNumber.value = val;
                document.getElementById('servoXValue').textContent = `${val}°`;
                localStorage.setItem('servo1', val);
            });
            servoX.addEventListener('change', sendFinalServo);
            servoX.addEventListener('mouseup', sendFinalServo);
            servoX.addEventListener('touchend', sendFinalServo);
            servoXNumber.addEventListener('input', () => {
                let val = Math.max(0, Math.min(180, parseInt(servoXNumber.value) || 0));
                servoX.value = val;
                servoXNumber.value = val;
                document.getElementById('servoXValue').textContent = `${val}°`;
                localStorage.setItem('servo1', val);
            });
            servoXNumber.addEventListener('change', sendFinalServo);
            servoXNumber.addEventListener('mouseup', sendFinalServo);
            servoXNumber.addEventListener('touchend', sendFinalServo);
        }

        if (servoY && servoYNumber) {
            servoY.addEventListener('input', () => {
                const val = servoY.value;
                servoYNumber.value = val;
                document.getElementById('servoYValue').textContent = `${val}°`;
                localStorage.setItem('servo2', val);
            });
            servoY.addEventListener('change', sendFinalServo);
            servoY.addEventListener('mouseup', sendFinalServo);
            servoY.addEventListener('touchend', sendFinalServo);
            servoYNumber.addEventListener('input', () => {
                let val = Math.max(0, Math.min(180, parseInt(servoYNumber.value) || 0));
                servoY.value = val;
                servoYNumber.value = val;
                document.getElementById('servoYValue').textContent = `${val}°`;
                localStorage.setItem('servo2', val);
            });
            servoYNumber.addEventListener('change', sendFinalServo);
            servoYNumber.addEventListener('mouseup', sendFinalServo);
            servoYNumber.addEventListener('touchend', sendFinalServo);
        }
    }

    setupAccordionEvents() {
        const galleryCollapse = document.getElementById('galleryCollapse');
        const videosCollapse = document.getElementById('videosCollapse');
        const logsCollapse = document.getElementById('logsCollapse');

        if (galleryCollapse) {
            galleryCollapse.addEventListener('show.bs.collapse', () => {
                if (this.currentPage === 0) this.loadGallery();
            });
        }

        if (videosCollapse) {
            videosCollapse.addEventListener('show.bs.collapse', () => {
                if (this.currentVideoPage === 0) this.loadVideos();
            });
        }

        if (logsCollapse) {
            // جلوگیری از ثبت چندباره رویداد
            if (!logsCollapse._logEventSet) {
                logsCollapse.addEventListener('show.bs.collapse', () => this.loadLogs());
                logsCollapse._logEventSet = true;
            }
        }
    }

    setupWebSocket() {
        // پاک‌سازی وب‌سوکت قبلی و handlerها
        if (this.websocket) {
            this.websocket.onclose = null;
            this.websocket.onerror = null;
            this.websocket.onopen = null;
            this.websocket.onmessage = null;
            try { this.websocket.close(); } catch {}
            this.websocket = null;
        }
        this.connectionErrorShown = false;
        try {
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            // فقط برای دریافت فریم و وضعیت، WebSocket ویدیویی راه‌اندازی کن
            const wsUrl = `${protocol}//${window.location.host}/ws/video`;
            this.websocket = new WebSocket(wsUrl);
            this.websocket.binaryType = 'arraybuffer';

            this.websocket.onopen = () => {
                if (window.isReloading) return;
                console.log('✅ اتصال WebSocket ویدیو برقرار شد');
                this.systemStatus.websocket = 'connected';
                this.updateConnectionStatus(true);
                this.updateStatusModal();
                this.retryCount = 0;
                this.connectionErrorShown = false;
            };

            this.websocket.onmessage = (event) => {
                if (window.isReloading) return;
                // فقط دریافت فریم ویدیو
                try {
                    const video = document.getElementById('streamVideo');
                    if (video && this.isStreaming) {
                        const blob = new Blob([event.data], {type: 'image/jpeg'});
                        video.src = URL.createObjectURL(blob);
                    }
                } catch (error) {
                    console.error('خطا در دریافت فریم ویدیو:', error);
                }
            };

            this.websocket.onclose = (event) => {
                if (window.isReloading) return;
                if (this.websocket && this.websocket.readyState === 1) return;
                this.systemStatus.websocket = 'disconnected';
                this.updateConnectionStatus(false);
                this.updateStatusModal();
                this.scheduleReconnect();
                if (!this.connectionErrorShown) {
                    this.showNotification(this.getTranslation('connectionError'), 'error', {
                        title: this.getTranslation('connectionError'),
                        message: event.reason || 'WebSocket closed',
                        code: event.code,
                        source: 'WebSocket',
                        event
                    });
                    this.connectionErrorShown = true;
                }
            };

            this.websocket.onerror = (event) => {
                if (window.isReloading) return;
                if (this.websocket && this.websocket.readyState === 1) return;
                this.systemStatus.websocket = 'disconnected';
                this.updateConnectionStatus(false);
                this.updateStatusModal();
                this.scheduleReconnect();
                if (!this.connectionErrorShown) {
                    this.showNotification(this.getTranslation('connectionError'), 'error', {
                        title: this.getTranslation('connectionError'),
                        message: event.message || 'WebSocket error',
                        code: event.code,
                        source: 'WebSocket',
                        event
                    });
                    this.connectionErrorShown = true;
                }
            };
        } catch (error) {
            if (window.isReloading) return;
            if (this.websocket && this.websocket.readyState === 1) return;
            console.error('خطا در راه‌اندازی WebSocket:', error);
            this.scheduleReconnect();
        }
    }

    scheduleReconnect() {
        if (this.retryCount < this.maxRetries) {
            this.retryCount++;
            const delay = this.retryDelay * this.retryCount;
            console.log(`تلاش مجدد اتصال WebSocket در ${delay}ms (تلاش ${this.retryCount}/${this.maxRetries})`);
            setTimeout(() => this.setupWebSocket(), delay);
        } else {
            console.error('تعداد تلاش‌های مجدد به پایان رسید');
            this.showNotification(this.getTranslation('connectionError'), 'error');
        }
    }

    handleWebSocketMessage(data) {
        try {
            // بررسی اعتبار داده
            if (!data || typeof data !== 'object') {
                console.warn('Invalid WebSocket message received:', data);
                return;
            }
            
            if (data.type === 'status') {
                Object.keys(data).forEach(key => {
                    if (key !== 'type') this.systemStatus[key] = data[key];
                });
                this.updateStatusModal && this.updateStatusModal();
                updateStatusPage && updateStatusPage();
                return;
            }
            
            switch (data.type) {
                case 'frame':
                    if (data.data && data.resolution) {
                        this.updateStreamFrame(data.data, data.resolution);
                    } else {
                        console.warn('Invalid frame data received:', data);
                    }
                    break;
                case 'photo_captured':
                    this.handlePhotoCaptured(data);
                    break;
                case 'video_created':
                    this.handleVideoCreated(data);
                    break;
                case 'motion_detected':
                    this.showNotification(this.getTranslation('motionDetected'), 'warning');
                    break;
                case 'command_response':
                    this.handleCommandResponse(data);
                    break;
                case 'critical_error':
                    this.handleCriticalError(data);
                    break;
                case 'error':
                    this.showNotification(data.message || 'Unknown error', 'error');
                    break;
                case 'pong':
                    // Handle pong response
                    break;
                case 'ping':
                    // Send pong response
                    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                        this.ws.send(JSON.stringify({type: 'pong'}));
                    }
                    break;
                default:
                    console.log('پیام WebSocket ناشناخته:', data);
            }
        } catch (error) {
            console.error('خطا در پردازش پیام WebSocket:', error);
            this.showNotification(this.getTranslation('connectionError'), 'error');
            
            // Log detailed error information
            if (error.stack) {
                console.error('Error stack:', error.stack);
            }
        }
    }

    handleCommandResponse(data) {
        const command = data.command;
        if (data.status === 'success') {
            if (command.type === 'servo') {
                this.showNotification(this.getTranslation('servoCommandSent'), 'success');
            } else if (command.type === 'device_mode') {
                this.deviceMode = command.device_mode;
                this.updateStreamResolution();
                this.showNotification(this.getTranslation(command.device_mode === 'mobile' ? 'mobileMode' : 'desktopMode'), 'info');
            } else if (command.type === 'action') {
                this.showNotification(this.getTranslation(command.action === 'start_recording' ? 'recordingStarted' : 'recordingStopped'), 'success');
            }
        } else if (data.status === 'warning') {
            this.showNotification(data.message || 'دستور با هشدار اجرا شد', 'warning');
        } else {
            this.showNotification(data.message || 'دستور با خطا مواجه شد', 'error');
        }
    }

    async toggleStream() {
        try {
            const btn = document.getElementById('toggleStreamBtn');
            const placeholder = document.getElementById('streamPlaceholder');
            const video = document.getElementById('streamVideo');

            if (!btn || !video || !placeholder) return;

            if (!this.isStreaming) {
                // فقط اینجا WebSocket را باز کن
                this.setupWebSocket();
                this.isStreaming = true;
                this.updateStreamButton();
                placeholder.style.display = 'none';
                video.classList.add('active');
                this.updateStreamResolution();
                this.showNotification(this.getTranslation('streamStarted'), 'success');
            } else {
                // اینجا WebSocket را ببند
                if (this.websocket) {
                    this.websocket.close();
                    this.websocket = null;
                }
                this.isStreaming = false;
                this.updateStreamButton();
                video.classList.remove('active');
                video.src = '';
                placeholder.style.display = 'flex';
                this.showNotification(this.getTranslation('streamStopped'), 'info');
            }
        } catch (error) {
            console.error('خطا در تغییر وضعیت استریم:', error);
            this.showNotification(this.getTranslation('connectionError'), 'error');
        }
    }

    updateStreamResolution() {
        const video = document.getElementById('streamVideo');
        if (video && this.isStreaming) {
            const { width, height } = this.resolution[this.deviceMode];
            video.style.width = `${width}px`;
            video.style.height = `${height}px`;
        }
    }

    updateDeviceModeButton() {
        const btn = document.getElementById('deviceModeToggle');
        if (!btn) return;
        btn.innerHTML = `<i class="fas fa-${this.deviceMode === 'mobile' ? 'mobile-alt' : 'desktop'} me-2"></i> ${this.getTranslation(this.deviceMode === 'mobile' ? 'mobileMode' : 'desktopMode')}`;
        btn.classList.toggle('btn-outline-secondary', this.deviceMode === 'desktop');
        btn.classList.toggle('btn-outline-primary', this.deviceMode === 'mobile');
    }

    async toggleDeviceMode() {
        try {
            const btn = document.getElementById('deviceModeToggle');
            if (!btn) return;
            const prevMode = localStorage.getItem('device_mode') || this.deviceMode || 'desktop';
            this.deviceMode = this.deviceMode === 'desktop' ? 'mobile' : 'desktop';
            localStorage.setItem('device_mode', this.deviceMode);
            this.saveUserSettingsToServer();
            this.updateDeviceModeButton();
            if (prevMode !== this.deviceMode) {
                this.showNotification(this.getTranslation(this.deviceMode === 'mobile' ? 'mobileMode' : 'desktopMode'), 'info');
            }
            // ارسال با HTTP
            await fetch('/set_device_mode', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({device_mode: this.deviceMode})
            });
            this.updateStreamResolution();
        } catch (error) {
            console.error('خطا در تغییر حالت دستگاه:', error);
            this.showNotification(this.getTranslation('connectionError'), 'error');
        }
    }

    async capturePhoto() {
        const btn = document.getElementById('capturePhotoBtn');
        if (btn && btn.disabled) {
            this.showNotification('عکس‌برداری در حال انجام است، لطفاً صبر کنید...', 'warning');
            return; // جلوگیری از ارسال همزمان
        }
        
        if (btn) btn.disabled = true; // غیرفعال کردن دکمه تا دریافت پاسخ
        
        try {
            const quality = localStorage.getItem('photoQuality') || document.getElementById('photoQuality')?.value || 80;
            let flashSettings = localStorage.getItem('flashSettings');
            let flashEnabled = false, flashIntensity = 50;
            try {
                flashSettings = JSON.parse(flashSettings || '{}');
                flashIntensity = flashSettings.intensity || 50;
                flashEnabled = flashSettings.enabled || false;
            } catch (error) {
                console.warn('Error parsing flash settings in capturePhoto:', error);
            }
            if (document.getElementById('flashToggle')) flashEnabled = document.getElementById('flashToggle').checked;
            if (document.getElementById('flashIntensity')) flashIntensity = document.getElementById('flashIntensity').value;

            const res = await fetch('/manual_photo', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({quality: parseInt(quality), flash: flashEnabled, intensity: parseInt(flashIntensity)})
            });
            const data = await res.json();
            if (data.status === 'success') {
                this.showNotification(this.getTranslation('photoCaptured'), 'info');
            } else {
                this.showNotification(data.message || this.getTranslation('settingsError'), 'error');
            }
        } catch (error) {
            console.error('خطا در ثبت تصویر:', error);
            this.showNotification(this.getTranslation('connectionError'), 'error');
        } finally {
            if (btn) btn.disabled = false; // فعال کردن مجدد دکمه
        }
    }

    updateQualityValue(value) {
        const qualityValue = document.getElementById('qualityValue');
        if (qualityValue) qualityValue.textContent = `${value}%`;
    }

    updateFlashIntensityValue(value) {
        const flashIntensityValue = document.getElementById('flashIntensityValue');
        if (flashIntensityValue) {
            flashIntensityValue.textContent = `${value}%`;
            localStorage.setItem('flashSettings', JSON.stringify({
                intensity: value,
                enabled: document.getElementById('flashToggle')?.checked || false
            }));
            this.saveUserSettingsToServer();
        }
    }

    toggleFlash(enabled) {
        const flashControls = document.getElementById('flashControls');
        if (flashControls) flashControls.classList.toggle('active', enabled);
        localStorage.setItem('flashSettings', JSON.stringify({
            intensity: document.getElementById('flashIntensity')?.value || 50,
            enabled
        }));
        this.saveUserSettingsToServer();
        // ارسال اکشن با HTTP
        fetch('/set_action', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: enabled ? 'flash_on' : 'flash_off', intensity: parseInt(document.getElementById('flashIntensity')?.value || 50)})
        });
        this.showNotification(this.getTranslation('flashToggled').replace('{enabled}', enabled ? 'فعال' : 'غیرفعال'), 'info');
    }

    async sendServoCommand() {
        const btn = document.getElementById('sendServoBtn');
        if (btn && btn.disabled) {
            this.showNotification('دستور سروو در حال ارسال است، لطفاً صبر کنید...', 'warning');
            return; // جلوگیری از ارسال همزمان
        }
        
        if (btn) btn.disabled = true; // غیرفعال کردن دکمه تا دریافت پاسخ
        
        try {
            const servoX = document.getElementById('servoX')?.value || 90;
            const servoY = document.getElementById('servoY')?.value || 90;

            if (servoX < 0 || servoX > 180 || servoY < 0 || servoY > 180) {
                this.showNotification(this.getTranslation('angleError'), 'error');
                return;
            }

            // ارسال از طریق HTTP endpoint (مسیر صحیح)
            const res = await fetch('/set_servo', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({servo1: parseInt(servoX), servo2: parseInt(servoY)})
            });
            const data = await res.json();
            if (data.status === 'success') {
                this.showNotification(this.getTranslation('servoCommandSent'), 'success');
            } else {
                this.showNotification(data.message || this.getTranslation('settingsError'), 'error');
            }
        } catch (error) {
            console.error('خطا در ارسال دستور سروو:', error);
            this.showNotification(this.getTranslation('connectionError'), 'error');
        } finally {
            if (btn) btn.disabled = false; // فعال کردن مجدد دکمه
        }
    }

    async resetServo() {
        try {
            const servoX = document.getElementById('servoX');
            const servoXNumber = document.getElementById('servoXNumber');
            const servoY = document.getElementById('servoY');
            const servoYNumber = document.getElementById('servoYNumber');

            if (servoX) servoX.value = 90;
            if (servoXNumber) servoXNumber.value = 90;
            if (document.getElementById('servoXValue')) document.getElementById('servoXValue').textContent = '90°';
            if (servoY) servoY.value = 90;
            if (servoYNumber) servoYNumber.value = 90;
            if (document.getElementById('servoYValue')) document.getElementById('servoYValue').textContent = '90°';

            // ارسال از طریق HTTP endpoint (مسیر صحیح)
            const res = await fetch('/set_servo', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({servo1: 90, servo2: 90})
            });
            const data = await res.json();
            if (data.status === 'success') {
                this.showNotification(this.getTranslation('servosReset'), 'success');
            } else {
                this.showNotification(data.message || this.getTranslation('settingsError'), 'error');
            }
        } catch (error) {
            console.error('خطا در بازنشانی سرووها:', error);
            this.showNotification(this.getTranslation('connectionError'), 'error');
        }
    }

    async loadGallery() {
        if (this.isLoading) return;
        this.isLoading = true;

        try {
            const response = await fetch(`/get_gallery?page=${this.currentPage}`);
            if (!response.ok) throw new Error('Failed to fetch gallery');
            const data = await response.json();

            const galleryContainer = document.getElementById('galleryContainer');
            if (!galleryContainer) return;

            if (this.currentPage === 0) galleryContainer.innerHTML = '';

            data.photos.forEach(photo => {
                const item = document.createElement('div');
                item.className = 'gallery-item';
                item.dataset.url = photo.url;
                item.dataset.timestamp = new Date(photo.timestamp).toLocaleString(this.language === 'fa' ? 'fa-IR' : 'en-US');
                item.dataset.filename = photo.filename; // اضافه کردن filename به dataset برای تصویر
                // Compute weekday
                const dateObj = new Date(photo.timestamp);
                const weekdays = this.language === 'fa' ? [
                    this.getTranslation('weekday_sun','یکشنبه'),
                    this.getTranslation('weekday_mon','دوشنبه'),
                    this.getTranslation('weekday_tue','سه‌شنبه'),
                    this.getTranslation('weekday_wed','چهارشنبه'),
                    this.getTranslation('weekday_thu','پنجشنبه'),
                    this.getTranslation('weekday_fri','جمعه'),
                    this.getTranslation('weekday_sat','شنبه')
                ] : [
                    this.getTranslation('weekday_sun','Sunday'),
                    this.getTranslation('weekday_mon','Monday'),
                    this.getTranslation('weekday_tue','Tuesday'),
                    this.getTranslation('weekday_wed','Wednesday'),
                    this.getTranslation('weekday_thu','Thursday'),
                    this.getTranslation('weekday_fri','Friday'),
                    this.getTranslation('weekday_sat','Saturday')
                ];
                const weekday = weekdays[dateObj.getDay()];
                const dateStr = dateObj.toLocaleString(this.language === 'fa' ? 'fa-IR' : 'en-US');
                // Detect mobile mode
                const isMobile = this.deviceMode === 'mobile' || window.innerWidth <= 600;
                item.innerHTML = `
                    <img src="${photo.url}" alt="${this.language === 'fa' ? 'تصویر امنیتی' : 'Security Image'}">
                    ${isMobile ? `
                    <div class="gallery-info-overlay" style="position:absolute;bottom:0;left:0;width:100%;background:rgba(0,0,0,0.55);color:#fff;padding:4px 6px;font-size:0.95em;display:flex;flex-direction:row;align-items:center;gap:10px;justify-content:center;z-index:2;">
                        <span style="display:flex;align-items:center;gap:3px;white-space:nowrap;">
                            <i class='fas fa-calendar-alt' style='color:#ffd700;'></i>
                            <span>${dateStr}</span>
                        </span>
                        <span style="display:flex;align-items:center;gap:3px;white-space:nowrap;">
                            <i class='fas fa-calendar-day' style='color:#ff9800;'></i>
                            <span>${weekday}</span>
                        </span>
                    </div>
                    ` : `
                    <div class="gallery-info" style="display:flex;flex-direction:row;align-items:center;gap:12px;flex-wrap:wrap;justify-content:flex-start;overflow:hidden;">
                        <span style="display:flex;align-items:center;gap:4px;white-space:nowrap;">
                            <i class="fas fa-calendar-alt" style="color:#6c63ff;"></i>
                            <span style="font-weight:bold;">${this.language === 'fa' ? 'تاریخ:' : 'Date:'}</span>
                            <span>${dateStr}</span>
                        </span>
                        <span style="display:flex;align-items:center;gap:4px;white-space:nowrap;">
                            <i class="fas fa-calendar-day" style="color:#ff9800;"></i>
                            <span style="font-weight:bold;">${this.language === 'fa' ? 'روز:' : 'Weekday:'}</span>
                            <span>${weekday}</span>
                        </span>
                    </div>
                    `}
                `;
                if (isMobile) item.style.position = 'relative';
                item.addEventListener('click', () => {
                    this.showGalleryModal(photo.url, dateStr, false, photo.filename, weekday);
                });
                galleryContainer.appendChild(item);
            });

            this.currentPage++;
            if (!data.has_more) {
                const loadMoreBtn = document.getElementById('loadMoreBtn');
                if (loadMoreBtn) loadMoreBtn.style.display = 'none';
            }
        } catch (error) {
            this.showNotification(this.getTranslation('galleryError'), 'error', {
                title: this.getTranslation('galleryError'),
                message: error.message,
                code: error.code || '-',
                source: 'fetch(/get_gallery)'
            });
        } finally {
            this.isLoading = false;
        }
    }

    async deletePhoto(filename, domItem = null) {
        try {
            const response = await fetch(`/delete_photo/${filename}`, { method: 'POST' });
            if (!response.ok) throw new Error('Failed to delete photo');
            const data = await response.json();
            this.showNotification(data.message, 'success');
            // حذف از DOM (افکت محو شدن)
            if (domItem) {
                domItem.classList.add('fade-out');
                setTimeout(() => {
                    domItem.remove();
                    this.currentPage = 0;
                    this.loadGallery();
                }, 350);
            } else {
                // اگر از مودال حذف شد، عکس را در گالری پیدا و حذف کن
                const galleryContainer = document.getElementById('galleryContainer');
                if (galleryContainer) {
                    const item = Array.from(galleryContainer.children).find(el => el.dataset.filename === filename);
                    if (item) {
                        item.classList.add('fade-out');
                        setTimeout(() => {
                            item.remove();
                            this.currentPage = 0;
                            this.loadGallery();
                        }, 350);
                    } else {
                        this.currentPage = 0;
                        this.loadGallery();
                    }
                } else {
                    this.currentPage = 0;
                    this.loadGallery();
                }
            }
            // اگر مودال باز است، آن را ببند
            const modalEl = document.getElementById('galleryModal');
            if (modalEl) {
                const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
                modal.hide();
            }
        } catch (error) {
            console.error('خطا در حذف تصویر:', error);
            this.showNotification(this.getTranslation('deleteError'), 'error');
        }
    }

    async loadVideos() {
        if (this.isLoading) return;
        this.isLoading = true;

        try {
            const response = await fetch(`/get_videos?page=${this.currentVideoPage}`);
            if (!response.ok) throw new Error('Failed to fetch videos');
            const data = await response.json();

            const videosContainer = document.getElementById('videosContainer');
            if (!videosContainer) return;

            // اگر صفحه 0 است، کانتینر را پاک کن
            if (this.currentVideoPage === 0) {
                videosContainer.innerHTML = '';
            }

            // بررسی تکراری بودن ویدیوها
            const existingFilenames = new Set();
            if (this.currentVideoPage > 0) {
                videosContainer.querySelectorAll('.gallery-item').forEach(item => {
                    const video = item.querySelector('video');
                    if (video && video.src) {
                        const filename = video.src.split('/').pop();
                        if (filename) existingFilenames.add(filename);
                    }
                });
            }

            data.videos.forEach(video => {
                // اگر ویدیو قبلاً نمایش داده شده، آن را اضافه نکن
                if (existingFilenames.has(video.filename)) {
                    return;
                }

                const item = document.createElement('div');
                item.className = 'gallery-item';
                item.dataset.url = video.url;
                item.dataset.timestamp = new Date(video.timestamp).toLocaleString(this.language === 'fa' ? 'fa-IR' : 'en-US');
                item.dataset.filename = video.filename; // اضافه کردن filename به dataset
                
                // Compute weekday
                const dateObj = new Date(video.timestamp);
                const weekdays = this.language === 'fa' ? [
                    this.getTranslation('weekday_sun','یکشنبه'),
                    this.getTranslation('weekday_mon','دوشنبه'),
                    this.getTranslation('weekday_tue','سه‌شنبه'),
                    this.getTranslation('weekday_wed','چهارشنبه'),
                    this.getTranslation('weekday_thu','پنجشنبه'),
                    this.getTranslation('weekday_fri','جمعه'),
                    this.getTranslation('weekday_sat','شنبه')
                ] : [
                    this.getTranslation('weekday_sun','Sunday'),
                    this.getTranslation('weekday_mon','Monday'),
                    this.getTranslation('weekday_tue','Tuesday'),
                    this.getTranslation('weekday_wed','Wednesday'),
                    this.getTranslation('weekday_thu','Thursday'),
                    this.getTranslation('weekday_fri','Friday'),
                    this.getTranslation('weekday_sat','Saturday')
                ];
                const weekday = weekdays[dateObj.getDay()];
                const dateStr = dateObj.toLocaleString(this.language === 'fa' ? 'fa-IR' : 'en-US');
                
                // Detect mobile mode
                const isMobile = this.deviceMode === 'mobile' || window.innerWidth <= 600;
                item.innerHTML = `
                    <video src="${video.url}" muted></video>
                    ${isMobile ? `
                    <div class="gallery-info-overlay" style="position:absolute;bottom:0;left:0;width:100%;background:rgba(0,0,0,0.55);color:#fff;padding:4px 6px;font-size:0.95em;display:flex;flex-direction:row;align-items:center;gap:10px;justify-content:center;z-index:2;">
                        <span style="display:flex;align-items:center;gap:3px;white-space:nowrap;">
                            <i class='fas fa-calendar-alt' style='color:#ffd700;'></i>
                            <span>${dateStr}</span>
                        </span>
                        <span style="display:flex;align-items:center;gap:3px;white-space:nowrap;">
                            <i class='fas fa-calendar-day' style='color:#ff9800;'></i>
                            <span>${weekday}</span>
                        </span>
                    </div>
                    ` : `
                    <div class="gallery-info" style="display:flex;flex-direction:row;align-items:center;gap:12px;flex-wrap:wrap;justify-content:flex-start;overflow:hidden;">
                        <span style="display:flex;align-items:center;gap:4px;white-space:nowrap;">
                            <i class="fas fa-calendar-alt" style="color:#6c63ff;"></i>
                            <span style="font-weight:bold;">${this.language === 'fa' ? 'تاریخ:' : 'Date:'}</span>
                            <span>${dateStr}</span>
                        </span>
                        <span style="display:flex;align-items:center;gap:4px;white-space:nowrap;">
                            <i class="fas fa-calendar-day" style="color:#ff9800;"></i>
                            <span style="font-weight:bold;">${this.language === 'fa' ? 'روز:' : 'Weekday:'}</span>
                            <span>${weekday}</span>
                        </span>
                    </div>
                    `}
                `;
                if (isMobile) item.style.position = 'relative';
                item.addEventListener('click', (e) => {
                    this.showGalleryModal(video.url, dateStr, true, video.filename, weekday);
                });
                videosContainer.appendChild(item);
            });

            this.currentVideoPage++;
            if (!data.has_more) {
                const loadMoreVideosBtn = document.getElementById('loadMoreVideosBtn');
                if (loadMoreVideosBtn) loadMoreVideosBtn.style.display = 'none';
            }
        } catch (error) {
            this.showNotification(this.getTranslation('galleryError'), 'error', {
                title: this.getTranslation('galleryError'),
                message: error.message,
                code: error.code || '-',
                source: 'fetch(/get_videos)'
            });
        } finally {
            this.isLoading = false;
        }
    }

    // تابع جدید برای پاک کردن تمام ویدیوهای مربوط به یک فایل
    removeVideoElementsFromGallery(filename) {
        const videosContainer = document.getElementById('videosContainer');
        if (videosContainer) {
            const videoItems = videosContainer.querySelectorAll('.gallery-item');
            videoItems.forEach(item => {
                const video = item.querySelector('video');
                if (video && video.src && video.src.includes(filename)) {
                    // پاک کردن ویدیو
                    video.pause();
                    video.currentTime = 0;
                    video.removeAttribute('src');
                    video.load();
                    // حذف آیتم از گالری
                    item.style.opacity = '0';
                    item.style.transform = 'scale(0.8)';
                    setTimeout(() => {
                        if (item.parentNode) {
                            item.parentNode.removeChild(item);
                        }
                    }, 300);
                }
            });
        }
    }

    // تابع جدید برای آزاد کردن کامل فایل ویدیو - بسیار قوی‌تر
    async forceReleaseVideoFile(filename) {
        console.log(`Starting aggressive cleanup for: ${filename}`);
        
        // 1. متوقف کردن فوری تمام ویدیوها
        const allVideos = document.querySelectorAll('video');
        allVideos.forEach(video => {
            if (video.src && video.src.includes(filename)) {
                console.log('Stopping video element:', video);
                video.pause();
                video.currentTime = 0;
                video.muted = true;
                video.volume = 0;
                video.removeAttribute('src');
                video.load();
                
                // حذف تمام event listeners
                const events = ['loadstart', 'loadedmetadata', 'loadeddata', 'canplay', 'canplaythrough', 
                               'play', 'pause', 'ended', 'error', 'abort', 'stalled', 'suspend', 'waiting'];
                events.forEach(event => {
                    video[`on${event}`] = null;
                });
            }
        });
        
        // 2. پاک کردن کش مرورگر به صورت فوری
        if ('caches' in window) {
            try {
                const cacheNames = await caches.keys();
                for (const cacheName of cacheNames) {
                    const cache = await caches.open(cacheName);
                    const requests = await cache.keys();
                    for (const request of requests) {
                        if (request.url.includes(filename)) {
                            await cache.delete(request);
                            console.log('Deleted from cache:', request.url);
                        }
                    }
                }
            } catch (e) {
                console.log('Cache cleanup failed:', e);
            }
        }
        
        // 3. پاک کردن تمام ویدیوهای مربوط به این فایل از گالری
        this.removeVideoElementsFromGallery(filename);
        
        // 4. تلاش برای garbage collection
        if (window.gc) {
            window.gc();
        }
        
        // 5. تاخیر کوتاه برای آزاد شدن منابع
        await new Promise(resolve => setTimeout(resolve, 100));
        
        console.log(`Aggressive cleanup completed for: ${filename}`);
    }

    // تابع جدید برای متوقف کردن فوری تمام بارگذاری‌ها
    async forceStopAllVideoLoading(filename) {
        console.log(`Force stopping all video loading for: ${filename}`);
        
        // 1. متوقف کردن تمام ویدیوهای در حال بارگذاری
        const allVideos = document.querySelectorAll('video');
        allVideos.forEach(video => {
            if (video.src && video.src.includes(filename)) {
                console.log('Force stopping video loading:', video);
                
                // متوقف کردن فوری
                video.pause();
                video.currentTime = 0;
                video.muted = true;
                video.volume = 0;
                
                // لغو تمام درخواست‌های HTTP
                if (video.src && video.src.startsWith('blob:')) {
                    URL.revokeObjectURL(video.src);
                }
                
                // پاک کردن src
                video.removeAttribute('src');
                video.load();
                
                // حذف تمام event listeners
                const events = ['loadstart', 'loadedmetadata', 'loadeddata', 'canplay', 'canplaythrough', 
                               'play', 'pause', 'ended', 'error', 'abort', 'stalled', 'suspend', 'waiting',
                               'progress', 'canplay', 'canplaythrough', 'loadedmetadata', 'loadeddata'];
                events.forEach(event => {
                    video[`on${event}`] = null;
                    video.removeEventListener(event, null);
                });
                
                // لغو تمام درخواست‌های fetch
                if (window.AbortController) {
                    if (!window.activeRequests) window.activeRequests = new Map();
                    const controller = new AbortController();
                    window.activeRequests.set(filename, controller);
                    controller.abort();
                }
            }
        });
        
        // 2. لغو تمام درخواست‌های fetch فعال
        if (window.activeRequests && window.activeRequests.has(filename)) {
            const controller = window.activeRequests.get(filename);
            controller.abort();
            window.activeRequests.delete(filename);
        }
        
        // 3. پاک کردن کش مرورگر
        if ('caches' in window) {
            try {
                const cacheNames = await caches.keys();
                for (const cacheName of cacheNames) {
                    const cache = await caches.open(cacheName);
                    const requests = await cache.keys();
                    for (const request of requests) {
                        if (request.url.includes(filename)) {
                            await cache.delete(request);
                            console.log('Deleted from cache:', request.url);
                        }
                    }
                }
            } catch (e) {
                console.log('Cache cleanup failed:', e);
            }
        }
        
        // 4. تاخیر کوتاه برای آزاد شدن منابع
        await new Promise(resolve => setTimeout(resolve, 100));
        
        console.log(`Force stop completed for: ${filename}`);
    }

    async deleteVideo(filename) {
        try {
            console.log(`Starting deletion process for: ${filename}`);
            // 1. متوقف کردن فوری تمام بارگذاری‌ها
            await this.forceStopAllVideoLoading(filename);
            const modalVideo = document.getElementById('modalVideo');
            if (modalVideo) {
                console.log('Cleaning up modal video');
                // 2. متوقف کردن کامل ویدیو
                modalVideo.pause();
                modalVideo.currentTime = 0;
                modalVideo.muted = true;
                modalVideo.volume = 0;
                // 3. پاک کردن تمام event listeners
                const events = ['loadstart', 'loadedmetadata', 'loadeddata', 'canplay', 'canplaythrough', 
                               'play', 'pause', 'ended', 'error', 'abort', 'stalled', 'suspend', 'waiting'];
                events.forEach(event => {
                    modalVideo[`on${event}`] = null;
                });
                // 4. پاک کردن src و revoke کردن URL
                if (modalVideo.src && modalVideo.src.startsWith('blob:')) {
                    URL.revokeObjectURL(modalVideo.src);
                }
                modalVideo.removeAttribute('src');
                modalVideo.load();
                // 5. حذف کامل از DOM
                const parent = modalVideo.parentNode;
                const next = modalVideo.nextSibling;
                parent.removeChild(modalVideo);
                // 6. ایجاد ویدیوی جدید
                const newVideo = document.createElement('video');
                newVideo.id = 'modalVideo';
                newVideo.className = 'modal-video';
                newVideo.style.display = 'none';
                newVideo.style.maxWidth = '100%';
                newVideo.style.maxHeight = '70vh';
                newVideo.controls = true;
                newVideo.preload = 'metadata';
                if (next) parent.insertBefore(newVideo, next); else parent.appendChild(newVideo);
            }
            // 7. بستن مودال
            const modalEl = document.getElementById('galleryModal');
            if (modalEl) {
                const modal = bootstrap.Modal.getInstance(modalEl);
                if (modal) modal.hide();
            }
            // 8. آزاد کردن کامل فایل - بسیار قوی‌تر
            await this.forceReleaseVideoFile(filename);
            // 9. تاخیر کمتر
            await new Promise(resolve => setTimeout(resolve, 200));
            // 10. تلاش برای حذف فایل با retry mechanism قوی‌تر
            let response;
            let retryCount = 0;
            const maxRetries = 8; // افزایش تعداد تلاش‌ها
            while (retryCount < maxRetries) {
                try {
                    console.log(`Delete attempt ${retryCount + 1}/${maxRetries} for ${filename}`);
                    // ایجاد AbortController برای لغو درخواست در صورت نیاز
                    const controller = new AbortController();
                    if (!window.activeRequests) window.activeRequests = new Map();
                    window.activeRequests.set(filename, controller);
                    response = await fetch(`/delete_video/${encodeURIComponent(filename)}`, {
                        method: 'POST',
                        headers: {
                            'Cache-Control': 'no-cache, no-store, must-revalidate',
                            'Pragma': 'no-cache',
                            'Expires': '0'
                        },
                        signal: controller.signal
                    });
                    // حذف از active requests
                    window.activeRequests.delete(filename);
                    if (response.ok) {
                        console.log(`Successfully deleted ${filename} on attempt ${retryCount + 1}`);
                        break; // موفقیت
                    }
                } catch (err) {
                    retryCount++;
                    await new Promise(resolve => setTimeout(resolve, 200 + retryCount * 100));
                }
            }
            if (!response || !response.ok) {
                throw new Error('Failed to delete video after retries');
            }
            const data = await response.json();
            this.showNotification(data.message, 'success');
            // حذف از DOM (افکت محو شدن)
            const galleryContainer = document.getElementById('videosContainer') || document.getElementById('galleryContainer');
            if (galleryContainer) {
                const item = Array.from(galleryContainer.children).find(el => el.dataset.filename === filename);
                if (item) {
                    item.classList.add('fade-out');
                    setTimeout(() => {
                        item.remove();
                        this.currentVideoPage = 0;
                        this.loadVideos();
                    }, 350);
                } else {
                    this.currentVideoPage = 0;
                    this.loadVideos();
                }
            } else {
                this.currentVideoPage = 0;
                this.loadVideos();
            }
        } catch (error) {
            console.error('خطا در حذف ویدیو:', error);
            this.showNotification(this.getTranslation('deleteError'), 'error');
        }
    }

    async loadLogs() {
        try {
            // --- دریافت وضعیت منابع سرور و نمایش در پنل مهندسی‌شده ---
            const statusPanel = document.getElementById('serverStatusPanel');
            if (statusPanel) {
                try {
                    const res = await fetch('/get_status');
                    if (res.ok) {
                        const statusData = await res.json();
                        if (statusData.status === 'success' && statusData.data) {
                            const d = statusData.data;
                            // RAM
                            const ram = document.getElementById('status-ram-value');
                            if (ram) { ram.textContent = d.ram_percent !== null && d.ram_percent !== undefined ? d.ram_percent + '%' : '--'; ram.className = 'status-value ' + (d.ram_percent < 70 ? 'status-success' : d.ram_percent < 90 ? 'status-warning' : 'status-error'); ram.setAttribute('data-key-label', 'ramLabel'); }
                            // CPU
                            const cpu = document.getElementById('status-cpu-value');
                            if (cpu) { cpu.textContent = d.cpu_percent !== null && d.cpu_percent !== undefined ? d.cpu_percent + '%' : '--'; cpu.className = 'status-value ' + (d.cpu_percent < 70 ? 'status-success' : d.cpu_percent < 90 ? 'status-warning' : 'status-error'); cpu.setAttribute('data-key-label', 'cpuLabel'); }
                            // Storage
                            const storage = document.getElementById('status-storage-value');
                            if (storage) { storage.textContent = d.storage || '--'; storage.className = 'status-value ' + (parseFloat((d.storage||'0').replace('%','')) > 20 ? 'status-success' : 'status-warning'); storage.setAttribute('data-key-label', 'storageLabel'); }
                            // Internet
                            const internet = document.getElementById('status-internet-value');
                            if (internet) { internet.textContent = d.internet === 'online' ? (this.language === 'fa' ? 'آنلاین' : 'Online') : (this.language === 'fa' ? 'آفلاین' : 'Offline'); internet.className = 'status-value ' + (d.internet === 'online' ? 'status-success' : 'status-error'); internet.setAttribute('data-key-label', 'internetLabel'); }
                            // Camera
                            const camera = document.getElementById('status-camera-value');
                            if (camera) { camera.textContent = d.camera_status === 'online' ? (this.language === 'fa' ? 'آنلاین' : 'Online') : (this.language === 'fa' ? 'آفلاین' : 'Offline'); camera.className = 'status-value ' + (d.camera_status === 'online' ? 'status-success' : 'status-error'); camera.setAttribute('data-key-label', 'cameraLabel'); }
                            // Pico
                            const pico = document.getElementById('status-pico-value');
                            if (pico) { pico.textContent = d.pico_status === 'online' ? (this.language === 'fa' ? 'آنلاین' : 'Online') : (this.language === 'fa' ? 'آفلاین' : 'Offline'); pico.className = 'status-value ' + (d.pico_status === 'online' ? 'status-success' : 'status-error'); pico.setAttribute('data-key-label', 'picoLabel'); }
                        }
                    }
                } catch (e) { /* ignore */ }
            }
            // --- بارگذاری لاگ‌ها ---
            const logLimit = document.getElementById('logLimit')?.value || 50;
            const response = await fetch(`/get_logs?limit=${logLimit}`);
            if (!response.ok) throw new Error('Failed to fetch logs');
            const data = await response.json();

            const logsContainer = document.getElementById('logsContainer');
            if (!logsContainer) return;

            logsContainer.innerHTML = '';
            // حذف لاگ‌های تکراری بر اساس message+timestamp+level
            const uniqueLogs = [];
            const seen = new Set();
            data.logs.forEach(log => {
                const key = `${log.message}|${log.timestamp}|${log.level}`;
                if (!seen.has(key)) {
                    uniqueLogs.push(log);
                    seen.add(key);
                }
            });
            uniqueLogs.forEach(log => {
                const logItem = document.createElement('div');
                logItem.className = `log-card log-level-${log.level ? log.level.toLowerCase() : 'info'}`;
                // آیکون سطح لاگ
                let icon = 'fa-info-circle';
                let levelKey = log.level ? log.level.toLowerCase() : 'info';
                // Fallback for Persian log levels in English mode
                if (this.language === 'en') {
                    const faToEn = {
                        'دستور': 'command',
                        'عکس': 'photo',
                        'حذف': 'delete',
                        'خطا': 'error',
                        'اطلاعات': 'info',
                        'هشدار': 'warning',
                        'اتصال': 'connection',
                        'ویدئو': 'video',
                        'پشتیبان': 'backup',
                        'حرکت': 'motion',
                        'خروج': 'logout',
                    };
                    if (faToEn[levelKey]) levelKey = faToEn[levelKey];
                }
                if (levelKey === 'error') icon = 'fa-times-circle';
                else if (levelKey === 'warning') icon = 'fa-exclamation-triangle';
                else if (levelKey === 'command') icon = 'fa-terminal';
                else if (levelKey === 'photo') icon = 'fa-camera';
                else if (levelKey === 'delete') icon = 'fa-trash';
                else if (levelKey === 'logout') icon = 'fa-sign-out-alt';
                // --- Show source and pico_timestamp clearly ---
                let detailsHtml = '';
                let sourceVal = log.source;
                if (log.source) {
                    detailsHtml += `<div class="log-detail"><span class="log-detail-key">${this.getTranslation('source', this.language === 'fa' ? 'منبع' : 'Source')}:</span> <span class="log-detail-value">${sourceVal}</span></div>`;
                }
                if (log.pico_timestamp) {
                    detailsHtml += `<div class="log-detail"><span class="log-detail-key">${this.getTranslation('picoTime', this.language === 'fa' ? 'زمان Pico' : 'Pico Time')}:</span> <span class="log-detail-value">${log.pico_timestamp}</span></div>`;
                }
                // Other details (if any)
                detailsHtml += Object.keys(log)
                    .filter(k => !['timestamp','level','message','source','pico_timestamp'].includes(k))
                    .map(k => `<div class="log-detail"><span class="log-detail-key">${this.getTranslation(k, k)}</span>: <span class="log-detail-value">${log[k]}</span></div>`).join('');
                logItem.innerHTML = `
                    <div class="log-card-header">
                        <i class="fas ${icon} log-icon"></i>
                        <span class="log-level-label">${this.getTranslation('logLevel_' + levelKey, this.language === 'fa' ? this.translateLogLevel(log.level) : levelKey.charAt(0).toUpperCase() + levelKey.slice(1))}</span>
                        <span class="log-time">${new Date(log.timestamp).toLocaleString(this.language === 'fa' ? 'fa-IR' : 'en-US')}</span>
                    </div>
                    <div class="log-message">${log.message}</div>
                    ${detailsHtml}
                `;
                logsContainer.appendChild(logItem);
            });

            // --- ترجمه labelها و valueها بعد از رندر ---
            this.translateLogDetailLabels();
            this.translateStatusLabels();
            this.translateLogLevelLabels();

            this.showNotification(this.getTranslation('logsUpdated'), 'success');
        } catch (error) {
            this.showNotification(this.getTranslation('connectionError'), 'error', {
                title: this.getTranslation('connectionError'),
                message: error.message,
                code: error.code || '-',
                source: 'fetch(/get_logs)'
            });
        }
    }

    async showAllLogs() {
        try {
            const response = await fetch('/get_all_logs');
            if (!response.ok) throw new Error('Failed to fetch all logs');
            const data = await response.json();

            const allLogsContainer = document.getElementById('allLogsContainer');
            if (!allLogsContainer) return;

            allLogsContainer.innerHTML = '';
            data.logs.forEach(log => {
                const logItem = document.createElement('div');
                let levelKey = log.level ? log.level.toLowerCase() : 'info';
                if (this.language === 'en') {
                    const faToEn = {
                        'دستور': 'command',
                        'عکس': 'photo',
                        'حذف': 'delete',
                        'خطا': 'error',
                        'اطلاعات': 'info',
                        'هشدار': 'warning',
                        'اتصال': 'connection',
                        'ویدئو': 'video',
                        'پشتیبان': 'backup',
                        'حرکت': 'motion',
                        'خروج': 'logout',
                    };
                    if (faToEn[levelKey]) levelKey = faToEn[levelKey];
                }
                logItem.className = `log-item log-level-${levelKey}`;
                logItem.innerHTML = `
                    <span class="log-time">${new Date(log.timestamp).toLocaleString(this.language === 'fa' ? 'fa-IR' : 'en-US')}</span>
                    <span class="log-level ${levelKey}">${this.language === 'fa' ? this.translateLogLevel(log.level) : this.getTranslation('logLevel_' + levelKey)}</span>
                    <span class="log-message">${this.getTranslation('logMsg_' + (log.code || levelKey), log.message)}</span>
                `;
                allLogsContainer.appendChild(logItem);
            });

            // Remove emoji from button text (if present)
            const showAllLogsBtn = document.getElementById('showAllLogsBtn');
            if (showAllLogsBtn) {
                showAllLogsBtn.innerHTML = this.language === 'fa' ? 'نمایش همه گزارش‌ها' : 'Show all logs';
            }
            const refreshLogsBtn = document.getElementById('refreshLogsBtn');
            if (refreshLogsBtn) {
                refreshLogsBtn.innerHTML = this.language === 'fa' ? 'به‌روزرسانی گزارش‌ها' : 'Refresh logs';
            }

            const modal = new bootstrap.Modal(document.getElementById('allLogsModal'));
            const modalEl = document.getElementById('allLogsModal');
            // Clean up overlays on close
            modalEl.removeEventListener('hidden.bs.modal', window._allLogsModalCleanup);
            window._allLogsModalCleanup = function() {
                document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
                document.body.classList.remove('modal-open');
                document.body.style.overflow = '';
                document.body.style.paddingRight = '';
            };
            modalEl.addEventListener('hidden.bs.modal', window._allLogsModalCleanup);
            modal.show();
        } catch (error) {
            this.showNotification(this.getTranslation('connectionError'), 'error', {
                title: this.getTranslation('connectionError'),
                message: error.message,
                code: error.code || '-',
                source: 'fetch(/get_all_logs)'
            });
        }
    }

    translateLogLevel(level) {
        const translations = {
            info: 'اطلاعات',
            error: 'خطا',
            warning: 'هشدار',
            connection: 'اتصال',
            command: 'دستور',
            photo: 'عکس',
            video: 'ویدئو',
            backup: 'پشتیبان',
            delete: 'حذف',
            motion: 'حرکت'
        };
        return translations[level.toLowerCase()] || level;
    }

    showGalleryModal(url, timestamp, isVideo = false, filename = '', weekday = '') {
        try {
            const modalImage = document.getElementById('modalImage');
            const modalVideo = document.getElementById('modalVideo');
            const modalTitle = document.getElementById('galleryModalLabel');
            const modalFooter = document.querySelector('#galleryModal .modal-footer');
            const modalVideoLoading = document.getElementById('modalVideoLoading');
            const modalVideoError = document.getElementById('modalVideoError');
            if (!modalImage || !modalVideo || !modalTitle || !modalFooter) return;

            // ابتدا ویدیو قبلی را متوقف کن
            modalVideo.pause();
            modalVideo.currentTime = 0;
            modalVideo.src = '';
            modalVideoLoading.style.display = 'none';
            modalVideoError.style.display = 'none';

            if (isVideo) {
                modalImage.style.display = 'none';
                modalVideo.style.display = '';
                modalVideoLoading.style.display = 'block';
                modalVideoError.style.display = 'none';
                modalVideo.src = url;
                modalVideo.load();
                modalVideo.oncanplay = function() {
                    modalVideoLoading.style.display = 'none';
                    modalVideo.style.display = '';
                    modalVideo.play();
                };
                modalVideo.onerror = function() {
                    modalVideoLoading.style.display = 'none';
                    modalVideoError.style.display = 'block';
                };
            } else {
                modalImage.style.display = '';
                modalImage.src = url;
                modalVideo.style.display = 'none';
                modalVideo.pause();
                modalVideo.src = '';
                modalVideoLoading.style.display = 'none';
                modalVideoError.style.display = 'none';
            }

            // نمایش تاریخ و نام روز هفته در عنوان
            modalTitle.textContent = this.language === 'fa'
                ? `نمایش ${isVideo ? 'ویدئو' : 'تصویر'}: ${timestamp}${weekday ? ' - ' + weekday : ''}`
                : `View ${isVideo ? 'Video' : 'Image'}: ${timestamp}${weekday ? ' - ' + weekday : ''}`;
            modalFooter.querySelector('a').href = url;
            modalFooter.querySelector('a').download = isVideo ? 'video.mp4' : 'image.jpg';

            // افزودن ایونت حذف به دکمه حذف مودال
            const deleteBtn = modalFooter.querySelector('.btn-danger');
            const self = this;
            if (deleteBtn) {
                deleteBtn.onclick = function() {
                    if (filename) {
                        if (isVideo) {
                            self.deleteVideo(filename);
                        } else {
                            self.deletePhoto(filename);
                        }
                    }
                };
            }

            const modalEl = document.getElementById('galleryModal');
            const modal = new bootstrap.Modal(modalEl);
            modal.show();

            // Custom close button support
            const closeBtn = document.getElementById('galleryModalCloseBtn');
            if (closeBtn) {
                closeBtn.onclick = function() {
                    modal.hide();
                };
            }

            // پاکسازی و توقف ویدیو هنگام بستن مودال
            if (!modalEl._videoCleanupAttached) {
                modalEl.addEventListener('hidden.bs.modal', function() {
                    modalVideo.pause();
                    modalVideo.currentTime = 0;
                    modalVideo.src = '';
                    modalVideoLoading.style.display = 'none';
                    modalVideoError.style.display = 'none';
                    // Remove all modal overlays and modal-open class
                    document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
                    document.body.classList.remove('modal-open');
                    document.body.style.overflow = '';
                    document.body.style.paddingRight = '';
                });
                modalEl._videoCleanupAttached = true;
            }
        } catch (error) {
            console.error('خطا در نمایش مودال گالری:', error);
            this.showNotification(this.getTranslation('galleryError'), 'error');
        }
    }

    toggleTheme() {
        try {
            const isDark = document.body.classList.toggle('dark-mode');
            localStorage.setItem('theme', isDark ? 'dark' : 'light');
            this.applySettingsToUI({
                theme: isDark ? 'dark' : 'light',
                language: this.language || localStorage.getItem('language') || 'fa',
                flashSettings: localStorage.getItem('flashSettings') || '{"intensity":50,"enabled":false}',
                servo1: localStorage.getItem('servo1') || 90,
                servo2: localStorage.getItem('servo2') || 90,
                device_mode: localStorage.getItem('device_mode') || 'desktop'
            });
            this.saveUserSettingsToServer();
            // بروزرسانی دکمه تغییر تم موبایل
            this.updateFooterThemeBtn();
        } catch (error) {
            console.error('خطا در تغییر تم:', error);
            this.showNotification(this.getTranslation('connectionError'), 'error');
        }
    }

    updateFooterThemeBtn() {
        const btn = document.getElementById('footerThemeBtn');
        if (!btn) return;
        const icon = btn.querySelector('i');
        const span = btn.querySelector('span[data-key="themeLight"]');
        const isDark = document.body.classList.contains('dark-mode');
        if (icon) icon.className = isDark ? 'fas fa-sun' : 'fas fa-moon';
        if (span) span.textContent = this.getTranslation(isDark ? 'themeLight' : 'themeDark');
    }

    async toggleLanguage() {
        try {
            this.language = this.language === 'fa' ? 'en' : 'fa';
            localStorage.setItem('language', this.language);
            fetch('/set_language', {
                method: 'POST',
                body: JSON.stringify({ lang: this.language })
            }).then(async res => {
                if (res.ok) {
                    const data = await res.json();
                    if (data.language) this.language = data.language;
                    localStorage.setItem('language', this.language);
                    await this.updateLanguage(this.language);
                    this.saveUserSettingsToServer();
                }
            });
        } catch (error) {
            console.error('خطا در تغییر زبان:', error);
            this.showNotification(this.getTranslation('connectionError'), 'error');
        }
    }

    async updateLanguage(lang) {
        this.language = lang;
        localStorage.setItem('language', lang);
        document.body.classList.toggle('lang-fa', lang === 'fa');
        document.body.classList.toggle('lang-en', lang === 'en');
        document.body.classList.remove('rtl', 'ltr');
        document.body.classList.add(lang === 'fa' ? 'rtl' : 'ltr');
        document.documentElement.lang = lang;
        // بارگذاری ترجمه‌ها از سرور اگر window.translations وجود نداشت
        if (!window.translations || !window.translations[lang]) {
            try {
                const res = await fetch(`/get_translations?lang=${lang}`);
                if (res.ok) {
                    window.translations = window.translations || {};
                    window.translations[lang] = await res.json();
                }
            } catch (error) {
                console.warn('Error loading translations:', error);
            }
        }
        this.translations = window.translations[lang] || {};
        // ترجمه داینامیک عناصر UI
        document.querySelectorAll('[data-key]').forEach(el => {
            const key = el.getAttribute('data-key');
            // اگر دکمه آیکون دارد (childNodes[1] متن است)
            if (el.querySelector('i') && el.childNodes.length > 1) {
                // اگر بعد از آیکون یک متن وجود دارد
                let foundText = false;
                for (let i = 0; i < el.childNodes.length; i++) {
                    if (el.childNodes[i].nodeType === 3) {
                        el.childNodes[i].nodeValue = ' ' + this.getTranslation(key, el.childNodes[i].nodeValue.trim());
                        foundText = true;
                        break;
                    }
                }
                if (!foundText) {
                    el.appendChild(document.createTextNode(' ' + this.getTranslation(key)));
                }
            } else {
                el.textContent = this.getTranslation(key, el.textContent);
            }
        });
        document.querySelectorAll('[data-key-title]').forEach(el => {
            const key = el.getAttribute('data-key-title');
            el.setAttribute('title', this.getTranslation(key, el.getAttribute('title')));
        });
        document.querySelectorAll('[data-key-placeholder]').forEach(el => {
            const key = el.getAttribute('data-key-placeholder');
            el.setAttribute('placeholder', this.getTranslation(key, el.getAttribute('placeholder')));
        });
        document.querySelectorAll('[data-key-alt]').forEach(el => {
            const key = el.getAttribute('data-key-alt');
            el.setAttribute('alt', this.getTranslation(key, el.getAttribute('alt')));
        });
        // اجرای مجدد تایپ‌نویس‌ها
        if (typeof runHeaderTypewriter === 'function') runHeaderTypewriter();
        if (typeof runFooterTypewriter === 'function') runFooterTypewriter();
        // بازسازی مودال پروفایل و وضعیت (در صورت وجود)
        if (document.getElementById('profileModal')) {
            document.getElementById('profileModal').remove();
        }
        if (document.getElementById('statusModal')) {
            document.getElementById('statusModal').remove();
        }
        // بروزرسانی دکمه‌های SPA و سایر بخش‌های داینامیک
        if (typeof updateSpaPagesLanguage === 'function') updateSpaPagesLanguage(lang);
        if (typeof setLogsAccordionButtonTexts === 'function') setLogsAccordionButtonTexts(lang);
        // بروزرسانی دکمه تغییر تم موبایل
        this.updateFooterThemeBtn();
        // بروزرسانی دکمه استریم
        this.updateStreamButton();
        // بروزرسانی دکمه حالت دسکتاپ/موبایل
        this.updateDeviceModeButton();
        // --- ADDED: Reload gallery and videos to update weekday/date on language change ---
        this.currentPage = 0;
        this.currentVideoPage = 0;
        await this.loadGallery();
        await this.loadVideos();
        // Patch updateLanguage to also update modal and popup texts
        const origUpdateLanguage = SmartCameraSystem.prototype.updateLanguage;
        SmartCameraSystem.prototype.updateLanguage = async function(lang) {
            await origUpdateLanguage.call(this, lang);
            // Update Profile Modal
            const profileModal = document.getElementById('profileModal');
            if (profileModal) {
                profileModal.querySelectorAll('[data-key]').forEach(el => {
                    const key = el.getAttribute('data-key');
                    el.textContent = this.getTranslation(key, el.textContent);
                });
                const themeVal = (window.system && typeof window.system.getTranslation === 'function')
                  ? (document.body.classList.contains('dark-mode')
                      ? window.system.getTranslation('themeDark')
                      : window.system.getTranslation('themeLight'))
                  : (document.body.classList.contains('dark-mode') ? 'Dark' : 'Light');
                const langVal = (window.system && typeof window.system.getTranslation === 'function')
                  ? window.system.getTranslation('langLabel')
                  : (localStorage.getItem('language') === 'fa' ? 'فارسی' : 'English');
                if (document.getElementById('profileTheme')) document.getElementById('profileTheme').textContent = themeVal;
                if (document.getElementById('profileLang')) document.getElementById('profileLang').textContent = langVal;
            }
            // Update Status Modal
            const statusModal = document.getElementById('statusModal');
            if (statusModal) {
                statusModal.querySelectorAll('[data-key]').forEach(el => {
                    const key = el.getAttribute('data-key');
                    el.textContent = this.getTranslation(key, el.textContent);
                });
                // Also update status list labels
                const statusList = document.getElementById('statusModalList');
                if (statusList) {
                    // Re-render status list by re-calling showStatusModal if open
                    if (statusModal.classList.contains('show')) {
                        showStatusModal();
                    }
                }
            }
            // Update Active Users Modal
            const activeUsersModal = document.getElementById('activeUsersModal');
            if (activeUsersModal) {
                activeUsersModal.querySelectorAll('[data-key]').forEach(el => {
                    const key = el.getAttribute('data-key');
                    el.textContent = this.getTranslation(key, el.textContent);
                });
                // If open, re-render body
                if (activeUsersModal.classList.contains('show')) {
                    // Try to re-show with current data if possible
                    if (window._lastActiveIps) {
                        showActiveUsersModal(window._lastActiveIps);
                    }
                }
            }
            // Update logs accordion buttons
            setLogsAccordionButtonTexts(lang);
            // ترجمه labelهای log-detail-key
            this.translateLogDetailLabels();
            // ترجمه labelهای وضعیت (status-value و status-label)
            this.translateStatusLabels();
            // --- تابع جدید برای ترجمه سطح لاگ (log-level-label) بعد از تغییر زبان ---
            this.translateLogLevelLabels();
            // ترجمه عنوان و دکمه بستن مودال وضعیت
            const t = this.getTranslation.bind(this);
            setTimeout(() => {
                const statusModalTitle = document.getElementById('statusModalTitle');
                if (statusModalTitle) statusModalTitle.innerHTML = `<i class="fas fa-info-circle me-2"></i> ${t('spaStatusTitle')}`;
                const statusModalCloseBtn = document.getElementById('statusModalCloseBtn');
                if (statusModalCloseBtn) statusModalCloseBtn.textContent = t('close');
            }, 0);
        };
        // Patch showActiveUsersModal to store last shown data for language update
        const origShowActiveUsersModal = window.showActiveUsersModal;
        window.showActiveUsersModal = function(ips) {
            window._lastActiveIps = ips;
            origShowActiveUsersModal(ips);
        };
    }

    async logout() {
        try {
            // Clear all localStorage items
            localStorage.clear();
            
            // Clear sessionStorage as well
            sessionStorage.clear();
            
            // Send logout request to server
            await fetch('/logout', { method: 'POST' });
            
            // Redirect to login page
            window.location.href = '/login';
            this.showNotification(this.getTranslation('logoutSuccess'), 'success');
        } catch (error) {
            console.error('خطا در خروج:', error);
            this.showNotification(this.getTranslation('connectionError'), 'error');
        }
    }

    toggleMenu() {
        const nav = document.querySelector('.header-nav');
        if (nav) nav.classList.toggle('active');
    }

    updateConnectionStatus(connected) {
        const statusIcon = document.createElement('i');
        statusIcon.className = `fas fa-circle status-icon ${connected ? 'connected' : 'disconnected'}`;
        const existingIcon = document.querySelector('.status-indicator .status-icon');
        if (existingIcon) existingIcon.remove();
        const statusIndicator = document.querySelector('.status-indicator');
        if (statusIndicator) statusIndicator.appendChild(statusIcon);
    }

    updateSystemStatus(data) {
        this.systemStatus.server = data.server_status || 'offline';
        this.systemStatus.camera = data.camera_status || 'offline';
        this.systemStatus.pico = data.pico_status || 'offline';
        this.updateStatusModal();
        console.log('وضعیت سیستم به‌روزرسانی شد:', this.systemStatus);
        
        // به‌روزرسانی وضعیت دستگاه‌ها
        if (data.device_status) {
            this.updateDeviceStatus(data.device_status);
        }
    }
    
    updateDeviceStatus(deviceStatus) {
        // به‌روزرسانی نمایش وضعیت دستگاه‌ها در UI
        const picoStatus = deviceStatus.pico?.online ? 'آنلاین' : 'آفلاین';
        const esp32camStatus = deviceStatus.esp32cam?.online ? 'آنلاین' : 'آفلاین';
        
        // نمایش در کنسول برای debug
        console.log('Device Status:', {
            pico: picoStatus,
            esp32cam: esp32camStatus,
            pico_errors: deviceStatus.pico?.errors?.length || 0,
            esp32cam_errors: deviceStatus.esp32cam?.errors?.length || 0
        });
        
        // اگر دستگاه‌ها آفلاین هستند، هشدار نمایش بده
        if (!deviceStatus.pico?.online) {
            this.showNotification('پیکو آفلاین است', 'warning');
        }
        if (!deviceStatus.esp32cam?.online) {
            this.showNotification('ESP32-CAM آفلاین است', 'warning');
        }
    }
    
    handleCriticalError(data) {
        console.error('Critical error received:', data);
        this.showNotification(`خطای بحرانی: ${data.message}`, 'error');
        
        // نمایش modal خطا
        this.showErrorModal({
            title: 'خطای بحرانی سیستم',
            message: data.message,
            source: data.source,
            timestamp: data.timestamp
        });
        
        // ارسال لاگ به سرور
        this.logErrorToServer('critical_error', data);
    }
    
    async logErrorToServer(type, data) {
        try {
            await fetch('/api/v1/log_error', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    type: type,
                    data: data,
                    timestamp: new Date().toISOString(),
                    user_agent: navigator.userAgent
                })
            });
        } catch (error) {
            console.error('Failed to log error to server:', error);
        }
    }

    updateStatusModal() {
        const wsStatus = document.getElementById('wsStatus');
        const serverStatus = document.getElementById('serverStatus');
        const cameraStatus = document.getElementById('cameraStatus');
        const picoStatus = document.getElementById('picoStatus');
        const dbStatus = document.getElementById('dbStatus');
        const internetStatus = document.getElementById('internetStatus');
        const storageStatus = document.getElementById('storageStatus');
        // Helper to set class based on value
        function setStatusClass(el, status) {
            if (!el) return;
            el.classList.remove('status-success', 'status-error', 'status-warning');
            if (["connected","online","متصل","آنلاین"].includes(status)) el.classList.add('status-success');
            else if (["disconnected","offline","قطع","آفلاین","خاموش"].includes(status)) el.classList.add('status-error');
            else el.classList.add('status-warning');
        }
        if (wsStatus) {
            const val = this.language === 'fa' ? (this.systemStatus.websocket === 'connected' ? 'متصل' : 'قطع') : this.systemStatus.websocket;
            wsStatus.textContent = val;
            setStatusClass(wsStatus, this.systemStatus.websocket === 'connected' ? 'connected' : 'disconnected');
        }
        if (serverStatus) {
            const val = this.language === 'fa' ? (this.systemStatus.server === 'online' ? 'آنلاین' : 'آفلاین') : this.systemStatus.server;
            serverStatus.textContent = val;
            setStatusClass(serverStatus, this.systemStatus.server === 'online' ? 'online' : 'offline');
        }
        if (cameraStatus) {
            const val = this.language === 'fa' ? (this.systemStatus.camera === 'online' ? 'آنلاین' : 'آفلاین') : this.systemStatus.camera;
            cameraStatus.textContent = val;
            setStatusClass(cameraStatus, this.systemStatus.camera === 'online' ? 'online' : 'offline');
        }
        if (picoStatus) {
            const val = this.language === 'fa' ? (this.systemStatus.pico === 'online' ? 'آنلاین' : 'آفلاین') : this.systemStatus.pico;
            picoStatus.textContent = val;
            setStatusClass(picoStatus, this.systemStatus.pico === 'online' ? 'online' : 'offline');
        }
        if (dbStatus) {
            const val = this.systemStatus.db || (this.language === 'fa' ? 'نامشخص' : 'Unknown');
            dbStatus.textContent = val;
            setStatusClass(dbStatus, val);
        }
        if (internetStatus) {
            const val = this.systemStatus.internet || (this.language === 'fa' ? 'نامشخص' : 'Unknown');
            internetStatus.textContent = val;
            setStatusClass(internetStatus, val);
        }
        if (storageStatus) {
            const val = this.systemStatus.storage || (this.language === 'fa' ? 'نامشخص' : 'Unknown');
            storageStatus.textContent = val;
            setStatusClass(storageStatus, val);
        }
    }

    updateStreamFrame(data, resolution) {
        try {
            const video = document.getElementById('streamVideo');
            if (video && this.isStreaming) {
                // بهینه‌سازی real-time با مدیریت حافظه پیشرفته
                const previousUrl = video.dataset.previousUrl;
                
                // پاک کردن URL قبلی فوری برای جلوگیری از memory leak
                if (previousUrl) {
                    URL.revokeObjectURL(previousUrl);
                }
                
                // ایجاد URL جدید با بهینه‌سازی
                const url = `data:image/jpeg;base64,${data}`;
                video.src = url;
                video.dataset.previousUrl = url;
                
                // تنظیم resolution با بهینه‌سازی
                if (resolution) {
                    const currentWidth = video.style.width;
                    const currentHeight = video.style.height;
                    const newWidth = `${resolution.width}px`;
                    const newHeight = `${resolution.height}px`;
                    
                    // فقط در صورت تغییر، style را به‌روزرسانی کن
                    if (currentWidth !== newWidth || currentHeight !== newHeight) {
                        video.style.width = newWidth;
                        video.style.height = newHeight;
                    }
                }
                
                // پاک کردن URL با تاخیر کمتر برای real-time بهتر
                setTimeout(() => {
                    if (video.dataset.previousUrl === url && video.src !== url) {
                        URL.revokeObjectURL(url);
                        delete video.dataset.previousUrl;
                    }
                }, 3000);  // کاهش از 5 ثانیه به 3 ثانیه
                
                // بهینه‌سازی حافظه اضافی
                if (this.frameUpdateCount % 100 === 0) {  // هر 100 فریم
                    this.cleanupMemory();
                }
                this.frameUpdateCount = (this.frameUpdateCount || 0) + 1;
            }
        } catch (error) {
            console.error('خطا در به‌روزرسانی فریم:', error);
        }
    }
    
    cleanupMemory() {
        try {
            // اجرای garbage collection در صورت امکان
            if (window.gc) {
                window.gc();
            }
            
            // پاک کردن cache اضافی
            if ('caches' in window) {
                caches.keys().then(names => {
                    names.forEach(name => {
                        if (name.includes('image') || name.includes('video')) {
                            caches.delete(name);
                        }
                    });
                }).catch(e => {
                    console.warn('Error cleaning caches:', e);
                });
            }
            
            // پاک کردن object URLs اضافی
            if (this.objectUrls) {
                this.objectUrls.forEach(url => {
                    try {
                        URL.revokeObjectURL(url);
                    } catch (e) {
                        console.warn('Error revoking URL:', e);
                    }
                });
                this.objectUrls = [];
            }
            
            // پاک کردن event listeners اضافی
            if (this.cleanupCallbacks) {
                this.cleanupCallbacks.forEach(callback => {
                    try {
                        callback();
                    } catch (e) {
                        console.warn('Error in cleanup callback:', e);
                    }
                });
            }
            
            // پاک کردن video elements اضافی
            const videos = document.querySelectorAll('video');
            videos.forEach(video => {
                if (video.src && video.src.startsWith('blob:')) {
                    try {
                        URL.revokeObjectURL(video.src);
                        video.removeAttribute('src');
                        video.load();
                    } catch (e) {
                        console.warn('Error cleaning up video:', e);
                    }
                }
            });
            
            // پاک کردن image elements اضافی
            const images = document.querySelectorAll('img');
            images.forEach(img => {
                if (img.src && img.src.startsWith('blob:')) {
                    try {
                        URL.revokeObjectURL(img.src);
                    } catch (e) {
                        console.warn('Error cleaning up image:', e);
                    }
                }
            });
            
            // پاک کردن WebSocket connections اضافی
            if (this.ws && this.ws.readyState === WebSocket.CLOSED) {
                this.ws = null;
            }
            
            // پاک کردن fetch requests اضافی
            if (window.activeRequests) {
                for (const [key, controller] of window.activeRequests.entries()) {
                    try {
                        controller.abort();
                    } catch (e) {
                        console.warn('Error aborting request:', e);
                    }
                }
                window.activeRequests.clear();
            }
            
            // پاک کردن timeouts اضافی
            if (this.cleanupTimeouts) {
                this.cleanupTimeouts.forEach(timeoutId => {
                    try {
                        clearTimeout(timeoutId);
                    } catch (e) {
                        console.warn('Error clearing timeout:', e);
                    }
                });
                this.cleanupTimeouts = [];
            }
            
            // پاک کردن intervals اضافی
            if (this.cleanupIntervals) {
                this.cleanupIntervals.forEach(intervalId => {
                    try {
                        clearInterval(intervalId);
                    } catch (e) {
                        console.warn('Error clearing interval:', e);
                    }
                });
                this.cleanupIntervals = [];
            }
            
        } catch (error) {
            console.warn('خطا در پاک‌سازی حافظه:', error);
        }
    }

    handlePhotoCaptured(data) {
        this.showNotification(this.getTranslation('photoCaptured'), 'success');
        this.currentPage = 0;
        document.getElementById('galleryContainer').innerHTML = '';
        this.loadGallery();
    }

    handleVideoCreated(data) {
        this.showNotification(this.language === 'fa' ? 'ویدئو جدید ایجاد شد' : 'New video created', 'success');
        // بازنشانی گالری ویدیوها
        this.currentVideoPage = 0;
        const videosContainer = document.getElementById('videosContainer');
        if (videosContainer) {
            videosContainer.innerHTML = '';
            this.loadVideos();
        }
    }

    async loadInitialData() {
        try {
            await Promise.all([this.loadGallery(), this.loadVideos()]); // حذف loadLogs از اینجا
        } catch (error) {
            console.error('خطا در بارگذاری داده‌های اولیه:', error);
            this.showNotification(this.getTranslation('connectionError'), 'error');
        }
    }

    startStatusUpdates() {
        // دیگر نیازی به ارسال ping یا get_frame با WebSocket نیست
        // اگر نیاز به آپدیت وضعیت باشد، می‌توان با fetch به /get_status این کار را انجام داد
        // setInterval(() => {
        //     fetch('/get_status').then(...)
        // }, 30000);
    }

    loadMorePhotos() {
        this.loadGallery();
    }

    loadMoreVideos() {
        if (!this.isLoading) {
            this.loadVideos();
        }
    }

    showNotification(messageKey, type, details) {
        const message = this.getTranslation(messageKey, messageKey);
        if (window.isReloading || document.readyState !== 'complete' || !window.system || !window.system.websocket) return;
        if (type === 'error' && this.websocket && this.websocket.readyState === 1) {
            return;
        }
        if (type === 'error') {
            if (this.activeErrorNotification) return;
        }
        document.querySelectorAll('.notification.notification-' + type).forEach(n => n.remove());
        let extraInfo = '';
        if (type === 'error') {
            const now = new Date();
            extraInfo += `<div style='font-size:0.92em;margin-top:4px;'><b>⏰ زمان:</b> ${now.toLocaleString('fa-IR')}<br/>`;
            extraInfo += `<b>WebSocket:</b> ${this.websocket ? this.websocket.readyState : 'N/A'}<br/>`;
            extraInfo += `<b>navigator.onLine:</b> ${navigator.onLine ? 'آنلاین' : 'آفلاین'}<br/>`;
            if (details && details.event) {
                extraInfo += `<b>event.type:</b> ${details.event.type || '-'}<br/>`;
                extraInfo += `<b>event:</b> ${JSON.stringify(details.event)}<br/>`;
            }
            if (details && details.stack) {
                extraInfo += `<b>Stack:</b> <pre style='white-space:pre-wrap;direction:ltr;'>${details.stack}</pre>`;
            }
            extraInfo += `</div>`;
        }
        if (type === 'error' && details) {
            this.showErrorModal(details);
        }
        const notification = document.createElement('div');
        notification.className = `notification notification-${type} animate__animated animate__fadeIn`;
        notification.innerHTML = `
            <span>${message}</span>
            ${extraInfo}
            <button class="notification-close"><i class="fas fa-times"></i></button>
        `;
        document.body.appendChild(notification);
        if (type === 'error') {
            this.activeErrorNotification = notification;
        }
        notification.querySelector('.notification-close').onclick = () => {
                notification.remove();
            if (type === 'error') this.activeErrorNotification = null;
        };
            setTimeout(() => {
            notification.classList.add('animate__fadeOut');
            setTimeout(() => notification.remove(), 500);
        }, 4000);
    }

    showErrorModal(details) {
        let modal = document.getElementById('errorModal');
        if (!modal) {
            modal = document.createElement('div');
            modal.className = 'modal fade';
            modal.id = 'errorModal';
            modal.tabIndex = -1;
            modal.innerHTML = `
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header bg-danger text-white">
                            <h5 class="modal-title"><i class="fas fa-exclamation-triangle me-2"></i> ${this.getTranslation('connectionError')}</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-2"><b>${this.language === 'fa' ? 'منبع' : 'Source'}:</b> ${details.source || '-'}</div>
                            <div class="mb-2"><b>${this.language === 'fa' ? 'کد خطا' : 'Error Code'}:</b> ${details.code || '-'}</div>
                            <div class="mb-2"><b>${this.language === 'fa' ? 'پیام' : 'Message'}:</b> ${details.message || '-'}</div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">${this.language === 'fa' ? 'بستن' : 'Close'}</button>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
        } else {
            modal.querySelector('.modal-title').innerHTML = `<i class="fas fa-exclamation-triangle me-2"></i> ${this.getTranslation('connectionError')}`;
            modal.querySelector('.modal-body').innerHTML = `
                <div class="mb-2"><b>${this.language === 'fa' ? 'منبع' : 'Source'}:</b> ${details.source || '-'}</div>
                <div class="mb-2"><b>${this.language === 'fa' ? 'کد خطا' : 'Error Code'}:</b> ${details.code || '-'}</div>
                <div class="mb-2"><b>${this.language === 'fa' ? 'پیام' : 'Message'}:</b> ${details.message || '-'}</div>
            `;
        }
        const bsModal = new bootstrap.Modal(modal);
        bsModal.show();
    }

    updateStreamButton() {
        const btn = document.getElementById('toggleStreamBtn');
        if (!btn) return;
        if (this.isStreaming) {
            btn.innerHTML = `<i class="fas fa-stop me-2"></i> ${this.getTranslation('streamStopped')}`;
            btn.classList.add('btn-danger');
            btn.classList.remove('btn-success');
        } else {
            btn.innerHTML = `<i class="fas fa-play me-2"></i> ${this.getTranslation('streamStarted')}`;
            btn.classList.add('btn-success');
            btn.classList.remove('btn-danger');
        }
    }

    // --- تابع جدید برای ترجمه labelها و valueها در لاگ و وضعیت ---
    translateLogDetailLabels() {
        document.querySelectorAll('.log-detail-key').forEach(el => {
            let txt = el.textContent.replace(':','').trim();
            el.textContent = this.getTranslation(txt, txt) + ':';
        });
    }
    translateStatusLabels() {
        // ترجمه labelهای وضعیت (status-value و status-label)
        const statusMap = {
            'fa': {
                'Online': 'آنلاین', 'Offline': 'آفلاین', 'Connected': 'متصل', 'Disconnected': 'قطع',
                'RAM': 'رم', 'CPU': 'سی‌پی‌یو', 'Storage': 'فضای ذخیره‌سازی', 'Internet': 'اینترنت', 'Camera': 'دوربین', 'Pico': 'پیکو'
            },
            'en': {
                'آنلاین': 'Online', 'آفلاین': 'Offline', 'متصل': 'Connected', 'قطع': 'Disconnected',
                'رم': 'RAM', 'سی‌پی‌یو': 'CPU', 'فضای ذخیره‌سازی': 'Storage', 'اینترنت': 'Internet', 'دوربین': 'Camera', 'پیکو': 'Pico'
            }
        };
        document.querySelectorAll('.status-label').forEach(el => {
            const txt = el.textContent.trim();
            if (this.language === 'fa' && statusMap['fa'][txt]) el.textContent = statusMap['fa'][txt];
            if (this.language === 'en' && statusMap['en'][txt]) el.textContent = statusMap['en'][txt];
        });
        document.querySelectorAll('.status-value').forEach(el => {
            const txt = el.textContent.trim();
            if (this.language === 'fa' && statusMap['fa'][txt]) el.textContent = statusMap['fa'][txt];
            if (this.language === 'en' && statusMap['en'][txt]) el.textContent = statusMap['en'][txt];
        });
    }
    // --- تابع جدید برای ترجمه سطح لاگ (log-level-label) بعد از تغییر زبان ---
    translateLogLevelLabels() {
        document.querySelectorAll('.log-level-label').forEach(el => {
            let txt = el.textContent.trim();
            // Try to find the translation key for this label
            let key = txt;
            // Map Persian to English keys if needed
            const faToEn = {
                'دستور': 'command',
                'عکس': 'photo',
                'حذف': 'delete',
                'خطا': 'error',
                'اطلاعات': 'info',
                'هشدار': 'warning',
                'اتصال': 'connection',
                'ویدئو': 'video',
                'پشتیبان': 'backup',
                'حرکت': 'motion',
                'خروج': 'logout',
            };
            if (this.language === 'en' && faToEn[txt]) key = faToEn[txt];
            el.textContent = this.getTranslation('logLevel_' + key, key.charAt(0).toUpperCase() + key.slice(1));
        });
    }
}

// --- Fix footer nav button listeners for mobile ---
document.addEventListener('DOMContentLoaded', () => {
    const system = new SmartCameraSystem();
    // Remove all hamburger/menu logic
    // ...
    // Setup theme/lang button listeners for desktop header
    const themeBtn = document.getElementById('themeToggle');
    const langBtn = document.getElementById('languageToggle');
    if (themeBtn) themeBtn.addEventListener('click', (e) => { e.preventDefault(); system.toggleTheme(); });
    if (langBtn) langBtn.addEventListener('click', (e) => { e.preventDefault(); system.toggleLanguage(); });
    // Setup theme/lang button listeners for mobile footer
    const footerThemeBtn = document.getElementById('footerThemeBtn');
    const footerLangBtn = document.getElementById('footerLangBtn');
    if (footerThemeBtn) footerThemeBtn.addEventListener('click', (e) => { e.preventDefault(); system.toggleTheme(); });
    if (footerLangBtn) footerLangBtn.addEventListener('click', (e) => { e.preventDefault(); system.toggleLanguage(); });
    // Setup footer nav SPA navigation
    const footerHomeBtn = document.getElementById('footerHomeBtn');
    const footerStatusBtn = document.getElementById('footerStatusBtn');
    const footerStoreBtn = document.getElementById('footerStoreBtn');
    if (footerHomeBtn) footerHomeBtn.addEventListener('click', (e) => { e.preventDefault(); if (typeof showHomePage === 'function') showHomePage(); });
    if (footerStatusBtn) footerStatusBtn.addEventListener('click', (e) => { e.preventDefault(); if (typeof showStatusPage === 'function') showStatusPage(); });
    if (footerStoreBtn) footerStoreBtn.addEventListener('click', (e) => { e.preventDefault(); if (typeof showStorePage === 'function') showStorePage(); });
    // Responsive: show/hide header buttons on resize
    function updateHeaderButtons() {
        const themeBtn = document.getElementById('themeToggle');
        const langBtn = document.getElementById('languageToggle');
        if (window.innerWidth < 992) {
            if (themeBtn) themeBtn.style.display = 'none';
            if (langBtn) langBtn.style.display = 'none';
        } else {
            if (themeBtn) themeBtn.style.display = '';
            if (langBtn) langBtn.style.display = '';
        }
    }
    window.addEventListener('resize', updateHeaderButtons);
    updateHeaderButtons();
    // On language/theme change, update icons/text in desktop header
    if (window.system) window.system.updateLanguage(window.system.language);
    // ... existing SPA init ...
    showHomePage();
    if (typeof system.init === 'function') {
        system.init();
    } else {
        system.setupEventListeners();
    }
});

// --- Add event listener for Profile button ---
document.addEventListener('DOMContentLoaded', () => {
    // ... existing code ...
    const footerProfileBtn = document.getElementById('footerProfileBtn');
    if (footerProfileBtn) footerProfileBtn.addEventListener('click', (e) => {
        e.preventDefault();
        // هیچ عملی انجام نشود (صفحه یا مودال پروفایل حذف شده است)
    });
});

// --- Smart Motion/Tracking State Management ---
function getSmartMotionState() {
    return JSON.parse(localStorage.getItem('smartMotionState') || '{"motion":false,"tracking":false}');
}
function setSmartMotionState(state) {
    localStorage.setItem('smartMotionState', JSON.stringify(state));
}
async function sendSmartFeaturesToServer(state) {
    console.log('Sending to server:', state);
    try {
        await fetch('/set_smart_features', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(state)
        });
    } catch (e) { console.error('Failed to send to server', e); }
}
async function fetchSmartFeaturesFromServer() {
    try {
        const res = await fetch('/get_smart_features');
        if (res.ok) {
            const data = await res.json();
            if (data.status === 'success') {
                const state = { motion: !!data.motion, tracking: !!data.tracking };
                setSmartMotionState(state);
                updateSmartMotionToggles();
            }
        }
    } catch (e) { /* ignore */ }
}
function updateSmartMotionToggles() {
    const state = getSmartMotionState();
    // Desktop
    const motionDesktop = document.getElementById('motionDetectToggleDesktop');
    const trackingDesktop = document.getElementById('objectTrackingToggleDesktop');
    if (motionDesktop) motionDesktop.checked = !!state.motion;
    if (trackingDesktop) trackingDesktop.checked = !!state.tracking;
    // Mobile
    const motionMobile = document.getElementById('motionDetectToggleMobile');
    const trackingMobile = document.getElementById('objectTrackingToggleMobile');
    if (motionMobile) motionMobile.checked = !!state.motion;
    if (trackingMobile) trackingMobile.checked = !!state.tracking;
}
function setupSmartMotionToggleListeners() {
    // Desktop
    const motionDesktop = document.getElementById('motionDetectToggleDesktop');
    const trackingDesktop = document.getElementById('objectTrackingToggleDesktop');
    // Mobile
    const motionMobile = document.getElementById('motionDetectToggleMobile');
    const trackingMobile = document.getElementById('objectTrackingToggleMobile');
    if (motionDesktop) motionDesktop.addEventListener('change', async (e) => {
        const state = getSmartMotionState();
        state.motion = e.target.checked;
        console.log('[SMART_FEATURES] motionDesktop toggled:', state);
        setSmartMotionState(state);
        updateSmartMotionToggles();
        await sendSmartFeaturesToServer(state);
        if (window.system && typeof window.system.showNotification === 'function') {
            window.system.showNotification(
                e.target.checked ?
                    (window.system.language === 'fa' ? 'تشخیص حرکت فعال شد' : 'Motion detection enabled') :
                    (window.system.language === 'fa' ? 'تشخیص حرکت غیرفعال شد' : 'Motion detection disabled'),
                'info');
        }
    });
    if (trackingDesktop) trackingDesktop.addEventListener('change', async (e) => {
        const state = getSmartMotionState();
        state.tracking = e.target.checked;
        console.log('[SMART_FEATURES] trackingDesktop toggled:', state);
        setSmartMotionState(state);
        updateSmartMotionToggles();
        await sendSmartFeaturesToServer(state);
        if (window.system && typeof window.system.showNotification === 'function') {
            window.system.showNotification(
                e.target.checked ?
                    (window.system.language === 'fa' ? 'ردیابی هوشمند فعال شد' : 'Object tracking enabled') :
                    (window.system.language === 'fa' ? 'ردیابی هوشمند غیرفعال شد' : 'Object tracking disabled'),
                'info');
        }
    });
    if (motionMobile) motionMobile.addEventListener('change', async (e) => {
        const state = getSmartMotionState();
        state.motion = e.target.checked;
        console.log('[SMART_FEATURES] motionMobile toggled:', state);
        setSmartMotionState(state);
        updateSmartMotionToggles();
        await sendSmartFeaturesToServer(state);
        if (window.system && typeof window.system.showNotification === 'function') {
            window.system.showNotification(
                e.target.checked ?
                    (window.system.language === 'fa' ? 'تشخیص حرکت فعال شد' : 'Motion detection enabled') :
                    (window.system.language === 'fa' ? 'تشخیص حرکت غیرفعال شد' : 'Motion detection disabled'),
                'info');
        }
    });
    if (trackingMobile) trackingMobile.addEventListener('change', async (e) => {
        const state = getSmartMotionState();
        state.tracking = e.target.checked;
        console.log('[SMART_FEATURES] trackingMobile toggled:', state);
        setSmartMotionState(state);
        updateSmartMotionToggles();
        await sendSmartFeaturesToServer(state);
        if (window.system && typeof window.system.showNotification === 'function') {
            window.system.showNotification(
                e.target.checked ?
                    (window.system.language === 'fa' ? 'ردیابی هوشمند فعال شد' : 'Object tracking enabled') :
                    (window.system.language === 'fa' ? 'ردیابی هوشمند غیرفعال شد' : 'Object tracking disabled'),
                'info');
        }
    });
}
// --- Patch logs accordion and status SPA to call update/setup on render ---
const origLoadLogs = window.system && window.system.loadLogs ? window.system.loadLogs.bind(window.system) : null;
if (origLoadLogs) {
    window.system.loadLogs = async function() {
        await origLoadLogs();
        updateSmartMotionToggles();
        setupSmartMotionToggleListeners();
    };
}
// Patch showStatusPage to inject toggles at top
const origShowStatusPage = typeof showStatusPage === 'function' ? showStatusPage : null;
window.showStatusPage = function() {
    if (origShowStatusPage) origShowStatusPage();
};
// On DOMContentLoaded, also update toggles for desktop logs accordion
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', async () => {
        await fetchSmartFeaturesFromServer();
        updateSmartMotionToggles();
        setupSmartMotionToggleListeners();
    });
} else {
    fetchSmartFeaturesFromServer().then(() => {
    updateSmartMotionToggles();
    setupSmartMotionToggleListeners();
    });
}
// ... existing code ...

// ... existing code ...
function saveSmartSwitchState() {
  const state = {
    motion: !!document.getElementById('motionDetectToggleDesktop')?.checked,
    tracking: !!document.getElementById('objectTrackingToggleDesktop')?.checked
  };
  localStorage.setItem('smartSwitchState', JSON.stringify(state));
}
function loadSmartSwitchState() {
  const state = JSON.parse(localStorage.getItem('smartSwitchState') || '{}');
  if (typeof state.motion !== 'undefined') {
    const el = document.getElementById('motionDetectToggleDesktop');
    if (el) el.checked = !!state.motion;
    const elMobile = document.getElementById('motionDetectToggleMobile');
    if (elMobile) elMobile.checked = !!state.motion;
  }
  if (typeof state.tracking !== 'undefined') {
    const el = document.getElementById('objectTrackingToggleDesktop');
    if (el) el.checked = !!state.tracking;
    const elMobile = document.getElementById('objectTrackingToggleMobile');
    if (elMobile) elMobile.checked = !!state.tracking;
  }
}
document.addEventListener('DOMContentLoaded', function() {
  loadSmartSwitchState();
  const motionDesktop = document.getElementById('motionDetectToggleDesktop');
  const trackingDesktop = document.getElementById('objectTrackingToggleDesktop');
  const motionMobile = document.getElementById('motionDetectToggleMobile');
  const trackingMobile = document.getElementById('objectTrackingToggleMobile');
  if (motionDesktop) motionDesktop.addEventListener('change', saveSmartSwitchState);
  if (trackingDesktop) trackingDesktop.addEventListener('change', saveSmartSwitchState);
  if (motionMobile) motionMobile.addEventListener('change', saveSmartSwitchState);
  if (trackingMobile) trackingMobile.addEventListener('change', saveSmartSwitchState);
});
// ... existing code ...

// ... existing code ...
// اطمینان از تعریف global برای system
window.system = window.system || null;

// ... existing code ...
// تعریف تابع خالی برای جلوگیری از خطا
function updateStatusPage() {}
// ... existing code ...

// ... existing code ...
// --- SPA navigation helpers (بازگردانی شده) ---
function hideAllSpaPages() {
    document.querySelectorAll('.spa-page').forEach(page => page.style.display = 'none');
    // همچنین آکاردئون اصلی را نمایش بده
    const mainPanel = document.querySelector('.main-panel');
    if (mainPanel) mainPanel.style.display = '';
}
// تابع مشترک بازگشت به خانه از هر SPA
function goHomeFromSpa() {
    document.querySelectorAll('.spa-page').forEach(page => page.remove());
    if (window.statusPageInterval) {
        clearInterval(window.statusPageInterval);
        window.statusPageInterval = null;
    }
    const mainPanel = document.querySelector('.main-panel');
    if (mainPanel) mainPanel.style.display = '';
}
function showHomePage() {
    goHomeFromSpa();
}
let statusPageInterval = null;
function showStatusPage() {
    hideAllSpaPages();
    let oldStatusPage = document.getElementById('statusSpaPage');
    if (oldStatusPage) oldStatusPage.remove();
    let statusPage = document.createElement('div');
    statusPage.id = 'statusSpaPage';
    statusPage.className = 'spa-page status-page';
    statusPage.innerHTML = `
        <div class="status-card">
            <h2 id="spaStatusTitle"></h2>
            <ul id="spaStatusList"></ul>
            <button id="spaActiveUsersBtn" class="btn btn-outline-info mt-2"><i class="fas fa-users"></i> <span id="spaActiveUsersText"></span></button>
            <button id="spaBackBtn" class="btn btn-outline-primary mt-3"><i class="fas fa-arrow-right rtl-arrow"></i> <span id="spaBackText"></span></button>
        </div>
        <div id="spaActiveIpsModal" class="modal fade" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="fas fa-users"></i> <span id="spaActiveIpsModalTitle"></span></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" id="spaActiveIpsModalBody" style="max-height:350px;overflow-y:auto;padding:0.5rem 0.5rem 0.5rem 0.5rem;"></div>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(statusPage);
    statusPage.style.display = 'flex';
    const mainPanel = document.querySelector('.main-panel');
    if (mainPanel) mainPanel.style.display = 'none';
    const lang = localStorage.getItem('language') || 'fa';
    // Use translations for the title and other texts
    const translations = (window.translations && window.translations[lang]) ? window.translations[lang] : {};
    document.getElementById('spaStatusTitle').textContent = translations.spaStatusTitle || (lang === 'fa' ? 'وضعیت سیستم' : 'System Status');
    document.getElementById('spaBackText').textContent = translations.spaBackText || (lang === 'fa' ? 'بازگشت' : 'Back');
    document.getElementById('spaActiveUsersText').textContent = translations.spaActiveUsers || (lang === 'fa' ? 'کاربران فعال' : 'Active Users');
    document.getElementById('spaActiveIpsModalTitle').textContent = translations.spaActiveUsers || (lang === 'fa' ? 'کاربران فعال' : 'Active Users');
    document.getElementById('spaBackBtn').onclick = goHomeFromSpa;
    document.getElementById('spaActiveUsersBtn').onclick = () => {
        const modal = new bootstrap.Modal(document.getElementById('spaActiveIpsModal'));
        modal.show();
    };
    function updateStatusPageData() {
        fetch('/get_status').then(r => r.json()).then(data => {
            if (data && data.data) {
                const statusList = document.getElementById('spaStatusList');
                statusList.innerHTML = '';
                const statusFields = [
                    { key: 'server_status', icon: 'fa-server', label: { fa: 'سرور', en: 'Server' } },
                    { key: 'camera_status', icon: 'fa-video', label: { fa: 'دوربین', en: 'Camera' } },
                    { key: 'pico_status', icon: 'fa-microchip', label: { fa: 'پیکو', en: 'Pico' } },
                    { key: 'internet', icon: 'fa-globe', label: { fa: 'اینترنت', en: 'Internet' } },
                    { key: 'storage', icon: 'fa-hdd', label: { fa: 'فضای ذخیره‌سازی', en: 'Storage' } },
                    { key: 'ram_percent', icon: 'fa-memory', label: { fa: 'درصد RAM', en: 'RAM %' } },
                    { key: 'cpu_percent', icon: 'fa-microchip', label: { fa: 'درصد CPU', en: 'CPU %' } },
                ];
                statusFields.forEach(field => {
                    let val = data.data[field.key];
                    let showVal = val;
                    let statusClass = '';
                    if (field.key.endsWith('_status') || field.key === 'internet') {
                        if (lang === 'fa') {
                            showVal = val === 'online' ? 'آنلاین' : val === 'offline' ? 'آفلاین' : val;
                        }
                        statusClass = (val === 'online' || val === 'connected') ? 'status-success' : (val === 'offline' || val === 'disconnected') ? 'status-error' : 'status-warning';
                    } else if (field.key === 'ram_percent' || field.key === 'cpu_percent') {
                        if (val !== undefined && val !== null) {
                            showVal = val + '%';
                            statusClass = val < 70 ? 'status-success' : val < 90 ? 'status-warning' : 'status-error';
                        } else {
                            showVal = lang === 'fa' ? 'نامشخص' : 'Unknown';
                            statusClass = 'status-warning';
                        }
                    } else if (field.key === 'storage') {
                        if (val && typeof val === 'string' && val.match(/\d+\.\d+%/)) {
                            showVal = val;
                            statusClass = parseFloat(val) > 20 ? 'status-success' : 'status-warning';
                        } else {
                            showVal = lang === 'fa' ? 'نامشخص' : 'Unknown';
                            statusClass = 'status-warning';
                        }
                    }
                    statusList.innerHTML += `
                        <li><i class="fas ${field.icon}"></i> ${field.label[lang]}: <span class="status-value ${statusClass}">${showVal ?? (lang === 'fa' ? 'نامشخص' : 'Unknown')}</span></li>
                    `;
                });
                const ips = data.data.active_ips || [];
                const modalBody = document.getElementById('spaActiveIpsModalBody');
                if (ips.length) {
                    let html = '<div style="display:flex;flex-direction:column;gap:10px;">';
                    ips.forEach(ip => {
                        html += `<div style="border:1px solid #eee;border-radius:10px;padding:8px 10px 8px 10px;margin-bottom:0;box-shadow:0 2px 8px rgba(0,0,0,0.04);font-size:0.98em;word-break:break-all;overflow-wrap:anywhere;">
                            <div style="display:flex;align-items:center;gap:6px;"><i class='fas fa-network-wired'></i> <b>${lang === 'fa' ? 'آی‌پی' : 'IP'}:</b> <span>${ip.ip}</span></div>
                            <div style="display:flex;align-items:center;gap:6px;"><i class='fas fa-clock'></i> <b>${lang === 'fa' ? 'زمان اتصال' : 'Connect Time'}:</b> <span>${new Date(ip.connect_time).toLocaleString(lang === 'fa' ? 'fa-IR' : 'en-US')}</span></div>
                            <div style="display:flex;align-items:center;gap:6px;"><i class='fas fa-history'></i> <b>${lang === 'fa' ? 'آخرین فعالیت' : 'Last Activity'}:</b> <span>${new Date(ip.last_activity).toLocaleString(lang === 'fa' ? 'fa-IR' : 'en-US')}</span></div>
                            <div style="display:flex;align-items:center;gap:6px;"><i class='fas fa-desktop'></i> <b>User-Agent:</b> <span style="font-size:0.93em;max-width:180px;display:inline-block;white-space:nowrap;overflow-x:auto;">${ip.user_agent || '-'}</span></div>
                        </div>`;
                    });
                    html += '</div>';
                    modalBody.innerHTML = html;
                } else {
                    modalBody.innerHTML = `<span>${lang === 'fa' ? 'هیچ کاربر فعالی وجود ندارد.' : 'No active users.'}</span>`;
                }
            }
        });
    }
    updateStatusPageData();
    window.statusPageInterval = setInterval(updateStatusPageData, 5000);
}

// ... existing code ...
// Typewriter header
function runHeaderTypewriter() {
    const el = document.getElementById('headerTypewriter');
    if (!el) return;
    const lang = document.documentElement.lang || (document.body.classList.contains('lang-en') ? 'en' : 'fa');
    // Use translations if available, else fallback
    let messages = (window.translations && window.translations[lang] && window.translations[lang]['typewriterHeader']) || null;
    if (!messages || !Array.isArray(messages) || messages.length === 0) {
        messages = lang === 'fa' ? [
            'امنیت هوشمند، آینده‌ای مطمئن 🛡️',
            'نظارت زنده، آرامش خاطر 👁️',
            'هوش مصنوعی در خدمت امنیت شما 🤖',
            'حفاظت ۲۴/۷ با فناوری نوین 🔒',
            'کنترل سریع، واکنش هوشمند ⚡',
            'دسترسی آسان از هر نقطه 🌐',
            'ثبت لحظات مهم امنیتی 📸',
            'امنیت خانه و محل کار شما 🛡️',
            'اتصال پایدار و بی‌وقفه 🛰️'
        ] : [
            'Smart Security, Confident Future 🛡️',
            'Live Monitoring, Peace of Mind 👁️',
            'AI-Powered Protection 🤖',
            '24/7 Safety with Innovation 🔒',
            'Fast Control, Smart Response ⚡',
            'Easy Access, Anywhere 🌐',
            'Capture Every Security Moment 📸',
            'Protecting Home & Business 🛡️',
            'Reliable, Uninterrupted Connection 🛰️'
        ];
    }
    let msgIdx = 0;
    let i = 0;
    let typing = true;
    let cursor = document.createElement('span');
    cursor.className = 'typewriter-cursor';
    cursor.textContent = '|';
    cursor.style.direction = (lang === 'fa') ? 'rtl' : 'ltr';
    el.textContent = '';
    el.dir = (lang === 'fa') ? 'rtl' : 'ltr';
    el.appendChild(cursor);
    if (!el.firstChild || el.firstChild.nodeType !== 3) {
        el.insertBefore(document.createTextNode(''), cursor);
    }
    if (window.headerTypewriterTimeout) {
        clearTimeout(window.headerTypewriterTimeout);
        window.headerTypewriterTimeout = null;
    }
    function type() {
        const text = messages[msgIdx];
        if (typing) {
            if (i <= text.length) {
                el.childNodes[0].textContent = text.slice(0, i);
                i++;
                window.headerTypewriterTimeout = setTimeout(type, lang === 'fa' ? 38 : 28);
            } else {
                typing = false;
                window.headerTypewriterTimeout = setTimeout(type, 1200);
            }
        } else {
            if (i > 0) {
                el.childNodes[0].textContent = text.slice(0, i);
                i--;
                window.headerTypewriterTimeout = setTimeout(type, 18);
            } else {
                el.childNodes[0].textContent = '';
                typing = true;
                msgIdx = (msgIdx + 1) % messages.length;
                window.headerTypewriterTimeout = setTimeout(type, 500);
            }
        }
    }
    if (window.headerTypewriterInterval) clearInterval(window.headerTypewriterInterval);
    window.headerTypewriterInterval = setInterval(() => {
        cursor.style.opacity = cursor.style.opacity === '0' ? '1' : '0';
    }, 480);
    type();
}
function runFooterTypewriter() {
    const el = document.getElementById('footerTypewriter');
    if (!el) return;
    const lang = document.documentElement.lang || (document.body.classList.contains('lang-en') ? 'en' : 'fa');
    let messages = (window.translations && window.translations[lang] && window.translations[lang]['typewriterFooter']) || null;
    if (!messages || !Array.isArray(messages) || messages.length === 0) {
        messages = lang === 'fa'
            ? [
                'امنیت خانه و محل کار با ما! 🏠🔒',
                'پشتیبانی حرفه‌ای و سریع 🚀',
                'دسترسی آسان از هرجا 🌍',
                'گزارش‌های تصویری و آماری 📈',
                'تجربه امنیت هوشمند با هوش مصنوعی 🤖',
                'ارتباط با ما همیشه باز است 📞',
                'به‌روزرسانی خودکار و رایگان 🔄'
            ]
            : [
                'Secure your home & business! 🏠🔒',
                'Fast & professional support 🚀',
                'Easy access from anywhere 🌍',
                'Visual & statistical reports 📈',
                'Smart security powered by AI 🤖',
                'We are always here for you 📞',
                'Free automatic updates 🔄'
            ];
    }
    let msgIdx = 0;
    let i = 0;
    let typing = true;
    let cursor = document.createElement('span');
    cursor.className = 'typewriter-cursor';
    cursor.textContent = '|';
    cursor.style.direction = (lang === 'fa') ? 'rtl' : 'ltr';
    el.textContent = '';
    el.dir = (lang === 'fa') ? 'rtl' : 'ltr';
    el.appendChild(cursor);
    if (!el.firstChild || el.firstChild.nodeType !== 3) {
        el.insertBefore(document.createTextNode(''), cursor);
    }
    if (window.footerTypewriterTimeout) {
        clearTimeout(window.footerTypewriterTimeout);
        window.footerTypewriterTimeout = null;
    }
    function type() {
        const text = messages[msgIdx];
        if (typing) {
            if (i <= text.length) {
                el.childNodes[0].textContent = text.slice(0, i);
                i++;
                window.footerTypewriterTimeout = setTimeout(type, lang === 'fa' ? 32 : 22);
            } else {
                typing = false;
                window.footerTypewriterTimeout = setTimeout(type, 1200);
            }
        } else {
            if (i > 0) {
                el.childNodes[0].textContent = text.slice(0, i);
                i--;
                window.footerTypewriterTimeout = setTimeout(type, 14);
            } else {
                el.childNodes[0].textContent = '';
                typing = true;
                msgIdx = (msgIdx + 1) % messages.length;
                window.footerTypewriterTimeout = setTimeout(type, 500);
            }
        }
    }
    if (window.footerTypewriterInterval) clearInterval(window.footerTypewriterInterval);
    window.footerTypewriterInterval = setInterval(() => {
        cursor.style.opacity = cursor.style.opacity === '0' ? '1' : '0';
    }, 480);
    type();
}
// ... existing code ...

// ... existing code ...
function setupHeaderHideOnScroll() {
    const header = document.querySelector('.main-header');
    if (!header) return;
    function onScroll() {
        if (window.innerWidth < 992) {
            header.classList.remove('hidden');
            return;
        }
        if (window.scrollY === 0) {
            header.classList.remove('hidden');
        } else {
            header.classList.add('hidden');
        }
    }
    window.addEventListener('scroll', onScroll);
    window.addEventListener('resize', () => {
        if (window.innerWidth < 992) header.classList.remove('hidden');
        else onScroll();
    });
    onScroll(); // اجرا در ابتدا
}
document.addEventListener('DOMContentLoaded', function() {
    runHeaderTypewriter();
    runFooterTypewriter();
    setupHeaderHideOnScroll();
    // ... existing code ...
});
// ... existing code ...

// ... existing code ...
document.addEventListener('DOMContentLoaded', () => {
    // Always scroll to top on page load/refresh
    window.scrollTo(0, 0);
    // ... existing code ...
});

// ... existing code ...
// --- Force scroll to top on every page load/reload, even after SPA or late scripts ---
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        window.scrollTo(0, 0);
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }, 0);
});
window.onload = function() {
    setTimeout(function() {
        window.scrollTo(0, 0);
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }, 0);
};
// ... existing code ...

// ... existing code ...
// --- Only one scroll to top, and disable browser scroll restoration ---
if ('scrollRestoration' in history) {
    history.scrollRestoration = 'manual';
}
document.addEventListener('DOMContentLoaded', function() {
    window.scrollTo(0, 0);
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
});
// ... existing code ...

// ... existing code ...
// --- Status Modal HTML injection (if not present) ---
function ensureStatusModal() {
    if (document.getElementById('statusModal')) return;
    const t = window.system ? window.system.getTranslation.bind(window.system) : (k, f) => f || k;
    const isDark = document.body.classList.contains('dark-mode');
    const modal = document.createElement('div');
    modal.id = 'statusModal';
    modal.className = 'modal fade';
    modal.tabIndex = -1;
    modal.innerHTML = `
        <div class="modal-dialog status-modal-dialog" style="max-width:430px;width:97vw;">
            <div class="modal-content status-modal-content ${isDark ? 'dark' : 'light'}">
                <div class="modal-header status-modal-header ${isDark ? 'dark' : 'light'}">
                    <h5 class="modal-title status-modal-title" id="statusModalTitle" data-key="spaStatusTitle"><i class="fas fa-info-circle me-2"></i> ${t('spaStatusTitle')}</h5>
                    <button type="button" class="status-modal-x-btn" data-bs-dismiss="modal" aria-label="Close" title="${t('close')}">
                        <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="14" cy="14" r="13" fill="${isDark ? '#232b3b' : '#fff'}" stroke="${isDark ? '#4fc3f7' : '#1976d2'}" stroke-width="2"/>
                            <path d="M9 9L19 19M19 9L9 19" stroke="${isDark ? '#4fc3f7' : '#1976d2'}" stroke-width="2.2" stroke-linecap="round"/>
                        </svg>
                    </button>
                </div>
                <div class="modal-body status-modal-body ${isDark ? 'dark' : 'light'}">
                    <ul id="statusModalList" class="status-modal-list" style="list-style:none;padding:0;margin:0 0 10px 0;"></ul>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    // استایل جذاب و مدرن برای مودال وضعیت و دکمه X و لیست
    const style = document.createElement('style');
    style.innerHTML = `
    .status-modal-dialog {
        max-width:430px !important;
        width:97vw !important;
        margin: 2.5rem auto !important;
    }
    .status-modal-content {
        border-radius: 1.4rem;
        box-shadow: 0 8px 32px 0 rgba(25, 118, 210, 0.16), 0 2px 8px 0 rgba(0,0,0,0.10);
        padding: 0.5rem 0.5rem 0.5rem 0.5rem;
        background: linear-gradient(135deg, ${isDark ? '#232b3b' : '#fafdff'} 0%, ${isDark ? '#26334d' : '#e3f0ff'} 100%);
        color: ${isDark ? '#e3f0ff' : '#232b3b'};
        border: none;
        transition: background 0.2s, color 0.2s;
    }
    .status-modal-header {
        border-bottom: none;
        padding: 1.2rem 1.3rem 0.7rem 1.3rem;
        background: transparent;
        display: flex; align-items: center; justify-content: space-between;
        color: ${isDark ? '#4fc3f7' : '#1976d2'};
    }
    .status-modal-title {
        font-size: 1.25rem;
        font-weight: 800;
        letter-spacing: 0.01em;
        color: ${isDark ? '#4fc3f7' : '#1976d2'};
        display: flex; align-items: center;
    }
    .status-modal-x-btn {
        background: none;
        border: none;
        outline: none;
        cursor: pointer;
        padding: 0.1rem;
        border-radius: 50%;
        transition: box-shadow 0.18s, background 0.18s, transform 0.18s;
        box-shadow: 0 2px 8px rgba(25,118,210,0.10);
        display: flex; align-items: center; justify-content: center;
    }
    .status-modal-x-btn:hover, .status-modal-x-btn:focus {
        background: ${isDark ? '#4fc3f7' : '#e3f0ff'};
        box-shadow: 0 4px 16px rgba(25,118,210,0.22);
        transform: scale(1.13) rotate(-8deg);
    }
    .status-modal-x-btn svg { display: block; }
    .status-modal-body {
        padding: 0.9rem 1.3rem 1.3rem 1.3rem;
        font-size: 1.13rem;
        color: ${isDark ? '#e3f0ff' : '#232b3b'};
    }
    .status-modal-list li {
        margin-bottom: 0.85em;
        font-size: 1.13em;
        font-weight: 600;
        border-radius: 0.7em;
        padding: 0.45em 0.7em 0.45em 0.7em;
        display: flex; align-items: center; gap: 0.7em;
        background: ${isDark ? 'rgba(255,255,255,0.03)' : 'rgba(25,118,210,0.04)'};
        box-shadow: 0 1.5px 6px 0 rgba(25,118,210,0.04);
        transition: background 0.18s, box-shadow 0.18s;
    }
    .status-modal-list li:hover {
        background: ${isDark ? 'rgba(79,195,247,0.10)' : 'rgba(25,118,210,0.10)'};
        box-shadow: 0 3px 12px 0 rgba(25,118,210,0.10);
    }
    .status-modal-list .status-label-icon {
        font-size: 1.18em;
        margin-left: 0.18em;
        margin-right: 0.18em;
        vertical-align: middle;
    }
    .status-value {
        font-weight: bold;
        margin-right: 0.3em;
        font-size: 1.09em;
        letter-spacing: 0.01em;
    }
    .status-value.online { color: #43b66e; }
    .status-value.offline { color: #e53935; }
    .status-value.info { color: #1976d2; }
    .status-value.dark.online { color: #4fc3f7; }
    .status-value.dark.offline { color: #ff8a80; }
    .status-value.dark.info { color: #90caf9; }
    @media (max-width: 600px) {
        .status-modal-dialog {
            max-width: 99vw !important;
            margin: 1.2rem auto !important;
        }
        .status-modal-content {
            border-radius: 0.8rem;
            padding: 0.2rem 0.2rem 0.5rem 0.2rem;
        }
        .status-modal-header, .status-modal-body {
            padding-left: 0.7rem; padding-right: 0.7rem;
        }
    }
        `;
    document.head.appendChild(style);
}

// --- Show Status Modal ---
async function showStatusModal() {
    ensureStatusModal();
    const lang = localStorage.getItem('language') || 'fa';
    const modalEl = document.getElementById('statusModal');
    const bsModal = new bootstrap.Modal(modalEl);
    // Clean up overlays on close
    modalEl.removeEventListener('hidden.bs.modal', window._statusModalCleanup);
    window._statusModalCleanup = function() {
        document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
        document.body.classList.remove('modal-open');
        document.body.style.overflow = '';
        document.body.style.paddingRight = '';
    };
    modalEl.addEventListener('hidden.bs.modal', window._statusModalCleanup);
    // Fetch and fill status
    try {
        const res = await fetch('/get_status');
        let d = {};
        if (res.ok) {
            const statusData = await res.json();
            if (statusData.status === 'success' && statusData.data) d = statusData.data;
        }
        const statusList = document.getElementById('statusModalList');
        statusList.innerHTML = '';
        const statusFields = [
            { key: 'server_status', icon: 'fa-server', label: { fa: 'سرور', en: 'Server' } },
            { key: 'camera_status', icon: 'fa-video', label: { fa: 'دوربین', en: 'Camera' } },
            { key: 'pico_status', icon: 'fa-microchip', label: { fa: 'پیکو', en: 'Pico' } },
            { key: 'internet', icon: 'fa-globe', label: { fa: 'اینترنت', en: 'Internet' } },
            { key: 'storage', icon: 'fa-hdd', label: { fa: 'فضای ذخیره‌سازی', en: 'Storage' } },
            { key: 'ram_percent', icon: 'fa-memory', label: { fa: 'درصد RAM', en: 'RAM %' } },
            { key: 'cpu_percent', icon: 'fa-microchip', label: { fa: 'درصد CPU', en: 'CPU %' } },
        ];
        statusFields.forEach(field => {
            let val = d[field.key];
            let showVal = val;
            let statusClass = '';
            if (field.key.endsWith('_status') || field.key === 'internet') {
                if (lang === 'fa') {
                    showVal = val === 'online' ? 'آنلاین' : val === 'offline' ? 'آفلاین' : val;
                } else {
                    showVal = val === 'online' ? 'Online' : val === 'offline' ? 'Offline' : val;
                }
                statusClass = (val === 'online' || val === 'connected') ? 'status-success' : (val === 'offline' || val === 'disconnected') ? 'status-error' : 'status-warning';
            } else if (field.key === 'ram_percent' || field.key === 'cpu_percent') {
                if (val !== undefined && val !== null) {
                    showVal = val + '%';
                    statusClass = val < 70 ? 'status-success' : val < 90 ? 'status-warning' : 'status-error';
                } else {
                    showVal = lang === 'fa' ? 'نامشخص' : 'Unknown';
                    statusClass = 'status-warning';
                }
            } else if (field.key === 'storage') {
                if (val && typeof val === 'string' && val.match(/\d+\.\d+%/)) {
                    showVal = val;
                    statusClass = parseFloat(val) > 20 ? 'status-success' : 'status-warning';
                } else {
                    showVal = lang === 'fa' ? 'نامشخص' : 'Unknown';
                    statusClass = 'status-warning';
                }
            }
            statusList.innerHTML += `
                <li style="margin-bottom:7px;"><i class="fas ${field.icon}"></i> ${field.label[lang]}: <span class="status-value ${statusClass}">${showVal ?? (lang === 'fa' ? 'نامشخص' : 'Unknown')}</span></li>
            `;
        });
        // دکمه کاربران فعال حذف شد
    } catch {}
    bsModal.show();
}
// ... existing code ...

// ... existing code ...
// Remove or disable SPA status page logic (showStatusPage)
function showStatusPage() {
    // Disabled: Only modal is used now
    showStatusModal();
}
// ... existing code ...

// ... existing code ...
// Utility to set button text with icon, no emoji
function setLogsAccordionButtonTexts(language) {
    const showAllLogsBtn = document.getElementById('showAllLogsBtn');
    if (showAllLogsBtn) {
        showAllLogsBtn.innerHTML = `<i class='fas fa-list'></i> ` + (language === 'fa' ? 'نمایش همه گزارش‌ها' : 'Show all logs');
    }
    const refreshLogsBtn = document.getElementById('refreshLogsBtn');
    if (refreshLogsBtn) {
        refreshLogsBtn.innerHTML = `<i class='fas fa-sync-alt'></i> ` + (language === 'fa' ? 'به‌روزرسانی گزارش‌ها' : 'Refresh logs');
    }
}

// Patch after DOMContentLoaded and on language change
(function() {
    document.addEventListener('DOMContentLoaded', function() {
        setLogsAccordionButtonTexts(localStorage.getItem('language') || 'fa');
    });
    // Patch updateLanguage to also update button texts
    const origUpdateLanguage = SmartCameraSystem.prototype.updateLanguage;
    SmartCameraSystem.prototype.updateLanguage = async function(lang) {
        await origUpdateLanguage.call(this, lang);
        setLogsAccordionButtonTexts(lang);
    };
})();
// ... existing code ...

// ... existing code ...
// Add debounce utility at the top or in the class
function debounce(func, wait) {
    let timeout;
    return function(...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
}
// ... existing code ...
// In SmartCameraSystem class, replace direct servo command sending with debounced version
// Find the method that sends servo commands (e.g., sendServoCommand or similar)
// Replace its usage in the UI event handlers with a debounced version:

// Example:
this.debouncedSendServoCommand = debounce((servo1, servo2) => {
    this.sendServoCommand(servo1, servo2);
}, 350);


// Patch reconnect logic
let reconnectTimeout = null;
SmartCameraSystem.prototype.scheduleReconnect = function() {
    if (reconnectTimeout) return;
    reconnectTimeout = setTimeout(() => {
        reconnectTimeout = null;
        this.setupWebSocket();
    }, 3000); // 3 seconds delay between reconnects
};
// ... existing code ...

document.addEventListener('DOMContentLoaded', () => {
    if (window.system && typeof window.system.setupEventListeners === 'function') {
        window.system.setupEventListeners();
    }
    if (window.system && typeof window.system.updateLanguage === 'function') {
        window.system.updateLanguage(window.system.language || localStorage.getItem('language') || 'fa');
    }
});

function updateSpaPagesLanguage(lang) {
    if (window.translations && window.translations[lang]) {
        document.querySelectorAll('.spa-page [data-key]').forEach(el => {
            const key = el.getAttribute('data-key');
            if (window.translations[lang][key]) {
                el.textContent = window.translations[lang][key];
            }
        });
        document.querySelectorAll('.spa-page [data-key-title]').forEach(el => {
            const key = el.getAttribute('data-key-title');
            if (window.translations[lang][key]) {
                el.setAttribute('title', window.translations[lang][key]);
            }
        });
        document.querySelectorAll('.spa-page [data-key-placeholder]').forEach(el => {
            const key = el.getAttribute('data-key-placeholder');
            if (window.translations[lang][key]) {
                el.setAttribute('placeholder', window.translations[lang][key]);
            }
        });
        document.querySelectorAll('.spa-page [data-key-alt]').forEach(el => {
            const key = el.getAttribute('data-key-alt');
            if (window.translations[lang][key]) {
                el.setAttribute('alt', window.translations[lang][key]);
            }
        });
    }
}
// ... existing code ...

// --- Ensure only one instance and correct event listeners for language switching ---
document.addEventListener('DOMContentLoaded', function() {
    if (!window.system) {
        window.system = new SmartCameraSystem();
        if (typeof window.system.init === 'function') {
            window.system.init();
        }
    }
    // Header language button
    const langBtn = document.getElementById('languageToggle');
    if (langBtn) {
        langBtn.onclick = function(e) { e.preventDefault(); window.system.toggleLanguage(); };
    }
    // Footer language button
    const footerLangBtn = document.getElementById('footerLangBtn');
    if (footerLangBtn) {
        footerLangBtn.onclick = function(e) { e.preventDefault(); window.system.toggleLanguage(); };
    }
});
