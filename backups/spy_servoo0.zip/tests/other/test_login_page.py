#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Login Page Test Script
تست صفحه لاگین و بررسی خطاها
"""

import asyncio
import aiohttp
import json
from datetime import datetime

async def test_login_page():
    """تست صفحه لاگین"""
    print("🧪 تست صفحه لاگین")
    print("=" * 50)
    
    async with aiohttp.ClientSession() as session:
        # تست بارگذاری صفحه لاگین
        print("📄 تست بارگذاری صفحه لاگین...")
        try:
            async with session.get('http://localhost:8000/login') as response:
                if response.status == 200:
                    print("✅ صفحه لاگین با موفقیت بارگذاری شد")
                    content = await response.text()
                    
                    # بررسی وجود عناصر مهم
                    checks = [
                        ('login-form', 'فرم لاگین'),
                        ('register-form', 'فرم ثبت‌نام'),
                        ('recovery-form', 'فرم بازیابی'),
                        ('register-phone', 'فیلد شماره تلفن'),
                        ('recovery-phone', 'فیلد شماره تلفن بازیابی'),
                        ('error-message', 'پیام خطا'),
                        ('success-message', 'پیام موفقیت'),
                        ('warning-message', 'پیام هشدار'),
                        ('info-message', 'پیام اطلاعات')
                    ]
                    
                    for element_id, description in checks:
                        if f'id="{element_id}"' in content:
                            print(f"✅ {description} موجود است")
                        else:
                            print(f"❌ {description} یافت نشد")
                    
                else:
                    print(f"❌ خطا در بارگذاری صفحه: {response.status}")
        except Exception as e:
            print(f"❌ خطا در اتصال: {e}")

async def test_registration():
    """تست ثبت‌نام"""
    print("\n📝 تست ثبت‌نام")
    print("=" * 30)
    
    async with aiohttp.ClientSession() as session:
        test_data = {
            "username": "testuser",
            "phone": "+989966902209",
            "password": "TestPass123!"
        }
        
        try:
            async with session.post('http://localhost:8000/register', 
                                  json=test_data) as response:
                data = await response.json()
                print(f"📊 وضعیت: {response.status}")
                print(f"📄 پاسخ: {data}")
                
                if response.status == 200:
                    print("✅ ثبت‌نام موفق")
                else:
                    print("❌ خطا در ثبت‌نام")
        except Exception as e:
            print(f"❌ خطا در اتصال: {e}")

async def test_password_recovery():
    """تست بازیابی رمز عبور"""
    print("\n🔐 تست بازیابی رمز عبور")
    print("=" * 40)
    
    async with aiohttp.ClientSession() as session:
        test_data = {
            "phone": "+989966902209"
        }
        
        try:
            async with session.post('http://localhost:8000/recover-password', 
                                  json=test_data) as response:
                data = await response.json()
                print(f"📊 وضعیت: {response.status}")
                print(f"📄 پاسخ: {data}")
                
                if response.status == 200:
                    print("✅ درخواست بازیابی ارسال شد")
                else:
                    print("❌ خطا در بازیابی")
        except Exception as e:
            print(f"❌ خطا در اتصال: {e}")

async def test_security_headers():
    """تست هدرهای امنیتی"""
    print("\n🔒 تست هدرهای امنیتی")
    print("=" * 35)
    
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get('http://localhost:8000/login') as response:
                headers = response.headers
                
                security_headers = [
                    'X-Content-Type-Options',
                    'X-Frame-Options', 
                    'X-XSS-Protection',
                    'Strict-Transport-Security',
                    'Content-Security-Policy',
                    'Referrer-Policy',
                    'Permissions-Policy'
                ]
                
                for header in security_headers:
                    if header in headers:
                        print(f"✅ {header}: {headers[header]}")
                    else:
                        print(f"❌ {header}: موجود نیست")
                        
        except Exception as e:
            print(f"❌ خطا در بررسی هدرها: {e}")

async def main():
    """تابع اصلی"""
    print("🚀 شروع تست صفحه لاگین")
    print("=" * 50)
    print(f"⏰ زمان شروع: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # تست‌های مختلف
    await test_login_page()
    await test_registration()
    await test_password_recovery()
    await test_security_headers()
    
    print("\n🏁 تست کامل شد!")
    print(f"⏰ زمان پایان: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

if __name__ == "__main__":
    asyncio.run(main()) 