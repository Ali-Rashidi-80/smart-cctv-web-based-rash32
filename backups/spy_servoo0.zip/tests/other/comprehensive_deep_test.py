#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Comprehensive Deep Test Script
تست جامع و عمیق سیستم
"""

import asyncio
import aiohttp
import requests
import json
import time
from datetime import datetime

class ComprehensiveDeepTest:
    def __init__(self):
        self.base_url = "http://localhost:3000"
        self.results = {
            "success": [],
            "failed": [],
            "warnings": []
        }
        
    def log_result(self, category, test_name, status, details=""):
        """ثبت نتیجه تست"""
        result = {
            "test": test_name,
            "status": status,
            "details": details,
            "timestamp": datetime.now().isoformat()
        }
        self.results[category].append(result)
        
        status_icon = "✅" if status == "SUCCESS" else "❌" if status == "FAILED" else "⚠️"
        print(f"{status_icon} {test_name}: {status}")
        if details:
            print(f"   📝 {details}")
    
    async def test_server_connection(self):
        """تست اتصال سرور"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{self.base_url}/health") as response:
                    if response.status == 200:
                        data = await response.json()
                        self.log_result("success", "Server Connection", "SUCCESS", 
                                      f"Server is running on port 3000, status: {data.get('status')}")
                    else:
                        self.log_result("failed", "Server Connection", "FAILED", 
                                      f"Status: {response.status}")
        except Exception as e:
            self.log_result("failed", "Server Connection", "FAILED", str(e))
    
    async def test_database_health(self):
        """تست سلامت دیتابیس"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{self.base_url}/health") as response:
                    if response.status == 200:
                        data = await response.json()
                        self.log_result("success", "Database Health", "SUCCESS", 
                                      "Database is accessible")
                    else:
                        self.log_result("failed", "Database Health", "FAILED", 
                                      f"Status: {response.status}")
        except Exception as e:
            self.log_result("failed", "Database Health", "FAILED", str(e))
    
    async def test_login_page_load(self):
        """تست بارگذاری صفحه لاگین"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{self.base_url}/login") as response:
                    if response.status == 200:
                        content = await response.text()
                        required_elements = [
                            'login-form', 'register-form', 'recovery-form',
                            'error-message', 'success-message', 'warning-message', 'info-message'
                        ]
                        missing_elements = []
                        for element in required_elements:
                            if element not in content:
                                missing_elements.append(element)
                        
                        if not missing_elements:
                            self.log_result("success", "Login Page Load", "SUCCESS", 
                                          "All required elements present")
                        else:
                            self.log_result("warnings", "Login Page Load", "WARNING", 
                                          f"Missing elements: {missing_elements}")
                    else:
                        self.log_result("failed", "Login Page Load", "FAILED", 
                                      f"Status: {response.status}")
        except Exception as e:
            self.log_result("failed", "Login Page Load", "FAILED", str(e))
    
    async def test_security_headers(self):
        """تست هدرهای امنیتی"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{self.base_url}/login") as response:
                    headers = response.headers
                    required_headers = [
                        'X-Content-Type-Options',
                        'X-Frame-Options', 
                        'X-XSS-Protection',
                        'Content-Security-Policy'
                    ]
                    missing_headers = []
                    for header in required_headers:
                        if header not in headers:
                            missing_headers.append(header)
                    
                    if not missing_headers:
                        self.log_result("success", "Security Headers", "SUCCESS", 
                                      "All security headers present")
                    else:
                        self.log_result("warnings", "Security Headers", "WARNING", 
                                      f"Missing headers: {missing_headers}")
        except Exception as e:
            self.log_result("failed", "Security Headers", "FAILED", str(e))
    
    async def test_api_endpoints(self):
        """تست API endpoints"""
        endpoints = [
            ("/health", "GET", None),
            ("/register", "POST", {"username": "testuser", "phone": "+989966902209", "password": "test123456"}),
            ("/recover-password", "POST", {"phone": "+989966902209"}),
        ]
        
        for endpoint, method, data in endpoints:
            try:
                async with aiohttp.ClientSession() as session:
                    if method == "GET":
                        async with session.get(f"{self.base_url}{endpoint}") as response:
                            if response.status in [200, 422, 400]:  # Acceptable responses
                                self.log_result("success", f"API {endpoint}", "SUCCESS", 
                                              f"Status: {response.status}")
                            else:
                                self.log_result("failed", f"API {endpoint}", "FAILED", 
                                              f"Status: {response.status}")
                    elif method == "POST":
                        headers = {'Content-Type': 'application/json'}
                        async with session.post(f"{self.base_url}{endpoint}", 
                                              json=data, headers=headers) as response:
                            if response.status in [200, 422, 400]:  # Acceptable responses
                                self.log_result("success", f"API {endpoint}", "SUCCESS", 
                                              f"Status: {response.status}")
                            else:
                                self.log_result("failed", f"API {endpoint}", "FAILED", 
                                              f"Status: {response.status}")
            except Exception as e:
                self.log_result("failed", f"API {endpoint}", "FAILED", str(e))
    
    async def test_form_validation(self):
        """تست اعتبارسنجی فرم‌ها"""
        # تست login با داده‌های خالی
        try:
            async with aiohttp.ClientSession() as session:
                headers = {'Content-Type': 'application/json'}
                data = {"username": "", "password": ""}
                async with session.post(f"{self.base_url}/login", 
                                      json=data, headers=headers) as response:
                    if response.status == 422:  # Validation error expected
                        self.log_result("success", "Form Validation - Empty Login", "SUCCESS", 
                                      "Validation working correctly")
                    else:
                        self.log_result("warnings", "Form Validation - Empty Login", "WARNING", 
                                      f"Expected 422, got {response.status}")
        except Exception as e:
            self.log_result("failed", "Form Validation - Empty Login", "FAILED", str(e))
        
        # تست register با داده‌های نامعتبر
        try:
            async with aiohttp.ClientSession() as session:
                headers = {'Content-Type': 'application/json'}
                data = {"username": "a", "phone": "invalid", "password": "123"}
                async with session.post(f"{self.base_url}/register", 
                                      json=data, headers=headers) as response:
                    if response.status == 422:  # Validation error expected
                        self.log_result("success", "Form Validation - Invalid Register", "SUCCESS", 
                                      "Validation working correctly")
                    else:
                        self.log_result("warnings", "Form Validation - Invalid Register", "WARNING", 
                                      f"Expected 422, got {response.status}")
        except Exception as e:
            self.log_result("failed", "Form Validation - Invalid Register", "FAILED", str(e))
    
    async def test_rate_limiting(self):
        """تست محدودیت نرخ"""
        try:
            async with aiohttp.ClientSession() as session:
                headers = {'Content-Type': 'application/json'}
                data = {"username": "test", "password": "test123"}
                
                # ارسال چندین درخواست پشت سر هم
                responses = []
                for i in range(5):
                    async with session.post(f"{self.base_url}/login", 
                                          json=data, headers=headers) as response:
                        responses.append(response.status)
                
                # بررسی اینکه آیا rate limiting اعمال شده
                if 429 in responses:
                    self.log_result("success", "Rate Limiting", "SUCCESS", 
                                  "Rate limiting is working")
                else:
                    self.log_result("warnings", "Rate Limiting", "WARNING", 
                                  "Rate limiting may not be working")
        except Exception as e:
            self.log_result("failed", "Rate Limiting", "FAILED", str(e))
    
    async def test_static_files(self):
        """تست فایل‌های استاتیک"""
        static_files = [
            "/static/css/index/styles.css",
            "/static/js/index/script.js",
            "/static/images/logo.png"
        ]
        
        for file_path in static_files:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(f"{self.base_url}{file_path}") as response:
                        if response.status == 200:
                            self.log_result("success", f"Static File {file_path}", "SUCCESS", 
                                          "File accessible")
                        else:
                            self.log_result("warnings", f"Static File {file_path}", "WARNING", 
                                          f"Status: {response.status}")
            except Exception as e:
                self.log_result("failed", f"Static File {file_path}", "FAILED", str(e))
    
    async def test_websocket_endpoints(self):
        """تست WebSocket endpoints"""
        websocket_endpoints = [
            "/ws",
            "/ws/pico", 
            "/ws/esp32cam"
        ]
        
        for endpoint in websocket_endpoints:
            try:
                # تست HTTP guard برای WebSocket endpoints
                async with aiohttp.ClientSession() as session:
                    async with session.get(f"{self.base_url}{endpoint}") as response:
                        if response.status in [405, 400]:  # Method not allowed for WebSocket
                            self.log_result("success", f"WebSocket {endpoint}", "SUCCESS", 
                                          "WebSocket endpoint protected")
                        else:
                            self.log_result("warnings", f"WebSocket {endpoint}", "WARNING", 
                                          f"Status: {response.status}")
            except Exception as e:
                self.log_result("failed", f"WebSocket {endpoint}", "FAILED", str(e))
    
    async def test_sms_functionality(self):
        """تست عملکرد SMS"""
        try:
            async with aiohttp.ClientSession() as session:
                headers = {'Content-Type': 'application/json'}
                data = {"phone": "+989966902209"}
                async with session.post(f"{self.base_url}/recover-password", 
                                      json=data, headers=headers) as response:
                    if response.status == 200:
                        response_data = await response.json()
                        if "success" in response_data.get("status", ""):
                            self.log_result("success", "SMS Functionality", "SUCCESS", 
                                          "SMS recovery working")
                        else:
                            self.log_result("warnings", "SMS Functionality", "WARNING", 
                                          "SMS recovery may not be working")
                    else:
                        self.log_result("failed", "SMS Functionality", "FAILED", 
                                      f"Status: {response.status}")
        except Exception as e:
            self.log_result("failed", "SMS Functionality", "FAILED", str(e))
    
    async def run_all_tests(self):
        """اجرای تمام تست‌ها"""
        print("🚀 شروع تست جامع و عمیق سیستم")
        print("=" * 60)
        print(f"⏰ زمان شروع: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print()
        
        # اجرای تمام تست‌ها
        await self.test_server_connection()
        await self.test_database_health()
        await self.test_login_page_load()
        await self.test_security_headers()
        await self.test_api_endpoints()
        await self.test_form_validation()
        await self.test_rate_limiting()
        await self.test_static_files()
        await self.test_websocket_endpoints()
        await self.test_sms_functionality()
        
        # نمایش نتایج نهایی
        self.print_final_report()
    
    def print_final_report(self):
        """نمایش گزارش نهایی"""
        print("\n" + "=" * 60)
        print("📊 گزارش نهایی تست جامع و عمیق")
        print("=" * 60)
        
        total_tests = len(self.results["success"]) + len(self.results["failed"]) + len(self.results["warnings"])
        success_rate = (len(self.results["success"]) / total_tests * 100) if total_tests > 0 else 0
        
        print(f"📈 کل تست‌ها: {total_tests}")
        print(f"✅ موفق: {len(self.results['success'])}")
        print(f"❌ ناموفق: {len(self.results['failed'])}")
        print(f"⚠️ هشدار: {len(self.results['warnings'])}")
        print(f"📊 درصد موفقیت: {success_rate:.1f}%")
        print()
        
        if self.results["failed"]:
            print("❌ تست‌های ناموفق:")
            for result in self.results["failed"]:
                print(f"  • {result['test']}: {result['details']}")
            print()
        
        if self.results["warnings"]:
            print("⚠️ تست‌های هشدار:")
            for result in self.results["warnings"]:
                print(f"  • {result['test']}: {result['details']}")
            print()
        
        print("✅ تست‌های موفق:")
        for result in self.results["success"]:
            print(f"  • {result['test']}")
        
        print(f"\n🏁 تست کامل شد!")
        print(f"⏰ زمان پایان: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        if success_rate >= 80:
            print("🎉 سیستم در وضعیت عالی است!")
        elif success_rate >= 60:
            print("👍 سیستم در وضعیت خوب است")
        else:
            print("⚠️ سیستم نیاز به بهبود دارد")

async def main():
    """تابع اصلی"""
    tester = ComprehensiveDeepTest()
    await tester.run_all_tests()

if __name__ == "__main__":
    asyncio.run(main()) 