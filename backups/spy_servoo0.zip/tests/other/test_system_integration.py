#!/usr/bin/env python3
"""
تست جامع سیستم برای بررسی تمام اصلاحات و یکپارچگی
"""

import requests
import json
import time
import asyncio
import websockets
import threading
from datetime import datetime

class SystemIntegrationTest:
    def __init__(self, base_url="http://localhost:3001"):
        self.base_url = base_url
        self.test_results = []
        self.auth_token = None
        
    def log_test(self, test_name, status, message=""):
        """ثبت نتیجه تست"""
        result = {
            "test": test_name,
            "status": status,
            "message": message,
            "timestamp": datetime.now().isoformat()
        }
        self.test_results.append(result)
        status_icon = "✅" if status == "PASS" else "❌"
        print(f"{status_icon} {test_name}: {message}")
        
    def login_and_get_token(self):
        """لاگین و دریافت توکن"""
        try:
            login_data = {
                "username": "rof642fr",
                "password": "5q\\0EKU@A@Tv"
            }
            
            response = requests.post(
                f"{self.base_url}/login",
                json=login_data,
                headers={'Content-Type': 'application/json'},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                self.auth_token = data.get('access_token')
                if self.auth_token:
                    self.log_test("Login", "PASS", "توکن دریافت شد")
                    return True
                else:
                    self.log_test("Login", "FAIL", "توکن در پاسخ یافت نشد")
                    return False
            else:
                self.log_test("Login", "FAIL", f"خطا در لاگین: {response.status_code}")
                return False
                
        except Exception as e:
            self.log_test("Login", "FAIL", f"خطا در لاگین: {e}")
            return False
    
    def test_server_health(self):
        """تست سلامت سرور"""
        try:
            response = requests.get(f"{self.base_url}/health", timeout=5)
            if response.status_code == 200:
                self.log_test("Server Health", "PASS", "سرور در دسترس است")
                return True
            else:
                self.log_test("Server Health", "FAIL", f"سرور در دسترس نیست: {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Server Health", "FAIL", f"خطا در بررسی سلامت سرور: {e}")
            return False
    
    def test_dynamic_ports(self):
        """تست مدیریت پورت‌های پویا"""
        try:
            response = requests.get(f"{self.base_url}/ports", timeout=5)
            if response.status_code == 200:
                data = response.json()
                if "ports" in data:
                    self.log_test("Dynamic Ports", "PASS", f"پورت‌های پویا: {data['ports']}")
                    return True
                else:
                    self.log_test("Dynamic Ports", "FAIL", "اطلاعات پورت‌ها یافت نشد")
                    return False
            else:
                self.log_test("Dynamic Ports", "FAIL", f"خطا در دریافت پورت‌ها: {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Dynamic Ports", "FAIL", f"خطا در تست پورت‌های پویا: {e}")
            return False
    
    def test_pico_status(self):
        """تست وضعیت پیکو"""
        if not self.auth_token:
            self.log_test("Pico Status", "SKIP", "توکن احراز هویت موجود نیست")
            return False
            
        try:
            headers = {'Authorization': f'Bearer {self.auth_token}'}
            response = requests.get(f"{self.base_url}/pico/status", headers=headers, timeout=5)
            
            if response.status_code == 200:
                data = response.json()
                if "online" in data:
                    status = "متصل" if data["online"] else "قطع"
                    self.log_test("Pico Status", "PASS", f"وضعیت پیکو: {status}")
                    return True
                else:
                    self.log_test("Pico Status", "FAIL", "اطلاعات وضعیت پیکو یافت نشد")
                    return False
            else:
                self.log_test("Pico Status", "FAIL", f"خطا در دریافت وضعیت پیکو: {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Pico Status", "FAIL", f"خطا در تست وضعیت پیکو: {e}")
            return False
    
    def test_esp32cam_status(self):
        """تست وضعیت ESP32CAM"""
        if not self.auth_token:
            self.log_test("ESP32CAM Status", "SKIP", "توکن احراز هویت موجود نیست")
            return False
            
        try:
            headers = {'Authorization': f'Bearer {self.auth_token}'}
            response = requests.get(f"{self.base_url}/esp32cam/status", headers=headers, timeout=5)
            
            if response.status_code == 200:
                data = response.json()
                if "online" in data:
                    status = "متصل" if data["online"] else "قطع"
                    self.log_test("ESP32CAM Status", "PASS", f"وضعیت ESP32CAM: {status}")
                    return True
                else:
                    self.log_test("ESP32CAM Status", "FAIL", "اطلاعات وضعیت ESP32CAM یافت نشد")
                    return False
            else:
                self.log_test("ESP32CAM Status", "FAIL", f"خطا در دریافت وضعیت ESP32CAM: {response.status_code}")
                return False
        except Exception as e:
            self.log_test("ESP32CAM Status", "FAIL", f"خطا در تست وضعیت ESP32CAM: {e}")
            return False
    
    def test_servo_command(self):
        """تست ارسال دستور سروو"""
        if not self.auth_token:
            self.log_test("Servo Command", "SKIP", "توکن احراز هویت موجود نیست")
            return False
            
        try:
            headers = {'Authorization': f'Bearer {self.auth_token}'}
            servo_data = {
                "servo1": 90,
                "servo2": 90
            }
            
            response = requests.post(
                f"{self.base_url}/set_servo",
                json=servo_data,
                headers=headers,
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "success":
                    self.log_test("Servo Command", "PASS", "دستور سروو ارسال شد")
                    return True
                else:
                    self.log_test("Servo Command", "FAIL", f"خطا در ارسال دستور: {data.get('message', 'Unknown error')}")
                    return False
            else:
                self.log_test("Servo Command", "FAIL", f"خطا در ارسال دستور سروو: {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Servo Command", "FAIL", f"خطا در تست دستور سروو: {e}")
            return False
    
    def test_user_settings(self):
        """تست تنظیمات کاربر"""
        if not self.auth_token:
            self.log_test("User Settings", "SKIP", "توکن احراز هویت موجود نیست")
            return False
            
        try:
            headers = {'Authorization': f'Bearer {self.auth_token}'}
            settings_data = {
                "language": "fa",
                "device_mode": "desktop",
                "servo1": 90,
                "servo2": 90
            }
            
            response = requests.post(
                f"{self.base_url}/save_user_settings",
                json=settings_data,
                headers=headers,
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "success":
                    self.log_test("User Settings", "PASS", "تنظیمات کاربر ذخیره شد")
                    return True
                else:
                    self.log_test("User Settings", "FAIL", f"خطا در ذخیره تنظیمات: {data.get('message', 'Unknown error')}")
                    return False
            else:
                self.log_test("User Settings", "FAIL", f"خطا در ذخیره تنظیمات: {response.status_code}")
                return False
        except Exception as e:
            self.log_test("User Settings", "FAIL", f"خطا در تست تنظیمات کاربر: {e}")
            return False
    
    def test_system_performance(self):
        """تست عملکرد سیستم"""
        if not self.auth_token:
            self.log_test("System Performance", "SKIP", "توکن احراز هویت موجود نیست")
            return False
            
        try:
            headers = {'Authorization': f'Bearer {self.auth_token}'}
            response = requests.get(f"{self.base_url}/system/performance", headers=headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if "memory_usage" in data and "cpu_usage" in data:
                    memory = data["memory_usage"]
                    cpu = data["cpu_usage"]
                    self.log_test("System Performance", "PASS", f"حافظه: {memory}%, CPU: {cpu}%")
                    return True
                else:
                    self.log_test("System Performance", "FAIL", "اطلاعات عملکرد یافت نشد")
                    return False
            else:
                self.log_test("System Performance", "FAIL", f"خطا در دریافت عملکرد: {response.status_code}")
                return False
        except Exception as e:
            self.log_test("System Performance", "FAIL", f"خطا در تست عملکرد: {e}")
            return False
    
    async def test_websocket_connection(self, device_type="pico"):
        """تست اتصال WebSocket"""
        try:
            # تست اتصال بدون توکن (باید رد شود)
            uri = f"ws://localhost:26852/ws/{device_type}"
            try:
                async with websockets.connect(uri) as websocket:
                    await websocket.send("test")
                    self.log_test(f"WebSocket {device_type} (No Auth)", "FAIL", "اتصال بدون توکن پذیرفته شد")
                    return False
            except:
                pass  # انتظار می‌رود که رد شود
            
            # تست اتصال با توکن نامعتبر (باید رد شود)
            try:
                headers = {"Authorization": "Bearer invalid_token"}
                async with websockets.connect(uri, extra_headers=headers) as websocket:
                    await websocket.send("test")
                    self.log_test(f"WebSocket {device_type} (Invalid Auth)", "FAIL", "اتصال با توکن نامعتبر پذیرفته شد")
                    return False
            except:
                pass  # انتظار می‌رود که رد شود
            
            # تست اتصال با توکن معتبر
            if device_type == "pico":
                valid_token = "m78jmdzu:2G/O\\S'W]_E]"
            else:
                valid_token = "esp32cam_secure_token_2024"
                
            try:
                headers = {"Authorization": f"Bearer {valid_token}"}
                async with websockets.connect(uri, extra_headers=headers) as websocket:
                    await websocket.send('{"type": "ping"}')
                    response = await websocket.recv()
                    self.log_test(f"WebSocket {device_type} (Valid Auth)", "PASS", "اتصال با توکن معتبر موفق")
                    return True
            except Exception as e:
                self.log_test(f"WebSocket {device_type} (Valid Auth)", "FAIL", f"خطا در اتصال: {e}")
                return False
                
        except Exception as e:
            self.log_test(f"WebSocket {device_type}", "FAIL", f"خطا در تست WebSocket: {e}")
            return False
    
    def run_all_tests(self):
        """اجرای تمام تست‌ها"""
        print("🚀 شروع تست‌های جامع سیستم...")
        print("=" * 60)
        
        # تست‌های HTTP
        self.test_server_health()
        self.test_dynamic_ports()
        
        if self.login_and_get_token():
            self.test_pico_status()
            self.test_esp32cam_status()
            self.test_servo_command()
            self.test_user_settings()
            self.test_system_performance()
        
        # تست‌های WebSocket
        print("\n🌐 تست‌های WebSocket...")
        asyncio.run(self.test_websocket_connection("pico"))
        asyncio.run(self.test_websocket_connection("esp32cam"))
        
        # خلاصه نتایج
        print("\n" + "=" * 60)
        print("📊 خلاصه نتایج تست:")
        
        passed = sum(1 for result in self.test_results if result["status"] == "PASS")
        failed = sum(1 for result in self.test_results if result["status"] == "FAIL")
        skipped = sum(1 for result in self.test_results if result["status"] == "SKIP")
        total = len(self.test_results)
        
        print(f"✅ موفق: {passed}")
        print(f"❌ ناموفق: {failed}")
        print(f"⏭️ رد شده: {skipped}")
        print(f"📈 کل: {total}")
        
        if failed == 0:
            print("\n🎉 تمام تست‌ها موفق بودند!")
        else:
            print(f"\n⚠️ {failed} تست ناموفق بودند:")
            for result in self.test_results:
                if result["status"] == "FAIL":
                    print(f"  - {result['test']}: {result['message']}")
        
        return failed == 0

def main():
    """تابع اصلی"""
    print("🔧 تست جامع سیستم Smart Camera Security")
    print("=" * 60)
    
    # تست سیستم
    tester = SystemIntegrationTest()
    success = tester.run_all_tests()
    
    if success:
        print("\n✅ سیستم آماده استفاده است!")
        return 0
    else:
        print("\n❌ مشکلاتی در سیستم وجود دارد که باید برطرف شوند.")
        return 1

if __name__ == "__main__":
    exit(main()) 