#!/usr/bin/env python3
"""
Simple test script to check if the server starts correctly
"""

import subprocess
import time
import requests
import sys
import os

def test_server_startup():
    """Test if the server starts correctly"""
    print("🚀 Testing server startup...")
    
    try:
        # Try to import the server module
        print("📦 Importing server module...")
        import server_fastapi
        print("✅ Server module imported successfully")
        
        # Check if required dependencies are available
        print("🔍 Checking dependencies...")
        try:
            import pyotp
            print("✅ pyotp imported successfully")
        except ImportError as e:
            print(f"❌ pyotp not available: {e}")
            return False
        
        try:
            import secrets
            print("✅ secrets imported successfully")
        except ImportError as e:
            print(f"❌ secrets not available: {e}")
            return False
        
        try:
            from pydantic import BaseModel, Field
            print("✅ pydantic imported successfully")
        except ImportError as e:
            print(f"❌ pydantic not available: {e}")
            return False
        
        print("✅ All dependencies are available")
        return True
        
    except Exception as e:
        print(f"❌ Error importing server module: {e}")
        return False

def test_basic_functionality():
    """Test basic functionality without starting the server"""
    print("\n🔧 Testing basic functionality...")
    
    try:
        # Test Pydantic models
        from server_fastapi import RegisterRequest, PasswordRecoveryRequest, TwoFactorVerifyRequest
        
        # Test RegisterRequest
        try:
            register_data = RegisterRequest(
                username="testuser",
                email="test@example.com",
                password="TestPass123!"
            )
            print("✅ RegisterRequest model works")
        except Exception as e:
            print(f"❌ RegisterRequest model failed: {e}")
            return False
        
        # Test PasswordRecoveryRequest
        try:
            recovery_data = PasswordRecoveryRequest(email="test@example.com")
            print("✅ PasswordRecoveryRequest model works")
        except Exception as e:
            print(f"❌ PasswordRecoveryRequest model failed: {e}")
            return False
        
        # Test TwoFactorVerifyRequest
        try:
            twofa_data = TwoFactorVerifyRequest(secret="testsecret", otp="123456")
            print("✅ TwoFactorVerifyRequest model works")
        except Exception as e:
            print(f"❌ TwoFactorVerifyRequest model failed: {e}")
            return False
        
        print("✅ All Pydantic models work correctly")
        return True
        
    except Exception as e:
        print(f"❌ Error testing functionality: {e}")
        return False

def main():
    """Main test function"""
    print("🧪 Server Startup Test")
    print("=" * 40)
    
    # Test 1: Import and dependencies
    if not test_server_startup():
        print("\n❌ Server startup test failed")
        return 1
    
    # Test 2: Basic functionality
    if not test_basic_functionality():
        print("\n❌ Basic functionality test failed")
        return 1
    
    print("\n🎉 All tests passed! Server should start correctly.")
    print("\n📋 Next steps:")
    print("1. Install dependencies: pip install -r requirements.txt")
    print("2. Start server: python server_fastapi.py")
    print("3. Access login page: http://localhost:8000/login")
    
    return 0

if __name__ == "__main__":
    sys.exit(main()) 