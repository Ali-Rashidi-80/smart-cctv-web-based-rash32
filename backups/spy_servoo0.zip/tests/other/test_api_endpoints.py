#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
API Endpoints Test Script
تست endpoint های API
"""

import asyncio
import aiohttp
import json
from datetime import datetime

async def test_api_endpoints():
    """تست endpoint های API"""
    print("🧪 تست API Endpoints")
    print("=" * 50)
    
    base_url = "http://localhost:3000"
    
    async with aiohttp.ClientSession() as session:
        # تست health endpoint
        print("📊 تست /health...")
        try:
            async with session.get(f"{base_url}/health") as response:
                print(f"   وضعیت: {response.status}")
                if response.status == 200:
                    data = await response.json()
                    print(f"   پاسخ: {data}")
                else:
                    text = await response.text()
                    print(f"   پاسخ: {text}")
        except Exception as e:
            print(f"   خطا: {e}")
        
        print()
        
        # تست register endpoint
        print("📝 تست /register...")
        test_data = {
            "username": f"testuser_{datetime.now().strftime('%H%M%S')}",
            "phone": "+989966902209",
            "password": "TestPass123!"
        }
        
        try:
            async with session.post(f"{base_url}/register", 
                                  json=test_data,
                                  headers={"Content-Type": "application/json"}) as response:
                print(f"   وضعیت: {response.status}")
                print(f"   Content-Type: {response.headers.get('content-type', 'N/A')}")
                
                if response.status == 200:
                    data = await response.json()
                    print(f"   پاسخ: {data}")
                else:
                    text = await response.text()
                    print(f"   پاسخ: {text}")
        except Exception as e:
            print(f"   خطا: {e}")
        
        print()
        
        # تست login endpoint
        print("🔐 تست /login...")
        login_data = {
            "username": "admin",
            "password": "admin123"
        }
        
        try:
            async with session.post(f"{base_url}/login", 
                                  json=login_data,
                                  headers={"Content-Type": "application/json"}) as response:
                print(f"   وضعیت: {response.status}")
                print(f"   Content-Type: {response.headers.get('content-type', 'N/A')}")
                
                if response.status == 200:
                    data = await response.json()
                    print(f"   پاسخ: {data}")
                else:
                    text = await response.text()
                    print(f"   پاسخ: {text}")
        except Exception as e:
            print(f"   خطا: {e}")
        
        print()
        
        # تست recover-password endpoint
        print("📱 تست /recover-password...")
        recovery_data = {
            "phone": "+989966902209"
        }
        
        try:
            async with session.post(f"{base_url}/recover-password", 
                                  json=recovery_data,
                                  headers={"Content-Type": "application/json"}) as response:
                print(f"   وضعیت: {response.status}")
                print(f"   Content-Type: {response.headers.get('content-type', 'N/A')}")
                
                if response.status == 200:
                    data = await response.json()
                    print(f"   پاسخ: {data}")
                else:
                    text = await response.text()
                    print(f"   پاسخ: {text}")
        except Exception as e:
            print(f"   خطا: {e}")

async def main():
    """تابع اصلی"""
    print("🚀 شروع تست API Endpoints")
    print("=" * 50)
    print(f"⏰ زمان شروع: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    await test_api_endpoints()
    
    print("\n🏁 تست کامل شد!")
    print(f"⏰ زمان پایان: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

if __name__ == "__main__":
    asyncio.run(main()) 