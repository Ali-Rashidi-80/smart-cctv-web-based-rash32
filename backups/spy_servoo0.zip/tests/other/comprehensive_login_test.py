#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Comprehensive Login Page Test Script
تست جامع و دقیق صفحه لاگین
"""

import asyncio
import aiohttp
import json
import re
from datetime import datetime
from bs4 import BeautifulSoup

class LoginPageTester:
    def __init__(self, base_url="http://localhost:3000"):
        self.base_url = base_url
        self.session = None
        self.test_results = []
        
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    def log_result(self, test_name, status, details=""):
        """ثبت نتیجه تست"""
        result = {
            "test": test_name,
            "status": status,
            "details": details,
            "timestamp": datetime.now().isoformat()
        }
        self.test_results.append(result)
        
        icon = "✅" if status == "PASS" else "❌"
        print(f"{icon} {test_name}: {details}")
    
    async def test_server_connection(self):
        """تست اتصال به سرور"""
        try:
            async with self.session.get(f"{self.base_url}/health") as response:
                if response.status == 200:
                    self.log_result("Server Connection", "PASS", "سرور در دسترس است")
                    return True
                else:
                    self.log_result("Server Connection", "FAIL", f"وضعیت سرور: {response.status}")
                    return False
        except Exception as e:
            self.log_result("Server Connection", "FAIL", f"خطا در اتصال: {e}")
            return False
    
    async def test_login_page_load(self):
        """تست بارگذاری صفحه لاگین"""
        try:
            async with self.session.get(f"{self.base_url}/login") as response:
                if response.status == 200:
                    content = await response.text()
                    soup = BeautifulSoup(content, 'html.parser')
                    
                    # بررسی عناصر اصلی
                    required_elements = [
                        ('login-form', 'فرم لاگین'),
                        ('register-form', 'فرم ثبت‌نام'),
                        ('recovery-form', 'فرم بازیابی'),
                        ('login-username', 'فیلد نام کاربری'),
                        ('login-password', 'فیلد رمز عبور'),
                        ('register-username', 'فیلد نام کاربری ثبت‌نام'),
                        ('register-phone', 'فیلد شماره تلفن'),
                        ('register-password', 'فیلد رمز عبور ثبت‌نام'),
                        ('recovery-phone', 'فیلد شماره تلفن بازیابی'),
                        ('error-message', 'پیام خطا'),
                        ('success-message', 'پیام موفقیت'),
                        ('warning-message', 'پیام هشدار'),
                        ('info-message', 'پیام اطلاعات')
                    ]
                    
                    missing_elements = []
                    for element_id, description in required_elements:
                        if not soup.find(id=element_id):
                            missing_elements.append(description)
                    
                    if not missing_elements:
                        self.log_result("Login Page Load", "PASS", "تمام عناصر موجود هستند")
                        return True
                    else:
                        self.log_result("Login Page Load", "FAIL", f"عناصر گمشده: {', '.join(missing_elements)}")
                        return False
                else:
                    self.log_result("Login Page Load", "FAIL", f"وضعیت HTTP: {response.status}")
                    return False
        except Exception as e:
            self.log_result("Login Page Load", "FAIL", f"خطا: {e}")
            return False
    
    async def test_security_headers(self):
        """تست هدرهای امنیتی"""
        try:
            async with self.session.get(f"{self.base_url}/login") as response:
                headers = response.headers
                
                security_headers = {
                    'X-Content-Type-Options': 'nosniff',
                    'X-Frame-Options': 'DENY',
                    'X-XSS-Protection': '1; mode=block',
                    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
                    'Content-Security-Policy': 'default-src',
                    'Referrer-Policy': 'strict-origin-when-cross-origin',
                    'Permissions-Policy': 'geolocation=(), microphone=(), camera=()'
                }
                
                missing_headers = []
                for header, expected_value in security_headers.items():
                    if header not in headers:
                        missing_headers.append(header)
                    elif expected_value and expected_value not in headers[header]:
                        missing_headers.append(f"{header} (مقدار نادرست)")
                
                if not missing_headers:
                    self.log_result("Security Headers", "PASS", "تمام هدرهای امنیتی موجود هستند")
                    return True
                else:
                    self.log_result("Security Headers", "FAIL", f"هدرهای گمشده: {', '.join(missing_headers)}")
                    return False
        except Exception as e:
            self.log_result("Security Headers", "FAIL", f"خطا: {e}")
            return False
    
    async def test_form_validation(self):
        """تست اعتبارسنجی فرم‌ها"""
        validation_tests = [
            # تست لاگین با داده‌های خالی
            {
                "name": "Empty Login",
                "endpoint": "/login",
                "data": {"username": "", "password": ""},
                "expected_status": 422
            },
            # تست ثبت‌نام با داده‌های نامعتبر
            {
                "name": "Invalid Registration",
                "endpoint": "/register",
                "data": {"username": "a", "phone": "invalid", "password": "123"},
                "expected_status": 422
            },
            # تست بازیابی با شماره تلفن نامعتبر
            {
                "name": "Invalid Recovery",
                "endpoint": "/recover-password",
                "data": {"phone": "invalid"},
                "expected_status": 422
            }
        ]
        
        for test in validation_tests:
            try:
                async with self.session.post(f"{self.base_url}{test['endpoint']}", 
                                           json=test['data']) as response:
                    if response.status == test['expected_status']:
                        self.log_result(f"Form Validation - {test['name']}", "PASS", "اعتبارسنجی صحیح")
                    else:
                        self.log_result(f"Form Validation - {test['name']}", "FAIL", 
                                      f"وضعیت: {response.status}, انتظار: {test['expected_status']}")
            except Exception as e:
                self.log_result(f"Form Validation - {test['name']}", "FAIL", f"خطا: {e}")
    
    async def test_registration_flow(self):
        """تست جریان ثبت‌نام"""
        test_data = {
            "username": f"testuser_{datetime.now().strftime('%H%M%S')}",
            "phone": "+989966902209",
            "password": "TestPass123!"
        }
        
        try:
            async with self.session.post(f"{self.base_url}/register", 
                                       json=test_data) as response:
                data = await response.json()
                
                if response.status == 200:
                    self.log_result("Registration Flow", "PASS", "ثبت‌نام موفق")
                    return test_data["username"]
                else:
                    self.log_result("Registration Flow", "FAIL", f"خطا: {data.get('detail', 'Unknown')}")
                    return None
        except Exception as e:
            self.log_result("Registration Flow", "FAIL", f"خطا: {e}")
            return None
    
    async def test_login_flow(self, username, password):
        """تست جریان لاگین"""
        login_data = {
            "username": username,
            "password": password
        }
        
        try:
            async with self.session.post(f"{self.base_url}/login", 
                                       json=login_data) as response:
                data = await response.json()
                
                if response.status == 200:
                    if data.get('requires_2fa'):
                        self.log_result("Login Flow", "PASS", "لاگین موفق (نیاز به 2FA)")
                    else:
                        self.log_result("Login Flow", "PASS", "لاگین موفق")
                    return True
                else:
                    self.log_result("Login Flow", "FAIL", f"خطا: {data.get('detail', 'Unknown')}")
                    return False
        except Exception as e:
            self.log_result("Login Flow", "FAIL", f"خطا: {e}")
            return False
    
    async def test_password_recovery_flow(self):
        """تست جریان بازیابی رمز عبور"""
        recovery_data = {
            "phone": "+989966902209"
        }
        
        try:
            async with self.session.post(f"{self.base_url}/recover-password", 
                                       json=recovery_data) as response:
                data = await response.json()
                
                if response.status == 200:
                    self.log_result("Password Recovery Flow", "PASS", "درخواست بازیابی ارسال شد")
                    return True
                else:
                    self.log_result("Password Recovery Flow", "FAIL", f"خطا: {data.get('detail', 'Unknown')}")
                    return False
        except Exception as e:
            self.log_result("Password Recovery Flow", "FAIL", f"خطا: {e}")
            return False
    
    async def test_rate_limiting(self):
        """تست محدودیت نرخ درخواست"""
        # ارسال چندین درخواست پشت سر هم
        for i in range(5):
            try:
                async with self.session.post(f"{self.base_url}/login", 
                                           json={"username": "test", "password": "test"}) as response:
                    if response.status == 429:
                        self.log_result("Rate Limiting", "PASS", "محدودیت نرخ اعمال شد")
                        return True
            except Exception as e:
                continue
        
        self.log_result("Rate Limiting", "FAIL", "محدودیت نرخ اعمال نشد")
        return False
    
    async def test_csrf_protection(self):
        """تست محافظت CSRF"""
        try:
            # تست بدون توکن CSRF
            async with self.session.post(f"{self.base_url}/login", 
                                       json={"username": "test", "password": "test"},
                                       headers={"X-CSRF-Token": "invalid"}) as response:
                # اگر سرور CSRF را بررسی کند، باید خطا بدهد
                if response.status in [403, 422]:
                    self.log_result("CSRF Protection", "PASS", "محافظت CSRF فعال است")
                    return True
                else:
                    self.log_result("CSRF Protection", "FAIL", "محافظت CSRF غیرفعال است")
                    return False
        except Exception as e:
            self.log_result("CSRF Protection", "FAIL", f"خطا: {e}")
            return False
    
    async def test_xss_protection(self):
        """تست محافظت XSS"""
        xss_payload = "<script>alert('xss')</script>"
        
        try:
            async with self.session.post(f"{self.base_url}/login", 
                                       json={"username": xss_payload, "password": "test"}) as response:
                data = await response.text()
                
                if xss_payload in data:
                    self.log_result("XSS Protection", "FAIL", "محافظت XSS غیرفعال است")
                    return False
                else:
                    self.log_result("XSS Protection", "PASS", "محافظت XSS فعال است")
                    return True
        except Exception as e:
            self.log_result("XSS Protection", "FAIL", f"خطا: {e}")
            return False
    
    async def test_sql_injection_protection(self):
        """تست محافظت SQL Injection"""
        sql_payload = "'; DROP TABLE users; --"
        
        try:
            async with self.session.post(f"{self.base_url}/login", 
                                       json={"username": sql_payload, "password": "test"}) as response:
                # اگر محافظت فعال باشد، نباید خطای SQL بدهد
                if response.status == 422:
                    self.log_result("SQL Injection Protection", "PASS", "محافظت SQL Injection فعال است")
                    return True
                else:
                    self.log_result("SQL Injection Protection", "FAIL", "محافظت SQL Injection غیرفعال است")
                    return False
        except Exception as e:
            self.log_result("SQL Injection Protection", "FAIL", f"خطا: {e}")
            return False
    
    def generate_report(self):
        """تولید گزارش نهایی"""
        total_tests = len(self.test_results)
        passed_tests = len([r for r in self.test_results if r['status'] == 'PASS'])
        failed_tests = total_tests - passed_tests
        
        print("\n" + "="*60)
        print("📊 گزارش نهایی تست صفحه لاگین")
        print("="*60)
        print(f"📈 کل تست‌ها: {total_tests}")
        print(f"✅ موفق: {passed_tests}")
        print(f"❌ ناموفق: {failed_tests}")
        print(f"📊 درصد موفقیت: {(passed_tests/total_tests*100):.1f}%")
        print("="*60)
        
        if failed_tests > 0:
            print("\n❌ تست‌های ناموفق:")
            for result in self.test_results:
                if result['status'] == 'FAIL':
                    print(f"  • {result['test']}: {result['details']}")
        
        print("\n✅ تست‌های موفق:")
        for result in self.test_results:
            if result['status'] == 'PASS':
                print(f"  • {result['test']}: {result['details']}")
        
        return passed_tests, failed_tests

async def main():
    """تابع اصلی"""
    print("🚀 شروع تست جامع صفحه لاگین")
    print("="*60)
    print(f"⏰ زمان شروع: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    async with LoginPageTester() as tester:
        # تست‌های اصلی
        await tester.test_server_connection()
        await tester.test_login_page_load()
        await tester.test_security_headers()
        await tester.test_form_validation()
        
        # تست جریان‌های کاربری
        username = await tester.test_registration_flow()
        if username:
            await tester.test_login_flow(username, "TestPass123!")
        
        await tester.test_password_recovery_flow()
        
        # تست‌های امنیتی
        await tester.test_rate_limiting()
        await tester.test_csrf_protection()
        await tester.test_xss_protection()
        await tester.test_sql_injection_protection()
        
        # تولید گزارش
        passed, failed = tester.generate_report()
        
        print(f"\n🏁 تست کامل شد!")
        print(f"⏰ زمان پایان: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        if failed == 0:
            print("🎉 تمام تست‌ها موفق بودند!")
        else:
            print(f"⚠️ {failed} تست ناموفق بودند. لطفاً بررسی کنید.")

if __name__ == "__main__":
    asyncio.run(main()) 