#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Database Reset Script
بازنشانی و راه‌اندازی مجدد دیتابیس
"""

import asyncio
import os
import aiosqlite
from datetime import datetime

async def reset_database():
    """بازنشانی و راه‌اندازی مجدد دیتابیس"""
    print("🔄 بازنشانی دیتابیس")
    print("=" * 50)
    
    # حذف فایل دیتابیس موجود
    db_file = "smart_camera_system.db"
    if os.path.exists(db_file):
        try:
            os.remove(db_file)
            print(f"✅ فایل دیتابیس {db_file} حذف شد")
        except Exception as e:
            print(f"❌ خطا در حذف فایل دیتابیس: {e}")
            return False
    else:
        print(f"ℹ️ فایل دیتابیس {db_file} وجود نداشت")
    
    # ایجاد دیتابیس جدید
    try:
        conn = await aiosqlite.connect(db_file)
        print("✅ اتصال به دیتابیس جدید برقرار شد")
        
        # ایجاد جدول کاربران
        await conn.execute("""CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            phone TEXT UNIQUE,
            password_hash TEXT NOT NULL,
            role TEXT DEFAULT 'user',
            is_active BOOLEAN DEFAULT 1,
            two_fa_enabled BOOLEAN DEFAULT 0,
            two_fa_secret TEXT,
            created_at TEXT NOT NULL
        )""")
        print("✅ جدول users ایجاد شد")
        
        # ایجاد جدول بازیابی رمز عبور
        await conn.execute("""CREATE TABLE IF NOT EXISTS password_recovery (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone TEXT NOT NULL,
            token TEXT UNIQUE NOT NULL,
            expires_at TEXT NOT NULL,
            used BOOLEAN DEFAULT 0,
            created_at TEXT NOT NULL
        )""")
        print("✅ جدول password_recovery ایجاد شد")
        
        # ایجاد جدول لاگ‌های دوربین
        await conn.execute("""CREATE TABLE IF NOT EXISTS camera_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message TEXT NOT NULL,
            log_type TEXT NOT NULL,
            created_at TEXT DEFAULT '',
            source TEXT DEFAULT 'server',
            pico_timestamp TEXT DEFAULT NULL
        )""")
        print("✅ جدول camera_logs ایجاد شد")
        
        # ایجاد جدول دستورات سروو
        await conn.execute("""CREATE TABLE IF NOT EXISTS servo_commands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            servo1 INTEGER NOT NULL,
            servo2 INTEGER NOT NULL,
            created_at TEXT DEFAULT '',
            processed INTEGER DEFAULT 0
        )""")
        print("✅ جدول servo_commands ایجاد شد")
        
        # ایجاد جدول دستورات عملیات
        await conn.execute("""CREATE TABLE IF NOT EXISTS action_commands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT NOT NULL,
            intensity INTEGER DEFAULT 50,
            created_at TEXT DEFAULT '',
            processed INTEGER DEFAULT 0
        )""")
        print("✅ جدول action_commands ایجاد شد")
        
        # ایجاد جدول تنظیمات دستگاه
        await conn.execute("""CREATE TABLE IF NOT EXISTS device_mode_commands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_mode TEXT NOT NULL,
            created_at TEXT DEFAULT '',
            processed INTEGER DEFAULT 0
        )""")
        print("✅ جدول device_mode_commands ایجاد شد")
        
        # ایجاد جدول عکس‌های دستی
        await conn.execute("""CREATE TABLE IF NOT EXISTS manual_photos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            filepath TEXT NOT NULL,
            quality INTEGER DEFAULT 80,
            flash_used BOOLEAN DEFAULT FALSE,
            flash_intensity INTEGER DEFAULT 50,
            created_at TEXT DEFAULT ''
        )""")
        print("✅ جدول manual_photos ایجاد شد")
        
        # ایجاد جدول ویدیوهای امنیتی
        await conn.execute("""CREATE TABLE IF NOT EXISTS security_videos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            filepath TEXT NOT NULL,
            hour_of_day INTEGER NOT NULL,
            duration INTEGER DEFAULT 3600,
            created_at TEXT DEFAULT ''
        )""")
        print("✅ جدول security_videos ایجاد شد")
        
        # ایجاد جدول تنظیمات کاربر
        await conn.execute("""CREATE TABLE IF NOT EXISTS user_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            ip TEXT,
            device_mode TEXT DEFAULT 'desktop',
            theme TEXT DEFAULT 'light',
            language TEXT DEFAULT 'fa',
            servo1 INTEGER,
            servo2 INTEGER,
            created_at TEXT DEFAULT '',
            updated_at TEXT DEFAULT ''
        )""")
        print("✅ جدول user_settings ایجاد شد")
        
        # ایجاد کاربر ادمین پیش‌فرض
        from passlib.hash import bcrypt
        admin_username = "admin"
        admin_password = "admin123"
        admin_password_hash = bcrypt.hash(admin_password)
        
        await conn.execute('''
            INSERT INTO users (username, phone, password_hash, role, is_active, created_at)
            VALUES (?, ?, ?, 'admin', 1, ?)
        ''', (admin_username, "+989966902209", admin_password_hash, datetime.now().isoformat()))
        print(f"✅ کاربر ادمین '{admin_username}' ایجاد شد")
        
        # ذخیره تغییرات
        await conn.commit()
        await conn.close()
        
        print("✅ دیتابیس با موفقیت بازنشانی شد!")
        return True
        
    except Exception as e:
        print(f"❌ خطا در بازنشانی دیتابیس: {e}")
        return False

async def main():
    """تابع اصلی"""
    print("🚀 شروع بازنشانی دیتابیس")
    print("=" * 50)
    print(f"⏰ زمان شروع: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    success = await reset_database()
    
    if success:
        print("\n🎉 بازنشانی دیتابیس با موفقیت انجام شد!")
        print("📊 حالا می‌توانید سیستم را مجدداً راه‌اندازی کنید")
    else:
        print("\n❌ خطا در بازنشانی دیتابیس")
    
    print(f"\n⏰ زمان پایان: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

if __name__ == "__main__":
    asyncio.run(main()) 