#!/usr/bin/env python3
"""
Comprehensive System Analysis Test Suite
Tests all critical fixes and improvements made to the login system and security features.
"""

import asyncio
import pytest
import aiosqlite
import tempfile
import os
import sys
import json
import hashlib
import secrets
from datetime import datetime, timedelta
from unittest.mock import Mock, patch, AsyncMock
import threading
import httpx

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import the functions we want to test
from server_fastapi import (
    hash_password, verify_password, sanitize_input, check_rate_limit,
    check_login_attempts, record_login_attempt, create_access_token,
    verify_token, get_jalali_now_str, init_db, get_db_connection,
    close_db_connection, insert_log
)

class TestLoginSystemSecurity:
    """Test suite for login system security features"""
    
    @pytest.fixture(autouse=True)
    def setup_test_environment(self):
        """Setup test environment with temporary database"""
        self.temp_db = tempfile.NamedTemporaryFile(delete=False, suffix='.db')
        self.db_path = self.temp_db.name
        self.temp_db.close()
        
        # Set environment variables for testing
        os.environ['SECRET_KEY'] = 'test_secret_key_for_testing_only'
        os.environ['ADMIN_USERNAME'] = 'test_admin'
        os.environ['ADMIN_PASSWORD'] = 'test_password'
        
        yield
        
        # Cleanup
        if os.path.exists(self.db_path):
            os.unlink(self.db_path)
    
    @pytest.mark.asyncio
    async def test_database_initialization(self):
        """Test database initialization and table creation"""
        # Mock the system_state
        with patch('server_fastapi.system_state') as mock_system_state:
            mock_system_state.db_initialized = False
            
            # Initialize database
            await init_db()
            
            # Verify database file exists
            assert os.path.exists(self.db_path)
            
            # Check tables were created
            conn = await get_db_connection()
            try:
                cursor = await conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = await cursor.fetchall()
                table_names = [table[0] for table in tables]
                
                # Check essential tables exist
                assert 'users' in table_names
                assert 'password_recovery' in table_names
                assert 'camera_logs' in table_names
                assert 'user_settings' in table_names
            finally:
                await close_db_connection(conn)
    
    def test_password_hashing_security(self):
        """Test password hashing with bcrypt"""
        password = "test_password_123"
        
        # Test password hashing
        hashed = hash_password(password)
        
        # Verify hash is different from plain text
        assert hashed != password
        
        # Verify password verification works
        assert verify_password(password, hashed) == True
        
        # Verify wrong password fails
        assert verify_password("wrong_password", hashed) == False
        
        # Verify hash is bcrypt format (starts with $2b$)
        assert hashed.startswith('$2b$')
    
    def test_input_sanitization(self):
        """Test input sanitization against various attack vectors"""
        # Test SQL injection attempts
        sql_injection_tests = [
            ("admin' OR '1'='1", "admin OR 11"),
            ("'; DROP TABLE users; --", " DROP TABLE users; "),
            ("admin' UNION SELECT * FROM users", "admin UNION SELECT FROM users"),
            ("admin' AND 1=1", "admin AND 11"),
        ]
        
        for malicious_input, expected_output in sql_injection_tests:
            sanitized = sanitize_input(malicious_input)
            assert sanitized != malicious_input
            assert "OR" not in sanitized or "OR" not in expected_output
            assert "DROP" not in sanitized or "DROP" not in expected_output
        
        # Test XSS attempts
        xss_tests = [
            ("<script>alert('xss')</script>", "scriptalertxss"),
            ("javascript:alert('xss')", "javascriptalertxss"),
            ("<img src=x onerror=alert('xss')>", "img srcx onerroralertxss"),
        ]
        
        for malicious_input, expected_output in xss_tests:
            sanitized = sanitize_input(malicious_input)
            assert "<" not in sanitized
            assert ">" not in sanitized
            assert "script" not in sanitized.lower()
            assert "javascript" not in sanitized.lower()
        
        # Test command injection attempts
        cmd_tests = [
            ("admin; rm -rf /", "admin; rm -rf "),
            ("admin && format c:", "admin && format c"),
            ("admin | powershell", "admin | powershell"),
        ]
        
        for malicious_input, expected_output in cmd_tests:
            sanitized = sanitize_input(malicious_input)
            assert "rm" not in sanitized or "rm" not in expected_output
            assert "format" not in sanitized or "format" not in expected_output
            assert "powershell" not in sanitized or "powershell" not in expected_output
    
    def test_rate_limiting(self):
        """Test rate limiting functionality"""
        client_ip = "192.168.1.100"
        
        # Test normal rate limiting
        for i in range(10):
            assert check_rate_limit(client_ip) == True
        
        # Test rate limit exceeded
        # Note: This depends on the rate limit configuration
        # The test may need adjustment based on actual limits
    
    def test_login_attempts_tracking(self):
        """Test login attempts tracking and blocking"""
        client_ip = "192.168.1.101"
        
        # Test initial state
        assert check_login_attempts(client_ip) == True
        
        # Record failed attempts
        for i in range(3):
            record_login_attempt(client_ip, False)
        
        # Should be blocked after max attempts
        assert check_login_attempts(client_ip) == False
        
        # Record successful attempt should reset
        record_login_attempt(client_ip, True)
        assert check_login_attempts(client_ip) == True
    
    def test_jwt_token_creation_and_verification(self):
        """Test JWT token creation and verification"""
        user_data = {
            "sub": "test_user",
            "role": "user",
            "ip": "192.168.1.100"
        }
        
        # Create token
        token = create_access_token(user_data)
        
        # Verify token
        decoded = verify_token(token)
        assert decoded is not None
        assert decoded["sub"] == "test_user"
        assert decoded["role"] == "user"
        assert decoded["ip"] == "192.168.1.100"
        
        # Test invalid token
        invalid_token = "invalid.token.here"
        assert verify_token(invalid_token) is None
    
    @pytest.mark.asyncio
    async def test_database_connection_management(self):
        """Test database connection management"""
        # Test connection creation
        conn = await get_db_connection()
        assert conn is not None
        
        # Test connection closure
        await close_db_connection(conn)
        
        # Test multiple connections
        connections = []
        for i in range(5):
            conn = await get_db_connection()
            connections.append(conn)
        
        # Close all connections
        for conn in connections:
            await close_db_connection(conn)
    
    @pytest.mark.asyncio
    async def test_logging_functionality(self):
        """Test logging functionality"""
        test_message = "Test log message"
        test_type = "test"
        test_source = "test_source"
        
        # Test log insertion
        await insert_log(test_message, test_type, test_source)
        
        # Verify log was inserted (this would require checking the database)
        # For now, we just test that the function doesn't raise an exception
    
    def test_jalali_date_formatting(self):
        """Test Jalali date formatting"""
        jalali_str = get_jalali_now_str()
        
        # Verify format is string
        assert isinstance(jalali_str, str)
        
        # Verify it's not empty
        assert len(jalali_str) > 0

class TestSecurityVulnerabilities:
    """Test suite for security vulnerability fixes"""
    
    def test_sql_injection_prevention(self):
        """Test SQL injection prevention in sanitization"""
        # Test various SQL injection patterns
        injection_patterns = [
            "admin' OR '1'='1'--",
            "admin'; DROP TABLE users; --",
            "admin' UNION SELECT * FROM users--",
            "admin' AND 1=1--",
            "admin' OR 1=1#",
            "admin' OR 1=1/*",
        ]
        
        for pattern in injection_patterns:
            sanitized = sanitize_input(pattern)
            
            # Check that dangerous SQL keywords are removed
            dangerous_keywords = ['OR', 'AND', 'UNION', 'SELECT', 'DROP', 'DELETE', 'INSERT', 'UPDATE']
            for keyword in dangerous_keywords:
                if keyword in pattern.upper():
                    # The sanitized version should not contain the dangerous keyword
                    # or it should be significantly different
                    assert sanitized != pattern
    
    def test_xss_prevention(self):
        """Test XSS prevention in sanitization"""
        # Test various XSS patterns
        xss_patterns = [
            "<script>alert('xss')</script>",
            "javascript:alert('xss')",
            "<img src=x onerror=alert('xss')>",
            "<iframe src=javascript:alert('xss')></iframe>",
            "onload=alert('xss')",
            "onerror=alert('xss')",
        ]
        
        for pattern in xss_patterns:
            sanitized = sanitize_input(pattern)
            
            # Check that dangerous HTML tags and attributes are removed
            assert "<" not in sanitized
            assert ">" not in sanitized
            assert "script" not in sanitized.lower()
            assert "javascript" not in sanitized.lower()
            assert "onload" not in sanitized.lower()
            assert "onerror" not in sanitized.lower()
    
    def test_command_injection_prevention(self):
        """Test command injection prevention"""
        # Test various command injection patterns
        cmd_patterns = [
            "admin; rm -rf /",
            "admin && format c:",
            "admin | powershell -Command 'Get-Process'",
            "admin; del /s /q *",
            "admin && mkfs.ext4 /dev/sda1",
        ]
        
        for pattern in cmd_patterns:
            sanitized = sanitize_input(pattern)
            
            # Check that dangerous commands are removed
            dangerous_commands = ['rm', 'del', 'format', 'mkfs', 'powershell', 'cmd']
            for cmd in dangerous_commands:
                if cmd in pattern.lower():
                    # The sanitized version should be different
                    assert sanitized != pattern

class TestLoginSystemIntegration:
    """Integration tests for the complete login system"""
    
    @pytest.mark.asyncio
    async def test_complete_login_flow(self):
        """Test complete login flow with database"""
        # This would require a more complex setup with the actual FastAPI app
        # For now, we test the individual components
        
        # Test password hashing
        password = "secure_password_123"
        hashed = hash_password(password)
        assert verify_password(password, hashed)
        
        # Test input sanitization
        username = "admin' OR '1'='1"
        sanitized = sanitize_input(username)
        assert sanitized != username
        
        # Test rate limiting
        client_ip = "192.168.1.100"
        assert check_rate_limit(client_ip)
        
        # Test login attempts
        assert check_login_attempts(client_ip)
        record_login_attempt(client_ip, False)
        record_login_attempt(client_ip, True)  # Reset with success
        assert check_login_attempts(client_ip)

@pytest.mark.asyncio
async def test_performance_metrics():
    async with httpx.AsyncClient() as client:
        resp = await client.get("http://localhost:3000/performance_metrics")
        assert resp.status_code in [200, 401, 403]

@pytest.mark.asyncio
async def test_get_translations():
    async with httpx.AsyncClient() as client:
        resp = await client.get("http://localhost:3000/get_translations?lang=fa")
        assert resp.status_code == 200
        resp = await client.get("http://localhost:3000/get_translations?lang=en")
        assert resp.status_code == 200

@pytest.mark.asyncio
async def test_get_photo_count():
    async with httpx.AsyncClient() as client:
        resp = await client.get("http://localhost:3000/get_photo_count")
        assert resp.status_code in [200, 401, 403]

@pytest.mark.asyncio
async def test_get_smart_features():
    async with httpx.AsyncClient() as client:
        resp = await client.get("http://localhost:3000/get_smart_features")
        assert resp.status_code in [200, 401, 403]

@pytest.mark.asyncio
async def test_set_smart_features():
    async with httpx.AsyncClient() as client:
        resp = await client.post("http://localhost:3000/set_smart_features", json={"motion": True, "tracking": False})
        assert resp.status_code in [200, 401, 403]

@pytest.mark.asyncio
async def test_get_all_logs():
    async with httpx.AsyncClient() as client:
        resp = await client.get("http://localhost:3000/get_all_logs")
        assert resp.status_code in [200, 401, 403]

@pytest.mark.asyncio
async def test_delete_video_by_filename():
    async with httpx.AsyncClient() as client:
        resp = await client.post("http://localhost:3000/delete_video/test_nonexistent.mp4")
        assert resp.status_code in [404, 401, 403, 503]

@pytest.mark.asyncio
async def test_api_users():
    async with httpx.AsyncClient() as client:
        resp = await client.get("http://localhost:3000/api/users")
        assert resp.status_code in [200, 401, 403]

@pytest.mark.asyncio
async def test_ws_video():
    import websockets
    try:
        async with websockets.connect("ws://localhost:3000/ws/video", extra_headers={"authorization": "Bearer invalidtoken"}) as ws:
            await ws.send("ping")
    except Exception:
        assert True  # Connection should fail or close

@pytest.mark.asyncio
async def test_ws_pico():
    import websockets
    try:
        async with websockets.connect("ws://localhost:3001/ws/pico", extra_headers={"authorization": "Bearer invalidtoken"}) as ws:
            await ws.send("ping")
    except Exception:
        assert True

@pytest.mark.asyncio
async def test_ws_esp32cam():
    import websockets
    try:
        async with websockets.connect("ws://localhost:3002/ws/esp32cam", extra_headers={"authorization": "Bearer invalidtoken"}) as ws:
            await ws.send("ping")
    except Exception:
        assert True

@pytest.mark.asyncio
async def test_device_status_endpoints():
    async with httpx.AsyncClient() as client:
        for url in ["/esp32cam/status", "/pico/status", "/devices/status", "/system/performance"]:
            resp = await client.get(f"http://localhost:3000{url}")
            assert resp.status_code in [200, 401, 403]

@pytest.mark.asyncio
async def test_ports_endpoint():
    async with httpx.AsyncClient() as client:
        resp = await client.get("http://localhost:3000/ports")
        assert resp.status_code == 200

@pytest.mark.asyncio
async def test_static_file():
    async with httpx.AsyncClient() as client:
        resp = await client.get("http://localhost:3000/static/css/index/styles.css")
        assert resp.status_code in [200, 404]

# Edge-case & fuzzing tests
@pytest.mark.asyncio
async def test_upload_photo_fuzz():
    async with httpx.AsyncClient() as client:
        # ارسال فایل بسیار بزرگ
        data = {"photo": b"x"*600_000, "quality": 80, "flash_used": False, "intensity": 50}
        resp = await client.post("http://localhost:3000/upload_photo", data=data)
        assert resp.status_code in [400, 413, 401, 403]

@pytest.mark.asyncio
async def test_upload_frame_fuzz():
    async with httpx.AsyncClient() as client:
        # ارسال داده باینری خراب
        data = {"frame": b"notajpegdata"}
        resp = await client.post("http://localhost:3000/upload_frame", data=data)
        assert resp.status_code in [400, 401, 403]

def run_comprehensive_tests():
    """Run all comprehensive tests"""
    print("🔍 Starting Comprehensive System Analysis Tests...")
    print("=" * 60)
    
    # Test categories
    test_categories = [
        ("Login System Security", TestLoginSystemSecurity),
        ("Security Vulnerabilities", TestSecurityVulnerabilities),
        ("Login System Integration", TestLoginSystemIntegration),
    ]
    
    total_tests = 0
    passed_tests = 0
    failed_tests = 0
    
    for category_name, test_class in test_categories:
        print(f"\n📋 Testing: {category_name}")
        print("-" * 40)
        
        # Get all test methods
        test_methods = [method for method in dir(test_class) if method.startswith('test_')]
        
        for test_method in test_methods:
            total_tests += 1
            try:
                # Create test instance and run test
                test_instance = test_class()
                if hasattr(test_instance, 'setup_test_environment'):
                    test_instance.setup_test_environment()
                
                # Run the test method
                test_method_obj = getattr(test_instance, test_method)
                if asyncio.iscoroutinefunction(test_method_obj):
                    asyncio.run(test_method_obj())
                else:
                    test_method_obj()
                
                print(f"✅ {test_method}: PASSED")
                passed_tests += 1
                
            except Exception as e:
                print(f"❌ {test_method}: FAILED - {str(e)}")
                failed_tests += 1
    
    print("\n" + "=" * 60)
    print("📊 TEST RESULTS SUMMARY")
    print("=" * 60)
    print(f"Total Tests: {total_tests}")
    print(f"Passed: {passed_tests}")
    print(f"Failed: {failed_tests}")
    print(f"Success Rate: {(passed_tests/total_tests*100):.1f}%" if total_tests > 0 else "No tests run")
    
    if failed_tests == 0:
        print("\n🎉 All tests passed! System is secure and functional.")
    else:
        print(f"\n⚠️  {failed_tests} tests failed. Please review the issues above.")
    
    return failed_tests == 0

if __name__ == "__main__":
    success = run_comprehensive_tests()
    sys.exit(0 if success else 1) 