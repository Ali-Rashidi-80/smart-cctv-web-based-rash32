#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Database Debug Script
دیباگ دیتابیس
"""

import asyncio
import aiosqlite

async def debug_database():
    """دیباگ دیتابیس"""
    print("🔍 دیباگ دیتابیس")
    print("=" * 50)
    
    try:
        conn = await aiosqlite.connect("smart_camera_system.db")
        
        # بررسی ساختار جدول users
        print("📊 بررسی ساختار جدول users:")
        cursor = await conn.execute("PRAGMA table_info(users)")
        columns = await cursor.fetchall()
        for col in columns:
            print(f"   {col[1]} ({col[2]}) - {col[3]}")
        
        print()
        
        # بررسی داده‌های کاربر admin
        print("👤 بررسی داده‌های کاربر admin:")
        cursor = await conn.execute(
            'SELECT username, password_hash, role, is_active, two_fa_enabled, two_fa_secret FROM users WHERE username = ?',
            ("admin",)
        )
        user_data = await cursor.fetchone()
        
        if user_data:
            print(f"   تعداد فیلدها: {len(user_data)}")
            print(f"   username: {user_data[0]}")
            print(f"   password_hash: {user_data[1][:20]}...")
            print(f"   role: {user_data[2]}")
            print(f"   is_active: {user_data[3]}")
            print(f"   two_fa_enabled: {user_data[4]}")
            print(f"   two_fa_secret: {user_data[5]}")
        else:
            print("   کاربر admin یافت نشد!")
        
        print()
        
        # تست unpacking
        print("🧪 تست unpacking:")
        if user_data:
            try:
                username, password_hash, role, is_active, two_fa_enabled, two_fa_secret = user_data
                print("   ✅ Unpacking موفق بود")
                print(f"   username: {username}")
                print(f"   role: {role}")
                print(f"   is_active: {is_active}")
            except Exception as e:
                print(f"   ❌ خطا در unpacking: {e}")
        
        await conn.close()
        
    except Exception as e:
        print(f"❌ خطا: {e}")

if __name__ == "__main__":
    asyncio.run(debug_database()) 