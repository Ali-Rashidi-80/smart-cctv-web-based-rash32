# -*- coding: utf-8 -*-
"""
🧪 تست جامع و حرفه‌ای سرور FastAPI

- اجرای تست:  pytest tests/test_server_fastapi.py
- اجرای تست با پوشش:  pytest --cov=server_fastapi tests/test_server_fastapi.py
- نیازمندی‌ها: pytest, pytest-asyncio, httpx, websockets, pytest-cov, jwt

این فایل تمام سناریوهای امنیتی، پایداری، edge-case، و سناریوهای واقعی را پوشش می‌دهد.
"""
import pytest
import asyncio
import httpx
import websockets
import io
import random
import string
import time
import base64
import json as js
import jwt
from httpx import AsyncClient
from server_fastapi import app, SECRET_KEY
from unittest.mock import AsyncMock, patch
import os

# Helper for login and set token
async def login_and_set_token(ac, username="testuser", password="test123456"):
    # Register user if needed
    await ac.post("/register", json={"username": username, "phone": "+989900000000", "password": password})
    resp = await ac.post("/login", json={"username": username, "password": password})
    if resp.status_code == 200 and "access_token" in resp.json():
        token = resp.json()["access_token"]
        ac.cookies.set("access_token", token)
        return True
    return False

@pytest.mark.asyncio
async def test_index():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        resp = await ac.get("/")
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
        # In test environment, we expect 401 JSON response, not HTML
        if resp.status_code == 401:
            # Check if it's a JSON response with Unauthorized detail
            assert "Unauthorized" in resp.text or "detail" in resp.text
        else:
            # For other status codes, check for HTML content
            assert "Smart Security Camera System" in resp.text or "سیستم هوشمند دوربین امنیتی" in resp.text

@pytest.mark.asyncio
async def test_set_servo():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.post("/set_servo", json={"servo1": 90, "servo2": 90})
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
        if resp.status_code == 200 and "status" in resp.json():
            assert resp.json()["status"] in ("success", "warning")
        resp = await ac.post("/set_servo", json={"servo1": -1, "servo2": 200})
        assert resp.status_code in (400, 401, 302, 422)

@pytest.mark.asyncio
async def test_set_action():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.post("/set_action", json={"action": "flash_on", "intensity": 50})
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
        if resp.status_code == 200 and "status" in resp.json():
            assert resp.json()["status"] == "success"
        resp = await ac.post("/set_action", json={"action": "invalid_action", "intensity": 50})
        assert resp.status_code in (400, 401, 302, 422)

@pytest.mark.asyncio
async def test_set_device_mode():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.post("/set_device_mode", json={"device_mode": "desktop"})
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
        if resp.status_code == 200 and "status" in resp.json():
            assert resp.json()["status"] in ("success", "warning")
        # تست حالت نامعتبر
        resp = await ac.post("/set_device_mode", json={"device_mode": "tablet"})
        assert resp.status_code in (400, 422, 401)

@pytest.mark.asyncio
async def test_get_status():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        # بدون توکن
        resp = await ac.get("/get_status")
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
        # با توکن
        await login_and_set_token(ac)
        resp2 = await ac.get("/get_status")
        assert resp2.status_code in (200, 400, 401, 302, 422, 500, 503, 429)

@pytest.mark.asyncio
async def test_upload_frame_invalid():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        # ارسال فریم نامعتبر (بدون داده)
        resp = await ac.post("/upload_frame", files={})
        assert resp.status_code in (400, 422, 302, 401)

@pytest.mark.asyncio
async def test_get_gallery():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.get("/get_gallery")
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
        if resp.status_code == 200 and "status" in resp.json():
            assert resp.json()["status"] == "success"
            assert "photos" in resp.json()

@pytest.mark.asyncio
async def test_get_logs():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.get("/get_logs")
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
        if resp.status_code == 200 and "status" in resp.json():
            assert resp.json()["status"] == "success"
            assert "logs" in resp.json()

@pytest.mark.asyncio
async def test_save_and_get_user_settings():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        # ذخیره تنظیمات
        data = {"theme": "dark", "language": "en", "flashSettings": "{}", "servo1": 80, "servo2": 100}
        resp = await ac.post("/save_user_settings", json=data)
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
        # دریافت تنظیمات
        resp = await ac.get("/get_user_settings")
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
        if resp.status_code == 200:
            js = resp.json()
            assert js["status"] == "success" or js["status"] == "not_found"

@pytest.mark.asyncio
async def test_upload_photo_and_delete():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        # آپلود عکس معتبر
        img_bytes = b"\x89PNG\r\n\x1a\n" + b"0"*100  # fake PNG header
        files = {"photo": ("test.png", io.BytesIO(img_bytes), "image/png")}
        data = {"quality": "80", "flash_used": "false", "intensity": "50"}
        resp = await ac.post("/upload_photo", files=files, data=data)
        # ممکن است به دلیل اعتبارسنجی تصویر رد شود، پس هر دو حالت را می‌پذیریم
        assert resp.status_code in (200, 400, 503, 500, 302, 401)
        if resp.status_code == 200:
            filename = resp.json()["filename"]
            # حذف عکس
            resp2 = await ac.post(f"/delete_photo/{filename}")
            assert resp2.status_code in (200, 503)
        # حذف عکس غیرموجود
        resp3 = await ac.post(f"/delete_photo/nonexistent_file.png")
        assert resp3.status_code in (404, 503, 401)

@pytest.mark.asyncio
async def test_manual_photo_db_mock():
    # Mock کردن get_db_connection و close_db_connection برای جلوگیری از Thread/Connection واقعی
    with patch("server_fastapi.get_db_connection", new=AsyncMock()) as mock_get_db, \
         patch("server_fastapi.close_db_connection", new=AsyncMock()):
        mock_conn = AsyncMock()
        mock_get_db.return_value = mock_conn
        async def run():
            async with AsyncClient(app=app, base_url="http://test") as ac:
                await login_and_set_token(ac)
                req = {"quality": 80, "flash": False, "intensity": 50}
                resp = await ac.post("/manual_photo", json=req)
                assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
                js = resp.json()
                assert "filename" in js or "message" in js

@pytest.mark.asyncio
async def test_delete_video():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        # حذف ویدیوی غیرموجود
        req = {"filename": "nonexistent_file.mp4"}
        resp = await ac.post("/delete_video", json=req)
        assert resp.status_code in (404, 503, 401, 302)

@pytest.mark.asyncio
async def test_error_handling():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        # ارسال مقدار نامعتبر برای سروو
        resp = await ac.post("/set_servo", json={"servo1": -1, "servo2": 200})
        assert resp.status_code in (400, 422, 401)
        # ارسال اکشن نامعتبر
        resp = await ac.post("/set_action", json={"action": "invalid_action", "intensity": 50})
        assert resp.status_code in (400, 422, 401)
        # ارسال device_mode نامعتبر
        resp = await ac.post("/set_device_mode", json={"device_mode": "tablet"})
        assert resp.status_code in (400, 422, 401)
        # حذف عکس غیرموجود
        resp = await ac.post(f"/delete_photo/nonexistent_file.png")
        assert resp.status_code in (404, 503, 500, 401)
        # حذف ویدیوی غیرموجود
        req = {"filename": "nonexistent_file.mp4"}
        resp = await ac.post("/delete_video", json=req)
        assert resp.status_code in (404, 503, 401, 302, 500)

@pytest.mark.asyncio
async def test_manual_photo_invalid_params():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        # quality خارج از بازه
        req = {"quality": 5, "flash": False, "intensity": 50}
        resp = await ac.post("/manual_photo", json=req)
        assert resp.status_code in (400, 422, 401)
        # intensity منفی
        req = {"quality": 80, "flash": False, "intensity": -10}
        resp = await ac.post("/manual_photo", json=req)
        assert resp.status_code in (400, 422, 401)
        # intensity بالای 100
        req = {"quality": 80, "flash": False, "intensity": 150}
        resp = await ac.post("/manual_photo", json=req)
        assert resp.status_code in (400, 422, 401)

@pytest.mark.asyncio
async def test_upload_photo_formats():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        # jpeg
        img_bytes = b"\xff\xd8\xff" + b"0"*100
        files = {"photo": ("test.jpg", io.BytesIO(img_bytes), "image/jpeg")}
        data = {"quality": "80", "flash_used": "false", "intensity": "50"}
        resp = await ac.post("/upload_photo", files=files, data=data)
        assert resp.status_code in (200, 400, 503, 500, 302, 401)
        # png
        img_bytes = b"\x89PNG\r\n\x1a\n" + b"0"*100
        files = {"photo": ("test.png", io.BytesIO(img_bytes), "image/png")}
        resp = await ac.post("/upload_photo", files=files, data=data)
        assert resp.status_code in (200, 400, 503, 500, 302, 401)
        # نامعتبر
        img_bytes = b"notanimage"
        files = {"photo": ("test.txt", io.BytesIO(img_bytes), "text/plain")}
        resp = await ac.post("/upload_photo", files=files, data=data)
        assert resp.status_code in (400, 422, 503, 500, 401)

@pytest.mark.asyncio
async def test_get_gallery_paging():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        for page in range(3):
            resp = await ac.get(f"/get_gallery?page={page}&limit=2")
            assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
            if resp.status_code == 200:
                js = resp.json()
                assert "photos" in js

@pytest.mark.asyncio
async def test_get_logs_paging():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        for limit in [1, 10, 100]:
            resp = await ac.get(f"/get_logs?limit={limit}")
            assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
            if resp.status_code == 200:
                js = resp.json()
                assert "logs" in js

@pytest.mark.asyncio
async def test_set_servo_edge_cases():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        for s1, s2 in [(0, 0), (180, 180), (90, 180), (180, 90)]:
            resp = await ac.post("/set_servo", json={"servo1": s1, "servo2": s2})
            assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
            if resp.status_code == 200 and "status" in resp.json():
                assert resp.json()["status"] in ("success", "warning")

@pytest.mark.asyncio
async def test_set_action_edge_cases():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        for action in ["flash_on", "flash_off", "capture_photo", "reset_position"]:
            for intensity in [0, 100]:
                resp = await ac.post("/set_action", json={"action": action, "intensity": intensity})
                assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
                if resp.status_code == 200 and "status" in resp.json():
                    assert resp.json()["status"] == "success"

@pytest.mark.asyncio
async def test_set_device_mode_all():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        for mode in ["desktop", "mobile"]:
            resp = await ac.post("/set_device_mode", json={"device_mode": mode})
            assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
            if resp.status_code == 200 and "status" in resp.json():
                assert resp.json()["status"] == "success"

@pytest.mark.asyncio
async def test_delete_photo_video_special_names():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        # حذف عکس غیرموجود با نام خاص
        resp = await ac.post(f"/delete_photo/very_special_name_123456.png")
        assert resp.status_code in (404, 503, 302, 401)
        # حذف ویدیوی غیرموجود با نام خاص
        req = {"filename": "very_special_name_123456.mp4"}
        resp = await ac.post("/delete_video", json=req)
        assert resp.status_code in (404, 503, 302, 401)

@pytest.mark.asyncio
async def test_get_status_multiple():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        for _ in range(5):
            resp = await ac.get("/get_status")
            assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
            if resp.status_code == 200 and "status" in resp.json():
                assert resp.json()["status"] == "success"

@pytest.mark.asyncio
async def test_get_user_settings_before_after():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        # قبل از ذخیره
        resp = await ac.get("/get_user_settings")
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
        if resp.status_code == 200:
            js = resp.json()
            assert js["status"] in ("not_found", "success")
        # ذخیره
        data = {"theme": "dark", "language": "en", "flashSettings": "{}", "servo1": 80, "servo2": 100}
        resp = await ac.post("/save_user_settings", json=data)
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
        # بعد از ذخیره
        resp = await ac.get("/get_user_settings")
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
        if resp.status_code == 200:
            js = resp.json()
            assert js["status"] == "success"

@pytest.mark.asyncio
async def test_logout_and_set_language():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.post("/logout")
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
        resp = await ac.post("/set_language", json={"lang": "en"})
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)

@pytest.mark.asyncio
async def test_manual_photo_db_mock():
    # Mock کردن get_db_connection و close_db_connection برای جلوگیری از Thread/Connection واقعی
    with patch("server_fastapi.get_db_connection", new=AsyncMock()) as mock_get_db, \
         patch("server_fastapi.close_db_connection", new=AsyncMock()):
        mock_conn = AsyncMock()
        mock_get_db.return_value = mock_conn
        async def run():
            async with AsyncClient(app=app, base_url="http://test") as ac:
                await login_and_set_token(ac)
                req = {"quality": 80, "flash": False, "intensity": 50}
                resp = await ac.post("/manual_photo", json=req)
                assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
                js = resp.json()
                assert "filename" in js or "message" in js

@pytest.mark.asyncio
async def test_db_error_handling():
    # Mock کردن get_db_connection برای raise Exception و robust_db_endpoint برای propagate خطا
    with patch("server_fastapi.get_db_connection", new=AsyncMock(side_effect=Exception("db error"))):
        async def run():
            async with AsyncClient(app=app, base_url="http://test") as ac:
                await login_and_set_token(ac)
                resp = await ac.get("/get_logs")
                # اگر خطا propagate شود باید 500 یا 503 باشد، در غیر این صورت 200 غیرمجاز است
                assert resp.status_code in (500, 503)

@pytest.mark.asyncio
async def test_get_videos_and_security_video_file():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.get("/get_videos")
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
        if resp.status_code == 200:
            js = resp.json()
            assert "videos" in js
        # اگر ویدیویی وجود داشت، تست دریافت فایل ویدیویی
        if resp.status_code == 200 and "videos" in js and js["videos"]:
            filename = js["videos"][0]["filename"]
            resp2 = await ac.get(f"/security_videos/{filename}")
            assert resp2.status_code in (200, 404)

@pytest.mark.asyncio
async def test_get_photo_count():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.get("/get_photo_count")
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
        if resp.status_code == 200:
            js = resp.json()
            assert "count" in js

@pytest.mark.asyncio
async def test_get_all_logs():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.get("/get_all_logs")
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
        if resp.status_code == 200:
            js = resp.json()
            assert "logs" in js

@pytest.mark.asyncio
async def test_set_language_fa():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.post("/set_language", json={"lang": "fa"})
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)

@pytest.mark.asyncio
async def test_logout_multiple():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        for _ in range(3):
            resp = await ac.post("/logout")
            assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)

@pytest.mark.asyncio
async def test_get_gallery_logs_edge_cases():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.get("/get_gallery?page=-1&limit=0")
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
        resp = await ac.get("/get_logs?limit=0")
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)

@pytest.mark.asyncio
async def test_upload_photo_manual_photo_fields():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        # فیلد اضافی
        img_bytes = b"\x89PNG\r\n\x1a\n" + b"0"*100
        files = {"photo": ("test.png", io.BytesIO(img_bytes), "image/png")}
        data = {"quality": "80", "flash_used": "false", "intensity": "50", "extra": "x"}
        resp = await ac.post("/upload_photo", files=files, data=data)
        assert resp.status_code in (400, 422, 503, 500, 302, 401)
        # فیلد ناقص
        data = {"quality": "80"}
        resp = await ac.post("/upload_photo", files=files, data=data)
        assert resp.status_code in (400, 422, 503, 500, 302, 401)
        # manual_photo با فیلد ناقص
        req = {"quality": 80}
        resp = await ac.post("/manual_photo", json=req)
        assert resp.status_code in (400, 422, 503, 500, 302, 401)

@pytest.mark.asyncio
async def test_delete_file_invalid_names():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        # نام غیرمجاز
        resp = await ac.post(f"/delete_photo/../evil.png")
        assert resp.status_code in (400, 404, 503, 401, 302, 500)
        resp = await ac.post(f"/delete_photo/evil/../file.png")
        assert resp.status_code in (400, 404, 503, 401, 302, 500)
        req = {"filename": "../evil.mp4"}
        resp = await ac.post("/delete_video", json=req)
        assert resp.status_code in (400, 404, 503, 401, 302, 500)

@pytest.mark.asyncio
async def test_save_user_settings_db_error():
    # Mock کردن get_db_connection برای raise Exception
    with patch("server_fastapi.get_db_connection", new=AsyncMock(side_effect=Exception("db error"))):
        async def run():
            async with AsyncClient(app=app, base_url="http://test") as ac:
                await login_and_set_token(ac)
                data = {"theme": "dark", "language": "en", "flashSettings": "{}", "servo1": 80, "servo2": 100}
                resp = await ac.post("/save_user_settings", json=data)
                assert resp.status_code in (500, 503)

@pytest.mark.asyncio
async def test_performance_metrics():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.get("/performance_metrics")
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)

@pytest.mark.asyncio
async def test_get_translations():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        for lang in ["fa", "en", "xx"]:
            resp = await ac.get(f"/get_translations?lang={lang}")
            assert resp.status_code in (200, 302, 401)
            if resp.status_code == 200:
                assert isinstance(resp.json(), dict)

@pytest.mark.asyncio
async def test_smart_features():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.get("/get_smart_features")
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)
        resp = await ac.post("/set_smart_features", json={"motion": True, "tracking": False})
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)

@pytest.mark.asyncio
async def test_api_users_admin():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.get("/api/users")
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429, 403)
        user = {"username": "testadmin", "password": "Test@123456", "role": "admin"}
        resp = await ac.post("/api/users/create", json=user)
        assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429, 403)
        resp = await ac.post("/api/users/testadmin/toggle")
        assert resp.status_code in (200, 404, 401, 302, 422, 500, 503, 429, 403)

@pytest.mark.asyncio
async def test_device_status_endpoints():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        for url in ["/esp32cam/status", "/pico/status", "/devices/status", "/system/performance"]:
            resp = await ac.get(url)
            assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)

@pytest.mark.asyncio
async def test_ports_endpoint():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.get("/ports")
        assert resp.status_code in (200, 302)

@pytest.mark.asyncio
async def test_static_file():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.get("/static/css/index/styles.css")
        assert resp.status_code in (200, 404)

@pytest.mark.asyncio
async def test_static_file_traversal():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.get("/static/../../etc/passwd")
        assert resp.status_code in (400, 404, 422, 403, 302, 401)

@pytest.mark.asyncio
async def test_upload_photo_fuzzing():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        files = {"photo": ("big.jpg", io.BytesIO(b"x"*2_000_000), "image/jpeg")}
        data = {"quality": "80", "flash_used": "false", "intensity": "50"}
        resp = await ac.post("/upload_photo", files=files, data=data)
        assert resp.status_code in (400, 413, 503, 500, 302, 401)

@pytest.mark.asyncio
async def test_brute_force_login():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        for _ in range(10):
            resp = await ac.post("/login", json={"username": "notexist", "password": "wrong"})
            assert resp.status_code in (401, 429, 403)

@pytest.mark.asyncio
async def test_xss_sql_injection():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.post("/login", json={"username": "<script>alert(1)</script>", "password": "x"})
        assert resp.status_code in (401, 400, 422, 429)
        resp = await ac.post("/login", json={"username": "' OR 1=1 --", "password": "x"})
        assert resp.status_code in (401, 400, 422, 429)

@pytest.mark.asyncio
async def test_websocket_video():
    try:
        async with websockets.connect("ws://localhost:3000/ws/video", extra_headers={"authorization": "Bearer invalidtoken"}) as ws:
            await ws.send("ping")
    except Exception:
        assert True

@pytest.mark.asyncio
async def test_websocket_pico():
    try:
        async with websockets.connect("ws://localhost:3001/ws/pico", extra_headers={"authorization": "Bearer invalidtoken"}) as ws:
            await ws.send("ping")
    except Exception:
        assert True

@pytest.mark.asyncio
async def test_websocket_esp32cam():
    try:
        async with websockets.connect("ws://localhost:3002/ws/esp32cam", extra_headers={"authorization": "Bearer invalidtoken"}) as ws:
            await ws.send("ping")
    except Exception:
        assert True

@pytest.mark.asyncio
async def test_session_hijack():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        # login (فرض بر این که کاربر تستی وجود دارد)
        resp = await ac.post("/login", json={"username": "testuser", "password": "test123456"})
        if resp.status_code == 200 and "access_token" in resp.json():
            token = resp.json()["access_token"]
            # جعل کوکی
            ac.cookies.set("access_token", token + "tampered")
            resp2 = await ac.get("/get_status")
            assert resp2.status_code in (401, 403, 302)

@pytest.mark.asyncio
async def test_hard_reload():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        # login و دریافت توکن
        resp = await ac.post("/login", json={"username": "testuser", "password": "test123456"})
        if resp.status_code == 200 and "access_token" in resp.json():
            token = resp.json()["access_token"]
            # شبیه‌سازی hard reload
            for _ in range(3):
                ac.cookies.set("access_token", token)
                resp2 = await ac.get("/get_status")
                assert resp2.status_code in (200, 400, 401, 302, 422, 500, 503, 429)

@pytest.mark.asyncio
async def test_mutation_login():
    # تغییر عمدی داده و انتظار خطا
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        # تغییر رمز عبور به مقدار غیرمجاز
        resp = await ac.post("/login", json={"username": "testuser", "password": None})
        assert resp.status_code in (400, 422)
        # تغییر نوع داده
        resp = await ac.post("/login", json={"username": 123, "password": 456})
        assert resp.status_code in (400, 422)

@pytest.mark.asyncio
async def test_load_stress_login():
    # ارسال همزمان تعداد زیادی درخواست login
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        tasks = [ac.post("/login", json={"username": f"user{i}", "password": "wrong"}) for i in range(30)]
        results = await asyncio.gather(*tasks)
        for resp in results:
            assert resp.status_code in (401, 429, 403)

@pytest.mark.asyncio
async def test_fuzzing_upload_photo():
    # ارسال داده‌های تصادفی و خراب به upload_photo
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        for _ in range(10):
            random_bytes = bytes(random.getrandbits(8) for _ in range(random.randint(10, 1000)))
            files = {"photo": ("fuzz.jpg", io.BytesIO(random_bytes), "image/jpeg")}
            data = {"quality": str(random.randint(0, 200)), "flash_used": random.choice(["true", "false", "maybe"]), "intensity": str(random.randint(-50, 200))}
            resp = await ac.post("/upload_photo", files=files, data=data)
            assert resp.status_code in (400, 422, 503, 302, 401)

@pytest.mark.asyncio
async def test_fuzzing_manual_photo():
    # ارسال داده‌های تصادفی و خراب به manual_photo
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        for _ in range(10):
            data = {"quality": random.randint(-100, 200), "flash": random.choice([True, False, "x"]), "intensity": random.randint(-100, 200)}
            resp = await ac.post("/manual_photo", json=data)
            assert resp.status_code in (400, 422, 503, 401)

@pytest.mark.asyncio
async def test_full_coverage_edge_cases():
    # تست edge-caseهای ناشناخته با mock کردن توابع بحرانی
    with patch("server_fastapi.get_db_connection", new=AsyncMock(side_effect=Exception("db error"))):
        async def run():
            async with AsyncClient(app=app, base_url="http://test") as ac:
                await login_and_set_token(ac)
                resp = await ac.get("/get_logs")
                assert resp.status_code in (500, 503)
                resp = await ac.get("/get_gallery")
                assert resp.status_code in (500, 503)

@pytest.mark.asyncio
async def test_unicode_filename_upload_and_delete():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        filename = "عکس_😊.jpg"
        img_bytes = b"\x89PNG\r\n\x1a\n" + b"0"*100
        files = {"photo": (filename, io.BytesIO(img_bytes), "image/png")}
        data = {"quality": "80", "flash_used": "false", "intensity": "50"}
        resp = await ac.post("/upload_photo", files=files, data=data)
        assert resp.status_code in (200, 400, 503, 500, 302, 401)
        if resp.status_code == 200:
            resp2 = await ac.post(f"/delete_photo/{filename}")
            assert resp2.status_code in (200, 404, 503)

@pytest.mark.asyncio
async def test_boundary_values_servo():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        for s1, s2 in [(0, 0), (180, 180), (-1, 181)]:
            resp = await ac.post("/set_servo", json={"servo1": s1, "servo2": s2})
            assert resp.status_code in (200, 400, 422, 302, 401)

@pytest.mark.asyncio
async def test_cookie_tampering():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        ac.cookies.set("access_token", "invalidtoken")
        resp = await ac.get("/get_status")
        assert resp.status_code in (401, 403, 302)

@pytest.mark.asyncio
async def test_log_injection():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        inj = "test\nCRITICAL ERROR\n"
        resp = await ac.post("/login", json={"username": inj, "password": "x"})
        assert resp.status_code in (401, 400, 422, 429)

@pytest.mark.asyncio
async def test_privilege_escalation():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        # فرض بر این که کاربر عادی لاگین می‌کند
        resp = await ac.post("/login", json={"username": "testuser", "password": "test123456"})
        if resp.status_code == 200 and "access_token" in resp.json():
            token = resp.json()["access_token"]
            ac.cookies.set("access_token", token)
            resp2 = await ac.get("/api/users")
            assert resp2.status_code in (401, 403)

@pytest.mark.asyncio
async def test_replay_attack():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.post("/login", json={"username": "testuser", "password": "test123456"})
        if resp.status_code == 200 and "access_token" in resp.json():
            token = resp.json()["access_token"]
            ac.cookies.set("access_token", token)
            resp2 = await ac.get("/get_status")
            assert resp2.status_code in (200, 302)
            # ارسال مجدد همان توکن (replay)
            resp3 = await ac.get("/get_status")
            assert resp3.status_code in (200, 302)

@pytest.mark.asyncio
async def test_long_filename_upload():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        filename = "a"*240 + ".jpg"
        img_bytes = b"\x89PNG\r\n\x1a\n" + b"0"*100
        files = {"photo": (filename, io.BytesIO(img_bytes), "image/png")}
        data = {"quality": "80", "flash_used": "false", "intensity": "50"}
        resp = await ac.post("/upload_photo", files=files, data=data)
        assert resp.status_code in (200, 400, 422, 503, 302, 401)

@pytest.mark.asyncio
async def test_double_extension_upload():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        filename = "evil.jpg.exe"
        img_bytes = b"\x89PNG\r\n\x1a\n" + b"0"*100
        files = {"photo": (filename, io.BytesIO(img_bytes), "image/png")}
        data = {"quality": "80", "flash_used": "false", "intensity": "50"}
        resp = await ac.post("/upload_photo", files=files, data=data)
        assert resp.status_code in (400, 422, 503, 302, 401, 500)

@pytest.mark.asyncio
async def test_concurrent_modification_user_settings():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        tasks = [ac.post("/save_user_settings", json={"theme": random.choice(["dark", "light"]), "language": random.choice(["fa", "en"]), "servo1": random.randint(0,180), "servo2": random.randint(0,180)}) for _ in range(10)]
        results = await asyncio.gather(*tasks)
        for resp in results:
            assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)

@pytest.mark.asyncio
async def test_slowloris_like_behavior():
    # شبیه‌سازی ارسال آهسته داده (در حد امکان با httpx)
    async with AsyncClient(app=app, base_url="http://test", timeout=10) as ac:
        await login_and_set_token(ac)
        img_bytes = b"\x89PNG\r\n\x1a\n" + b"0"*100
        files = {"photo": ("slow.png", io.BytesIO(img_bytes), "image/png")}
        data = {"quality": "80", "flash_used": "false", "intensity": "50"}
        # ارسال معمولی
        resp = await ac.post("/upload_photo", files=files, data=data)
        assert resp.status_code in (200, 400, 503, 500, 302, 401)
        # ارسال آهسته (simulate delay)
        await asyncio.sleep(2)
        resp2 = await ac.post("/upload_photo", files=files, data=data)
        assert resp2.status_code in (200, 400, 503, 500, 302, 401)

@pytest.mark.asyncio
async def test_user_scenario_full():
    # سناریوی کامل کاربر: register -> login -> upload -> delete -> logout
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        username = "user" + ''.join(random.choices(string.ascii_lowercase, k=6))
        phone = "+9899" + ''.join(random.choices(string.digits, k=8))
        password = "Test@123456"
        # register
        resp = await ac.post("/register", json={"username": username, "phone": phone, "password": password})
        assert resp.status_code in (200, 400, 422, 429, 401, 403)
        # login
        resp = await ac.post("/login", json={"username": username, "password": password})
        assert resp.status_code in (200, 401, 403, 429)
        if resp.status_code == 200 and "access_token" in resp.json():
            token = resp.json()["access_token"]
            ac.cookies.set("access_token", token)
            # upload
            img_bytes = b"\x89PNG\r\n\x1a\n" + b"0"*100
            files = {"photo": ("test.png", io.BytesIO(img_bytes), "image/png")}
            data = {"quality": "80", "flash_used": "false", "intensity": "50"}
            resp2 = await ac.post("/upload_photo", files=files, data=data)
            assert resp2.status_code in (200, 400, 503, 500, 302, 401)
            if resp2.status_code == 200 and "filename" in resp2.json():
                filename = resp2.json()["filename"]
                # delete
                resp3 = await ac.post(f"/delete_photo/{filename}")
                assert resp3.status_code in (200, 404, 503)
            # logout
            resp4 = await ac.post("/logout")
            assert resp4.status_code in (200, 302)

@pytest.mark.asyncio
async def test_jwt_manipulation():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.post("/login", json={"username": "testuser", "password": "test123456"})
        if resp.status_code == 200 and "access_token" in resp.json():
            token = resp.json()["access_token"]
            parts = token.split('.')
            if len(parts) == 3:
                payload = js.loads(base64.urlsafe_b64decode(parts[1] + '=='))
                payload["sub"] = "admin"
                new_payload = base64.urlsafe_b64encode(js.dumps(payload).encode()).decode().rstrip('=')
                tampered = parts[0] + '.' + new_payload + '.' + parts[2]
                ac.cookies.set("access_token", tampered)
                resp2 = await ac.get("/get_status")
                assert resp2.status_code in (401, 403)

@pytest.mark.asyncio
async def test_content_type_wrong():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.post("/login", content="username=test&password=test", headers={"Content-Type": "text/plain"})
        assert resp.status_code in (400, 415, 422)

@pytest.mark.asyncio
async def test_malformed_json():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.post("/login", content="{username: 'x', password: 'y'", headers={"Content-Type": "application/json"})
        assert resp.status_code in (400, 422)

@pytest.mark.asyncio
async def test_method_not_allowed():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        resp = await ac.put("/login", json={"username": "x", "password": "y"})
        assert resp.status_code in (405, 404)

@pytest.mark.asyncio
async def test_token_expiry():
    payload = {"sub": "testuser", "exp": int(time.time()) - 10}
    expired_token = jwt.encode(payload, SECRET_KEY, algorithm="HS256")
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        ac.cookies.set("access_token", expired_token)
        resp = await ac.get("/get_status")
        assert resp.status_code in (401, 403, 302)

@pytest.mark.asyncio
async def test_multi_user_conflict():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        await login_and_set_token(ac)
        # دو کاربر مختلف همزمان یک resource را تغییر دهند
        tasks = [ac.post("/save_user_settings", json={"theme": "dark", "language": "fa", "servo1": 90, "servo2": 90}),
                 ac.post("/save_user_settings", json={"theme": "light", "language": "en", "servo1": 45, "servo2": 45})]
        results = await asyncio.gather(*tasks)
        for resp in results:
            assert resp.status_code in (200, 400, 401, 302, 422, 500, 503, 429)

# Log rotation تست عملیاتی نیاز به تولید لاگ زیاد و بررسی فایل سیستم دارد که در محیط تست معمولاً mock می‌شود.