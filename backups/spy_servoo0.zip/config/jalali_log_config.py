from server_fastapi import JalaliFormatter

LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "jalali": {
            "()": "utils.jalali_formatter.JalaliFormatter",
            "fmt": "%(asctime)s - %(levelname)s - %(message)s\n"
        }
    },
    "handlers": {
        "default": {
            "formatter": "jalali",
            "class": "logging.StreamHandler",
            "stream": "ext://sys.stdout",
        },
    },
    "loggers": {
        "": {"handlers": ["default"], "level": "INFO"},
        "uvicorn": {"handlers": ["default"], "level": "INFO", "propagate": False},
        "uvicorn.error": {"handlers": ["default"], "level": "INFO", "propagate": False},
        "uvicorn.access": {"handlers": ["default"], "level": "INFO", "propagate": False},
        "fastapi": {"handlers": ["default"], "level": "INFO", "propagate": False},
        "app": {"handlers": ["default"], "level": "INFO", "propagate": False},
        "db": {"handlers": ["default"], "level": "INFO", "propagate": False},
    }
} 