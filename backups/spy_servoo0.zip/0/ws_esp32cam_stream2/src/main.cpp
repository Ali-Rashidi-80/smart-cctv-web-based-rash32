#include "esp_camera.h"
#include <WiFi.h>
#define WEBSOCKETS_USE_COMPRESSION 1
#include <ArduinoWebsockets.h>
#include <nvs_flash.h>
#include <ArduinoJson.h>

using namespace websockets;

// اطلاعات شبکه و سرور
const char* ssid = "SAMSUNG";      
const char* password = "panzer790"; 
const char* websocket_server = "services.gen6.chabokan.net"; 
const uint16_t websocket_port = 8080; 
const char* websocket_path = "/ws/esp32cam";

// تنظیمات احراز هویت
const char* AUTH_TOKEN = "esp32cam_secure_token_2024";
const char* AUTH_HEADER = "Authorization: Bearer esp32cam_secure_token_2024";

// پین‌های دوربین (AI-THINKER)
#define PWDN_GPIO_NUM     32
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM      0
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27
#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       21
#define Y4_GPIO_NUM       19
#define Y3_GPIO_NUM       18
#define Y2_GPIO_NUM        5
#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22
#define FLASH_GPIO_NUM     4 // پین فلاش LED (PWM)

// تنظیمات PWM برای فلاش
#define FLASH_PWM_CHANNEL  1
#define FLASH_PWM_FREQ     1000
#define FLASH_PWM_RESOLUTION 8
#define MAX_FLASH_DUTY     230 // 90% از 255

// متغیرهای برنامه
WebsocketsClient client;
bool isConnected = false;
bool isManualPhotoMode = false;  // فلگ برای جلوگیری از تداخل
unsigned long manualPhotoStartTime = 0;  // زمان شروع عکس دستی
unsigned long lastFrameTime = 0;
unsigned long frameCount = 0;
float fps = 0;
unsigned long lastAecAdjustTime = 0;
const unsigned long aecAdjustInterval = 3000;
unsigned long reconnectDelay = 1000;
const unsigned long maxReconnectDelay = 4000;
int reconnectAttempts = 0;
const int maxReconnectAttempts = 3;
unsigned long lastDisconnectTime = 0;
const unsigned long maxDisconnectDuration = 300000;
RTC_DATA_ATTR float brightnessMovingAverage = 0;
float lastBrightness = 0;
const float alpha = 0.3;
const float BRIGHTNESS_OFFSET = 0.0;
int cameraErrorCount = 0;
const int maxCameraErrors = 3;
int wifiRestartCount = 0;
const int maxWifiRestarts = 3;
RTC_DATA_ATTR int deepSleepCount = 0;
const int maxDeepSleepCount = 3;
int frameErrorCount = 0;
const int maxFrameErrors = 7;
unsigned long lastLogTime = 0;
const unsigned long logInterval = 10000;

// متغیر برای ذخیره عکس دستی
camera_fb_t* last_captured_fb = nullptr;

// ارسال لاگ به سرور
void sendLog(const String& message, const String& log_type = "info") {
  if (isConnected) {
    String json = "{\"type\":\"log\",\"message\":\"" + message + "\",\"log_type\":\"" + log_type + "\"}";
    client.send(json);
  }
}

// بررسی کیفیت سیگنال WiFi
bool checkWiFiSignal() {
  int32_t rssi = WiFi.RSSI();
  if (rssi < -80) {
    String msg = "Weak WiFi signal: " + String(rssi) + " dBm. Check router!";
    sendLog(msg, "warning");
    return false;
  }
  return true;
}

// تابع ارسال عکس دستی فقط به سرور (بدون ذخیره در SPIFFS)
void sendManualPhoto() {
  // جلوگیری از اجرای همزمان چند عکس دستی
  if (isManualPhotoMode) {
    sendLog("Manual photo already in progress, skipping new request", "warning");
    client.send("{\"type\":\"photo_error\",\"message\":\"Photo capture already in progress\"}");
    return;
  }
  
  isManualPhotoMode = true;
  manualPhotoStartTime = millis();
  
  sendLog("Starting manual photo capture...", "info");
  
  // گرفتن عکس با کیفیت بالا
  camera_fb_t* fb = esp_camera_fb_get();
  if (!fb) {
    sendLog("Failed to capture manual photo", "error");
    client.send("{\"type\":\"photo_error\",\"message\":\"Failed to capture photo\"}");
    isManualPhotoMode = false;
    return;
  }
  
  // ارسال عکس به سرور
  bool sent = client.sendBinary((const char*)fb->buf, fb->len);
  if (sent) {
    sendLog("Manual photo sent successfully: " + String(fb->len) + " bytes", "info");
    client.send("{\"type\":\"photo_sent\",\"size\":" + String(fb->len) + "}");
  } else {
    sendLog("Failed to send manual photo", "error");
    client.send("{\"type\":\"photo_error\",\"message\":\"Failed to send photo\"}");
  }
  
  // آزادسازی حافظه
  esp_camera_fb_return(fb);
  isManualPhotoMode = false;
}

// پردازش دستورات کنترل
void processControlCommand(const String& jsonStr) {
  StaticJsonDocument<512> doc;
  DeserializationError err = deserializeJson(doc, jsonStr);
  if (err) {
    sendLog("JSON parse error in control command: " + String(err.c_str()), "error");
    return;
  }
  
  // پردازش دستورات مختلف
  if (doc.containsKey("action")) {
    String action = doc["action"].as<String>();
    sendLog("Processing action: " + action, "info");
    
    if (action == "capture_photo") {
      sendManualPhoto();
    } else if (action == "flash_on") {
      ledcWrite(FLASH_PWM_CHANNEL, MAX_FLASH_DUTY);
      sendLog("Flash turned ON", "info");
      client.send("{\"type\":\"flash\",\"status\":\"on\"}");
    } else if (action == "flash_off") {
      ledcWrite(FLASH_PWM_CHANNEL, 0);
      sendLog("Flash turned OFF", "info");
      client.send("{\"type\":\"flash\",\"status\":\"off\"}");
    } else if (action == "reset_position") {
      sendLog("Reset position command received", "info");
      client.send("{\"type\":\"reset_position\",\"status\":\"success\"}");
    } else if (action == "emergency_stop") {
      sendLog("Emergency stop command received", "warning");
      client.send("{\"type\":\"emergency_stop\",\"status\":\"success\"}");
    } else if (action == "system_reboot") {
      sendLog("System reboot command received", "warning");
      client.send("{\"type\":\"system_reboot\",\"status\":\"success\"}");
      delay(1000);
      ESP.restart();
    } else {
      sendLog("Unknown action: " + action, "warning");
      client.send("{\"type\":\"unknown_action\",\"action\":\"" + action + "\"}");
    }
  }
  
  // پردازش دستورات سروو (برای لاگ کردن)
  if (doc.containsKey("servo1") && doc.containsKey("servo2")) {
    int servo1 = doc["servo1"].as<int>();
    int servo2 = doc["servo2"].as<int>();
    sendLog("Servo command received: servo1=" + String(servo1) + ", servo2=" + String(servo2), "info");
    client.send("{\"type\":\"servo_command\",\"servo1\":" + String(servo1) + ",\"servo2\":" + String(servo2) + "}");
  }
  
  // پردازش دستورات کیفیت عکس
  if (doc.containsKey("photo_quality")) {
    int quality = doc["photo_quality"].as<int>();
    sendLog("Photo quality set to: " + String(quality), "info");
    // تنظیم کیفیت دوربین
    sensor_t *s = esp_camera_sensor_get();
    if (s) {
      s->set_quality(s, quality);
      client.send("{\"type\":\"photo_quality\",\"quality\":" + String(quality) + "}");
    }
  }
  
  // پردازش دستورات فلاش
  if (doc.containsKey("flash")) {
    bool flash_on = doc["flash"].as<bool>();
    if (flash_on) {
      ledcWrite(FLASH_PWM_CHANNEL, MAX_FLASH_DUTY);
      sendLog("Flash turned ON via command", "info");
    } else {
      ledcWrite(FLASH_PWM_CHANNEL, 0);
      sendLog("Flash turned OFF via command", "info");
    }
    client.send("{\"type\":\"flash\",\"status\":\"" + String(flash_on ? "on" : "off") + "\"}");
  }
}

// callback وب‌سوکت
void onEventsCallback(WebsocketsEvent event, String data) {
  if (event == WebsocketsEvent::ConnectionOpened) {
    sendLog("WebSocket connection opened");
    isConnected = true;
    reconnectAttempts = 0;
    reconnectDelay = 1000;
    lastDisconnectTime = 0;
  } else if (event == WebsocketsEvent::ConnectionClosed) {
    sendLog("WebSocket connection closed", "warning");
    isConnected = false;
    lastDisconnectTime = millis();
  } else if (event == WebsocketsEvent::GotPing) {
    sendLog("Received Ping");
    client.pong();
  } else if (event == WebsocketsEvent::GotText) {
    processControlCommand(data);
  }
}

// اتصال به وب‌سوکت
void connectWebSocket() {
  if (WiFi.status() != WL_CONNECTED) {
    sendLog("WiFi disconnected, attempting to reconnect...", "warning");
    WiFi.reconnect();
    delay(1000);
    if (WiFi.status() != WL_CONNECTED) {
      sendLog("WiFi reconnect failed!", "error");
      return;
    }
  }

  if (!checkWiFiSignal()) {
    sendLog("Weak WiFi signal detected. Entering deep sleep...", "error");
    deepSleepCount++;
    unsigned long sleepTime = (deepSleepCount > maxDeepSleepCount) ? 60000000 : 30000000;
    String msg = "Deep sleep count: " + String(deepSleepCount) + ", sleeping for " + String(sleepTime) + " ms. Check WiFi router!";
    sendLog(msg, "error");
    ledcWrite(FLASH_PWM_CHANNEL, 0);
    esp_sleep_enable_timer_wakeup(sleepTime);
    esp_deep_sleep_start();
  }

  String url = String("ws://") + websocket_server + ":" + String(websocket_port) + websocket_path;
  sendLog("Connecting to " + url);
  
  // تنظیم headers برای احراز هویت
  client.addHeader("Authorization", AUTH_HEADER);
  
  if (client.connect(websocket_server, websocket_port, websocket_path)) {
    sendLog("WebSocket connected!");
    isConnected = true;
    reconnectAttempts = 0;
    reconnectDelay = 1000;
    lastDisconnectTime = 0;
    
    // ارسال پیام اولیه
    String initialMessage = "{\"type\":\"connect\",\"device\":\"esp32cam\",\"timestamp\":\"" + String(millis()) + "\",\"version\":\"1.0\",\"auth_token\":\"" + String(AUTH_TOKEN).substring(0, 10) + "...\"}";
    client.send(initialMessage);
    sendLog("Initial connection message sent");
  } else {
    sendLog("WebSocket connection failed!", "error");
    isConnected = false;
    reconnectAttempts++;
    
    if (reconnectAttempts >= maxReconnectAttempts) {
      sendLog("Max reconnection attempts reached. Entering deep sleep...", "error");
      deepSleepCount++;
      unsigned long sleepTime = (deepSleepCount > maxDeepSleepCount) ? 60000000 : 30000000;
      ledcWrite(FLASH_PWM_CHANNEL, 0);
      esp_sleep_enable_timer_wakeup(sleepTime);
      esp_deep_sleep_start();
    }
    
    // افزایش تدریجی delay
    reconnectDelay = min(reconnectDelay * 2, maxReconnectDelay);
  }
}

// راه‌اندازی مجدد دوربین
void restartCamera() {
  sendLog("Restarting camera...", "warning");
  
  // آزادسازی حافظه فریم
  if (last_captured_fb) {
    esp_camera_fb_return(last_captured_fb);
    last_captured_fb = nullptr;
  }
  
  // راه‌اندازی مجدد دوربین
  esp_camera_deinit();
  delay(1000);
  
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;
  config.pin_sscb_sda = SIOD_GPIO_NUM;
  config.pin_sscb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;
  config.frame_size = FRAMESIZE_VGA;
  config.jpeg_quality = 80;
  config.fb_count = 2;
  
  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    sendLog("Camera init failed with error: " + String(esp_err_to_name(err)), "error");
    cameraErrorCount++;
  } else {
    sendLog("Camera restarted successfully", "info");
    cameraErrorCount = 0;
  }
}

// تنظیم نوردهی خودکار
void adjustExposure(sensor_t *s, unsigned long &frameDuration) {
  if (!s) return;
  
  // تنظیم AEC (Auto Exposure Control)
  s->set_aec2(s, 1);
  s->set_ae_level(s, 0);
  s->set_aec_value(s, 300);
  
  // تنظیم AWB (Auto White Balance)
  s->set_awb_gain(s, 1);
  s->set_wb_mode(s, 0);
  
  // تنظیم WBMODE
  s->set_wb_mode(s, 0);
  
  // تنظیم brightness
  s->set_brightness(s, 0);
  
  // تنظیم contrast
  s->set_contrast(s, 0);
  
  // تنظیم saturation
  s->set_saturation(s, 0);
  
  // تنظیم sharpness
  s->set_sharpness(s, 0);
  
  // تنظیم denoise
  s->set_denoise(s, 1);
  
  // تنظیم quality
  s->set_quality(s, 80);
  
  // تنظیم colorbar
  s->set_colorbar(s, 0);
  
  // تنظیم white balance
  s->set_whitebal(s, 1);
  
  // تنظیم gain control
  s->set_gain_ctrl(s, 1);
  
  // تنظیم exposure control
  s->set_exposure_ctrl(s, 1);
  
  // تنظیم bpc
  s->set_bpc(s, 0);
  
  // تنظیم wpc
  s->set_wpc(s, 1);
  
  // تنظیم raw gma
  s->set_raw_gma(s, 1);
  
  // تنظیم lenc
  s->set_lenc(s, 1);
  
  // تنظیم hmirror
  s->set_hmirror(s, 0);
  
  // تنظیم vflip
  s->set_vflip(s, 0);
  
  // تنظیم dcw
  s->set_dcw(s, 1);
  
  // تنظیم colorbar
  s->set_colorbar(s, 0);
  
  frameDuration = 66; // 15 FPS
}

void setup() {
  Serial.begin(115200);
  Serial.println("ESP32CAM Starting...");
  
  // راه‌اندازی NVS
  esp_err_t ret = nvs_flash_init();
  if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    ESP_ERROR_CHECK(nvs_flash_erase());
    ret = nvs_flash_init();
  }
  ESP_ERROR_CHECK(ret);
  
  // راه‌اندازی PWM برای فلاش
  ledcSetup(FLASH_PWM_CHANNEL, FLASH_PWM_FREQ, FLASH_PWM_RESOLUTION);
  ledcAttachPin(FLASH_GPIO_NUM, FLASH_PWM_CHANNEL);
  ledcWrite(FLASH_PWM_CHANNEL, 0);
  
  // راه‌اندازی دوربین
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;
  config.pin_sscb_sda = SIOD_GPIO_NUM;
  config.pin_sscb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;
  config.frame_size = FRAMESIZE_VGA;
  config.jpeg_quality = 80;
  config.fb_count = 2;
  
  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("Camera init failed with error 0x%x", err);
    return;
  }
  
  // تنظیم WebSocket callback
  client.onEvent(onEventsCallback);
  
  // اتصال به WiFi
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  Serial.println("WiFi connected");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());
  
  // اتصال به WebSocket
  connectWebSocket();
  
  Serial.println("ESP32CAM setup complete");
}

void loop() {
  client.poll();

  // بررسی timeout عکس دستی
  if (isManualPhotoMode && (millis() - manualPhotoStartTime > 2000)) {
    isManualPhotoMode = false;
    sendLog("Manual photo mode timeout - forcing deactivation", "warning");
    client.send("{\"type\":\"photo_error\",\"message\":\"Photo capture timeout\"}");
  }

  // بررسی قطع طولانی
  if (!isConnected && lastDisconnectTime != 0 && (millis() - lastDisconnectTime >= maxDisconnectDuration)) {
    String msg = "Long disconnection detected. Entering deep sleep...";
    sendLog(msg, "error");
    WiFi.disconnect();
    deepSleepCount++;
    unsigned long sleepTime = (deepSleepCount > maxDeepSleepCount) ? 60000000 : 30000000;
    String sleepMsg = "Deep sleep count: " + String(deepSleepCount) + ", sleeping for " + String(sleepTime) + " ms. Check server availability!";
    sendLog(sleepMsg, "error");
    ledcWrite(FLASH_PWM_CHANNEL, 0);
    esp_sleep_enable_timer_wakeup(sleepTime);
    esp_deep_sleep_start();
  }

  if (!isConnected) {
    connectWebSocket();
    delay(reconnectDelay);
    return;
  }

  // بررسی حافظه - بهبود یافته با مدیریت real-time
  size_t freeMemory = heap_caps_get_free_size(MALLOC_CAP_8BIT);
  if (freeMemory < 30000) {  // افزایش threshold برای ثبات بیشتر
    sendLog("Low memory! Skipping frame", "warning");
    frameErrorCount++;
    if (frameErrorCount >= maxFrameErrors) {
      sendLog("Critical: Persistent low memory - restarting camera...", "error");
      client.send("{\"type\":\"system_error\",\"message\":\"Critical low memory - restarting camera\"}");
      restartCamera();
      frameErrorCount = 0;
      // تاخیر بیشتر بعد از restart
      delay(1000);  // افزایش delay برای ثبات بیشتر
    }
    delay(100);  // افزایش delay برای real-time بهتر
    return;
  } else {
    frameErrorCount = 0;
  }
  
  // بررسی حافظه بحرانی
  if (freeMemory < 15000) {
    sendLog("Critical memory! Emergency cleanup", "error");
    client.send("{\"type\":\"system_error\",\"message\":\"Critical memory - emergency cleanup\"}");
    // اجرای garbage collection اجباری
    ESP.getMinFreeHeap();
    delay(500);
    return;
  }
  
  // بررسی حافظه اضافی برای جلوگیری از memory leaks
  static unsigned long lastMemoryCheck = 0;
  if (millis() - lastMemoryCheck > 20000) { // هر 20 ثانیه - افزایش فرکانس
    lastMemoryCheck = millis();
    try {
      size_t freeMemory = heap_caps_get_free_size(MALLOC_CAP_8BIT);
      if (freeMemory < 60000) {  // افزایش threshold
        sendLog("Memory cleanup needed", "warning");
        // اجرای garbage collection
        ESP.getMinFreeHeap();
        // پاکسازی اضافی
        if (freeMemory < 40000) {
          sendLog("Critical memory cleanup", "error");
          // تلاش برای آزاد کردن حافظه بیشتر
          delay(100);
        }
      }
      
      // بررسی fragmentation حافظه
      size_t largestFreeBlock = heap_caps_get_largest_free_block(MALLOC_CAP_8BIT);
      if (largestFreeBlock < 10000) {
        sendLog("Memory fragmentation detected", "warning");
        client.send("{\"type\":\"system_warning\",\"message\":\"Memory fragmentation detected\"}");
      }
      
    } catch (...) {
      sendLog("Memory check error", "error");
    }
  }
  
  // بررسی تعداد خطاهای دوربین
  if (cameraErrorCount > 10) {
    sendLog("Too many camera errors - restarting camera...", "error");
    client.send("{\"type\":\"system_error\",\"message\":\"Too many camera errors - restarting camera\"}");
    restartCamera();
    cameraErrorCount = 0;
    delay(500);
    return;
  }
  
  // بررسی خطاهای سیستم
  static unsigned long lastSystemCheck = 0;
  if (millis() - lastSystemCheck > 60000) { // هر دقیقه
    lastSystemCheck = millis();
    
    // بررسی حافظه آزاد
    size_t freeHeap = ESP.getFreeHeap();
    if (freeHeap < 50000) {
      sendLog("Low heap memory detected", "warning");
      client.send("{\"type\":\"system_warning\",\"message\":\"Low heap memory\"}");
    }
    
    // بررسی کیفیت سیگنال WiFi
    int32_t rssi = WiFi.RSSI();
    if (rssi < -85) {
      sendLog("Weak WiFi signal detected", "warning");
      client.send("{\"type\":\"system_warning\",\"message\":\"Weak WiFi signal\"}");
    }
    
    // بررسی uptime سیستم
    unsigned long uptime = millis() / 1000; // به ثانیه
    if (uptime > 86400) { // بیشتر از 24 ساعت
      sendLog("System uptime: " + String(uptime / 3600) + " hours", "info");
    }
    
    // بررسی تعداد خطاهای دوربین
    if (cameraErrorCount > 5) {
      sendLog("High camera error count: " + String(cameraErrorCount), "warning");
      client.send("{\"type\":\"system_warning\",\"message\":\"High camera error count\"}");
    }
  }
  
  // بررسی وضعیت WiFi
  if (WiFi.status() != WL_CONNECTED) {
    sendLog("WiFi disconnected - attempting reconnect...", "warning");
    WiFi.reconnect();
    delay(1000);
    if (WiFi.status() != WL_CONNECTED) {
      sendLog("WiFi reconnect failed - entering deep sleep...", "error");
      client.send("{\"type\":\"system_error\",\"message\":\"WiFi connection lost - entering deep sleep\"}");
      deepSleepCount++;
      unsigned long sleepTime = (deepSleepCount > maxDeepSleepCount) ? 60000000 : 30000000;
      ledcWrite(FLASH_PWM_CHANNEL, 0);
      esp_sleep_enable_timer_wakeup(sleepTime);
      esp_deep_sleep_start();
    }
  }

  // تنظیم نوردهی و فلاش
  unsigned long frameDuration = 66;
  if (millis() - lastAecAdjustTime >= aecAdjustInterval) {
    sensor_t *s = esp_camera_sensor_get();
    adjustExposure(s, frameDuration);
    lastAecAdjustTime = millis();
  }

  // گرفتن فریم
  camera_fb_t* fb = esp_camera_fb_get();
  if (!fb) {
    sendLog("Camera capture failed", "error");
    cameraErrorCount++;
    frameErrorCount++;
    if (frameErrorCount >= maxFrameErrors) {
      sendLog("Max frame errors reached, restarting camera...", "error");
      client.send("{\"type\":\"system_error\",\"message\":\"Max frame errors reached - restarting camera\"}");
      restartCamera();
      frameErrorCount = 0;
      cameraErrorCount = 0;
      delay(500);
    }
    return;
  } else {
    frameErrorCount = 0;
    cameraErrorCount = 0;  // ریست کردن شمارنده خطا در صورت موفقیت
  }
  
  // بررسی کیفیت فریم
  if (fb->len < 1000) {
    sendLog("Invalid frame size detected", "warning");
    esp_camera_fb_return(fb);
    frameErrorCount++;
    if (frameErrorCount >= maxFrameErrors) {
      sendLog("Too many invalid frames, restarting camera...", "error");
      client.send("{\"type\":\"system_error\",\"message\":\"Too many invalid frames - restarting camera\"}");
      restartCamera();
      frameErrorCount = 0;
      delay(500);
    }
    return;
  }
  // ذخیره آخرین فریم برای عکس دستی
  if (last_captured_fb) {
    esp_camera_fb_return(last_captured_fb);
    last_captured_fb = nullptr;
  }
  last_captured_fb = fb;

  // ارسال فریم (فقط اگر در حالت عکس دستی نیستیم)
  if (isConnected && !isManualPhotoMode) {
    bool sent = client.sendBinary((const char*)fb->buf, fb->len);
    if (!sent) {
      sendLog("Failed to send frame", "error");
    } else if (millis() - lastLogTime >= logInterval) {
      String msg = "Sent frame of size " + String(fb->len) + " bytes";
      sendLog(msg, "info");
    }
  } else if (isManualPhotoMode) {
    sendLog("Skipping frame during manual photo mode", "info");
  }

  // آزادسازی حافظه فریم
  if (fb) {
    esp_camera_fb_return(fb);
    fb = nullptr;
  }

  // محاسبه FPS
  frameCount++;
  unsigned long currentTime = millis();
  if (currentTime - lastFrameTime >= 1000) {
    fps = frameCount * 1000.0 / (currentTime - lastFrameTime);
    if (millis() - lastLogTime >= logInterval) {
      String msg = "FPS: " + String(fps, 2);
      sendLog(msg, "info");
      lastLogTime = millis();
    }
    frameCount = 0;
    lastFrameTime = currentTime;
  }

  // کنترل نرخ فریم با بهینه‌سازی real-time
  unsigned long elapsed = millis() - currentTime;
  unsigned long targetDelay = frameDuration - elapsed;
  
  // بهینه‌سازی delay برای real-time بهتر
  if (targetDelay > 0 && targetDelay < 100) {  // فقط delay کوتاه
    delay(targetDelay);
  } else if (targetDelay >= 100) {
    // برای delay طولانی، از yield استفاده کن
    unsigned long startTime = millis();
    while (millis() - startTime < targetDelay) {
      yield();  // اجازه بده به سایر taskها برسد
      if (millis() - startTime >= targetDelay) break;
    }
  }
}