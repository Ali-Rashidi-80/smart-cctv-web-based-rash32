import network, time, uos, gc, math, ujson
import uasyncio as asyncio
from machine import Pin, PWM, reset
import client as ws_client

# ================================
# تنظیمات سرور و پورت
# ================================
WS_URL = "ws://services.gen6.chabokan.net:26852/ws/pico"  # آدرس IP کامپیوتر سرور

# ================================
# تنظیمات احراز هویت
# ================================
AUTH_TOKEN = "m78jmdzu:2G/O\\S'W]_E]"  # توکن احراز هویت
AUTH_HEADER = f"Authorization: Bearer {AUTH_TOKEN}"

# ================================
# اتصال به WiFi
# ================================
WIFI_CONFIGS = [
    {"ssid": "SAMSUNG", "password": "panzer790"},
    {"ssid": "Galaxy_A25_5G", "password": "88888888"}
]
ERROR_THRESHOLD = 5
MAX_WS_ERRORS = 5
error_counter = 0
ws_error_count = 0
LOG_INTERVAL = 60
last_log_time = 0
last_pong = 0
global_pico_last_seen = 0
sent_error_messages = set()

# ================================
# تنظیمات سروو
# ================================
SERVO1_PIN = 17
SERVO2_PIN = 16
SERVO1_FILE = "servo1.json"
SERVO2_FILE = "servo2.json"

# ================================
# متغیرهای سراسری
# ================================
current_angle1 = 90
current_angle2 = 90
servo1 = None
servo2 = None

# ================================
# توابع کمکی
# ================================
def get_now_str():
    """دریافت زمان فعلی به صورت رشته"""
    try:
        import time
        return time.strftime("%Y-%m-%d %H:%M:%S")
    except:
        return "unknown"

def append_error_log(error_data):
    """ثبت خطا در فایل"""
    try:
        with open("error_log.json", "a") as f:
            f.write(ujson.dumps(error_data) + "\n")
    except:
        pass

def send_log(ws, message, level="info"):
    """ارسال لاگ به سرور"""
    try:
        log_message = {
            "type": "log",
            "message": message,
            "level": level,
            "timestamp": get_now_str()
        }
        ws.send(ujson.dumps(log_message))
    except Exception as e:
        print(f"⚠️ خطا در ارسال لاگ: {e}")

def send_ack(ws, command_type, status="success", detail=""):
    """ارسال تایید به سرور"""
    try:
        ack_message = {
            "type": "ack",
            "command_type": command_type,
            "status": status,
            "detail": detail,
            "timestamp": get_now_str()
        }
        ws.send(ujson.dumps(ack_message))
    except Exception as e:
        print(f"⚠️ خطا در ارسال ACK: {e}")

# ================================
# کلاس کنترل سروو
# ================================
class ServoController:
    def __init__(self, pin_num, angle_file):
        self.pin = PWM(Pin(pin_num))
        self.pin.freq(50)
        self.angle_file = angle_file
        self.current_angle = self.load_angle()
        self.set_angle(self.current_angle, self.current_angle, immediate=True)
    
    def save_angle(self, angle):
        try:
            with open(self.angle_file, 'w') as f:
                ujson.dump({"angle": angle}, f)
        except Exception as e:
            print(f"⚠️ خطا در ذخیره زاویه: {e}")
    
    def load_angle(self):
        try:
            with open(self.angle_file, 'r') as f:
                data = ujson.load(f)
                return data.get("angle", 90)
        except:
            return 90
    
    def angle_to_duty(self, angle):
        """تبدیل زاویه به duty cycle"""
        return int(500 + (angle / 180) * 2000)
    
    async def set_angle(self, current, target, immediate=False):
        """تنظیم زاویه سروو"""
        if immediate:
            duty = self.angle_to_duty(target)
            self.pin.duty_u16(duty * 65535 // 20000)
            self.current_angle = target
            self.save_angle(target)
            print(f"🎯 سروو {self.pin} به زاویه {target}° تنظیم شد")
            return target
        
        # حرکت تدریجی با پاکسازی حافظه
        step = 1 if target > current else -1
        for angle in range(current, target + step, step):
            duty = self.angle_to_duty(angle)
            self.pin.duty_u16(duty * 65535 // 20000)
            await asyncio.sleep(0.01)  # 10ms delay
            
            # پاکسازی حافظه هر 10 مرحله
            if (angle - current) % 10 == 0:
                gc.collect()
        
        self.current_angle = target
        self.save_angle(target)
        print(f"🎯 سروو {self.pin} به زاویه {target}° تنظیم شد")
        return target

# ================================
# اتصال WiFi
# ================================
async def connect_wifi():
    """اتصال به WiFi"""
    global error_counter
    
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    
    for config in WIFI_CONFIGS:
        try:
            print(f"🔗 تلاش برای اتصال به {config['ssid']}...")
            wlan.connect(config['ssid'], config['password'])
            
            # انتظار برای اتصال
            max_wait = 10
            while max_wait > 0:
                if wlan.isconnected():
                    print(f"✅ اتصال WiFi موفق: {config['ssid']}")
                    print(f"📡 IP: {wlan.ifconfig()[0]}")
                    error_counter = 0
                    return True
                max_wait -= 1
                await asyncio.sleep(1)
            
            print(f"❌ اتصال به {config['ssid']} ناموفق")
            
        except Exception as e:
            print(f"⚠️ خطا در اتصال به {config['ssid']}: {e}")
            error_counter += 1
    
    print("❌ اتصال به هیچ شبکه‌ای موفق نبود")
    error_counter += 1
    
    if error_counter >= ERROR_THRESHOLD:
        print("🔄 ریست سیستم به دلیل خطاهای مکرر...")
        await asyncio.sleep(2)
        reset()
    
    return False

# ================================
# ریست سیستم
# ================================
async def do_reboot():
    """ریست سیستم"""
    print("🔄 ریست سیستم در حال انجام...")
    send_log(None, "System reboot initiated", "warning")
    await asyncio.sleep(2)
    reset()

# ================================
# پردازش دستورات
# ================================
async def process_command(cmd, ws=None):
    """پردازش دستورات دریافتی"""
    global current_angle1, current_angle2
    
    try:
        # پاکسازی حافظه قبل از پردازش
        gc.collect()
        
        print(f"📥 دریافت دستور: {cmd}")
        
        cmd_type = cmd.get('type')
        if cmd_type == 'pong':
            print("دریافت پیام pong")
            last_pong = time.time()
            return
        if cmd_type == 'ping':
            print("دریافت پیام ping از سرور، ارسال pong...")
            if ws:
                try:
                    ws.send(ujson.dumps({"type": "pong"}))
                except Exception as e:
                    print(f"⚠️ خطا در ارسال pong: {e}")
            return
        if cmd_type == 'ack':
            print(f"دریافت پیام ack: {cmd}")
            return
        if not cmd_type or cmd_type == '':
            print("پیام خالی دریافت شد، نادیده گرفته شد")
            return
        if cmd_type == 'status':
            print("دریافت پیام status، نادیده گرفته شد")
            if ws:
                send_ack(ws, 'status', status='received')
            return
        if cmd_type == 'servo':
            servo_data = cmd.get('command', cmd)  # Support both formats
            servo1_target = int(servo_data.get('servo1', 90))
            servo2_target = int(servo_data.get('servo2', 90))
            
            # اعتبارسنجی زاویه‌ها
            servo1_target = max(0, min(180, servo1_target))
            servo2_target = max(0, min(180, servo2_target))
            
            if servo1_target == current_angle1 and servo2_target == current_angle2:
                print(f"دستور تکراری سروو دریافت شد (servo1={servo1_target}, servo2={servo2_target})، نادیده گرفته شد.")
                if ws:
                    send_ack(ws, 'servo', status='ignored', detail='Duplicate command')
                return
                
            print(f"🎯 دریافت دستور سروو: servo1 = {servo1_target}°, servo2 = {servo2_target}°")
            
            # اجرای دستور سروو
            if servo1 and servo2:
                try:
                    current_angle1 = await servo1.set_angle(current_angle1, servo1_target)
                    current_angle2 = await servo2.set_angle(current_angle2, servo2_target)
                    print(f"✅ دستور سروو اجرا شد: X={current_angle1}°, Y={current_angle2}°")
                    
                    if ws:
                        send_ack(ws, 'servo', status='success', detail=f'X={current_angle1}°, Y={current_angle2}°')
                        
                except Exception as e:
                    print(f"❌ خطا در اجرای دستور سروو: {e}")
                    if ws:
                        send_ack(ws, 'servo', status='error', detail=str(e))
            else:
                print("❌ سرووها آماده نیستند")
                if ws:
                    send_ack(ws, 'servo', status='error', detail='Servos not initialized')
                    
        elif cmd_type == 'action':
            action_data = cmd.get('command', {})
            action = action_data.get('action', '')
            intensity = int(action_data.get('intensity', 50))
            print(f"🎯 دریافت دستور عملیاتی: action={action}, intensity={intensity}")
            
            if action == 'reset_position':
                if servo1 and servo2:
                    try:
                        await servo1.set_angle(current_angle1, 90, immediate=True)
                        await servo2.set_angle(current_angle2, 90, immediate=True)
                        current_angle1 = 90
                        current_angle2 = 90
                        print("✅ سرووها به موقعیت مرکزی بازگشتند")
                        if ws:
                            send_ack(ws, 'action', status='success', detail='Reset to center position')
                    except Exception as e:
                        print(f"❌ خطا در reset position: {e}")
                        if ws:
                            send_ack(ws, 'action', status='error', detail=str(e))
            elif action == 'emergency_stop':
                if servo1 and servo2:
                    try:
                        await servo1.set_angle(current_angle1, current_angle1, immediate=True)
                        await servo2.set_angle(current_angle2, current_angle2, immediate=True)
                        print("🛑 توقف اضطراری سرووها")
                        if ws:
                            send_ack(ws, 'action', status='success', detail='Emergency stop executed')
                    except Exception as e:
                        print(f"❌ خطا در emergency stop: {e}")
                        if ws:
                            send_ack(ws, 'action', status='error', detail=str(e))
            elif action == 'system_reboot':
                print("🔄 دریافت دستور ریست سخت‌افزاری از سرور!")
                send_log(ws, "System reboot command received from server", "warning")
                asyncio.create_task(do_reboot())
            else:
                print(f"❌ عملیات ناشناخته: {action}")
                if ws:
                    send_ack(ws, 'action', status='error', detail=f'Unknown action: {action}')
            
        elif cmd_type == 'command':
            # Handle legacy 'command' type
            command_data = cmd.get('command', {})
            if 'servo1' in command_data or 'servo2' in command_data:
                servo1_target = int(command_data.get('servo1', 90))
                servo2_target = int(command_data.get('servo2', 90))
                
                # اعتبارسنجی زاویه‌ها
                servo1_target = max(0, min(180, servo1_target))
                servo2_target = max(0, min(180, servo2_target))
                
                print(f"🎯 دریافت دستور command (servo): servo1 = {servo1_target}°, servo2 = {servo2_target}°")
                
                if servo1 and servo2:
                    try:
                        current_angle1 = await servo1.set_angle(current_angle1, servo1_target)
                        current_angle2 = await servo2.set_angle(current_angle2, servo2_target)
                        print(f"✅ دستور command اجرا شد: X={current_angle1}°, Y={current_angle2}°")
                        if ws:
                            send_ack(ws, 'command', status='success', detail='Processed as servo command')
                    except Exception as e:
                        print(f"❌ خطا در اجرای command: {e}")
                        if ws:
                            send_ack(ws, 'command', status='error', detail=str(e))
                else:
                    if ws:
                        send_ack(ws, 'command', status='error', detail='Servos not initialized')
                        
            elif 'action' in command_data:
                action = command_data.get('action', '')
                intensity = int(command_data.get('intensity', 50))
                print(f"🎯 دریافت دستور command (action): action={action}, intensity={intensity}")
                
                if action == 'reset_position':
                    if servo1 and servo2:
                        try:
                            await servo1.set_angle(current_angle1, 90, immediate=True)
                            await servo2.set_angle(current_angle2, 90, immediate=True)
                            current_angle1 = 90
                            current_angle2 = 90
                            print("✅ سرووها به موقعیت مرکزی بازگشتند")
                            if ws:
                                send_ack(ws, 'command', status='success', detail='Reset to center position')
                        except Exception as e:
                            print(f"❌ خطا در reset position: {e}")
                            if ws:
                                send_ack(ws, 'command', status='error', detail=str(e))
                elif action == 'emergency_stop':
                    if servo1 and servo2:
                        try:
                            await servo1.set_angle(current_angle1, current_angle1, immediate=True)
                            await servo2.set_angle(current_angle2, current_angle2, immediate=True)
                            print("🛑 توقف اضطراری سرووها")
                            if ws:
                                send_ack(ws, 'command', status='success', detail='Emergency stop executed')
                        except Exception as e:
                            print(f"❌ خطا در emergency stop: {e}")
                            if ws:
                                send_ack(ws, 'command', status='error', detail=str(e))
                elif action == 'system_reboot':
                    print("🔄 دریافت دستور ریست سخت‌افزاری از سرور!")
                    send_log(ws, "System reboot command received from server", "warning")
                    asyncio.create_task(do_reboot())
                else:
                    print(f"❌ عملیات ناشناخته: {action}")
                    if ws:
                        send_ack(ws, 'command', status='error', detail=f'Unknown action: {action}')
            else:
                print(f"❌ پیام command نامعتبر: {cmd}")
                if ws:
                    send_ack(ws, 'command', status='ignored', detail='Invalid command format')
        else:
            print(f"❌ پیام ناشناخته: {cmd}")
            if ws:
                send_ack(ws, 'unknown', status='ignored', detail=str(cmd))
                
    except Exception as e:
        print(f"❌ خطا در پردازش دستور: {e}")
        if ws:
            send_ack(ws, 'error', status='error', detail=str(e))

# ================================
# WebSocket Client
# ================================
async def websocket_client():
    global error_counter, global_pico_last_seen, ws_error_count, WS_URL, last_pong
    reconnect_attempt = 0
    ws = None
    
    while True:
        try:
            # پاکسازی حافظه قبل از اتصال
            gc.collect()
            
            print(f"🔗 تلاش برای اتصال به WebSocket: {WS_URL}")
            print(f"🔑 استفاده از توکن: {AUTH_TOKEN[:10]}...")
            
            # اتصال به WebSocket با احراز هویت
            ws = ws_client.connect(WS_URL, headers=[AUTH_HEADER])
            
            if ws:
                print("✅ اتصال WebSocket موفق")
                ws_error_count = 0
                reconnect_attempt = 0
                global_pico_last_seen = time.time()
                
                # ارسال پیام اولیه
                initial_message = {
                    "type": "connect",
                    "device": "pico",
                    "timestamp": get_now_str(),
                    "version": "1.0",
                    "servo1_angle": current_angle1,
                    "servo2_angle": current_angle2,
                    "auth_token": AUTH_TOKEN[:10] + "..."
                }
                ws.send(ujson.dumps(initial_message))
                print("📤 پیام اولیه ارسال شد")
                
                # حلقه اصلی WebSocket
                message_count = 0
                last_activity = time.time()
                last_ping = time.time()
                
                while True:
                    try:
                        current_time = time.time()
                        
                        # بررسی timeout اتصال
                        if current_time - last_activity > 30:  # 30 ثانیه timeout
                            print("⏰ timeout اتصال، تلاش مجدد...")
                            break
                        
                        # ارسال ping هر 15 ثانیه
                        if current_time - last_ping > 15:
                            try:
                                ping_message = {"type": "ping", "timestamp": get_now_str()}
                                ws.send(ujson.dumps(ping_message))
                                last_ping = current_time
                                print("📤 ping ارسال شد")
                            except Exception as e:
                                print(f"⚠️ خطا در ارسال ping: {e}")
                                break
                        
                        # پاکسازی حافظه هر 10 پیام
                        if message_count % 10 == 0:
                            gc.collect()
                        
                        message = ws.recv()
                        if message:
                            last_activity = current_time
                            global_pico_last_seen = current_time
                            message_count += 1
                            data = ujson.loads(message)
                            await process_command(data, ws)
                        
                        # انتظار کوتاه‌تر
                        await asyncio.sleep(0.005)  # 5ms delay
                        
                    except Exception as e:
                        print(f"⚠️ خطا در دریافت پیام: {e}")
                        break
                        
            else:
                print("❌ اتصال WebSocket ناموفق")
                ws_error_count += 1
                
        except Exception as e:
            print(f"❌ خطا در WebSocket client: {e}")
            ws_error_count += 1
            error_counter += 1
            
            # ثبت خطا
            append_error_log({
                "type": "websocket_error",
                "error": str(e),
                "timestamp": get_now_str(),
                "ws_error_count": ws_error_count,
                "error_counter": error_counter
            })
            
            # بررسی تعداد خطاها
            if ws_error_count >= MAX_WS_ERRORS:
                print(f"❌ تعداد خطاهای WebSocket به حد مجاز رسید ({MAX_WS_ERRORS})")
                if error_counter >= ERROR_THRESHOLD:
                    print("🔄 ریست سیستم به دلیل خطاهای مکرر...")
                    await asyncio.sleep(2)
                    reset()
                else:
                    print("⏰ انتظار طولانی‌تر قبل از تلاش مجدد...")
                    await asyncio.sleep(30)
                    ws_error_count = 0
            else:
                # انتظار تدریجی
                reconnect_delay = min(5 * (reconnect_attempt + 1), 30)
                print(f"⏰ انتظار {reconnect_delay} ثانیه قبل از تلاش مجدد...")
                await asyncio.sleep(reconnect_delay)
                reconnect_attempt += 1

# ================================
# تابع اصلی
# ================================
async def main():
    global servo1, servo2, current_angle1, current_angle2
    
    print("🚀 راه‌اندازی سیستم پیکو...")
    
    # پاکسازی حافظه اولیه
    gc.collect()
    print(f"💾 حافظه آزاد: {gc.mem_free()} bytes")
    
    # راه‌اندازی سرووها
    try:
        servo1 = ServoController(SERVO1_PIN, SERVO1_FILE)
        servo2 = ServoController(SERVO2_PIN, SERVO2_FILE)
        current_angle1 = servo1.current_angle
        current_angle2 = servo2.current_angle
        print(f"✅ سرووها راه‌اندازی شدند: X={current_angle1}°, Y={current_angle2}°")
    except Exception as e:
        print(f"❌ خطا در راه‌اندازی سرووها: {e}")
    
    # اتصال به WiFi
    wlan = network.WLAN(network.STA_IF)
    while not wlan.isconnected():
        await connect_wifi()
    
    print("🌐 اتصال WiFi برقرار شد")
    print(f"💾 حافظه آزاد بعد از WiFi: {gc.mem_free()} bytes")
    
    # شروع WebSocket client
    print("🌐 شروع WebSocket client...")
    try:
        await websocket_client()
    except Exception as e:
        print(f"❌ خطا در WebSocket client: {e}")
        append_error_log({
            "type": "log",
            "level": "error",
            "message": f"WebSocket client error: {e}",
            "timestamp": get_now_str()
        })
        await asyncio.sleep(5)

# ================================
# اجرای برنامه
# ================================
if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n🛑 برنامه توسط کاربر متوقف شد")
    except Exception as e:
        print(f"❌ خطای غیرمنتظره: {e}")
        append_error_log({
            "type": "fatal_error",
            "error": str(e),
            "timestamp": get_now_str()
        })
        reset()
